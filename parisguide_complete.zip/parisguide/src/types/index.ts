export type Json = string | number | boolean | null | { [key: string]: Json } | Json[];

export interface Database {
  public: {
    Tables: {
      profiles: {
        Row: { id: string; full_name: string | null; avatar_url: string | null; created_at: string };
        Insert: { id: string; full_name?: string | null; avatar_url?: string | null };
        Update: { full_name?: string | null; avatar_url?: string | null };
      };
      expenses: {
        Row: { id: string; user_id: string; label: string; amount: number; category: string; created_at: string };
        Insert: { user_id: string; label: string; amount: number; category?: string };
        Update: { label?: string; amount?: number; category?: string };
      };
      commute_routes: {
        Row: { id: string; user_id: string; from_label: string; from_id: string | null; to_label: string; to_id: string | null; created_at: string };
        Insert: { user_id: string; from_label: string; from_id?: string; to_label: string; to_id?: string };
        Update: never;
      };
      favourite_pois: {
        Row: { id: string; user_id: string; poi_id: string; poi_name: string; lat: number | null; lng: number | null; created_at: string };
        Insert: { user_id: string; poi_id: string; poi_name: string; lat?: number; lng?: number };
        Update: never;
      };
      quest_badges: {
        Row: { id: string; user_id: string; badge_id: string; badge_name: string | null; rarity: string; xp: number; category: string | null; earned_at: string };
        Insert: { user_id: string; badge_id: string; badge_name?: string; rarity?: string; xp?: number; category?: string };
        Update: never;
      };
      chat_messages: {
        Row: { id: string; user_id: string; role: 'user' | 'assistant'; content: string; created_at: string };
        Insert: { user_id: string; role: 'user' | 'assistant'; content: string };
        Update: never;
      };
    };
  };
}

// App types
export interface Expense {
  id: string;
  label: string;
  amount: number;
  category: 'food' | 'café' | 'ticket' | 'other';
  created_at: string;
}

export interface CommuteRoute {
  id: string;
  from_label: string;
  from_id: string | null;
  to_label: string;
  to_id: string | null;
  created_at: string;
}

export interface QuestBadge {
  id: string;
  badge_id: string;
  badge_name: string | null;
  rarity: 'common' | 'rare' | 'legendary';
  xp: number;
  category: string | null;
  earned_at: string;
}

export interface ParisPOI {
  id: string;
  name: string;
  emoji: string;
  category: 'landmark' | 'culture' | 'neighborhood' | 'nature' | 'idf' | 'food';
  lat: number;
  lng: number;
  color: string;
  tagline: string;
  neighborhood: string;
  photo: string;
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  created_at: string;
}

export interface BadgeCatalogItem {
  badge_id: string;
  emoji: string;
  name: string;
  description: string;
  category: string;
  rarity: 'common' | 'rare' | 'legendary';
  keywords: string[];
}
