'use client';
import { createContext, useContext, useEffect, useState, useCallback } from 'react';
import { type LangCode, LANGUAGES, translations, t as tFn } from './translations';

// ─── Settings types ──────────────────────────────────────────────────────────
export type Theme = 'dark' | 'light' | 'system';
export type TextSize = 'small' | 'medium' | 'large';

export interface AppSettings {
  theme: Theme;
  textSize: TextSize;
  highContrast: boolean;
  reduceMotion: boolean;
  notificationsEnabled: boolean;
  notifAdmin: boolean;
  notifTips: boolean;
  notifTransport: boolean;
  notifQuest: boolean;
  analyticsEnabled: boolean;
  locationEnabled: boolean;
  offlineMode: boolean;
}

const DEFAULT_SETTINGS: AppSettings = {
  theme: 'dark',
  textSize: 'medium',
  highContrast: false,
  reduceMotion: false,
  notificationsEnabled: true,
  notifAdmin: true,
  notifTips: true,
  notifTransport: false,
  notifQuest: true,
  analyticsEnabled: false,
  locationEnabled: true,
  offlineMode: false,
};

// ─── Context shape ───────────────────────────────────────────────────────────
interface AppContextValue {
  lang: LangCode;
  setLang: (l: LangCode) => void;
  t: (obj: { [K in LangCode]: string }) => string;
  isRTL: boolean;
  dir: 'ltr' | 'rtl';
  settings: AppSettings;
  updateSetting: <K extends keyof AppSettings>(key: K, value: AppSettings[K]) => void;
  hasChosenLang: boolean;
  confirmLang: () => void;
}

const AppContext = createContext<AppContextValue>({
  lang: 'en',
  setLang: () => {},
  t: (obj) => obj['en'],
  isRTL: false,
  dir: 'ltr',
  settings: DEFAULT_SETTINGS,
  updateSetting: () => {},
  hasChosenLang: false,
  confirmLang: () => {},
});

// ─── CSS variable injection for text size & contrast ────────────────────────
function applySettings(settings: AppSettings) {
  const root = document.documentElement;
  const sizeMap = { small: '13px', medium: '15px', large: '17px' };
  root.style.setProperty('--app-font-size', sizeMap[settings.textSize]);
  root.style.setProperty('--app-contrast', settings.highContrast ? '1' : '0');
  if (settings.reduceMotion) {
    root.style.setProperty('--app-motion', '0');
  } else {
    root.style.removeProperty('--app-motion');
  }
}

// ─── Provider ────────────────────────────────────────────────────────────────
export function LanguageProvider({ children }: { children: React.ReactNode }) {
  const [lang, setLangState] = useState<LangCode>('en');
  const [hasChosenLang, setHasChosenLang] = useState(false);
  const [settings, setSettings] = useState<AppSettings>(DEFAULT_SETTINGS);

  // Load everything from localStorage on mount
  useEffect(() => {
    const storedLang = localStorage.getItem('paris_lang') as LangCode | null;
    const storedChosen = localStorage.getItem('paris_lang_chosen');
    const storedSettings = localStorage.getItem('paris_settings');

    if (storedLang && LANGUAGES.find(l => l.code === storedLang)) {
      setLangState(storedLang);
    }
    if (storedChosen === '1') {
      setHasChosenLang(true);
    }
    if (storedSettings) {
      try {
        const parsed = JSON.parse(storedSettings) as Partial<AppSettings>;
        setSettings(prev => ({ ...prev, ...parsed }));
      } catch {}
    }
  }, []);

  // Apply RTL + lang attr to <html>
  useEffect(() => {
    const langDef = LANGUAGES.find(l => l.code === lang);
    const isRTL = langDef?.rtl ?? false;
    document.documentElement.setAttribute('lang', lang);
    document.documentElement.setAttribute('dir', isRTL ? 'rtl' : 'ltr');
  }, [lang]);

  // Apply CSS settings
  useEffect(() => {
    applySettings(settings);
  }, [settings]);

  const setLang = useCallback((l: LangCode) => {
    localStorage.setItem('paris_lang', l);
    setLangState(l);
  }, []);

  const confirmLang = useCallback(() => {
    localStorage.setItem('paris_lang_chosen', '1');
    setHasChosenLang(true);
  }, []);

  const updateSetting = useCallback(<K extends keyof AppSettings>(key: K, value: AppSettings[K]) => {
    setSettings(prev => {
      const next = { ...prev, [key]: value };
      localStorage.setItem('paris_settings', JSON.stringify(next));
      return next;
    });
  }, []);

  const langDef = LANGUAGES.find(l => l.code === lang);
  const isRTL = langDef?.rtl ?? false;
  const t = (obj: { [K in LangCode]: string }) => tFn(obj, lang);

  return (
    <AppContext.Provider value={{
      lang, setLang, t, isRTL, dir: isRTL ? 'rtl' : 'ltr',
      settings, updateSetting,
      hasChosenLang, confirmLang,
    }}>
      {children}
    </AppContext.Provider>
  );
}

// ─── Hooks ───────────────────────────────────────────────────────────────────
export function useLanguage() {
  return useContext(AppContext);
}
export function useSettings() {
  const ctx = useContext(AppContext);
  return { settings: ctx.settings, updateSetting: ctx.updateSetting };
}

// Re-exports
export { translations, LANGUAGES };
