// ─── Language definitions ────────────────────────────────────────────────────
export type LangCode = 'en' | 'fr' | 'ar' | 'pt' | 'zh' | 'hi';

export const LANGUAGES: { code: LangCode; label: string; flag: string; rtl?: boolean; native: string }[] = [
  { code: 'en', label: 'English',    flag: '🇬🇧', native: 'English'   },
  { code: 'fr', label: 'French',     flag: '🇫🇷', native: 'Français'  },
  { code: 'ar', label: 'Arabic',     flag: '🇸🇦', native: 'العربية',  rtl: true },
  { code: 'pt', label: 'Portuguese', flag: '🇧🇷', native: 'Português' },
  { code: 'zh', label: 'Mandarin',   flag: '🇨🇳', native: '中文'      },
  { code: 'hi', label: 'Hindi',      flag: '🇮🇳', native: 'हिन्दी'   },
];

// ─── Shorthand type ──────────────────────────────────────────────────────────
type T = { en: string; fr: string; ar: string; pt: string; zh: string; hi: string };

// ─── Translation dictionary ──────────────────────────────────────────────────
export const translations = {

  // ── Navigation ─────────────────────────────────────────────────────────────
  nav: {
    groups: {
      core:     { en: 'Core Tools',        fr: 'Outils Essentiels',   ar: 'الأدوات الأساسية',   pt: 'Ferramentas Principais', zh: '核心工具',   hi: 'मुख्य उपकरण'    } as T,
      settling: { en: 'Settling In',       fr: "S'installer",         ar: 'الاستقرار',          pt: 'Estabelecendo-se',       zh: '安家落户',   hi: 'बसना'           } as T,
      life:     { en: 'Life in Paris',     fr: 'Vie à Paris',         ar: 'الحياة في باريس',    pt: 'Vida em Paris',          zh: '巴黎生活',   hi: 'पेरिस में जीवन'  } as T,
      discover:  { en: 'Discover & Safety', fr: 'Découvrir & Sécurité', ar: 'اكتشاف وأمان',      pt: 'Descobrir & Segurança',  zh: '探索与安全', hi: 'खोजें और सुरक्षा'  } as T,
      parisPlus: { en: 'Paris+ Secrets',    fr: 'Paris+ Secrets',       ar: 'باريس+ أسرار',      pt: 'Segredos Paris+',        zh: '巴黎+秘密',  hi: 'पेरिस+ रहस्य'      } as T,
    },
    items: {
      dashboard:      { en: 'Dashboard',          fr: 'Tableau de bord',   ar: 'لوحة التحكم',              pt: 'Painel',              zh: '仪表板',      hi: 'डैशबोर्ड'         } as T,
      profile:        { en: 'My Profile',          fr: 'Mon Profil',        ar: 'ملفي الشخصي',              pt: 'Meu Perfil',          zh: '我的档案',    hi: 'मेरी प्रोफ़ाइल'   } as T,
      chat:           { en: 'AI Chat',             fr: 'Chat IA',           ar: 'محادثة الذكاء الاصطناعي',  pt: 'Chat IA',             zh: 'AI 聊天',     hi: 'AI चैट'           } as T,
      translate:      { en: 'Translate',           fr: 'Traduction',        ar: 'ترجمة',                    pt: 'Traduzir',            zh: '翻译',        hi: 'अनुवाद'           } as T,
      itinerary:      { en: 'Itinerary',           fr: 'Itinéraire',        ar: 'خط سير',                   pt: 'Itinerário',          zh: '行程',        hi: 'यात्रा कार्यक्रम' } as T,
      explore:        { en: 'Explore',             fr: 'Explorer',          ar: 'استكشاف',                  pt: 'Explorar',            zh: '探索',        hi: 'खोजें'            } as T,
      checklist:      { en: '30-Day Plan',         fr: 'Plan 30 Jours',     ar: 'خطة 30 يومًا',             pt: 'Plano de 30 Dias',    zh: '30天计划',    hi: '30 दिन की योजना' } as T,
      arrival:        { en: 'Arrival Mode',        fr: 'Mode Arrivée',      ar: 'وضع الوصول',               pt: 'Modo de Chegada',     zh: '到达模式',    hi: 'आगमन मोड'         } as T,
      navigo:         { en: 'Navigo',              fr: 'Navigo',            ar: 'نافيغو',                   pt: 'Navigo',              zh: 'Navigo',      hi: 'Navigo'           } as T,
      commute:        { en: 'Commute',             fr: 'Trajet',            ar: 'التنقل',                   pt: 'Deslocamento',        zh: '通勤',        hi: 'आवागमन'           } as T,
      admin:          { en: 'Admin Guide',         fr: 'Guide Admin',       ar: 'دليل الإدارة',             pt: 'Guia Administrativo', zh: '行政指南',    hi: 'प्रशासन गाइड'     } as T,
      housing:        { en: 'Housing',             fr: 'Logement',          ar: 'السكن',                    pt: 'Habitação',           zh: '住房',        hi: 'आवास'             } as T,
      banking:        { en: 'Banking',             fr: 'Banque',            ar: 'البنك',                    pt: 'Banco',               zh: '银行',        hi: 'बैंकिंग'          } as T,
      healthcare:     { en: 'Healthcare',          fr: 'Santé',             ar: 'الرعاية الصحية',           pt: 'Saúde',               zh: '医疗',        hi: 'स्वास्थ्य सेवा'   } as T,
      work:           { en: 'Work & Career',       fr: 'Travail',           ar: 'العمل والمهنة',            pt: 'Trabalho & Carreira', zh: '工作与职业',  hi: 'काम और करियर'     } as T,
      education:      { en: 'Education',           fr: 'Éducation',         ar: 'التعليم',                  pt: 'Educação',            zh: '教育',        hi: 'शिक्षा'           } as T,
      culture:        { en: 'Culture',             fr: 'Culture',           ar: 'الثقافة',                  pt: 'Cultura',             zh: '文化',        hi: 'संस्कृति'         } as T,
      sustainability: { en: 'Eco Life',            fr: 'Éco Vie',           ar: 'حياة صديقة للبيئة',        pt: 'Vida Sustentável',    zh: '环保生活',    hi: 'इको लाइफ'         } as T,
      pets:           { en: 'Pets',                fr: 'Animaux',           ar: 'الحيوانات الأليفة',        pt: 'Animais de Estimação',zh: '宠物',        hi: 'पालतू जानवर'      } as T,
      neighborhoods:  { en: 'Neighbourhoods',      fr: 'Quartiers',         ar: 'الأحياء',                  pt: 'Bairros',             zh: '街区',        hi: 'पड़ोस'            } as T,
      budget:         { en: 'Budget & Meals',      fr: 'Budget & Repas',    ar: 'الميزانية والوجبات',       pt: 'Orçamento & Refeições',zh: '预算与餐饮',  hi: 'बजट और खाना'      } as T,
      seasonal:       { en: 'Seasons & Tips',      fr: 'Saisons & Conseils',ar: 'المواسم والنصائح',         pt: 'Estações & Dicas',    zh: '季节与贴士',  hi: 'मौसम और टिप्स'    } as T,
      legal:          { en: 'Legal & Emergency',   fr: 'Légal & Urgences',  ar: 'القانوني والطوارئ',        pt: 'Legal & Emergências', zh: '法律与紧急',  hi: 'कानूनी और आपातकाल'} as T,
      quest:          { en: 'Trophies',            fr: 'Trophées',          ar: 'الجوائز',                  pt: 'Troféus',             zh: '奖杯',        hi: 'ट्रॉफी'           } as T,
      settings:       { en: 'Settings',            fr: 'Paramètres',        ar: 'الإعدادات',                pt: 'Configurações',       zh: '设置',        hi: 'सेटिंग्स'          } as T,
      fromagePassport:{ en: 'Fromage Passport',    fr: 'Passeport Fromage', ar: 'جواز الجبن',               pt: 'Passaporte de Queijo',zh: '奶酪护照',    hi: 'फ्रोमेज पासपोर्ट'  } as T,
      windowLight:    { en: 'Window Light',         fr: 'Lumière Fenêtres',  ar: 'ضوء النوافذ',              pt: 'Luz das Janelas',     zh: '窗户光线',    hi: 'खिड़की की रोशनी'   } as T,
      pigeonTranslate:{ en: 'Pigeon Translator',   fr: 'Traducteur Pigeon', ar: 'مترجم الحمام',             pt: 'Tradutor Pombo',      zh: '鸽子翻译器',  hi: 'कबूतर अनुवादक'    } as T,
      gentrifyMap:    { en: 'Gentrification Map',  fr: 'Carte Gentrification',ar: 'خريطة التحولات',         pt: 'Mapa Gentrificação',  zh: '士绅化地图',  hi: 'जेंट्रिफिकेशन मैप' } as T,
      streetMusicians:{ en: 'Street Musicians',    fr: 'Musiciens de Rue',  ar: 'موسيقيو الشوارع',          pt: 'Músicos de Rua',      zh: '街头音乐人',  hi: 'सड़क संगीतकार'    } as T,
      rainyDay:       { en: 'Rainy Day Mode',      fr: 'Mode Jour de Pluie',ar: 'وضع يوم الأمطار',          pt: 'Modo Dia Chuvoso',    zh: '雨天模式',    hi: 'बरसाती दिन मोड'   } as T,
      secretParis:    { en: 'Secret Paris',        fr: 'Paris Secret',      ar: 'باريس السرية',             pt: 'Paris Secreta',       zh: '秘密巴黎',    hi: 'गुप्त पेरिस'       } as T,
      morningRitual:  { en: 'Morning Ritual',      fr: 'Rituel du Matin',   ar: 'طقوس الصباح',             pt: 'Ritual Matinal',      zh: '晨间仪式',    hi: 'सुबह की रस्म'     } as T,
      soundscape:     { en: 'Soundscape',          fr: 'Paysage Sonore',    ar: 'المشهد الصوتي',            pt: 'Paisagem Sonora',     zh: '声景',        hi: 'ध्वनि परिदृश्य'   } as T,
      famousGraves:   { en: 'Famous Graves',       fr: 'Tombes Célèbres',   ar: 'القبور المشهورة',          pt: 'Túmulos Famosos',     zh: '名人墓地',    hi: 'प्रसिद्ध कब्रें'  } as T,
    },
  },

  // ── AppShell ────────────────────────────────────────────────────────────────
  shell: {
    rgpd:     { en: '🔒 GDPR compliant · Data protected', fr: '🔒 Conforme RGPD · Données protégées', ar: '🔒 متوافق مع GDPR · البيانات محمية', pt: '🔒 Conforme GDPR · Dados protegidos', zh: '🔒 符合GDPR · 数据受保护', hi: '🔒 GDPR अनुपालन · डेटा सुरक्षित' } as T,
    language: { en: 'Language', fr: 'Langue', ar: 'اللغة', pt: 'Idioma', zh: '语言', hi: 'भाषा' } as T,
  },

  // ── Language gate (first launch screen) ────────────────────────────────────
  langGate: {
    welcome:  { en: 'Welcome to Paris', fr: 'Bienvenue à Paris', ar: 'مرحباً بك في باريس', pt: 'Bem-vindo a Paris', zh: '欢迎来到巴黎', hi: 'पेरिस में आपका स्वागत है' } as T,
    subtitle: { en: 'Choose your preferred language to get started', fr: 'Choisissez votre langue préférée pour commencer', ar: 'اختر لغتك المفضلة للبدء', pt: 'Escolha seu idioma preferido para começar', zh: '选择您的首选语言以开始', hi: 'शुरू करने के लिए अपनी पसंदीदा भाषा चुनें' } as T,
    cta:      { en: 'Continue', fr: 'Continuer', ar: 'متابعة', pt: 'Continuar', zh: '继续', hi: 'जारी रखें' } as T,
    tagline:  { en: 'Your AI companion for Paris & Île-de-France', fr: 'Votre compagnon IA pour Paris & Île-de-France', ar: 'رفيقك الذكي في باريس وإيل-دو-فرانس', pt: 'Seu companheiro de IA para Paris e Île-de-France', zh: '您的巴黎与法兰西岛AI伴侣', hi: 'पेरिस और Île-de-France के लिए आपका AI साथी' } as T,
  },

  // ── Onboarding ──────────────────────────────────────────────────────────────
  onboarding: {
    marcelIntro: { en: "In 2 minutes I'll build you a personalised administrative timeline, recommend the tools you need first, and make sure you never miss an important deadline. Let's go!", fr: "En 2 minutes, je construirai un calendrier personnalisé et recommanderai les outils essentiels. Allons-y!", ar: "في دقيقتين سأبني جدولاً إدارياً شخصياً وأوصي بالأدوات التي تحتاجها. هيا بنا!", pt: "Em 2 minutos vou criar uma linha do tempo e recomendar as ferramentas certas. Vamos lá!", zh: "2分钟内我将为您建立个性化行政时间表并推荐必要工具。开始吧！", hi: "2 मिनट में मैं आपकी व्यक्तिगत योजना बनाऊंगा। चलिए!" } as T,
    loading: {
      title:   { en: 'Marcel is building your plan…', fr: 'Marcel construit votre plan…', ar: 'مارسيل يبني خطتك…', pt: 'Marcel está construindo seu plano…', zh: 'Marcel正在建立您的计划…', hi: 'Marcel आपकी योजना बना रहा है…' } as T,
      subtitle:{ en: 'Generating your personalised Paris timeline 🗼', fr: 'Génération de votre plan Paris personnalisé 🗼', ar: 'جاري إنشاء جدولك في باريس 🗼', pt: 'Gerando sua linha do tempo em Paris 🗼', zh: '正在生成您的个性化巴黎时间表 🗼', hi: 'आपकी पेरिस समयरेखा तैयार हो रही है 🗼' } as T,
    },
    nav: {
      back:     { en: 'Back',     fr: 'Retour',    ar: 'رجوع',   pt: 'Voltar',    zh: '返回', hi: 'वापस'     } as T,
      continue: { en: 'Continue', fr: 'Continuer', ar: 'متابعة', pt: 'Continuar', zh: '继续', hi: 'जारी रखें' } as T,
      finish:   { en: 'Build My Paris Plan', fr: 'Créer Mon Plan Paris', ar: 'بناء خطتي في باريس', pt: 'Criar Meu Plano Paris', zh: '建立我的巴黎计划', hi: 'मेरी पेरिस योजना बनाएं' } as T,
      step:     { en: 'Step', fr: 'Étape', ar: 'خطوة', pt: 'Passo', zh: '步骤', hi: 'चरण' } as T,
      of:       { en: 'of',   fr: 'sur',   ar: 'من',   pt: 'de',    zh: '共',   hi: 'का'   } as T,
    },
    langStep: {
      title:    { en: 'Welcome to Paris 🗼', fr: 'Bienvenue à Paris 🗼', ar: 'مرحباً بك في باريس 🗼', pt: 'Bem-vindo a Paris 🗼', zh: '欢迎来到巴黎 🗼', hi: 'पेरिस में आपका स्वागत है 🗼' } as T,
      subtitle: { en: 'Which language do you prefer?', fr: 'Quelle langue préférez-vous ?', ar: 'أي لغة تفضل؟', pt: 'Qual idioma você prefere?', zh: '您首选哪种语言？', hi: 'आप कौन सी भाषा पसंद करते हैं?' } as T,
    },
    nameStep: {
      subtitle:    { en: "Let's personalise your Paris experience.", fr: 'Personnalisons votre expérience à Paris.', ar: 'لنخصص تجربتك في باريس.', pt: 'Vamos personalizar sua experiência em Paris.', zh: '让我们个性化您的巴黎体验。', hi: 'आपके पेरिस अनुभव को व्यक्तिगत बनाते हैं।' } as T,
      placeholder: { en: 'Your first name…', fr: 'Votre prénom…', ar: 'اسمك الأول…', pt: 'Seu primeiro nome…', zh: '您的名字…', hi: 'आपका पहला नाम…' } as T,
    },
    profileStep: {
      title:    { en: 'What brings you to Paris?', fr: "Qu'est-ce qui vous amène à Paris ?", ar: 'ما الذي يجلبك إلى باريس؟', pt: 'O que te traz a Paris?', zh: '是什么让您来到巴黎？', hi: 'पेरिस में आपका मकसद क्या है?' } as T,
      subtitle: { en: 'This shapes every recommendation I make.', fr: 'Cela oriente chaque recommandation.', ar: 'هذا يشكل كل توصية أقدمها.', pt: 'Isso molda cada recomendação.', zh: '这将影响我的每一项建议。', hi: 'यह मेरी हर सिफारिश को प्रभावित करता है।' } as T,
    },
    visaStep: {
      title:    { en: 'What is your visa situation?', fr: 'Quelle est votre situation de visa ?', ar: 'ما وضع تأشيرتك؟', pt: 'Qual é a sua situação de visto?', zh: '您的签证情况如何？', hi: 'आपकी वीज़ा स्थिति क्या है?' } as T,
      subtitle: { en: "I'll flag the right administrative steps.", fr: "Je vais signaler les bonnes étapes administratives.", ar: 'سأحدد الخطوات الإدارية الصحيحة.', pt: 'Indicarei os passos administrativos certos.', zh: '我将标记正确的行政步骤。', hi: 'मैं सही प्रशासनिक कदम बताऊंगा।' } as T,
    },
    situationStep: {
      title:        { en: 'Your French & housing situation', fr: 'Votre niveau de français et logement', ar: 'وضع لغتك الفرنسية والإسكان', pt: 'Seu francês e situação de moradia', zh: '您的法语和住房情况', hi: 'आपकी फ्रेंच और आवास स्थिति' } as T,
      subtitle:     { en: 'Helps me tailor language support and admin priorities.', fr: "M'aide à adapter le soutien linguistique.", ar: 'يساعدني على تخصيص الدعم اللغوي.', pt: 'Me ajuda a adaptar o suporte linguístico.', zh: '帮助我定制语言支持和行政优先事项。', hi: 'भाषा सहायता और प्राथमिकताओं को अनुकूलित करने में मदद करता है।' } as T,
      frenchLabel:  { en: 'French level',    fr: 'Niveau de français', ar: 'مستوى الفرنسية', pt: 'Nível de francês', zh: '法语水平', hi: 'फ्रेंच स्तर' } as T,
      housingLabel: { en: 'Housing status',  fr: 'Situation de logement', ar: 'وضع السكن', pt: 'Situação de moradia', zh: '住房状态', hi: 'आवास स्थिति' } as T,
    },
    goalsStep: {
      title:    { en: 'What do you need most right now?', fr: 'De quoi avez-vous le plus besoin ?', ar: 'ماذا تحتاج أكثر الآن؟', pt: 'Do que você mais precisa agora?', zh: '您现在最需要什么？', hi: 'आपको अभी सबसे ज़्यादा क्या चाहिए?' } as T,
      subtitle: { en: 'Select everything that applies — no wrong answers.', fr: 'Sélectionnez tout ce qui applique.', ar: 'اختر كل ما ينطبق — لا إجابات خاطئة.', pt: 'Selecione tudo que se aplica.', zh: '选择所有适用的选项——没有错误答案。', hi: 'जो भी लागू हो सब चुनें — कोई गलत जवाब नहीं।' } as T,
      selected: { en: 'priorities selected ✓', fr: 'priorités sélectionnées ✓', ar: 'أولويات محددة ✓', pt: 'prioridades selecionadas ✓', zh: '已选优先事项 ✓', hi: 'प्राथमिकताएं चुनी गईं ✓' } as T,
    },
    locationStep: {
      title:    { en: 'Which area of Paris are you in?', fr: 'Dans quel quartier de Paris êtes-vous ?', ar: 'في أي منطقة من باريس أنت؟', pt: 'Em qual área de Paris você está?', zh: '您在巴黎哪个区域？', hi: 'आप पेरिस के किस क्षेत्र में हैं?' } as T,
      subtitle: { en: "I'll tailor tips to your neighbourhood.", fr: "J'adapterai les conseils à votre quartier.", ar: 'سأخصص النصائح لحيك.', pt: 'Adaptarei as dicas para o seu bairro.', zh: '我将根据您的街区定制建议。', hi: 'मैं आपके पड़ोस के अनुसार टिप्स तैयार करूंगा।' } as T,
    },
    finalStep: {
      title:    { en: 'Almost done! Two quick things.', fr: 'Presque terminé ! Deux petites choses.', ar: 'اقتربنا! شيئان سريعان.', pt: 'Quase pronto! Duas coisas rápidas.', zh: '快完成了！两件快速的事情。', hi: 'लगभग हो गया! दो त्वरित बातें।' } as T,
      subtitle: { en: 'This helps Marcel build your exact to-do timeline.', fr: 'Cela aide Marcel à construire votre plan.', ar: 'هذا يساعد مارسيل على بناء جدولك الزمني.', pt: 'Isso ajuda Marcel a construir sua linha do tempo.', zh: '这帮助Marcel建立您的精确待办时间表。', hi: 'यह Marcel को आपकी सटीक योजना बनाने में मदद करता है।' } as T,
      arrivalQ: { en: 'When did you (or will you) arrive in Paris?', fr: 'Quand êtes-vous (ou serez-vous) arrivé(e) à Paris ?', ar: 'متى وصلت (أو ستصل) إلى باريس؟', pt: 'Quando você chegou (ou chegará) em Paris?', zh: '您何时到达（或将到达）巴黎？', hi: 'आप पेरिस कब पहुंचे (या पहुंचेंगे)?' } as T,
      children: { en: 'Children?', fr: 'Enfants ?',  ar: 'أطفال؟',              pt: 'Filhos?',  zh: '孩子？', hi: 'बच्चे?'           } as T,
      pets:     { en: 'Pets?',     fr: 'Animaux ?', ar: 'حيوانات أليفة؟',      pt: 'Animais?', zh: '宠物？', hi: 'पालतू जानवर?'     } as T,
      yes:      { en: 'Yes',       fr: 'Oui',       ar: 'نعم',                  pt: 'Sim',      zh: '是',     hi: 'हाँ'             } as T,
      no:       { en: 'No',        fr: 'Non',       ar: 'لا',                   pt: 'Não',      zh: '否',     hi: 'नहीं'            } as T,
    },
  },

  // ── Dashboard ───────────────────────────────────────────────────────────────
  dashboard: {
    morning:   { en: 'Bonjour',        fr: 'Bonjour',        ar: 'صباح الخير',  pt: 'Bom dia',    zh: '早上好',  hi: 'सुप्रभात'   } as T,
    afternoon: { en: 'Bon après-midi', fr: 'Bon après-midi', ar: 'مساء النور',  pt: 'Boa tarde',  zh: '下午好',  hi: 'नमस्कार'    } as T,
    evening:   { en: 'Bonsoir',        fr: 'Bonsoir',        ar: 'مساء الخير',  pt: 'Boa noite',  zh: '晚上好',  hi: 'शुभ संध्या'  } as T,
  },

  // ── Settings page ───────────────────────────────────────────────────────────
  settings: {
    title:    { en: 'Settings',         fr: 'Paramètres',      ar: 'الإعدادات',       pt: 'Configurações',  zh: '设置',    hi: 'सेटिंग्स'        } as T,
    subtitle: { en: 'Manage your preferences', fr: 'Gérez vos préférences', ar: 'إدارة تفضيلاتك', pt: 'Gerencie suas preferências', zh: '管理您的偏好设置', hi: 'अपनी प्राथमिकताएं प्रबंधित करें' } as T,
    saved:    { en: 'Changes saved',    fr: 'Modifications enregistrées', ar: 'تم حفظ التغييرات', pt: 'Alterações salvas', zh: '更改已保存', hi: 'परिवर्तन सहेजे गए' } as T,

    sections: {
      language:      { en: 'Language',              fr: 'Langue',              ar: 'اللغة',              pt: 'Idioma',               zh: '语言',      hi: 'भाषा'            } as T,
      appearance:    { en: 'Appearance',            fr: 'Apparence',           ar: 'المظهر',             pt: 'Aparência',            zh: '外观',      hi: 'उपस्थिति'        } as T,
      notifications: { en: 'Notifications',         fr: 'Notifications',       ar: 'الإشعارات',          pt: 'Notificações',         zh: '通知',      hi: 'सूचनाएं'         } as T,
      privacy:       { en: 'Privacy & Data',        fr: 'Confidentialité',     ar: 'الخصوصية والبيانات', pt: 'Privacidade & Dados',  zh: '隐私与数据', hi: 'गोपनीयता और डेटा' } as T,
      accessibility: { en: 'Accessibility',         fr: 'Accessibilité',       ar: 'إمكانية الوصول',    pt: 'Acessibilidade',        zh: '无障碍',    hi: 'पहुंच योग्यता'   } as T,
      account:       { en: 'Account',               fr: 'Compte',              ar: 'الحساب',             pt: 'Conta',                zh: '账户',      hi: 'खाता'            } as T,
      storage:       { en: 'Cache & Storage',       fr: 'Cache & Stockage',    ar: 'التخزين المؤقت',    pt: 'Cache & Armazenamento', zh: '缓存与存储', hi: 'कैश और स्टोरेज'  } as T,
      help:          { en: 'Help & Support',        fr: 'Aide & Support',      ar: 'المساعدة والدعم',    pt: 'Ajuda & Suporte',      zh: '帮助与支持', hi: 'सहायता और समर्थन'} as T,
    },

    language: {
      label:   { en: 'App Language', fr: "Langue de l'application", ar: 'لغة التطبيق', pt: 'Idioma do Aplicativo', zh: '应用语言', hi: 'ऐप भाषा' } as T,
      desc:    { en: 'All content will be displayed in the selected language', fr: 'Tout le contenu sera affiché dans la langue sélectionnée', ar: 'سيتم عرض جميع المحتويات باللغة المحددة', pt: 'Todo o conteúdo será exibido no idioma selecionado', zh: '所有内容将以所选语言显示', hi: 'सभी सामग्री चुनी गई भाषा में प्रदर्शित होगी' } as T,
    },

    appearance: {
      theme:   { en: 'Theme',       fr: 'Thème',       ar: 'السمة',      pt: 'Tema',        zh: '主题',   hi: 'थीम'   } as T,
      dark:    { en: 'Dark',        fr: 'Sombre',      ar: 'داكن',       pt: 'Escuro',       zh: '深色',   hi: 'डार्क'  } as T,
      light:   { en: 'Light',       fr: 'Clair',       ar: 'فاتح',       pt: 'Claro',        zh: '浅色',   hi: 'लाइट'  } as T,
      system:  { en: 'System',      fr: 'Système',     ar: 'النظام',     pt: 'Sistema',      zh: '跟随系统', hi: 'सिस्टम' } as T,
      desc:    { en: 'Choose how the app looks', fr: "Choisissez l'apparence", ar: 'اختر مظهر التطبيق', pt: 'Escolha a aparência', zh: '选择应用外观', hi: 'ऐप का रूप चुनें' } as T,
    },

    notifications: {
      enable:      { en: 'Enable notifications',      fr: 'Activer les notifications',    ar: 'تفعيل الإشعارات',         pt: 'Ativar notificações',         zh: '启用通知',    hi: 'सूचनाएं सक्षम करें'   } as T,
      admin:       { en: 'Admin deadlines',           fr: 'Échéances administratives',    ar: 'المواعيد الإدارية',         pt: 'Prazos administrativos',      zh: '行政截止日期',  hi: 'प्रशासनिक समय सीमा'   } as T,
      tips:        { en: 'Daily Paris tips',          fr: 'Conseils Paris quotidiens',    ar: 'نصائح يومية لباريس',       pt: 'Dicas diárias de Paris',      zh: '每日巴黎贴士',  hi: 'दैनिक पेरिस टिप्स'   } as T,
      transport:   { en: 'Transport alerts',          fr: 'Alertes transport',             ar: 'تنبيهات المواصلات',        pt: 'Alertas de transporte',       zh: '交通提醒',     hi: 'परिवहन अलर्ट'         } as T,
      quest:       { en: 'Quest & badge updates',     fr: 'Mises à jour quêtes & badges', ar: 'تحديثات الإنجازات',        pt: 'Atualizações de quests',      zh: '任务与徽章更新', hi: 'क्वेस्ट और बैज अपडेट' } as T,
    },

    privacy: {
      analytics:   { en: 'Usage analytics',          fr: "Analyse d'utilisation",        ar: 'تحليلات الاستخدام',        pt: 'Análise de uso',              zh: '使用分析',    hi: 'उपयोग विश्लेषण'       } as T,
      analyticsD:  { en: 'Help improve the app anonymously', fr: "Aider à améliorer l'appli", ar: 'المساعدة في تحسين التطبيق بشكل مجهول', pt: 'Ajudar a melhorar o app anonimamente', zh: '匿名帮助改进应用', hi: 'अनाम रूप से ऐप सुधारने में मदद करें' } as T,
      location:    { en: 'Location services',         fr: 'Services de localisation',     ar: 'خدمات الموقع',             pt: 'Serviços de localização',     zh: '位置服务',    hi: 'स्थान सेवाएं'          } as T,
      locationD:   { en: 'Used for commute & map features', fr: 'Pour les trajets et la carte', ar: 'للتنقل وميزات الخريطة', pt: 'Para transporte e mapa', zh: '用于通勤和地图功能', hi: 'आवागमन और मानचित्र के लिए' } as T,
      dataExport:  { en: 'Export my data',            fr: 'Exporter mes données',         ar: 'تصدير بياناتي',            pt: 'Exportar meus dados',         zh: '导出我的数据',  hi: 'मेरा डेटा निर्यात करें' } as T,
    },

    accessibility: {
      textSize:    { en: 'Text size',                 fr: 'Taille du texte',              ar: 'حجم النص',                 pt: 'Tamanho do texto',            zh: '文字大小',    hi: 'टेक्स्ट आकार'         } as T,
      small:       { en: 'Small',  fr: 'Petit',   ar: 'صغير', pt: 'Pequeno', zh: '小', hi: 'छोटा'  } as T,
      medium:      { en: 'Medium', fr: 'Moyen',   ar: 'متوسط',pt: 'Médio',   zh: '中', hi: 'मध्यम' } as T,
      large:       { en: 'Large',  fr: 'Grand',   ar: 'كبير', pt: 'Grande',  zh: '大', hi: 'बड़ा'   } as T,
      contrast:    { en: 'High contrast',             fr: 'Contraste élevé',              ar: 'تباين عالٍ',               pt: 'Alto contraste',              zh: '高对比度',    hi: 'उच्च कंट्रास्ट'       } as T,
      contrastD:   { en: 'Increase color contrast for readability', fr: 'Augmenter le contraste pour lisibilité', ar: 'زيادة التباين للقراءة', pt: 'Aumentar contraste para leitura', zh: '增加颜色对比度以提高可读性', hi: 'पठनीयता के लिए रंग कंट्रास्ट बढ़ाएं' } as T,
      reduceMotion:{ en: 'Reduce motion',             fr: 'Réduire les animations',       ar: 'تقليل الحركة',             pt: 'Reduzir movimento',           zh: '减少动画',    hi: 'गति कम करें'           } as T,
      reduceMotionD:{ en: 'Minimise animations and transitions', fr: 'Minimiser les animations', ar: 'تقليل الرسوم المتحركة', pt: 'Minimizar animações', zh: '最小化动画和过渡效果', hi: 'एनिमेशन और ट्रांज़िशन कम करें' } as T,
    },

    account: {
      profileName: { en: 'Profile name',              fr: 'Nom du profil',                ar: 'اسم الملف الشخصي',         pt: 'Nome do perfil',              zh: '档案名称',    hi: 'प्रोफाइल नाम'         } as T,
      editProfile: { en: 'Edit profile',              fr: 'Modifier le profil',           ar: 'تعديل الملف الشخصي',       pt: 'Editar perfil',               zh: '编辑档案',    hi: 'प्रोफ़ाइल संपादित करें'} as T,
      resetProfile:{ en: 'Reset onboarding',          fr: "Réinitialiser l'onboarding",   ar: 'إعادة تعيين الإعداد',      pt: 'Redefinir integração',        zh: '重置引导',    hi: 'ऑनबोर्डिंग रीसेट करें' } as T,
      resetDesc:   { en: 'Start fresh with a new profile', fr: 'Recommencer avec un nouveau profil', ar: 'ابدأ من جديد بملف شخصي جديد', pt: 'Começar com um novo perfil', zh: '使用新档案重新开始', hi: 'नई प्रोफ़ाइल से ताज़ा शुरू करें' } as T,
      deleteAccount:{ en: 'Delete account',           fr: 'Supprimer le compte',          ar: 'حذف الحساب',               pt: 'Excluir conta',               zh: '删除账户',    hi: 'खाता हटाएं'           } as T,
      deleteDesc:  { en: 'Remove all data permanently', fr: 'Supprimer toutes les données définitivement', ar: 'إزالة جميع البيانات نهائياً', pt: 'Remover todos os dados permanentemente', zh: '永久删除所有数据', hi: 'सभी डेटा स्थायी रूप से हटाएं' } as T,
    },

    storage: {
      cacheSize:   { en: 'Cache size',                fr: 'Taille du cache',              ar: 'حجم التخزين المؤقت',       pt: 'Tamanho do cache',            zh: '缓存大小',    hi: 'कैश आकार'             } as T,
      clearCache:  { en: 'Clear cache',               fr: 'Vider le cache',               ar: 'مسح التخزين المؤقت',       pt: 'Limpar cache',                zh: '清除缓存',    hi: 'कैश साफ़ करें'         } as T,
      cleared:     { en: 'Cache cleared!',            fr: 'Cache vidé !',                 ar: 'تم مسح التخزين المؤقت!',   pt: 'Cache limpo!',                zh: '缓存已清除！', hi: 'कैश साफ़ हो गया!'      } as T,
      offlineMode: { en: 'Offline mode',              fr: 'Mode hors ligne',              ar: 'وضع عدم الاتصال',          pt: 'Modo offline',                zh: '离线模式',    hi: 'ऑफलाइन मोड'           } as T,
      offlineDesc: { en: 'Save content for offline use', fr: 'Sauvegarder pour utilisation hors ligne', ar: 'حفظ المحتوى للاستخدام دون اتصال', pt: 'Salvar conteúdo para uso offline', zh: '保存内容供离线使用', hi: 'ऑफलाइन उपयोग के लिए सामग्री सहेजें' } as T,
    },

    help: {
      faq:         { en: 'FAQ',                       fr: 'FAQ',                          ar: 'الأسئلة الشائعة',          pt: 'FAQ',                         zh: '常见问题',    hi: 'अक्सर पूछे जाने वाले प्रश्न' } as T,
      faqDesc:     { en: 'Common questions answered', fr: 'Questions fréquentes répondues', ar: 'إجابات على الأسئلة الشائعة', pt: 'Perguntas frequentes respondidas', zh: '常见问题解答', hi: 'सामान्य प्रश्नों के उत्तर' } as T,
      feedback:    { en: 'Send feedback',             fr: 'Envoyer un commentaire',       ar: 'إرسال ملاحظة',             pt: 'Enviar feedback',             zh: '发送反馈',    hi: 'फीडबैक भेजें'          } as T,
      feedbackDesc:{ en: 'Report bugs or suggest features', fr: 'Signaler des bugs ou suggestions', ar: 'الإبلاغ عن أخطاء أو اقتراحات', pt: 'Reportar bugs ou sugerir recursos', zh: '报告错误或建议功能', hi: 'बग रिपोर्ट करें या सुविधाएं सुझाएं' } as T,
      privacy:     { en: 'Privacy policy',            fr: 'Politique de confidentialité', ar: 'سياسة الخصوصية',           pt: 'Política de privacidade',     zh: '隐私政策',    hi: 'गोपनीयता नीति'         } as T,
      terms:       { en: 'Terms of service',          fr: "Conditions d'utilisation",     ar: 'شروط الخدمة',              pt: 'Termos de serviço',           zh: '服务条款',    hi: 'सेवा की शर्तें'        } as T,
      version:     { en: 'Version',                   fr: 'Version',                      ar: 'الإصدار',                  pt: 'Versão',                      zh: '版本',        hi: 'संस्करण'              } as T,
    },

    common: {
      on:     { en: 'On',     fr: 'Activé',   ar: 'مفعّل',   pt: 'Ativado',    zh: '开启', hi: 'चालू'  } as T,
      off:    { en: 'Off',    fr: 'Désactivé',ar: 'معطّل',   pt: 'Desativado', zh: '关闭', hi: 'बंद'   } as T,
      save:   { en: 'Save',   fr: 'Sauvegarder', ar: 'حفظ', pt: 'Salvar',     zh: '保存', hi: 'सहेजें' } as T,
      cancel: { en: 'Cancel', fr: 'Annuler',  ar: 'إلغاء',  pt: 'Cancelar',   zh: '取消', hi: 'रद्द करें' } as T,
      confirm:{ en: 'Confirm',fr: 'Confirmer',ar: 'تأكيد',  pt: 'Confirmar',  zh: '确认', hi: 'पुष्टि करें' } as T,
      delete: { en: 'Delete', fr: 'Supprimer',ar: 'حذف',    pt: 'Excluir',    zh: '删除', hi: 'हटाएं' } as T,
      export: { en: 'Export', fr: 'Exporter', ar: 'تصدير',  pt: 'Exportar',   zh: '导出', hi: 'निर्यात' } as T,
      open:   { en: 'Open',   fr: 'Ouvrir',   ar: 'فتح',    pt: 'Abrir',      zh: '打开', hi: 'खोलें' } as T,
    },
  },
  // ── MarcelDashboard ─────────────────────────────────────────────────────────
  marcel: {
    header: {
      title:   { en: 'Marcel · Your Paris AI',     fr: 'Marcel · Votre IA Paris',        ar: 'مارسيل · ذكاؤك الاصطناعي في باريس', pt: 'Marcel · Seu AI Paris',          zh: 'Marcel · 您的巴黎AI',   hi: 'Marcel · आपका पेरिस AI'   } as T,
      settled: { en: 'Settled',                     fr: 'Installé',                       ar: 'استقرار',                            pt: 'Instalado',                      zh: '安家指数',              hi: 'बसाव'                     } as T,
    },
    progress: {
      of:            { en: 'of',           fr: 'sur',          ar: 'من',         pt: 'de',          zh: '/',        hi: 'में से'       } as T,
      tasksDone:     { en: 'tasks done',   fr: 'tâches faites',ar: 'مهام مكتملة',pt: 'tarefas feitas',zh: '任务完成', hi: 'कार्य पूर्ण'  } as T,
      updateProfile: { en: 'Update profile',fr: 'Mettre à jour',ar: 'تحديث الملف',pt: 'Atualizar perfil',zh: '更新档案', hi: 'प्रोफ़ाइल अपडेट करें' } as T,
    },
    tabs: {
      tasks:    { en: 'My Tasks',  fr: 'Mes Tâches', ar: 'مهامي',       pt: 'Minhas Tarefas', zh: '我的任务', hi: 'मेरे कार्य'  } as T,
      timeline: { en: 'Timeline',  fr: 'Calendrier', ar: 'الجدول الزمني',pt: 'Cronograma',     zh: '时间线',   hi: 'समयरेखा'     } as T,
      tips:     { en: 'Tips',      fr: 'Conseils',   ar: 'نصائح',        pt: 'Dicas',          zh: '贴士',     hi: 'टिप्स'       } as T,
    },
    urgency: {
      urgent:     { en: '⚡ Urgent',      fr: '⚡ Urgent',      ar: '⚡ عاجل',          pt: '⚡ Urgente',      zh: '⚡ 紧急',     hi: '⚡ अर्जेंट'      } as T,
      soon:       { en: '📅 Soon',        fr: '📅 Bientôt',    ar: '📅 قريباً',         pt: '📅 Em breve',    zh: '📅 即将',     hi: '📅 जल्द'         } as T,
      when_ready: { en: '✨ When ready',  fr: '✨ Quand prêt',  ar: '✨ عند الاستعداد', pt: '✨ Quando pronto',zh: '✨ 随时',     hi: '✨ तैयार होने पर' } as T,
    },
    tasks: {
      empty:       { en: 'No tasks yet',          fr: 'Aucune tâche pour le moment', ar: 'لا توجد مهام بعد',    pt: 'Nenhuma tarefa ainda',       zh: '暂无任务',        hi: 'अभी कोई कार्य नहीं'   } as T,
      openLink:    { en: 'Open link',             fr: 'Ouvrir le lien',             ar: 'فتح الرابط',           pt: 'Abrir link',                 zh: '打开链接',        hi: 'लिंक खोलें'           } as T,
      recommended: { en: 'Marcel recommends for you', fr: 'Marcel recommande pour vous', ar: 'مارسيل يوصي لك', pt: 'Marcel recomenda para você', zh: 'Marcel为您推荐',  hi: 'Marcel आपके लिए सुझाव' } as T,
    },
    celebration: {
      title:    { en: "You're officially settling in!",          fr: 'Vous êtes officiellement en train de vous installer !', ar: 'أنت رسمياً تستقر!',               pt: 'Você está oficialmente se instalando!', zh: '您正式安家落户！',      hi: 'आप आधिकारिक तौर पर बस रहे हैं!'  } as T,
      subtitle: { en: 'All priority tasks done. Paris is starting to feel like home.', fr: 'Toutes les tâches prioritaires sont faites. Paris devient votre chez-vous.', ar: 'تمت جميع المهام ذات الأولوية. باريس تبدأ تشعر وكأنها منزلك.', pt: 'Todas as tarefas prioritárias concluídas. Paris começa a parecer lar.', zh: '所有优先任务完成。巴黎开始有家的感觉了。', hi: 'सभी प्राथमिकता कार्य पूर्ण। पेरिस घर जैसा लगने लगा है।' } as T,
    },
  },

} as const;

// ─── Helper ──────────────────────────────────────────────────────────────────
export function t(obj: { [K in LangCode]: string }, lang: LangCode): string {
  return obj[lang] ?? obj['en'];
}
