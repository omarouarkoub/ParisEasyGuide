import type { BadgeCatalogItem } from '@/types';

export const XP_PER_RARITY: Record<string, number> = {
  common: 50,
  rare: 150,
  legendary: 400,
};

export const LEVELS = [
  { level: 1, title: 'Tourist',        minXP: 0 },
  { level: 2, title: 'Wanderer',       minXP: 100 },
  { level: 3, title: 'Explorer',       minXP: 300 },
  { level: 4, title: 'Parisian',       minXP: 600 },
  { level: 5, title: 'Connoisseur',    minXP: 1000 },
  { level: 6, title: 'Flâneur',        minXP: 1500 },
  { level: 7, title: 'Vieux Parisien', minXP: 2200 },
  { level: 8, title: 'Légendaire',     minXP: 3000 },
];

export function getLevelInfo(totalXP: number) {
  let current = LEVELS[0];
  let next = LEVELS[1];
  for (let i = 0; i < LEVELS.length; i++) {
    if (totalXP >= LEVELS[i].minXP) {
      current = LEVELS[i];
      next = LEVELS[i + 1] || null!;
    }
  }
  const progress = next
    ? ((totalXP - current.minXP) / (next.minXP - current.minXP)) * 100
    : 100;
  return { current, next, progress: Math.min(progress, 100) };
}

export const RARITY_STYLES: Record<string, { border: string; glow: string; badge: string }> = {
  common:    { border: 'border-slate-500/40',  glow: '',                                        badge: 'bg-slate-700 text-slate-300' },
  rare:      { border: 'border-blue-500/50',   glow: 'shadow-[0_0_16px_rgba(59,130,246,0.3)]', badge: 'bg-blue-900/60 text-blue-300' },
  legendary: { border: 'border-amber-400/60',  glow: 'shadow-[0_0_20px_rgba(251,191,36,0.4)]', badge: 'bg-amber-900/60 text-amber-300' },
};

export const BADGE_CATALOG: BadgeCatalogItem[] = [
  { badge_id: 'eiffel',          emoji: '🗼', name: 'Iron Lady',         description: 'Visited the Eiffel Tower',               category: 'landmark',  rarity: 'common',    keywords: ['eiffel', 'trocadéro', 'champ de mars'] },
  { badge_id: 'louvre',          emoji: '🏛️', name: 'Da Vinci Club',     description: 'Explored the Louvre Museum',             category: 'landmark',  rarity: 'rare',      keywords: ['louvre', 'pyramide du louvre'] },
  { badge_id: 'notredame',       emoji: '⛪', name: 'Cathedral Soul',    description: 'Visited Notre-Dame de Paris',            category: 'landmark',  rarity: 'rare',      keywords: ['notre-dame', 'notre dame', 'île de la cité'] },
  { badge_id: 'sacre_coeur',     emoji: '🕌', name: 'Bohemian Heights',  description: 'Climbed to Sacré-Cœur in Montmartre',    category: 'landmark',  rarity: 'common',    keywords: ['montmartre', 'sacré-cœur', 'abbesses'] },
  { badge_id: 'arc_triomphe',    emoji: '🏛️', name: 'Triumphal Arch',    description: 'Stood under the Arc de Triomphe',        category: 'landmark',  rarity: 'common',    keywords: ['arc de triomphe', 'champs-élysées'] },
  { badge_id: 'sainte_chapelle', emoji: '💎', name: 'Stained Glass',     description: 'Admired the jewel of Sainte-Chapelle',   category: 'culture',   rarity: 'legendary', keywords: ['sainte-chapelle'] },
  { badge_id: 'catacombs',       emoji: '💀', name: 'Underworld Walker', description: 'Descended into the Paris Catacombs',     category: 'landmark',  rarity: 'legendary', keywords: ['catacombes', 'catacombs'] },
  { badge_id: 'museorsay',       emoji: '🖼️', name: 'Impressionist',     description: "Visited Musée d'Orsay",                  category: 'culture',   rarity: 'rare',      keywords: ["orsay", "musée d'orsay"] },
  { badge_id: 'centrepompidou',  emoji: '🎪', name: 'Modern Mind',       description: 'Visited Centre Pompidou',                category: 'culture',   rarity: 'rare',      keywords: ['pompidou', 'beaubourg'] },
  { badge_id: 'musee_orangerie', emoji: '🌺', name: 'Water Lily Dream',  description: "Saw Monet's Nymphéas at l'Orangerie",    category: 'culture',   rarity: 'legendary', keywords: ['orangerie', 'nymphéas', 'monet'] },
  { badge_id: 'shakespeare',     emoji: '📚', name: 'Bookworm',          description: 'Visited Shakespeare & Company',          category: 'culture',   rarity: 'common',    keywords: ['shakespeare', 'bookshop'] },
  { badge_id: 'versailles',      emoji: '👑', name: 'Royal Court',       description: 'Visited the Palace of Versailles',       category: 'idf',       rarity: 'legendary', keywords: ['versailles'] },
  { badge_id: 'fontainebleau',   emoji: '🦌', name: 'Forest Royal',      description: 'Explored Château de Fontainebleau',      category: 'idf',       rarity: 'legendary', keywords: ['fontainebleau'] },
  { badge_id: 'chantilly',       emoji: '🐎', name: 'Horse & Cream',     description: 'Visited Château de Chantilly',           category: 'idf',       rarity: 'rare',      keywords: ['chantilly'] },
  { badge_id: 'giverny',         emoji: '🌸', name: "Monet's Garden",    description: "Visited Monet's garden in Giverny",      category: 'idf',       rarity: 'legendary', keywords: ['giverny'] },
  { badge_id: 'disneyland',      emoji: '🎠', name: 'Magic Kingdom',     description: 'Visited Disneyland Paris',               category: 'idf',       rarity: 'common',    keywords: ['disneyland', 'disney'] },
  { badge_id: 'marais',          emoji: '🏘️', name: 'Marais Maven',      description: 'Explored Le Marais',                    category: 'explorer',  rarity: 'common',    keywords: ['marais', 'bastille'] },
  { badge_id: 'baguette',        emoji: '🥖', name: 'Baguette Master',   description: 'Found the best boulangerie in Paris',    category: 'food',      rarity: 'common',    keywords: ['boulangerie', 'baguette', 'bakery'] },
  { badge_id: 'menu_translator', emoji: '🍽️', name: 'Menu Whisperer',   description: 'Translated a French restaurant menu',    category: 'language',  rarity: 'common',    keywords: ['menu', 'plat', 'entrée', 'dessert'] },
  { badge_id: 'polyglot',        emoji: '🌐', name: 'Polyglot',          description: 'Used Arabic translation feature',        category: 'language',  rarity: 'rare',      keywords: ['arabic', 'arabe'] },
  { badge_id: 'itinerary_maker', emoji: '🗺️', name: 'Itinerary Maker',  description: 'Generated your first AI itinerary',      category: 'explorer',  rarity: 'common',    keywords: [] },
  { badge_id: 'budget_master',   emoji: '💶', name: 'Budget Master',     description: 'Tracked expenses for a full week',       category: 'explorer',  rarity: 'rare',      keywords: [] },
];

export function matchBadges(text: string): BadgeCatalogItem[] {
  const lower = text.toLowerCase();
  return BADGE_CATALOG.filter((b) => b.keywords.some((k) => lower.includes(k)));
}
