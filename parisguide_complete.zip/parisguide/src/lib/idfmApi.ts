const IDFM_BASE = 'https://prim.idfm.fr/marketplace/navitia';

function idfmHeaders() {
  return {
    apiKey: process.env.IDFM_API_KEY || '',
    Accept: 'application/json',
  };
}

export interface IdfmPlace {
  id: string;
  label: string;
  lat: number;
  lng: number;
}

export interface IdfmSection {
  type: string;
  mode?: string;
  from?: { name: string };
  to?: { name: string };
  duration: number;
  display_informations?: { commercial_mode: string; label: string; color: string };
}

export interface IdfmJourney {
  duration: number;
  nb_transfers: number;
  departure_date_time: string;
  arrival_date_time: string;
  sections: IdfmSection[];
}

export async function geocodePlace(query: string): Promise<IdfmPlace | null> {
  try {
    const params = new URLSearchParams({ q: query, type: 'stop_area', count: '1' });
    let res = await fetch(`${IDFM_BASE}/places?${params}`, { headers: idfmHeaders() });
    let data = await res.json();
    let place = data?.places?.[0];
    if (!place) {
      const params2 = new URLSearchParams({ q: query, count: '1' });
      res = await fetch(`${IDFM_BASE}/places?${params2}`, { headers: idfmHeaders() });
      data = await res.json();
      place = data?.places?.[0];
    }
    if (!place) return null;
    const coord = place.stop_area?.coord || place.address?.coord || place.poi?.coord;
    return { id: place.id, label: place.name, lat: parseFloat(coord?.lat), lng: parseFloat(coord?.lon) };
  } catch {
    return null;
  }
}

export async function getJourneys(fromId: string, toId: string, datetime?: string): Promise<IdfmJourney[]> {
  try {
    const params = new URLSearchParams({ from: fromId, to: toId, count: '3', min_nb_journeys: '3' });
    if (datetime) params.set('datetime', datetime);
    const res = await fetch(`${IDFM_BASE}/journeys?${params}`, { headers: idfmHeaders() });
    const data = await res.json();
    return data?.journeys || [];
  } catch {
    return [];
  }
}
