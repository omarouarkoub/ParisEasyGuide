'use client';
import { useState, useRef, useEffect } from 'react';
import { Send, Sparkles, Image as ImageIcon, X, MapPin, Loader2 } from 'lucide-react';
import { useLanguage, LANGUAGES } from '@/lib/i18n/LanguageContext';

interface Message { id: string; role: 'user' | 'assistant'; content: string; time: string; }

const SUGGESTIONS: { [key: string]: string[] } = {
  en: ['How do I use a Navigo card?', 'Cheapest way from CDG to city center?', 'Best boulangerie near the Marais?', 'Documents needed for a French bank account?', 'Free things to do in Paris this weekend'],
  fr: ["Comment utiliser un Navigo ?", "Le moins cher de CDG au centre-ville ?", "Meilleure boulangerie près du Marais ?", "Documents pour un compte bancaire français ?", "Activités gratuites à Paris ce week-end"],
  ar: ['كيف أستخدم بطاقة نافيغو؟', 'أرخص طريقة من CDG إلى وسط المدينة؟', 'أفضل مخبز قرب مارييه؟', 'وثائق لفتح حساب بنكي فرنسي؟', 'أنشطة مجانية في باريس هذا الأسبوع'],
  pt: ['Como usar o cartão Navigo?', 'Mais barato de CDG ao centro?', 'Melhor padaria perto do Marais?', 'Documentos para conta bancária francesa?', 'Coisas gratuitas em Paris esse fim de semana'],
  zh: ['如何使用Navigo卡？', '从CDG到市中心最便宜的方式？', '马莱区附近最好的面包店？', '法国银行账户所需文件？', '本周末巴黎免费活动'],
  hi: ['Navigo कार्ड कैसे उपयोग करें?', 'CDG से शहर तक सबसे सस्ता रास्ता?', 'Marais के पास सबसे अच्छी बेकरी?', 'फ्रेंच बैंक खाते के लिए दस्तावेज़?', 'इस सप्ताहांत पेरिस में मुफ्त गतिविधियाँ'],
};

const GREETINGS: { [key: string]: string } = {
  en: "Bonjour! 👋 I'm your Paris AI guide. Ask me anything about Paris — transport, culture, budget tips, admin questions, or send a photo of a sign/document and I'll help you!",
  fr: "Bonjour! 👋 Je suis votre guide IA pour Paris. Posez-moi n'importe quelle question sur Paris — transport, culture, conseils budget, démarches administratives, ou envoyez une photo d'un panneau!",
  ar: "مرحباً! 👋 أنا دليلك الذكي في باريس. اسألني أي شيء عن باريس — المواصلات، الثقافة، الميزانية، الإجراءات الإدارية، أو أرسل صورة لافتة وسأساعدك!",
  pt: "Bonjour! 👋 Sou seu guia de IA para Paris. Pergunte-me qualquer coisa sobre Paris — transporte, cultura, dicas de orçamento, questões administrativas, ou envie uma foto de um sinal!",
  zh: "Bonjour! 👋 我是您的巴黎AI向导。向我询问任何关于巴黎的问题——交通、文化、预算技巧、行政事务，或者发送一张标志/文件的照片，我会帮助您！",
  hi: "Bonjour! 👋 मैं आपका पेरिस AI गाइड हूं। पेरिस के बारे में कुछ भी पूछें — परिवहन, संस्कृति, बजट टिप्स, प्रशासनिक प्रश्न, या किसी साइन/दस्तावेज़ की फोटो भेजें!",
};

export default function ChatPage() {
  const { lang, t } = useLanguage();

  const [messages, setMessages] = useState<Message[]>([{
    id: '1', role: 'assistant',
    time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    content: GREETINGS[lang] ?? GREETINGS['en'],
  }]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [imageFile, setImageFile] = useState<string | null>(null);
  const [locating, setLocating] = useState(false);
  const endRef = useRef<HTMLDivElement>(null);
  const fileRef = useRef<HTMLInputElement>(null);

  useEffect(() => { endRef.current?.scrollIntoView({ behavior: 'smooth' }); }, [messages]);

  const suggestions = SUGGESTIONS[lang] ?? SUGGESTIONS['en'];
  const currentLang = LANGUAGES.find(l => l.code === lang);

  const shareLocation = () => {
    if (!navigator.geolocation) return;
    setLocating(true);
    navigator.geolocation.getCurrentPosition(async (pos) => {
      const { latitude: lat, longitude: lng } = pos.coords;
      try {
        const res = await fetch(`https://nominatim.openstreetmap.org/reverse?lat=${lat}&lon=${lng}&format=json`);
        const data = await res.json();
        const addr = data.display_name || `${lat.toFixed(5)}, ${lng.toFixed(5)}`;
        sendMessage(`📍 My location: ${addr}. Give me tips and things to do nearby!`);
      } catch { sendMessage(`📍 Location: ${lat.toFixed(5)}, ${lng.toFixed(5)}`); }
      finally { setLocating(false); }
    }, () => setLocating(false), { enableHighAccuracy: true, timeout: 10000 });
  };

  const handleImage = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => setImageFile((reader.result as string).split(',')[1]);
    reader.readAsDataURL(file);
  };

  const sendMessage = async (text?: string) => {
    const msgText = text || input;
    if (!msgText.trim() && !imageFile) return;

    const userMsg: Message = {
      id: Date.now().toString(), role: 'user', content: msgText,
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };
    const newMessages = [...messages, userMsg];
    setMessages(newMessages);
    setInput('');
    setLoading(true);

    try {
      const res = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          messages: newMessages.map(m => ({ role: m.role, content: m.content })),
          image: imageFile,
          lang: currentLang?.label ?? 'English',
        }),
      });
      const data = await res.json();
      if (data.error) throw new Error(data.error);
      setMessages(prev => [...prev, {
        id: Date.now().toString(), role: 'assistant', content: data.content,
        time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      }]);
    } catch {
      setMessages(prev => [...prev, {
        id: Date.now().toString(), role: 'assistant',
        content: { en: 'Sorry, I encountered an error. Please try again.', fr: 'Désolé, une erreur est survenue.', ar: 'عذراً، حدث خطأ. يرجى المحاولة مرة أخرى.', pt: 'Desculpe, ocorreu um erro.', zh: '抱歉，发生了错误，请重试。', hi: 'क्षमा करें, एक त्रुटि हुई।' }[lang] ?? 'Sorry, an error occurred.',
        time: '',
      }]);
    } finally {
      setLoading(false);
      setImageFile(null);
    }
  };

  const renderContent = (text: string) =>
    text.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>').replace(/\n/g, '<br/>');

  return (
    <div style={{
      display: 'flex', flexDirection: 'column', height: '100vh',
      maxWidth: 800, margin: '0 auto', padding: '1.5rem 1rem 1rem',
    }}>
      {/* Header */}
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '1.5rem', paddingBottom: '1rem', borderBottom: '1px solid rgba(255,255,255,0.08)' }}>
        <div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 4 }}>
            <Sparkles style={{ width: 16, height: 16, color: '#C9A84C' }} />
            <span style={{ fontSize: 12, fontWeight: 600, color: '#C9A84C', textTransform: 'uppercase', letterSpacing: '0.1em' }}>
              {currentLang?.flag} AI Paris Guide
            </span>
          </div>
          <h1 style={{ fontFamily: 'Playfair Display, serif', fontSize: '1.5rem', fontWeight: 700, color: '#fff' }}>
            {{ en: 'Chat with Paris AI', fr: 'Chat avec l\'IA Paris', ar: 'دردشة مع ذكاء باريس', pt: 'Chat com IA Paris', zh: '与巴黎AI对话', hi: 'पेरिस AI से चैट' }[lang] ?? 'Chat with Paris AI'}
          </h1>
        </div>
        {/* Quick language flags */}
        <div style={{ display: 'flex', gap: 4, flexWrap: 'wrap', justifyContent: 'flex-end', maxWidth: 180 }}>
          {LANGUAGES.map(l => (
            <span key={l.code} title={l.native} style={{ fontSize: 20, cursor: 'default', opacity: lang === l.code ? 1 : 0.3, transition: 'opacity 0.2s' }}>{l.flag}</span>
          ))}
        </div>
      </div>

      {/* Messages */}
      <div style={{ flex: 1, overflowY: 'auto', display: 'flex', flexDirection: 'column', gap: '1rem', paddingBottom: '1rem' }}>
        {messages.map(msg => (
          <div key={msg.id} style={{ display: 'flex', justifyContent: msg.role === 'user' ? 'flex-end' : 'flex-start' }}>
            {msg.role === 'assistant' && (
              <div style={{ width: 32, height: 32, borderRadius: '50%', background: 'rgba(0,64,130,0.3)', border: '1px solid rgba(0,64,130,0.5)', display: 'flex', alignItems: 'center', justifyContent: 'center', marginRight: 8, flexShrink: 0, marginTop: 4 }}>
                <Sparkles style={{ width: 14, height: 14, color: '#C9A84C' }} />
              </div>
            )}
            <div style={{ maxWidth: '75%' }}>
              <div style={{
                padding: '12px 16px',
                borderRadius: msg.role === 'user' ? '18px 18px 4px 18px' : '18px 18px 18px 4px',
                background: msg.role === 'user' ? 'linear-gradient(135deg, #004082, #1a5cb5)' : 'rgba(255,255,255,0.06)',
                border: msg.role === 'user' ? 'none' : '1px solid rgba(255,255,255,0.1)',
                color: '#fff', fontSize: 14, lineHeight: 1.7,
              }} dangerouslySetInnerHTML={{ __html: renderContent(msg.content) }} />
              {msg.time && <div style={{ fontSize: 11, color: '#4b5563', marginTop: 4, textAlign: msg.role === 'user' ? 'right' : 'left' }}>{msg.time}</div>}
            </div>
          </div>
        ))}

        {loading && (
          <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
            <div style={{ width: 32, height: 32, borderRadius: '50%', background: 'rgba(0,64,130,0.3)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
              <Sparkles style={{ width: 14, height: 14, color: '#C9A84C' }} />
            </div>
            <div style={{ padding: '12px 16px', borderRadius: '18px 18px 18px 4px', background: 'rgba(255,255,255,0.06)', border: '1px solid rgba(255,255,255,0.1)', display: 'flex', gap: 4 }}>
              {[0, 1, 2].map(i => (
                <MotionDot key={i} delay={i * 0.15} />
              ))}
            </div>
          </div>
        )}
        <div ref={endRef} />
      </div>

      {/* Suggestions */}
      {messages.length <= 1 && (
        <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap', marginBottom: '0.75rem' }}>
          {suggestions.slice(0, 3).map(s => (
            <button key={s} onClick={() => sendMessage(s)}
              style={{ padding: '6px 12px', borderRadius: 20, fontSize: 12, cursor: 'pointer', border: '1px solid rgba(0,64,130,0.4)', background: 'rgba(0,64,130,0.1)', color: '#9ca3af', whiteSpace: 'nowrap', maxWidth: 220, overflow: 'hidden', textOverflow: 'ellipsis' }}>
              {s}
            </button>
          ))}
        </div>
      )}

      {/* Image preview */}
      {imageFile && (
        <div style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '8px 12px', marginBottom: 8, borderRadius: 12, background: 'rgba(0,64,130,0.15)', border: '1px solid rgba(0,64,130,0.3)' }}>
          <ImageIcon style={{ width: 14, height: 14, color: '#3a7bd5' }} />
          <span style={{ fontSize: 12, color: '#3a7bd5', flex: 1 }}>
            {{ en: 'Image attached — ready to send', fr: 'Image jointe — prête à envoyer', ar: 'صورة مرفقة — جاهزة للإرسال', pt: 'Imagem anexada — pronta para enviar', zh: '图片已附加 — 准备发送', hi: 'छवि संलग्न — भेजने के लिए तैयार' }[lang] ?? 'Image attached'}
          </span>
          <button onClick={() => setImageFile(null)} style={{ background: 'none', border: 'none', cursor: 'pointer', color: '#6b7280' }}><X style={{ width: 14, height: 14 }} /></button>
        </div>
      )}

      {/* Input bar */}
      <div style={{ display: 'flex', gap: 8, padding: '12px', borderRadius: 16, background: 'rgba(255,255,255,0.05)', border: '1px solid rgba(255,255,255,0.1)' }}>
        <button onClick={() => fileRef.current?.click()}
          style={{ padding: 8, borderRadius: 10, background: 'rgba(0,64,130,0.2)', border: '1px solid rgba(0,64,130,0.3)', cursor: 'pointer', color: '#3a7bd5', flexShrink: 0 }}>
          <ImageIcon style={{ width: 16, height: 16 }} />
        </button>
        <button onClick={shareLocation} disabled={locating}
          style={{ padding: 8, borderRadius: 10, background: 'rgba(238,36,54,0.15)', border: '1px solid rgba(238,36,54,0.3)', cursor: 'pointer', color: '#f87171', flexShrink: 0 }}>
          {locating
            ? <Loader2 style={{ width: 16, height: 16, animation: 'spin 1s linear infinite' }} />
            : <MapPin style={{ width: 16, height: 16 }} />}
        </button>
        <input ref={fileRef} type="file" accept="image/*" onChange={handleImage} style={{ display: 'none' }} />
        <input
          value={input}
          onChange={e => setInput(e.target.value)}
          onKeyDown={e => e.key === 'Enter' && !e.shiftKey && sendMessage()}
          placeholder={{ en: 'Ask anything about Paris…', fr: 'Posez n\'importe quelle question…', ar: 'اسأل أي شيء عن باريس…', pt: 'Pergunte qualquer coisa sobre Paris…', zh: '询问任何关于巴黎的问题…', hi: 'पेरिस के बारे में कुछ भी पूछें…' }[lang] ?? 'Ask anything about Paris…'}
          style={{ flex: 1, background: 'none', border: 'none', outline: 'none', color: '#fff', fontSize: 14 }}
        />
        <button
          onClick={() => sendMessage()}
          disabled={loading || (!input.trim() && !imageFile)}
          style={{ padding: '8px 14px', borderRadius: 10, background: (!input.trim() && !imageFile) ? 'rgba(255,255,255,0.05)' : 'linear-gradient(135deg, #004082, #1a5cb5)', border: 'none', cursor: 'pointer', color: '#fff', flexShrink: 0 }}>
          <Send style={{ width: 16, height: 16 }} />
        </button>
      </div>
      <style>{`@keyframes spin{from{transform:rotate(0deg)}to{transform:rotate(360deg)}}@keyframes bounce{0%,100%{transform:translateY(0)}50%{transform:translateY(-4px)}}`}</style>
    </div>
  );
}

// Typing dots
function MotionDot({ delay }: { delay: number }) {
  return (
    <div style={{
      width: 7, height: 7, borderRadius: '50%', background: '#C9A84C',
      animation: `bounce 1s ease-in-out ${delay}s infinite`,
    }} />
  );
}
