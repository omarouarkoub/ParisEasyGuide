'use client';
import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Heart, Phone, Search, Loader2, AlertCircle, ExternalLink, Sparkles } from 'lucide-react';
import { useLanguage, LANGUAGES } from '@/lib/i18n/LanguageContext';
import { toast } from 'sonner';
import { FadeIn } from '@/components/shared/PageMotion';

const EMERGENCY_NUMBERS = [
  { number: '15', label: 'SAMU', desc: 'Medical emergency / ambulance', color: '#ef4444', icon: '🚑' },
  { number: '18', label: 'Pompiers', desc: 'Fire brigade / first aid', color: '#f97316', icon: '🚒' },
  { number: '17', label: 'Police', desc: 'Police / crime emergency', color: '#3b82f6', icon: '🚓' },
  { number: '112', label: 'EU Emergency', desc: 'Universal European emergency', color: '#8b5cf6', icon: '🆘' },
  { number: '114', label: 'Deaf/HoH', desc: 'Emergency for deaf & hard of hearing', color: '#6b7280', icon: '🤟' },
  { number: '3114', label: 'Suicide Prevention', desc: 'National suicide prevention hotline', color: '#10b981', icon: '💚' },
  { number: '3237', label: 'Doctolib', desc: 'Book doctor appointments (non-emergency)', color: '#004082', icon: '📅' },
  { number: '3989', label: 'SOS Amitié', desc: 'Emotional distress helpline', color: '#d97706', icon: '💛' },
];

const ENGLISH_HOSPITALS = [
  { name: 'American Hospital of Paris', area: 'Neuilly-sur-Seine (92)', url: 'https://www.american-hospital.org', note: 'Full English-speaking care, US insurance accepted', icon: '🇺🇸' },
  { name: 'Franco-British Hospital', area: 'Levallois-Perret (92)', url: 'https://www.ihfb.org', note: 'Bilingual French/English staff, A&E available', icon: '🇬🇧' },
  { name: 'Hôpital Lariboisière', area: '10ème – near Gare du Nord', url: 'https://www.aphp.fr', note: 'Major A&E, public hospital, free with Carte Vitale', icon: '🏥' },
  { name: 'Hôtel-Dieu', area: '4ème – Île de la Cité', url: 'https://www.aphp.fr', note: 'Central Paris A&E, 24h emergency', icon: '🏛️' },
];

const MENTAL_HEALTH = [
  { name: 'Mon Soutien Psy', desc: 'Up to 12 FREE therapy sessions via your médecin traitant referral', url: 'https://monsoutienpsy.ameli.fr', emoji: '🧠' },
  { name: '3114 – Numéro National Prévention Suicide', desc: '24/7 crisis line, free, confidential, trained counselors', url: 'https://www.3114.fr', emoji: '💚' },
  { name: 'SOS Amitié', desc: 'Emotional support hotline 24/7: call 09 72 39 40 50', url: 'https://www.sos-amitie.com', emoji: '💛' },
  { name: 'Fil Santé Jeunes', desc: 'Free support for 12–25 year-olds: 0800 235 236', url: 'https://www.filsantejeunes.com', emoji: '🌱' },
  { name: 'CMP (Centre Médico-Psychologique)', desc: 'Free public mental health centers — find yours at your mairie', url: 'https://www.psycom.org', emoji: '🏥' },
];

const PHARMACY_TIPS = [
  '🟢 Green cross sign = pharmacie. It glows when open.',
  '🌙 Pharmacie de garde: find the nearest one open at night at pharmaciedegarde.fr or ask any pharmacist for the duty pharmacy slip.',
  '💊 Pharmacists can diagnose minor ailments (colds, UTIs, etc.) and recommend OTC treatments — no appointment needed.',
  '🤕 Minor injuries, cuts, burns — pharmacists can treat and advise for free.',
  '💳 With Carte Vitale, most prescriptions cost very little (often €0.50–5). Without it, pay full price then reimburse via Ameli.',
  '📦 Parapharmacy items (vitamins, cosmetics, baby products) are sold at pharmacies, often cheaper than supermarkets.',
];

interface HealthAdvice {
  situation: string;
  what_to_do: string[];
  french_phrase: string;
  useful_apps: string[];
  cost_estimate: string;
  pro_tip: string;
}

export default function HealthcarePage() {
  const { lang } = useLanguage();
  const langLabel = LANGUAGES.find(l => l.code === lang)?.label ?? "English";
  const [query, setQuery] = useState('');
  const [advice, setAdvice] = useState<HealthAdvice | null>(null);
  const [loading, setLoading] = useState(false);
  const [activeTab, setActiveTab] = useState<'emergency' | 'doctor' | 'mental' | 'pharmacy'>('emergency');

  const QUICK = [
    'I have a fever — what do I do?',
    'I need to find a doctor who speaks English',
    'I lost my Carte Vitale',
    'Dental emergency in Paris',
    'I need a médecin traitant',
    'Pregnancy care in Paris',
  ];

  const getAdvice = async (q?: string) => {
    const question = q || query;
    if (!question.trim()) return;
    setLoading(true); setAdvice(null);
    try {
      const res = await fetch('/api/healthcare', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ question }),
      });
      const data = await res.json();
      if (data.advice) setAdvice(data.advice);
      else toast.error('Could not get advice. Please try again.');
    } catch { toast.error('Connection error.'); }
    finally { setLoading(false); }
  };

  const TABS = [
    { id: 'emergency', label: '🚨 Emergency', color: '#ef4444' },
    { id: 'doctor', label: '🩺 Doctors', color: '#3b82f6' },
    { id: 'mental', label: '🧠 Mental Health', color: '#10b981' },
    { id: 'pharmacy', label: '💊 Pharmacy', color: '#8b5cf6' },
  ] as const;

  return (
    <div style={{ padding: '2rem 2.5rem', maxWidth: 1100, margin: '0 auto' }}>
      <FadeIn>
        <div style={{ marginBottom: '2rem' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 4 }}>
            <Heart style={{ width: 16, height: 16, color: '#C9A84C' }} />
            <span style={{ fontSize: 12, fontWeight: 600, color: '#C9A84C', textTransform: 'uppercase', letterSpacing: '0.1em' }}>Healthcare</span>
          </div>
          <h1 style={{ fontFamily: 'Playfair Display, serif', fontSize: '2rem', fontWeight: 700, color: '#fff' }}>Health & Emergency Guide</h1>
          <p style={{ color: '#6b7280', fontSize: 14 }}>Emergency numbers, doctors, pharmacies & mental health resources in Paris</p>
        </div>
      </FadeIn>

      {/* AI Health Advisor */}
      <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }}
        style={{ padding: '1.5rem', borderRadius: 16, background: 'rgba(16,185,129,0.06)', border: '1px solid rgba(16,185,129,0.2)', marginBottom: '1.5rem' }}>
        <div style={{ fontSize: 13, fontWeight: 700, color: '#34d399', marginBottom: '0.75rem', display: 'flex', alignItems: 'center', gap: 6 }}>
          <Sparkles style={{ width: 14, height: 14 }} /> AI Health Navigator
        </div>
        <div style={{ display: 'flex', gap: 8, marginBottom: '0.75rem' }}>
          <input value={query} onChange={e => setQuery(e.target.value)} onKeyDown={e => e.key === 'Enter' && getAdvice()}
            placeholder="Describe your health situation or ask a question…"
            style={{ flex: 1, background: 'rgba(255,255,255,0.06)', border: '1px solid rgba(255,255,255,0.1)', borderRadius: 10, padding: '10px 14px', color: '#fff', fontSize: 14, outline: 'none' }} />
          <motion.button whileTap={{ scale: 0.95 }} onClick={() => getAdvice()} disabled={loading}
            style={{ padding: '10px 18px', borderRadius: 10, background: 'linear-gradient(135deg,#059669,#047857)', border: 'none', cursor: 'pointer', color: '#fff', fontWeight: 700, fontSize: 13 }}>
            {loading ? <Loader2 style={{ width: 16, height: 16, animation: 'spin 1s linear infinite' }} /> : 'Ask'}
          </motion.button>
        </div>
        <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}>
          {QUICK.map(q => (
            <button key={q} onClick={() => { setQuery(q); getAdvice(q); }}
              style={{ padding: '5px 10px', borderRadius: 20, fontSize: 11, fontWeight: 600, cursor: 'pointer', border: '1px solid rgba(16,185,129,0.25)', background: 'rgba(16,185,129,0.06)', color: '#6ee7b7' }}>
              {q}
            </button>
          ))}
        </div>

        <AnimatePresence>
          {advice && (
            <motion.div key="advice" initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }}
              style={{ marginTop: '1.25rem', padding: '1.25rem', borderRadius: 12, background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.08)' }}>
              <div style={{ fontWeight: 700, color: '#fff', marginBottom: '0.75rem' }}>📋 {advice.situation}</div>
              <div style={{ marginBottom: '0.75rem' }}>
                {advice.what_to_do?.map((step, i) => (
                  <div key={i} style={{ display: 'flex', gap: 8, marginBottom: 6, fontSize: 13, color: '#e5e7eb' }}>
                    <span style={{ color: '#34d399', fontWeight: 700, flexShrink: 0 }}>{i + 1}.</span>{step}
                  </div>
                ))}
              </div>
              {advice.french_phrase && (
                <div style={{ padding: '8px 12px', borderRadius: 8, background: 'rgba(0,64,130,0.15)', border: '1px solid rgba(0,64,130,0.3)', marginBottom: '0.75rem' }}>
                  <span style={{ fontSize: 12, color: '#60a5fa', fontStyle: 'italic' }}>🇫🇷 Say: "{advice.french_phrase}"</span>
                </div>
              )}
              <div style={{ display: 'flex', gap: '1rem', flexWrap: 'wrap' }}>
                <div style={{ fontSize: 12, color: '#fbbf24' }}>💶 {advice.cost_estimate}</div>
                <div style={{ fontSize: 12, color: '#a78bfa' }}>📱 {advice.useful_apps?.join(', ')}</div>
              </div>
              {advice.pro_tip && (
                <div style={{ marginTop: '0.75rem', fontSize: 12, color: '#fbbf24', fontWeight: 700 }}>💡 Pro Tip: {advice.pro_tip}</div>
              )}
            </motion.div>
          )}
        </AnimatePresence>
      </motion.div>

      {/* Tabs */}
      <div style={{ display: 'flex', gap: 6, marginBottom: '1.25rem', flexWrap: 'wrap' }}>
        {TABS.map(tab => (
          <button key={tab.id} onClick={() => setActiveTab(tab.id)}
            style={{ padding: '8px 16px', borderRadius: 20, fontSize: 13, fontWeight: 700, cursor: 'pointer', border: `1px solid ${activeTab === tab.id ? tab.color + '66' : 'rgba(255,255,255,0.08)'}`, background: activeTab === tab.id ? `${tab.color}15` : 'rgba(255,255,255,0.03)', color: activeTab === tab.id ? '#fff' : '#9ca3af', transition: 'all 0.2s' }}>
            {tab.label}
          </button>
        ))}
      </div>

      <AnimatePresence mode="wait">
        {activeTab === 'emergency' && (
          <motion.div key="emergency" initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(240px, 1fr))', gap: '1rem' }}>
              {EMERGENCY_NUMBERS.map(e => (
                <motion.a key={e.number} href={`tel:${e.number}`} whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }}
                  style={{ padding: '1.25rem', borderRadius: 16, background: `${e.color}10`, border: `1px solid ${e.color}40`, textDecoration: 'none', display: 'block' }}>
                  <div style={{ fontSize: '1.5rem', marginBottom: 8 }}>{e.icon}</div>
                  <div style={{ fontWeight: 800, fontSize: '2rem', color: e.color, lineHeight: 1, marginBottom: 4 }}>{e.number}</div>
                  <div style={{ fontWeight: 700, color: '#fff', fontSize: 14, marginBottom: 2 }}>{e.label}</div>
                  <div style={{ fontSize: 12, color: '#9ca3af', lineHeight: 1.5 }}>{e.desc}</div>
                </motion.a>
              ))}
            </div>
            <div style={{ marginTop: '1.5rem', padding: '1rem 1.25rem', borderRadius: 12, background: 'rgba(239,68,68,0.06)', border: '1px solid rgba(239,68,68,0.2)', fontSize: 13, color: '#fca5a5' }}>
              <strong>🚨 If in doubt, call 15 (SAMU)</strong> — they will dispatch or redirect you to the right service. Describe your symptoms in simple terms. They are trained for non-French speakers.
            </div>
          </motion.div>
        )}

        {activeTab === 'doctor' && (
          <motion.div key="doctor" initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}>
            <div style={{ padding: '1.25rem', borderRadius: 16, background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.08)', marginBottom: '1.25rem' }}>
              <h3 style={{ fontWeight: 700, color: '#fff', marginBottom: '1rem', fontSize: 15 }}>🩺 How to Find a Doctor</h3>
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(200px, 1fr))', gap: '0.75rem', marginBottom: '1rem' }}>
                {[
                  { name: 'Doctolib', desc: 'Book any doctor instantly. Filter by English-speaking.', url: 'https://www.doctolib.fr', color: '#004082' },
                  { name: 'Ameli.fr', desc: 'Find your médecin traitant + get reimbursed up to 70%', url: 'https://www.ameli.fr', color: '#059669' },
                  { name: 'Kry / Livi', desc: 'Online teleconsultation in English, same-day', url: 'https://www.kry.fr', color: '#7c3aed' },
                  { name: 'Qare', desc: 'Video doctor consultation, even without Carte Vitale', url: 'https://www.qare.fr', color: '#ea580c' },
                ].map(item => (
                  <a key={item.name} href={item.url} target="_blank" rel="noreferrer"
                    style={{ padding: '12px', borderRadius: 12, background: `${item.color}10`, border: `1px solid ${item.color}30`, textDecoration: 'none', display: 'block' }}>
                    <div style={{ fontWeight: 700, color: '#fff', fontSize: 13, marginBottom: 4 }}>{item.name}</div>
                    <div style={{ fontSize: 11, color: '#9ca3af', lineHeight: 1.5 }}>{item.desc}</div>
                    <div style={{ fontSize: 10, color: item.color, marginTop: 4 }}>Open →</div>
                  </a>
                ))}
              </div>
              <div style={{ padding: '10px 14px', borderRadius: 10, background: 'rgba(201,168,76,0.08)', border: '1px solid rgba(201,168,76,0.2)', fontSize: 12, color: '#fbbf24' }}>
                💡 <strong>Pro Tip:</strong> Register a <em>médecin traitant</em> (GP) on Ameli.fr — your reimbursement jumps from 30% to 70% for specialist visits that go through your GP first.
              </div>
            </div>

            <h3 style={{ fontWeight: 700, color: '#fff', marginBottom: '0.75rem', fontSize: 15 }}>🏥 English-Friendly Hospitals</h3>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '0.75rem' }}>
              {ENGLISH_HOSPITALS.map(h => (
                <a key={h.name} href={h.url} target="_blank" rel="noreferrer"
                  style={{ padding: '1rem 1.25rem', borderRadius: 14, background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.08)', textDecoration: 'none', display: 'flex', alignItems: 'center', gap: '1rem' }}>
                  <span style={{ fontSize: '1.5rem' }}>{h.icon}</span>
                  <div style={{ flex: 1 }}>
                    <div style={{ fontWeight: 700, color: '#fff', fontSize: 14 }}>{h.name}</div>
                    <div style={{ fontSize: 12, color: '#3b82f6', marginBottom: 2 }}>📍 {h.area}</div>
                    <div style={{ fontSize: 12, color: '#9ca3af' }}>{h.note}</div>
                  </div>
                  <ExternalLink style={{ width: 14, height: 14, color: '#6b7280', flexShrink: 0 }} />
                </a>
              ))}
            </div>
          </motion.div>
        )}

        {activeTab === 'mental' && (
          <motion.div key="mental" initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}>
            <div style={{ padding: '1rem 1.25rem', borderRadius: 12, background: 'rgba(16,185,129,0.06)', border: '1px solid rgba(16,185,129,0.2)', marginBottom: '1.25rem', fontSize: 13, color: '#6ee7b7' }}>
              💚 Mental health care is covered by French Sécurité Sociale. You are not alone — help is available in English too.
            </div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '0.75rem' }}>
              {MENTAL_HEALTH.map(r => (
                <a key={r.name} href={r.url} target="_blank" rel="noreferrer"
                  style={{ padding: '1.1rem 1.25rem', borderRadius: 14, background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(16,185,129,0.15)', textDecoration: 'none', display: 'flex', gap: '1rem', alignItems: 'flex-start' }}>
                  <span style={{ fontSize: '1.5rem', flexShrink: 0 }}>{r.emoji}</span>
                  <div>
                    <div style={{ fontWeight: 700, color: '#fff', fontSize: 14, marginBottom: 4 }}>{r.name}</div>
                    <div style={{ fontSize: 12, color: '#9ca3af', lineHeight: 1.6 }}>{r.desc}</div>
                  </div>
                  <ExternalLink style={{ width: 13, height: 13, color: '#6b7280', flexShrink: 0, marginTop: 4 }} />
                </a>
              ))}
            </div>
          </motion.div>
        )}

        {activeTab === 'pharmacy' && (
          <motion.div key="pharmacy" initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '0.75rem', marginBottom: '1.25rem' }}>
              {PHARMACY_TIPS.map((tip, i) => (
                <motion.div key={i} initial={{ opacity: 0, x: -10 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: i * 0.05 }}
                  style={{ padding: '12px 16px', borderRadius: 12, background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.08)', fontSize: 13, color: '#e5e7eb', lineHeight: 1.6 }}>
                  {tip}
                </motion.div>
              ))}
            </div>
            <a href="https://www.pharmaciedegarde.fr" target="_blank" rel="noreferrer"
              style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8, padding: '14px', borderRadius: 12, background: 'linear-gradient(135deg,#7c3aed,#5b21b6)', border: 'none', cursor: 'pointer', color: '#fff', fontWeight: 700, fontSize: 14, textDecoration: 'none' }}>
              <Phone style={{ width: 16, height: 16 }} /> Find Nearest Night Pharmacy →
            </a>
          </motion.div>
        )}
      </AnimatePresence>
      <style>{`@keyframes spin { from { transform:rotate(0deg) } to { transform:rotate(360deg) } }`}</style>
    </div>
  );
}
