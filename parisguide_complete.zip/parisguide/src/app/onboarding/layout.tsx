export default function Layout({ children }: { children: React.ReactNode }) {
  // Onboarding is full-screen, no sidebar
  return <>{children}</>;
}
