'use client';
import Link from 'next/link';
import { useState, useEffect, Suspense } from 'react';
import { motion } from 'framer-motion';
import { Sparkles, ArrowRight, TrendingUp, User } from 'lucide-react';
import { useLanguage } from '@/lib/i18n/LanguageContext';
import PageMotion, { FadeIn } from '@/components/shared/PageMotion';
import StatCard from '@/components/shared/StatCard';
import dynamic from 'next/dynamic';
const MarcelDashboard = dynamic(() => import('@/components/shared/MarcelDashboard'), { ssr: false });

const GOLD = '#C9A84C';

const ALL_TOOLS = [
  { emoji: '✈️', title: 'Arrival Mode',       desc: 'CDG/Orly → your door in 90 min',           path: '/arrival',       color: '#004082', new: true },
  { emoji: '🌐', title: 'AI Translation',      desc: 'Text & camera OCR — 6 languages',           path: '/translate',     color: '#7c3aed' },
  { emoji: '💶', title: 'Budget & Meals',      desc: 'Expense tracker + AI meal planner',          path: '/budget',        color: '#059669' },
  { emoji: '🗺️', title: 'Itinerary AI',       desc: 'Generate full day plans in seconds',         path: '/itinerary',     color: '#ea580c' },
  { emoji: '🚇', title: 'Navigo Optimizer',    desc: 'Stop overpaying — find your ideal pass',     path: '/navigo',        color: '#2563eb', new: true },
  { emoji: '🚆', title: 'Commute Planner',     desc: 'IDFM Métro, RER & Bus routes',              path: '/commute',       color: '#3b82f6' },
  { emoji: '🏛️', title: 'Admin Guide',         desc: 'Préfecture, CAF, CVEC & more',              path: '/admin',         color: '#059669', new: true },
  { emoji: '🏠', title: 'Housing Finder',      desc: 'Platforms, CAF, guarantors, scam alerts',   path: '/housing',       color: '#10b981', new: true },
  { emoji: '🏘️', title: 'Neighbourhoods',     desc: 'Deep-dive guides for every arrondissement',  path: '/neighborhoods', color: '#f59e0b', new: true },
  { emoji: '📍', title: 'Explore Map',         desc: '35+ Paris POIs on satellite 3D map',         path: '/explore',       color: '#00bfff' },
  { emoji: '💬', title: 'AI Chat Guide',       desc: 'Ask anything — send photos too',             path: '/chat',          color: '#db2777' },
  { emoji: '🏆', title: 'Quest & Badges',      desc: 'Earn XP exploring Paris',                    path: '/quest',         color: '#d97706' },
];

const TIPS = [
  { tip: 'The Navigo Liberté+ card lets you top up trips individually — great for tourists.', icon: '🚇' },
  { tip: 'Most Paris museums are free on the first Sunday of each month.', icon: '🏛️' },
  { tip: 'Supermarché happy hour: Monoprix & Franprix discount fresh food after 7pm.', icon: '🛒' },
  { tip: 'Book your préfecture appointment at 8:00 AM sharp — slots fill in minutes.', icon: '🏛️' },
  { tip: 'CAF housing aid can reduce your rent by €80–250/month — apply within 3 months of moving in.', icon: '🏠' },
  { tip: 'Students under 26 save ~€57/month with Imagine\'R vs the monthly Navigo pass.', icon: '💡' },
];

function getGreeting(lang: string) {
  const h = new Date().getHours();
  const greetings: Record<string, string[]> = {
    en: ['Bonjour', 'Bon après-midi', 'Bonsoir'],
    fr: ['Bonjour', 'Bon après-midi', 'Bonsoir'],
    ar: ['صباح الخير', 'مساء النور', 'مساء الخير'],
    pt: ['Bom dia', 'Boa tarde', 'Boa noite'],
    zh: ['早上好', '下午好', '晚上好'],
    hi: ['सुप्रभात', 'नमस्कार', 'शुभ संध्या'],
  };
  const set = greetings[lang] ?? greetings['en'];
  if (h < 12) return set[0];
  if (h < 18) return set[1];
  return set[2];
}

function getCalendarAlert() {
  const m = new Date().getMonth() + 1;
  const alerts: Record<number, { msg: string; color: string; icon: string }> = {
    2:  { msg: 'Parcoursup opens this month — submit your choices before March 13', color: '#3b82f6', icon: '📚' },
    6:  { msg: 'URGENT: Book your préfecture appointment NOW before August closure', color: '#ef4444', icon: '🚨' },
    7:  { msg: 'Préfecture partially closed — emergency admin only from Aug 1', color: '#f59e0b', icon: '⚠️' },
    8:  { msg: 'Most préfectures CLOSED. File everything online this week', color: '#ef4444', icon: '🔴' },
    9:  { msg: 'Rentrée: CVEC fee due · Register Sécurité Sociale · CAF application open', color: '#059669', icon: '📅' },
    10: { msg: 'CVEC deadline approaching Oct 15 · CAF housing aid window open', color: '#f59e0b', icon: '⏰' },
  };
  return alerts[m] || null;
}

export default function DashboardPage() {
  const { lang } = useLanguage();
  const tip = TIPS[new Date().getDay() % TIPS.length];
  const alert = getCalendarAlert();
  const [hasProfile, setHasProfile] = useState(false);
  const [profileName, setProfileName] = useState('');

  useEffect(() => {
    try {
      const p = localStorage.getItem('paris_profile');
      if (p) {
        const parsed = JSON.parse(p);
        setHasProfile(true);
        setProfileName(parsed.name || '');
      }
    } catch {}
  }, []);

  return (
    <PageMotion style={{ padding: '2rem 2.5rem', maxWidth: 1200, margin: '0 auto' }}>
      {/* Header */}
      <FadeIn>
        <div style={{ marginBottom: '1.75rem' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 4 }}>
            <motion.div animate={{ rotate: [0, 15, -10, 0] }} transition={{ duration: 2, repeat: Infinity, repeatDelay: 4 }}>
              <Sparkles style={{ width: 18, height: 18, color: GOLD }} />
            </motion.div>
            <span style={{ fontSize: 12, fontWeight: 600, color: GOLD, textTransform: 'uppercase', letterSpacing: '0.1em' }}>Your AI companion</span>
          </div>
          <h1 style={{ fontFamily: 'Playfair Display, serif', fontSize: 'clamp(1.8rem, 3vw, 2.5rem)', fontWeight: 700, color: '#fff', marginBottom: '0.4rem' }}>
            {getGreeting(lang)}{profileName ? `, ${profileName}` : ', Parisien'} 👋
          </h1>
          <p style={{ color: '#6b7280', fontSize: '0.95rem' }}>Everything you need for life in Paris & Île-de-France</p>
        </div>
      </FadeIn>

      {/* Marcel personalised panel OR onboarding CTA */}
      {hasProfile ? (
        <MarcelDashboard />
      ) : (
        <motion.div initial={{ opacity: 0, y: -8 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.15 }}
          style={{ padding: '1.25rem 1.5rem', borderRadius: 16, background: 'linear-gradient(135deg,rgba(0,64,130,0.12),rgba(201,168,76,0.05))', border: '1px solid rgba(0,64,130,0.3)', marginBottom: '1.5rem', display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: '1rem', flexWrap: 'wrap' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.875rem' }}>
            <div style={{ width: 40, height: 40, borderRadius: 12, background: 'linear-gradient(135deg,#004082,#1a5cb5)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 20, flexShrink: 0 }}>🤖</div>
            <div>
              <div style={{ fontWeight: 700, color: '#fff', fontSize: 14, marginBottom: 3 }}>Meet Marcel — Your Personal Paris AI</div>
              <p style={{ color: '#9ca3af', fontSize: 12.5, lineHeight: 1.5 }}>Answer 7 quick questions and Marcel builds your personalised to-do timeline, settled-in score, and recommends exactly what you need first.</p>
            </div>
          </div>
          <Link href="/onboarding" style={{ display: 'inline-flex', alignItems: 'center', gap: 6, padding: '10px 20px', borderRadius: 12, background: 'linear-gradient(135deg,#004082,#1a5cb5)', color: '#fff', fontWeight: 700, fontSize: 13, textDecoration: 'none', flexShrink: 0, boxShadow: '0 0 20px rgba(0,64,130,0.3)' }}>
            <User style={{ width: 14, height: 14 }} /> Set up my profile
          </Link>
        </motion.div>
      )}

      {/* Calendar alert */}
      {alert && (
        <motion.div initial={{ opacity: 0, y: -8 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }}
          style={{ padding: '12px 16px', borderRadius: 12, background: `${alert.color}15`, border: `1px solid ${alert.color}44`, marginBottom: '1.5rem', display: 'flex', alignItems: 'center', gap: 10 }}>
          <span style={{ fontSize: 18 }}>{alert.icon}</span>
          <span style={{ fontSize: 13, fontWeight: 600, color: alert.color }}>{alert.msg}</span>
        </motion.div>
      )}

      {/* Stats */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(140px, 1fr))', gap: '0.875rem', marginBottom: '2rem' }}>
        <StatCard value={12}  label="AI Modules"    color="#3a7bd5" delay={0} />
        <StatCard value={3}   label="Languages"     color="#059669" delay={0.08} />
        <StatCard value={35}  label="Paris POIs"    color="#d97706" suffix="+" delay={0.16} />
        <StatCard value={25}  label="Badges"        color="#db2777" suffix="+" delay={0.24} />
        <StatCard value={100} label="Free & Private" color="#C9A84C" suffix="%" delay={0.32} />
      </div>

      {/* Tools grid */}
      <FadeIn delay={0.2}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '1.1rem' }}>
          <div>
            <h2 style={{ fontWeight: 700, color: '#fff', fontSize: 16 }}>All Tools</h2>
            <p style={{ fontSize: 12, color: '#6b7280' }}>12 AI-powered modules for students & newcomers</p>
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 6, padding: '4px 10px', borderRadius: 20, background: 'rgba(0,64,130,0.15)', border: '1px solid rgba(0,64,130,0.3)' }}>
            <div style={{ width: 6, height: 6, borderRadius: '50%', background: '#22c55e', animation: 'pulse 2s infinite' }} />
            <span style={{ fontSize: 10, fontWeight: 700, color: '#60a5fa' }}>5 NEW features</span>
          </div>
        </div>
      </FadeIn>

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(220px, 1fr))', gap: '0.875rem', marginBottom: '2rem' }}>
        {ALL_TOOLS.map((tool, i) => (
          <motion.div key={tool.path}
            initial={{ opacity: 0, y: 18 }} animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.06 + i * 0.055, type: 'spring', stiffness: 280, damping: 22 }}
            whileHover={{ scale: 1.03, y: -2 }} whileTap={{ scale: 0.97 }}>
            <Link href={tool.path} style={{ textDecoration: 'none', display: 'block', height: '100%' }}>
              <div style={{ padding: '1.1rem 1.25rem', borderRadius: 14, background: 'rgba(255,255,255,0.04)', border: `1px solid ${tool.color}33`, backdropFilter: 'blur(20px)', height: '100%', position: 'relative', overflow: 'hidden', cursor: 'pointer' }}>
                {tool.new && (
                  <div style={{ position: 'absolute', top: 8, right: 8, fontSize: 9, fontWeight: 800, color: '#fff', background: '#ef4444', padding: '2px 6px', borderRadius: 20, letterSpacing: '0.05em' }}>NEW</div>
                )}
                <div style={{ position: 'absolute', top: -16, right: -16, width: 64, height: 64, borderRadius: '50%', background: `radial-gradient(circle,${tool.color}18,transparent)`, pointerEvents: 'none' }} />
                <div style={{ fontSize: 22, marginBottom: '0.6rem' }}>{tool.emoji}</div>
                <div style={{ fontWeight: 700, color: '#fff', marginBottom: '0.3rem', fontSize: 13 }}>{tool.title}</div>
                <div style={{ fontSize: 11, color: '#9ca3af', lineHeight: 1.55, marginBottom: '0.6rem' }}>{tool.desc}</div>
                <div style={{ display: 'flex', alignItems: 'center', gap: 3, fontSize: 10, fontWeight: 700, color: tool.color }}>
                  Open <ArrowRight style={{ width: 10, height: 10 }} />
                </div>
              </div>
            </Link>
          </motion.div>
        ))}
      </div>

      {/* Daily tip */}
      <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.7 }}
        style={{ padding: '1.1rem 1.4rem', borderRadius: 14, background: 'linear-gradient(135deg,rgba(0,64,130,0.08),rgba(201,168,76,0.04))', border: '1px solid rgba(0,64,130,0.18)' }}>
        <div style={{ display: 'flex', gap: '0.875rem', alignItems: 'flex-start' }}>
          <div style={{ width: 36, height: 36, borderRadius: 10, background: 'rgba(0,64,130,0.2)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 18, flexShrink: 0 }}>
            {tip.icon}
          </div>
          <div>
            <div style={{ fontWeight: 700, color: '#fff', marginBottom: '0.3rem', fontSize: 13, display: 'flex', alignItems: 'center', gap: 6 }}>
              <TrendingUp style={{ width: 13, height: 13, color: GOLD }} /> Paris Tip of the Day
            </div>
            <p style={{ fontSize: 13, color: '#9ca3af', lineHeight: 1.65 }}>{tip.tip}</p>
          </div>
        </div>
      </motion.div>
      <style>{`@keyframes pulse { 0%,100%{opacity:1} 50%{opacity:0.4} }`}</style>
    </PageMotion>
  );
}
