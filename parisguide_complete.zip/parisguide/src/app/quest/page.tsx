'use client';
import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Trophy, Zap, Sparkles, Loader2 } from 'lucide-react';
import { BADGE_CATALOG, LEVELS, getLevelInfo, XP_PER_RARITY } from '@/lib/questBadges';
import type { QuestBadge } from '@/types';
import { fireBadgeToast } from '@/components/quest/BadgeUnlockToast';
import { FadeIn } from '@/components/shared/PageMotion';
import StatCard from '@/components/shared/StatCard';

const CATEGORY_LABELS: Record<string, string> = {
  landmark: '🗺️ Landmarks', culture: '🎨 Culture', idf: '🏰 Île-de-France',
  nature: '🌳 Nature & Parks', food: '🍷 Food & Markets', transport: '🚇 Transport',
  language: '🌐 Language', explorer: '💡 Explorer', special: '⭐ Special',
};

export default function QuestPage() {
  const [badges, setBadges] = useState<QuestBadge[]>([]);
  const [loading, setLoading] = useState(true);
  const [demoLoading, setDemoLoading] = useState(false);

  useEffect(() => {
    fetch('/api/badges').then(r => r.json()).then(d => { setBadges(d.badges || []); setLoading(false); });
  }, []);

  const earnedIds = badges.map(b => b.badge_id);
  const totalXP = badges.reduce((s, b) => s + (b.xp || XP_PER_RARITY[b.rarity] || 50), 0);
  const { current: level, next: nextLevel, progress } = getLevelInfo(totalXP);

  const grouped: Record<string, typeof BADGE_CATALOG> = {};
  BADGE_CATALOG.forEach(b => { if (!grouped[b.category]) grouped[b.category] = []; grouped[b.category].push(b); });

  const demoBadge = async () => {
    setDemoLoading(true);
    const unearned = BADGE_CATALOG.filter(b => !earnedIds.includes(b.badge_id));
    const badge = unearned[Math.floor(Math.random() * unearned.length)] || BADGE_CATALOG[0];
    await new Promise(r => setTimeout(r, 400));
    fireBadgeToast({ id: badge.badge_id, emoji: badge.emoji, name: badge.name, description: badge.description, rarity: badge.rarity, xp: XP_PER_RARITY[badge.rarity] });
    setDemoLoading(false);
  };

  const rarityStyle = (rarity: string) => {
    if (rarity === 'legendary') return { border: 'rgba(251,191,36,0.4)', shadow: '0 0 20px rgba(251,191,36,0.15)', star: '#fbbf24', label: '⭐ Legendary' };
    if (rarity === 'rare') return { border: 'rgba(96,165,250,0.4)', shadow: '0 0 16px rgba(96,165,250,0.12)', star: '#60a5fa', label: '💎 Rare' };
    return { border: 'rgba(255,255,255,0.1)', shadow: 'none', star: '#9ca3af', label: '🔹 Common' };
  };

  return (
    <div style={{ padding: '2rem 2.5rem', maxWidth: 1100, margin: '0 auto' }}>
      <FadeIn>
        <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', marginBottom: '2rem', flexWrap: 'wrap', gap: '1rem' }}>
          <div>
            <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 4 }}>
              <Trophy style={{ width: 16, height: 16, color: '#C9A84C' }} />
              <span style={{ fontSize: 12, fontWeight: 600, color: '#C9A84C', textTransform: 'uppercase', letterSpacing: '0.1em' }}>Quest & Badges</span>
            </div>
            <h1 style={{ fontFamily: 'Playfair Display, serif', fontSize: '2rem', fontWeight: 700, color: '#fff' }}>Your Trophies</h1>
            <p style={{ color: '#6b7280', fontSize: 14 }}>Earn XP and unlock badges as you explore Paris</p>
          </div>
          <motion.button whileTap={{ scale: 0.95 }} onClick={demoBadge} disabled={demoLoading}
            style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '10px 18px', borderRadius: 12, background: 'linear-gradient(135deg,#7c3aed,#6d28d9)', border: 'none', cursor: 'pointer', color: '#fff', fontWeight: 700, fontSize: 13 }}>
            {demoLoading ? <Loader2 style={{ width: 14, height: 14, animation: 'spin 1s linear infinite' }} /> : <Sparkles style={{ width: 14, height: 14 }} />}
            Preview Badge Toast
          </motion.button>
        </div>
      </FadeIn>

      {/* XP card */}
      <motion.div initial={{ opacity: 0, scale: 0.97 }} animate={{ opacity: 1, scale: 1 }} transition={{ delay: 0.1 }}
        style={{ padding: '1.5rem', borderRadius: 16, background: 'linear-gradient(135deg,rgba(201,168,76,0.08),rgba(251,191,36,0.04))', border: '1px solid rgba(201,168,76,0.25)', marginBottom: '1.5rem', display: 'grid', gridTemplateColumns: '1fr auto', gap: '1rem', alignItems: 'center' }}>
        <div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 8 }}>
            <span style={{ fontSize: '1.25rem', fontWeight: 700, color: '#C9A84C' }}>Level {level.level}</span>
            <span style={{ padding: '3px 10px', borderRadius: 20, background: 'rgba(201,168,76,0.2)', fontSize: 12, fontWeight: 600, color: '#C9A84C' }}>{level.title}</span>
          </div>
          <div style={{ height: 8, borderRadius: 4, background: 'rgba(255,255,255,0.08)', marginBottom: 8, overflow: 'hidden' }}>
            <motion.div initial={{ width: 0 }} animate={{ width: `${progress}%` }} transition={{ duration: 1.2, ease: 'easeOut', delay: 0.3 }}
              style={{ height: '100%', borderRadius: 4, background: 'linear-gradient(90deg,#C9A84C,#fbbf24)' }} />
          </div>
          <div style={{ fontSize: 12, color: '#9ca3af' }}>
            {totalXP} XP {nextLevel ? `· ${nextLevel.minXP - totalXP} XP to ${nextLevel.title}` : '· Max level!'}
          </div>
        </div>
        <div style={{ textAlign: 'right' }}>
          <div style={{ fontSize: '2rem', fontWeight: 800, color: '#C9A84C' }}>{badges.length}</div>
          <div style={{ fontSize: 12, color: '#6b7280' }}>Badges earned</div>
        </div>
      </motion.div>

      {/* Stats */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3,1fr)', gap: '0.75rem', marginBottom: '2rem' }}>
        <StatCard value={badges.filter(b=>b.rarity==='legendary').length} label="Legendary" color="#fbbf24" prefix="⭐ " delay={0} />
        <StatCard value={badges.filter(b=>b.rarity==='rare').length}      label="Rare"      color="#60a5fa" prefix="💎 " delay={0.1} />
        <StatCard value={badges.filter(b=>b.rarity==='common').length}    label="Common"    color="#9ca3af" prefix="🔹 " delay={0.2} />
      </div>

      {/* Badge grid by category */}
      {Object.entries(grouped).map(([cat, catBadges]) => (
        <div key={cat} style={{ marginBottom: '2rem' }}>
          <h2 style={{ fontWeight: 700, color: '#fff', marginBottom: '1rem', fontSize: '0.95rem' }}>{CATEGORY_LABELS[cat] || cat}</h2>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(190px, 1fr))', gap: '0.75rem' }}>
            {catBadges.map((badge, i) => {
              const earned = earnedIds.includes(badge.badge_id);
              const rs = rarityStyle(badge.rarity);
              return (
                <motion.div key={badge.badge_id}
                  initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.04 }}
                  whileHover={earned ? { scale: 1.04, y: -2 } : {}}
                  style={{ padding: '1rem', borderRadius: 12, background: earned ? 'rgba(255,255,255,0.06)' : 'rgba(255,255,255,0.02)', border: `1px solid ${earned ? rs.border : 'rgba(255,255,255,0.06)'}`, opacity: earned ? 1 : 0.5, boxShadow: earned ? rs.shadow : 'none', transition: 'border-color 0.2s' }}>
                  <div style={{ display: 'flex', alignItems: 'flex-start', gap: 10, marginBottom: 8 }}>
                    <motion.div animate={earned ? { rotate: [0, -8, 8, 0] } : {}} transition={{ duration: 0.5, delay: i * 0.05 }}
                      style={{ fontSize: 26, filter: earned ? 'none' : 'grayscale(1)' }}>
                      {earned ? badge.emoji : '🔒'}
                    </motion.div>
                    <div style={{ flex: 1 }}>
                      <div style={{ fontWeight: 600, fontSize: 13, color: earned ? '#fff' : '#4b5563', marginBottom: 2 }}>{badge.name}</div>
                      <div style={{ fontSize: 10, color: rs.star }}>{rs.label} · {XP_PER_RARITY[badge.rarity]} XP</div>
                    </div>
                  </div>
                  <div style={{ fontSize: 12, color: earned ? '#9ca3af' : '#374151', lineHeight: 1.5 }}>{badge.description}</div>
                  {earned && <div style={{ marginTop: 6, fontSize: 10, color: '#C9A84C', fontWeight: 700 }}>✓ EARNED</div>}
                </motion.div>
              );
            })}
          </div>
        </div>
      ))}

      <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.5 }}
        style={{ padding: '1.25rem 1.5rem', borderRadius: 14, background: 'rgba(0,64,130,0.1)', border: '1px solid rgba(0,64,130,0.2)', marginTop: '1rem' }}>
        <div style={{ fontWeight: 600, color: '#fff', marginBottom: 4, display: 'flex', alignItems: 'center', gap: 8, fontSize: 13 }}>
          <Zap style={{ width: 14, height: 14, color: '#C9A84C' }} /> How to earn badges
        </div>
        <p style={{ fontSize: 13, color: '#9ca3af', lineHeight: 1.7 }}>
          Use the <strong style={{ color: '#fff' }}>AI Chat</strong> to mention visiting landmarks, use <strong style={{ color: '#fff' }}>Translate</strong> for menus or Arabic text,
          and <strong style={{ color: '#fff' }}>generate itineraries</strong> — badges are awarded automatically based on your Paris activity.
        </p>
      </motion.div>
      <style>{`@keyframes spin { from { transform:rotate(0deg) } to { transform:rotate(360deg) } }`}</style>
    </div>
  );
}
