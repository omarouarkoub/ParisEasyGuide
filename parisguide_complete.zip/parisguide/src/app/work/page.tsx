'use client';
import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Briefcase, Sparkles, Loader2, ExternalLink, CheckCircle2 } from 'lucide-react';
import { useLanguage, LANGUAGES } from '@/lib/i18n/LanguageContext';
import { toast } from 'sonner';
import { FadeIn } from '@/components/shared/PageMotion';

const JOB_PLATFORMS = [
  { name: 'LinkedIn', desc: 'Professional network + job listings. Strongest for cadres & tech.', url: 'https://www.linkedin.com', emoji: '💼', color: '#0077b5' },
  { name: 'Welcome to the Jungle', desc: 'Startups, culture-focused listings. Very popular in Paris.', url: 'https://www.welcometothejungle.com', emoji: '🌴', color: '#2ecc71' },
  { name: 'Indeed France', desc: 'Broad market, all sectors. Good for English-language roles.', url: 'https://fr.indeed.com', emoji: '🔍', color: '#003a9b' },
  { name: 'APEC', desc: 'Exclusively cadres (managers). Free. High-quality listings.', url: 'https://www.apec.fr', emoji: '👔', color: '#004082' },
  { name: 'France Travail', desc: 'Former Pôle Emploi. Register for unemployment benefits.', url: 'https://www.francetravail.fr', emoji: '🏛️', color: '#059669' },
  { name: 'Malt', desc: 'Freelance marketplace for consultants, designers, devs.', url: 'https://www.malt.fr', emoji: '🚀', color: '#ff6b6b' },
];

const CONTRACTS = [
  { type: 'CDI', name: 'Contrat à Durée Indéterminée', desc: 'Permanent contract — the gold standard. Hard to terminate. Best for housing applications.', color: '#059669', stability: 5 },
  { type: 'CDD', name: 'Contrat à Durée Déterminée', desc: 'Fixed-term contract. Max 18 months usually. Can be renewed once. Common entry point.', color: '#f59e0b', stability: 3 },
  { type: 'Interim', name: 'Travail Temporaire', desc: 'Agency temp work. Pays 10% "précarité" bonus at end. Flexible but no job security.', color: '#ef4444', stability: 1 },
  { type: 'Portage Salarial', name: 'Umbrella Company', desc: 'Best of freelance + employee: you invoice clients, the portage company handles payroll. Great for consultants.', color: '#8b5cf6', stability: 3 },
  { type: 'Auto-entrepreneur', name: 'Micro-entrepreneur', desc: 'Simplest freelance status. Online registration in 10 min. Revenue limits apply (€77k services / €188k commerce).', color: '#3b82f6', stability: 2 },
];

const RIGHTS = [
  { title: '35-hour work week', desc: 'Standard legal working time. Hours above this are RTT or overtime.', emoji: '⏰' },
  { title: '5 weeks paid leave', desc: '25 working days/year (congés payés). Accrued monthly. Cannot be waived.', emoji: '🏖️' },
  { title: 'Mutuelle', desc: 'Employer must contribute ≥50% to your health top-up insurance.', emoji: '🏥' },
  { title: 'Tickets Restaurant', desc: 'Employer co-funded meal vouchers (~€9–13/day). Used at restaurants + supermarkets.', emoji: '🍽️' },
  { title: '50% Navigo refund', desc: 'Employer must reimburse 50% of your monthly Navigo pass.', emoji: '🚇' },
  { title: 'Prud\'hommes', desc: 'Labour court — free, impartial, handles all employment disputes. Very effective.', emoji: '⚖️' },
];

const COWORKING = [
  { name: 'WeWork Paris', area: 'Multiple locations', price: '~€350/mo', url: 'https://www.wework.com', emoji: '🏢' },
  { name: 'Morning Coworking', area: 'Multiple Paris', price: '~€200/mo', url: 'https://www.morning.co', emoji: '☀️' },
  { name: 'La Ruche', area: 'Various', price: 'From €150/mo', url: 'https://www.laruche.co', emoji: '🐝' },
  { name: 'Kwerk', area: 'Premium, multiple', price: '~€500/mo', url: 'https://www.kwerk.fr', emoji: '✨' },
  { name: 'BNF / Libraries', area: 'All arrondissements', price: 'Free', url: 'https://bibliotheques.paris.fr', emoji: '📚' },
];

export default function WorkPage() {
  const { lang } = useLanguage();
  const langLabel = LANGUAGES.find(l => l.code === lang)?.label ?? "English";
  const [activeTab, setActiveTab] = useState<'jobs' | 'contracts' | 'rights' | 'freelance' | 'cowork'>('jobs');
  const [question, setQuestion] = useState('');
  const [answer, setAnswer] = useState('');
  const [loading, setLoading] = useState(false);

  const QUICK_Q = ['How do I set up as an auto-entrepreneur?', 'What is ACRE tax exemption?', 'How much does an employer cost in France?', 'How to negotiate a CDI?'];

  const ask = async (q?: string) => {
    const query = q || question;
    if (!query.trim()) return;
    setLoading(true); setAnswer('');
    try {
      const res = await fetch('/api/work', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ question: query }) });
      const data = await res.json();
      setAnswer(data.answer || '');
    } catch { toast.error('Connection error'); }
    finally { setLoading(false); }
  };

  const TABS = [
    { id: 'jobs', label: '🔍 Job Search', color: '#004082' },
    { id: 'contracts', label: '📄 Contracts', color: '#059669' },
    { id: 'rights', label: '⚖️ Employee Rights', color: '#d97706' },
    { id: 'freelance', label: '🚀 Freelance', color: '#8b5cf6' },
    { id: 'cowork', label: '🏢 Coworking', color: '#ea580c' },
  ] as const;

  return (
    <div style={{ padding: '2rem 2.5rem', maxWidth: 1100, margin: '0 auto' }}>
      <FadeIn>
        <div style={{ marginBottom: '2rem' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 4 }}>
            <Briefcase style={{ width: 16, height: 16, color: '#C9A84C' }} />
            <span style={{ fontSize: 12, fontWeight: 600, color: '#C9A84C', textTransform: 'uppercase', letterSpacing: '0.1em' }}>Work & Career</span>
          </div>
          <h1 style={{ fontFamily: 'Playfair Display, serif', fontSize: '2rem', fontWeight: 700, color: '#fff' }}>Work & Professional Life</h1>
          <p style={{ color: '#6b7280', fontSize: 14 }}>Job hunting, contracts, rights, freelancing & coworking in Paris</p>
        </div>
      </FadeIn>

      <div style={{ display: 'flex', gap: 6, marginBottom: '1.25rem', flexWrap: 'wrap' }}>
        {TABS.map(tab => (
          <button key={tab.id} onClick={() => setActiveTab(tab.id)}
            style={{ padding: '8px 16px', borderRadius: 20, fontSize: 13, fontWeight: 700, cursor: 'pointer', border: `1px solid ${activeTab === tab.id ? tab.color + '66' : 'rgba(255,255,255,0.08)'}`, background: activeTab === tab.id ? `${tab.color}15` : 'rgba(255,255,255,0.03)', color: activeTab === tab.id ? '#fff' : '#9ca3af', transition: 'all 0.2s' }}>
            {tab.label}
          </button>
        ))}
      </div>

      <AnimatePresence mode="wait">
        {activeTab === 'jobs' && (
          <motion.div key="jobs" initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(290px, 1fr))', gap: '1rem' }}>
              {JOB_PLATFORMS.map(p => (
                <a key={p.name} href={p.url} target="_blank" rel="noreferrer"
                  style={{ padding: '1.1rem', borderRadius: 14, background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.08)', textDecoration: 'none', display: 'block', transition: 'border-color 0.2s' }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 8 }}>
                    <span style={{ fontSize: '1.3rem' }}>{p.emoji}</span>
                    <span style={{ fontWeight: 700, color: '#fff', fontSize: 14 }}>{p.name}</span>
                    <ExternalLink style={{ width: 12, height: 12, color: '#6b7280', marginLeft: 'auto' }} />
                  </div>
                  <div style={{ fontSize: 12, color: '#9ca3af', lineHeight: 1.6 }}>{p.desc}</div>
                </a>
              ))}
            </div>
            <div style={{ marginTop: '1.25rem', padding: '1rem 1.25rem', borderRadius: 12, background: 'rgba(201,168,76,0.08)', border: '1px solid rgba(201,168,76,0.2)', fontSize: 12, color: '#fbbf24' }}>
              💡 <strong>Pro Tip:</strong> English-language networking events: Paris Network, Toastmasters Paris, Internations monthly meetups, and Tech meetups on Meetup.com. LinkedIn is widely used in France — keep your profile in both French and English.
            </div>
          </motion.div>
        )}

        {activeTab === 'contracts' && (
          <motion.div key="contracts" initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '0.75rem' }}>
              {CONTRACTS.map(c => (
                <div key={c.type} style={{ padding: '1.1rem 1.25rem', borderRadius: 14, background: `${c.color}08`, border: `1px solid ${c.color}30` }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem', marginBottom: 6 }}>
                    <span style={{ fontWeight: 800, fontSize: 14, color: c.color, minWidth: 90 }}>{c.type}</span>
                    <span style={{ fontSize: 12, color: '#9ca3af' }}>{c.name}</span>
                    <div style={{ marginLeft: 'auto', display: 'flex', gap: 3 }}>
                      {[1,2,3,4,5].map(i => (
                        <div key={i} style={{ width: 8, height: 8, borderRadius: '50%', background: i <= c.stability ? c.color : 'rgba(255,255,255,0.1)' }} />
                      ))}
                    </div>
                  </div>
                  <div style={{ fontSize: 12, color: '#e5e7eb', lineHeight: 1.6 }}>{c.desc}</div>
                </div>
              ))}
            </div>
          </motion.div>
        )}

        {activeTab === 'rights' && (
          <motion.div key="rights" initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(280px, 1fr))', gap: '1rem' }}>
              {RIGHTS.map(r => (
                <div key={r.title} style={{ padding: '1.1rem', borderRadius: 14, background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.08)' }}>
                  <div style={{ fontSize: '1.5rem', marginBottom: 8 }}>{r.emoji}</div>
                  <div style={{ fontWeight: 700, color: '#fff', fontSize: 14, marginBottom: 4 }}>{r.title}</div>
                  <div style={{ fontSize: 12, color: '#9ca3af', lineHeight: 1.6 }}>{r.desc}</div>
                </div>
              ))}
            </div>
          </motion.div>
        )}

        {activeTab === 'freelance' && (
          <motion.div key="freelance" initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}>
            <div style={{ padding: '1.5rem', borderRadius: 16, background: 'rgba(139,92,246,0.06)', border: '1px solid rgba(139,92,246,0.2)', marginBottom: '1.25rem' }}>
              <div style={{ fontWeight: 700, color: '#fff', marginBottom: '0.75rem', fontSize: 15 }}>🚀 Auto-entrepreneur Setup Guide</div>
              {['Register at autoentrepreneur.urssaf.fr (10 minutes online)', 'Choose your activity code (APE/NAF) — use the URSSAF guide', 'Open a dedicated business bank account (required above €10k/year)', 'File quarterly or monthly revenue declarations on urssaf.fr', 'Invoice clients with your SIRET number + auto-entrepreneur mention', 'Apply for ACRE exemption (50% reduced charges for 1st year) if eligible', 'Consider VAT registration if crossing €36,800 (services) threshold'].map((step, i) => (
                <div key={i} style={{ display: 'flex', gap: 10, marginBottom: 8, fontSize: 13 }}>
                  <span style={{ color: '#a78bfa', fontWeight: 700, flexShrink: 0 }}>{i + 1}.</span>
                  <span style={{ color: '#e5e7eb' }}>{step}</span>
                </div>
              ))}
            </div>
            <div style={{ display: 'flex', gap: 8, marginBottom: '0.75rem' }}>
              <input value={question} onChange={e => setQuestion(e.target.value)} onKeyDown={e => e.key === 'Enter' && ask()}
                placeholder="Ask about auto-entrepreneur, ACRE, VAT, charges…"
                style={{ flex: 1, background: 'rgba(255,255,255,0.06)', border: '1px solid rgba(255,255,255,0.1)', borderRadius: 10, padding: '10px 14px', color: '#fff', fontSize: 14, outline: 'none' }} />
              <button onClick={() => ask()} disabled={loading}
                style={{ padding: '10px 18px', borderRadius: 10, background: 'linear-gradient(135deg,#7c3aed,#5b21b6)', border: 'none', cursor: 'pointer', color: '#fff', fontWeight: 700 }}>
                {loading ? <Loader2 style={{ width: 16, height: 16, animation: 'spin 1s linear infinite' }} /> : 'Ask'}
              </button>
            </div>
            <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap', marginBottom: '1rem' }}>
              {QUICK_Q.map(q => (
                <button key={q} onClick={() => { setQuestion(q); ask(q); }}
                  style={{ padding: '5px 10px', borderRadius: 20, fontSize: 11, cursor: 'pointer', border: '1px solid rgba(139,92,246,0.25)', background: 'rgba(139,92,246,0.06)', color: '#a78bfa' }}>
                  {q}
                </button>
              ))}
            </div>
            {answer && (
              <div style={{ padding: '1rem', borderRadius: 12, background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.08)', fontSize: 13, color: '#e5e7eb', lineHeight: 1.7 }}
                dangerouslySetInnerHTML={{ __html: answer.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>').replace(/\n/g, '<br/>') }} />
            )}
          </motion.div>
        )}

        {activeTab === 'cowork' && (
          <motion.div key="cowork" initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '0.75rem' }}>
              {COWORKING.map(c => (
                <a key={c.name} href={c.url} target="_blank" rel="noreferrer"
                  style={{ padding: '1rem 1.25rem', borderRadius: 14, background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.08)', textDecoration: 'none', display: 'flex', alignItems: 'center', gap: '1rem' }}>
                  <span style={{ fontSize: '1.5rem' }}>{c.emoji}</span>
                  <div style={{ flex: 1 }}>
                    <div style={{ fontWeight: 700, color: '#fff', fontSize: 14 }}>{c.name}</div>
                    <div style={{ fontSize: 12, color: '#9ca3af' }}>📍 {c.area}</div>
                  </div>
                  <div style={{ fontWeight: 700, color: '#34d399', fontSize: 13 }}>{c.price}</div>
                  <ExternalLink style={{ width: 13, height: 13, color: '#6b7280' }} />
                </a>
              ))}
            </div>
            <div style={{ marginTop: '1rem', padding: '1rem', borderRadius: 12, background: 'rgba(201,168,76,0.08)', border: '1px solid rgba(201,168,76,0.2)', fontSize: 12, color: '#fbbf24' }}>
              💡 <strong>Pro Tip:</strong> Paris municipal libraries (bibliothèques de Paris) offer free coworking with WiFi. The BNF (Bibliothèque nationale) requires a free registration. Great quiet spots with no cost.
            </div>
          </motion.div>
        )}
      </AnimatePresence>
      <style>{`@keyframes spin { from { transform:rotate(0deg) } to { transform:rotate(360deg) } }`}</style>
    </div>
  );
}
