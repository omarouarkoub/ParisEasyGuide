'use client';
import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { MapPin, Trophy, ChevronDown, ChevronUp, CheckCircle2, BookOpen } from 'lucide-react';
import { FadeIn } from '@/components/shared/PageMotion';
import { fireBadgeToast } from '@/components/quest/BadgeUnlockToast';

const GOLD = '#C9A84C';
const RED = '#EE2436';

type Cemetery = 'pere_lachaise' | 'montparnasse' | 'montmartre';

interface Grave {
  id: string;
  name: string;
  cemetery: Cemetery;
  born: string;
  died: string;
  knownFor: string;
  sectionDivision: string;
  gpsHint: string;
  story: string;
  funFact: string;
  visitNote: string;
  emoji: string;
  category: string;
  difficulty: 'easy' | 'medium' | 'hard';
  xp: number;
}

const GRAVES: Grave[] = [
  // Père Lachaise
  { id: 'jim_morrison', name: 'Jim Morrison', cemetery: 'pere_lachaise', born: '1943', died: '1971', knownFor: 'Lead singer of The Doors', sectionDivision: 'Division 6', gpsHint: 'Avenue Principale → turn right at the large map board. Look for the crowd.', story: 'Morrison died in Paris aged 27 — officially heart failure, though the circumstances remain murky. He was buried at Père Lachaise after Parisian authorities initially refused. His grave became an international pilgrimage site and was fenced in 2004 after years of vandalism by devoted fans.', funFact: 'Morrison is buried alongside Molière and Balzac — he would have hated how bourgeois the neighborhood is.', visitNote: 'Usually has flowers, notes, and poetry left by pilgrims. Security guards keep order.', emoji: '🎸', category: 'Rock', difficulty: 'easy', xp: 75 },
  { id: 'oscar_wilde', name: 'Oscar Wilde', cemetery: 'pere_lachaise', born: '1854', died: '1900', knownFor: 'Playwright, poet, wit', sectionDivision: 'Division 89', gpsHint: 'Eastern edge of cemetery near Rue de la Réunion. Follow signs from main map.', story: 'Wilde died destitute in Paris, in a hotel on Rue des Beaux-Arts, after his release from Reading Gaol destroyed him financially and socially. His tomb, by sculptor Jacob Epstein, depicts a flying sphinx. For decades visitors left lipstick kisses on the stone; a glass barrier was installed in 2011 to protect it.', funFact: '"Either that wallpaper goes, or I do" — his alleged last words, looking at the hotel room décor.', visitNote: 'The glass barrier now prevents lip prints. Leave a note in the box instead.', emoji: '🪶', category: 'Literature', difficulty: 'easy', xp: 75 },
  { id: 'chopin', name: 'Frédéric Chopin', cemetery: 'pere_lachaise', born: '1810', died: '1849', knownFor: 'Romantic composer and pianist', sectionDivision: 'Division 11', gpsHint: 'Near Avenue du Puits, a white marble tomb usually adorned with flowers and occasionally someone weeping.', story: 'Chopin died of tuberculosis aged 39. His heart was taken to Warsaw (per his wishes) and is still there, in a pillar of the Holy Cross Church. The rest of him is here. His tomb features a mourning muse by Auguste Clésinger, and fresh flowers are almost always present.', funFact: 'Chopin\'s heart has been in Warsaw for 175 years. In 2014, scientists confirmed it shows signs of pericarditis — a complication of tuberculosis.', visitNote: 'Classical music plays from someone\'s phone here almost daily. Brings sheet music if you want to leave a tribute.', emoji: '🎹', category: 'Music', difficulty: 'medium', xp: 100 },
  { id: 'proust', name: 'Marcel Proust', cemetery: 'pere_lachaise', born: '1871', died: '1922', knownFor: 'Author of In Search of Lost Time', sectionDivision: 'Division 85', gpsHint: 'Black marble tomb in the south-eastern section. Easy to miss — look carefully at the inscriptions.', story: 'Proust spent the last years of his life in a cork-lined room in Paris, writing his seven-volume masterpiece. He died of pneumonia after catching a chill. His tomb is strikingly simple for such a towering figure — black granite, minimal inscription. Time, he would have said, does the rest.', funFact: 'In Search of Lost Time is 4,215 pages across 7 volumes. Proust wrote most of it in bed, at night, by lamplight.', visitNote: 'Quieter than Morrison and Wilde. Literary pilgrims leave bookmarks, bookmarks, and more bookmarks.', emoji: '📚', category: 'Literature', difficulty: 'hard', xp: 150 },
  { id: 'edith_piaf', name: 'Édith Piaf', cemetery: 'pere_lachaise', born: '1915', died: '1963', knownFor: 'La Môme — icon of French chanson', sectionDivision: 'Division 97', gpsHint: 'Near the main avenue in the southern section. A simple black granite tomb.', story: 'Piaf — "the little sparrow" — was born on the streets of Belleville and died of liver cancer aged 47. She is buried with her father, her second husband Théo Sarapo, and her infant daughter Marcelle who died aged 2. Over a million people attended her funeral procession, stopping Paris traffic for hours.', funFact: '"Je ne regrette rien" — No, she didn\'t regret anything. Except possibly the 20+ car accidents.', visitNote: 'Always flowers, always someone singing softly nearby on a weekend.', emoji: '🎤', category: 'Music', difficulty: 'easy', xp: 75 },
  { id: 'modigliani', name: 'Amedeo Modigliani', cemetery: 'pere_lachaise', born: '1884', died: '1920', knownFor: 'Painter of elongated portraits', sectionDivision: 'Division 96', gpsHint: 'Near Piaf in Division 96–97 area. His wife Jeanne Hébuterne is buried alongside.', story: 'Modigliani died of tubercular meningitis aged 35, penniless, in Paris. His pregnant wife Jeanne threw herself from a 5th-floor window the next morning. They are buried together. Modigliani\'s work, dismissed in his lifetime, now sells for €150 million at auction.', funFact: 'In 1984 a "lost Modigliani" was found in a Livorno canal during a search. It was immediately revealed as a student prank.', visitNote: 'The double grave is deeply moving. A reminder of how badly Paris treated its great artists.', emoji: '🎨', category: 'Art', difficulty: 'hard', xp: 150 },

  // Montparnasse
  { id: 'sartre_beauvoir', name: 'Sartre & de Beauvoir', cemetery: 'montparnasse', born: '1905 / 1908', died: '1980 / 1986', knownFor: 'Existentialism, feminist philosophy', sectionDivision: 'Near main entrance, Division 20', gpsHint: 'Clearly signposted from the cemetery entrance. One of the most-visited graves.', story: 'Jean-Paul Sartre and Simone de Beauvoir are buried together in a shared grave, their lifelong "open relationship" ending in a shared eternity. Beauvoir outlived Sartre by 6 years. Visitors leave Metro tickets on the tomb — a nod to existentialist freedom and the Paris underground.', funFact: 'Visitors still leave Metro tickets as offerings — existence precedes essence, but apparently a valid Navigo card helps.', visitNote: 'Metro tickets are the traditional offering here. Leave one from your trip.', emoji: '🧠', category: 'Philosophy', difficulty: 'easy', xp: 75 },
  { id: 'baudelaire', name: 'Charles Baudelaire', cemetery: 'montparnasse', born: '1821', died: '1867', knownFor: 'Les Fleurs du Mal, Symbolist poetry', sectionDivision: 'Division 6', gpsHint: 'The tomb features a reclining effigy. Division 6, toward the western wall.', story: 'Baudelaire died of syphilis and laudanum at 46, partially paralysed and almost speechless. Les Fleurs du Mal was prosecuted for obscenity in 1857 — six poems were banned until 1949. His stepfather, General Aupick, is buried in the same tomb. Baudelaire hated him.', funFact: 'Sharing a tomb with the stepfather he despised, for eternity. Even death could not liberate him from Aupick.', visitNote: 'A dark, powerful place. Read "Correspondances" here if you know it.', emoji: '🌹', category: 'Literature', difficulty: 'medium', xp: 100 },
  { id: 'guy_de_maupassant', name: 'Guy de Maupassant', cemetery: 'montparnasse', born: '1850', died: '1893', knownFor: 'Short story master, Bel-Ami', sectionDivision: 'Division 26', gpsHint: 'In the central section. The headstone has a sculpted book relief.', story: 'Maupassant died of syphilis aged 42, in an asylum near Nice. He had tried to cut his own throat the year before. In his prime he wrote over 300 short stories, 6 novels, and famously hated the Eiffel Tower — he lunched there daily to avoid having to look at it.', funFact: 'He lunched in the Eiffel Tower restaurant to avoid seeing the tower. The only place in Paris with that view.', visitNote: 'Bring a Maupassant short story to read. "The Necklace" or "Boule de Suif" are 20-minute reads, perfect on a grave bench.', emoji: '✍️', category: 'Literature', difficulty: 'medium', xp: 100 },

  // Montmartre
  { id: 'stendhal', name: 'Stendhal', cemetery: 'montmartre', born: '1783', died: '1842', knownFor: 'The Red and the Black, Le Rouge et le Noir', sectionDivision: 'Division 3', gpsHint: 'Northern section, Division 3. The tomb inscription is self-written and famously terse.', story: 'Stendhal wrote his own epitaph: "Arrigo Beyle, Milanese. He lived, wrote, loved." He was 59, died of apoplexy on the Rue des Capucines. He predicted his own literary fame 50 years too early — he wrote "I will be read in 1880." He was right.', funFact: '"Arrigo Beyle, Milanese. He lived, wrote, loved." Six words. The most efficient literary legacy in history.', visitNote: 'The tomb is often bare. Bring a red rose — the color of The Red and the Black.', emoji: '❤️', category: 'Literature', difficulty: 'hard', xp: 150 },
  { id: 'truffaut', name: 'François Truffaut', cemetery: 'montmartre', born: '1932', died: '1984', knownFor: 'The 400 Blows, Jules and Jim, New Wave cinema', sectionDivision: 'Division 21', gpsHint: 'Division 21, eastern section. A relatively simple marble slab.', story: 'Truffaut died of a brain tumour aged 52, at the height of his powers. He was the young delinquent who became France\'s greatest film critic, then its greatest director. His grave is in the cemetery of his beloved Montmartre, where he grew up as the troubled child of Les 400 Coups.', funFact: 'The autobiographical child in Les 400 Coups (Antoine Doinel) ends the film running toward the sea. It\'s one of cinema\'s most famous final frames.', visitNote: 'Film lovers often leave single frames of 35mm film on the tomb. A beautiful tradition.', emoji: '🎬', category: 'Film', difficulty: 'medium', xp: 100 },
  { id: 'heine', name: 'Heinrich Heine', cemetery: 'montmartre', born: '1797', died: '1856', knownFor: 'Poet, journalist, early exile from Germany', sectionDivision: 'Division 23', gpsHint: 'Division 23, towards the north wall. A white marble bust marks the grave.', story: 'Heine, the great German-Jewish Romantic poet, spent the last 25 years of his life in Paris — his "mattress grave" period — paralysed from spinal disease, writing some of his most beautiful late poetry. He died in Montmartre, his adopted home. His grave is guarded by a white marble bust.', funFact: '"Where they burn books, they will also burn people." Heine wrote this in 1820. The Nazis burned his books in 1933.', visitNote: 'The prophetic quote above is inscribed in the Bebelplatz in Berlin, where the Nazis burned books. Leave a book here.', emoji: '📜', category: 'Literature', difficulty: 'hard', xp: 150 },
];

const CEMETERY_CONFIG: Record<Cemetery, { name: string; emoji: string; address: string; hours: string; color: string; desc: string }> = {
  pere_lachaise: { name: 'Père Lachaise', emoji: '🏛️', address: '16 Rue du Repos, 20e', hours: 'Mon–Fri 8h–18h, Sat–Sun 8h30–18h', color: GOLD, desc: 'The most visited cemetery in the world. 70,000 graves over 44 hectares.' },
  montparnasse:  { name: 'Montparnasse', emoji: '📚', address: '3 Blvd Edgar Quinet, 14e', hours: 'Daily 8h–18h (seasonal variation)', color: '#60a5fa', desc: 'Home to the great intellectuals, writers, and artists of the Left Bank.' },
  montmartre:    { name: 'Montmartre', emoji: '🎨', address: '20 Avenue Rachel, 18e', hours: 'Mon–Fri 8h–18h, Sat–Sun 9h–18h', color: RED, desc: 'Set in a former quarry, the cemetery of Montmartre\'s bohemian community.' },
};

export default function FamousGravesPage() {
  const [visited, setVisited] = useState<string[]>([]);
  const [cemetery, setCemetery] = useState<Cemetery | 'all'>('all');
  const [expanded, setExpanded] = useState<string | null>(null);
  const [category, setCategory] = useState('All');

  useEffect(() => {
    const v = localStorage.getItem('graves_visited');
    if (v) setVisited(JSON.parse(v));
  }, []);

  const markVisited = (grave: Grave) => {
    if (visited.includes(grave.id)) return;
    const next = [...visited, grave.id];
    setVisited(next);
    localStorage.setItem('graves_visited', JSON.stringify(next));

    fireBadgeToast({ id: `grave_${grave.id}`, emoji: grave.emoji, name: `Visited ${grave.name}`, description: `You found ${grave.name}'s grave!`, rarity: grave.difficulty === 'hard' ? 'legendary' : grave.difficulty === 'medium' ? 'rare' : 'common', xp: grave.xp });

    // Special milestones
    if (next.length === 5) fireBadgeToast({ id: 'graves_5', emoji: '🏆', name: 'Necronaut', description: '5 famous graves found!', rarity: 'rare', xp: 300 });
    if (next.length === GRAVES.length) fireBadgeToast({ id: 'graves_all', emoji: '💀', name: 'Grand Tour Complète', description: 'All famous graves visited. Respect.', rarity: 'legendary', xp: 1000 });
  };

  const categories = ['All', ...Array.from(new Set(GRAVES.map(g => g.category))).sort()];

  const filtered = GRAVES.filter(g => {
    const cMatch = cemetery === 'all' || g.cemetery === cemetery;
    const catMatch = category === 'All' || g.category === category;
    return cMatch && catMatch;
  });

  const totalXP = visited.reduce((acc, id) => {
    const g = GRAVES.find(gr => gr.id === id);
    return acc + (g?.xp || 0);
  }, 0);

  const diffConfig = { easy: { color: '#34d399', label: 'Easy to find' }, medium: { color: GOLD, label: 'Some navigation' }, hard: { color: RED, label: 'Requires searching' } };

  return (
    <div style={{ padding: '2rem 2.5rem', maxWidth: 1100, margin: '0 auto' }}>
      <FadeIn>
        {/* Header */}
        <div style={{ marginBottom: '1.5rem' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 4 }}>
            <Trophy style={{ width: 16, height: 16, color: GOLD }} />
            <span style={{ fontSize: 12, fontWeight: 600, color: GOLD, textTransform: 'uppercase', letterSpacing: '0.1em' }}>GPS Cemetery Quest</span>
          </div>
          <h1 style={{ fontFamily: 'Playfair Display, serif', fontSize: '2rem', fontWeight: 700, color: '#fff', marginBottom: 6 }}>Famous Graves Quest</h1>
          <p style={{ color: '#6b7280', fontSize: 14 }}>Guided hunt through Père Lachaise, Montparnasse & Montmartre cemeteries. Find the graves, read the stories, earn the badges.</p>
        </div>

        {/* Progress panel */}
        <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }}
          style={{ padding: '1.25rem 1.5rem', borderRadius: 16, background: 'linear-gradient(135deg,rgba(201,168,76,0.07),rgba(0,0,0,0.3))', border: '1px solid rgba(201,168,76,0.25)', marginBottom: '1.5rem', display: 'grid', gridTemplateColumns: '1fr auto', gap: '1rem', alignItems: 'center' }}>
          <div>
            <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 10 }}>
              <span style={{ fontSize: '1.5rem', fontWeight: 800, color: GOLD, fontFamily: 'Playfair Display, serif' }}>{visited.length}<span style={{ fontSize: 14, color: '#6b7280', fontFamily: 'sans-serif' }}>/{GRAVES.length}</span></span>
              <span style={{ fontSize: 12, color: '#9ca3af' }}>graves visited</span>
              <span style={{ padding: '3px 10px', borderRadius: 20, background: 'rgba(201,168,76,0.15)', fontSize: 12, color: GOLD, fontWeight: 700 }}>{totalXP} XP</span>
            </div>
            <div style={{ height: 8, borderRadius: 4, background: 'rgba(255,255,255,0.08)', overflow: 'hidden', maxWidth: 400 }}>
              <motion.div initial={{ width: 0 }} animate={{ width: `${(visited.length/GRAVES.length)*100}%` }} transition={{ duration: 1.2, ease: 'easeOut' }}
                style={{ height: '100%', borderRadius: 4, background: 'linear-gradient(90deg,#C9A84C,#EE2436)' }} />
            </div>
          </div>
          <div style={{ textAlign: 'center' }}>
            <div style={{ fontSize: '2rem' }}>{visited.length >= GRAVES.length ? '💀' : visited.length >= 6 ? '🏆' : visited.length >= 3 ? '⚰️' : '🪦'}</div>
            <div style={{ fontSize: 9, color: '#6b7280', fontWeight: 700, marginTop: 2 }}>
              {visited.length >= GRAVES.length ? 'Grand Touriste' : visited.length >= 6 ? 'Necronaut' : visited.length >= 3 ? 'Tomb Raider' : 'Novice'}
            </div>
          </div>
        </motion.div>

        {/* Cemetery cards */}
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3,1fr)', gap: '1rem', marginBottom: '1.5rem' }}>
          {(Object.keys(CEMETERY_CONFIG) as Cemetery[]).map(cem => {
            const cfg = CEMETERY_CONFIG[cem];
            const cemGraves = GRAVES.filter(g => g.cemetery === cem);
            const cemVisited = cemGraves.filter(g => visited.includes(g.id)).length;
            return (
              <button key={cem} onClick={() => setCemetery(cemetery === cem ? 'all' : cem)}
                style={{ padding: '1rem', borderRadius: 12, border: `1px solid ${cemetery === cem ? cfg.color : 'rgba(255,255,255,0.08)'}`, background: cemetery === cem ? `${cfg.color}12` : 'rgba(255,255,255,0.03)', cursor: 'pointer', textAlign: 'left', transition: 'all 0.2s' }}>
                <div style={{ fontSize: 20, marginBottom: 6 }}>{cfg.emoji}</div>
                <div style={{ fontWeight: 700, color: '#fff', fontSize: 13, marginBottom: 2 }}>{cfg.name}</div>
                <div style={{ fontSize: 10, color: '#6b7280', marginBottom: 6 }}>{cfg.address}</div>
                <div style={{ fontSize: 11, color: cfg.color, fontWeight: 700 }}>{cemVisited}/{cemGraves.length} visited</div>
              </button>
            );
          })}
        </div>

        {/* Category filter */}
        <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap', marginBottom: '1.5rem' }}>
          {categories.map(cat => (
            <button key={cat} onClick={() => setCategory(cat)}
              style={{ padding: '5px 12px', borderRadius: 20, border: `1px solid ${category === cat ? GOLD : 'rgba(255,255,255,0.1)'}`, background: category === cat ? 'rgba(201,168,76,0.12)' : 'rgba(255,255,255,0.03)', color: category === cat ? GOLD : '#9ca3af', fontSize: 11, fontWeight: 600, cursor: 'pointer' }}>
              {cat}
            </button>
          ))}
        </div>

        {/* Graves list */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
          {filtered.map((grave, i) => {
            const isVisited = visited.includes(grave.id);
            const isExpanded = expanded === grave.id;
            const cemCfg = CEMETERY_CONFIG[grave.cemetery];
            const diff = diffConfig[grave.difficulty];

            return (
              <motion.div key={grave.id}
                initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.04 }}
                style={{ borderRadius: 14, background: isVisited ? 'rgba(201,168,76,0.06)' : 'rgba(255,255,255,0.02)', border: `1px solid ${isVisited ? 'rgba(201,168,76,0.35)' : 'rgba(255,255,255,0.07)'}`, overflow: 'hidden' }}>

                <div style={{ padding: '1.25rem' }}>
                  <div style={{ display: 'grid', gridTemplateColumns: '1fr auto', gap: '1rem', alignItems: 'start' }}>
                    <div>
                      <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 6 }}>
                        <span style={{ fontSize: 22 }}>{grave.emoji}</span>
                        <div>
                          <div style={{ fontWeight: 700, color: '#fff', fontSize: 15 }}>{grave.name}</div>
                          <div style={{ fontSize: 11, color: '#6b7280' }}>{grave.born}–{grave.died} · {grave.knownFor}</div>
                        </div>
                      </div>

                      <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap', marginBottom: 8 }}>
                        <span style={{ padding: '2px 8px', borderRadius: 10, background: `${cemCfg.color}15`, fontSize: 10, color: cemCfg.color, fontWeight: 700 }}>{cemCfg.emoji} {cemCfg.name}</span>
                        <span style={{ padding: '2px 8px', borderRadius: 10, background: 'rgba(255,255,255,0.05)', fontSize: 10, color: '#9ca3af' }}>{grave.category}</span>
                        <span style={{ padding: '2px 8px', borderRadius: 10, background: `${diff.color}15`, fontSize: 10, color: diff.color, fontWeight: 600 }}>{diff.label}</span>
                        <span style={{ padding: '2px 8px', borderRadius: 10, background: 'rgba(201,168,76,0.1)', fontSize: 10, color: GOLD, fontWeight: 700 }}>+{grave.xp} XP</span>
                      </div>

                      <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                        <MapPin style={{ width: 11, height: 11, color: '#6b7280' }} />
                        <span style={{ fontSize: 11, color: '#6b7280' }}>{grave.sectionDivision}</span>
                      </div>
                    </div>

                    <div style={{ display: 'flex', flexDirection: 'column', gap: 8, alignItems: 'flex-end' }}>
                      {isVisited ? (
                        <div style={{ display: 'flex', alignItems: 'center', gap: 5, fontSize: 12, color: GOLD, fontWeight: 700 }}>
                          <CheckCircle2 style={{ width: 14, height: 14 }} /> Visited
                        </div>
                      ) : (
                        <button onClick={() => markVisited(grave)}
                          style={{ padding: '7px 14px', borderRadius: 10, border: `1px solid ${cemCfg.color}50`, background: `${cemCfg.color}12`, color: cemCfg.color, fontWeight: 700, fontSize: 12, cursor: 'pointer' }}>
                          ✓ Mark Visited
                        </button>
                      )}
                      <button onClick={() => setExpanded(isExpanded ? null : grave.id)}
                        style={{ display: 'flex', alignItems: 'center', gap: 4, padding: '5px 10px', borderRadius: 8, border: '1px solid rgba(255,255,255,0.1)', background: 'transparent', color: '#9ca3af', fontSize: 11, cursor: 'pointer' }}>
                        <BookOpen style={{ width: 11, height: 11 }} />
                        Story {isExpanded ? <ChevronUp style={{ width: 11, height: 11 }} /> : <ChevronDown style={{ width: 11, height: 11 }} />}
                      </button>
                    </div>
                  </div>
                </div>

                {/* Expanded story */}
                <AnimatePresence>
                  {isExpanded && (
                    <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: 'auto', opacity: 1 }} exit={{ height: 0, opacity: 0 }} transition={{ duration: 0.3 }}
                      style={{ overflow: 'hidden', borderTop: '1px solid rgba(255,255,255,0.06)' }}>
                      <div style={{ padding: '1.25rem', display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1.5rem' }}>
                        <div>
                          <div style={{ fontSize: 10, fontWeight: 700, color: '#6b7280', textTransform: 'uppercase', letterSpacing: '0.08em', marginBottom: 6 }}>Their Story</div>
                          <p style={{ fontSize: 12, color: '#d1d5db', lineHeight: 1.7, margin: 0 }}>{grave.story}</p>
                        </div>
                        <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
                          <div style={{ padding: '12px', borderRadius: 10, background: 'rgba(201,168,76,0.07)', border: '1px solid rgba(201,168,76,0.2)' }}>
                            <div style={{ fontSize: 10, fontWeight: 700, color: GOLD, marginBottom: 4 }}>⚡ FUN FACT</div>
                            <div style={{ fontSize: 12, color: '#fde68a', lineHeight: 1.5 }}>{grave.funFact}</div>
                          </div>
                          <div style={{ padding: '12px', borderRadius: 10, background: 'rgba(0,64,130,0.12)', border: '1px solid rgba(0,64,130,0.25)' }}>
                            <div style={{ fontSize: 10, fontWeight: 700, color: '#93c5fd', marginBottom: 4 }}>📍 GPS HINT</div>
                            <div style={{ fontSize: 12, color: '#bfdbfe', lineHeight: 1.5 }}>{grave.gpsHint}</div>
                          </div>
                          <div style={{ padding: '12px', borderRadius: 10, background: 'rgba(255,255,255,0.03)', border: '1px solid rgba(255,255,255,0.08)' }}>
                            <div style={{ fontSize: 10, fontWeight: 700, color: '#9ca3af', marginBottom: 4 }}>👁️ VISIT NOTE</div>
                            <div style={{ fontSize: 12, color: '#d1d5db', lineHeight: 1.5 }}>{grave.visitNote}</div>
                          </div>
                        </div>
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </motion.div>
            );
          })}
        </div>
      </FadeIn>
    </div>
  );
}
