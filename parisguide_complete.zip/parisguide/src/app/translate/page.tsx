'use client';
import { useState } from 'react';
import { Languages, ArrowLeftRight, Sparkles, Copy, Check, Upload, X, Loader2 } from 'lucide-react';
import { toast } from 'sonner';
import { useLanguage } from '@/lib/i18n/LanguageContext';

const LANGS = ['French', 'English', 'Arabic', 'Portuguese', 'Mandarin', 'Hindi'];

const UI: Record<string, Record<string, string>> = {
  en: { title: 'Translate', subtitle: 'Text & image OCR in 6 languages', from: 'From', to: 'To', placeholder: 'Enter text to translate…', btn: 'Translate', result: 'Translation', copy: 'Copy', attach: 'Image attached — ready to translate', upload: 'Upload image for OCR translation' },
  fr: { title: 'Traduction', subtitle: 'Texte et OCR image en 6 langues', from: 'De', to: 'Vers', placeholder: 'Saisissez le texte à traduire…', btn: 'Traduire', result: 'Traduction', copy: 'Copier', attach: 'Image jointe — prête à traduire', upload: 'Importez une image pour la traduction OCR' },
  ar: { title: 'ترجمة', subtitle: 'نص وتعرف ضوئي بـ 6 لغات', from: 'من', to: 'إلى', placeholder: 'أدخل النص للترجمة…', btn: 'ترجم', result: 'الترجمة', copy: 'نسخ', attach: 'صورة مرفقة — جاهزة للترجمة', upload: 'ارفع صورة للترجمة الضوئية' },
  pt: { title: 'Traduzir', subtitle: 'Texto e OCR em 6 idiomas', from: 'De', to: 'Para', placeholder: 'Digite o texto para traduzir…', btn: 'Traduzir', result: 'Tradução', copy: 'Copiar', attach: 'Imagem anexada — pronta para traduzir', upload: 'Envie imagem para tradução OCR' },
  zh: { title: '翻译', subtitle: '6种语言文本和图像OCR', from: '从', to: '到', placeholder: '输入要翻译的文本…', btn: '翻译', result: '翻译结果', copy: '复制', attach: '图片已附加 — 准备翻译', upload: '上传图片进行OCR翻译' },
  hi: { title: 'अनुवाद', subtitle: '6 भाषाओं में टेक्स्ट और इमेज OCR', from: 'से', to: 'तक', placeholder: 'अनुवाद के लिए टेक्स्ट दर्ज करें…', btn: 'अनुवाद करें', result: 'अनुवाद', copy: 'कॉपी करें', attach: 'छवि संलग्न — अनुवाद के लिए तैयार', upload: 'OCR अनुवाद के लिए छवि अपलोड करें' },
};

export default function TranslatePage() {
  const { lang } = useLanguage();
  const ui = UI[lang] ?? UI['en'];

  const [fromLang, setFromLang] = useState('French');
  const [toLang, setToLang] = useState('English');
  const [inputText, setInputText] = useState('');
  const [translated, setTranslated] = useState('');
  const [loading, setLoading] = useState(false);
  const [copied, setCopied] = useState(false);
  const [imageFile, setImageFile] = useState<string | null>(null);
  const fileInputId = 'translate-file-input';

  const swap = () => {
    setFromLang(toLang);
    setToLang(fromLang);
    setInputText(translated);
    setTranslated('');
  };

  const translate = async () => {
    if (!inputText.trim() && !imageFile) return;
    setLoading(true);
    setTranslated('');
    try {
      const res = await fetch('/api/translate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ text: inputText, fromLang, toLang, image: imageFile }),
      });
      const data = await res.json();
      if (data.error) throw new Error(data.error);
      setTranslated(data.result);
      toast.success({ en: 'Translation complete!', fr: 'Traduction terminée !', ar: 'اكتملت الترجمة!', pt: 'Tradução concluída!', zh: '翻译完成！', hi: 'अनुवाद पूर्ण!' }[lang] ?? 'Done!');
    } catch {
      toast.error({ en: 'Translation failed. Please try again.', fr: 'Échec de la traduction.', ar: 'فشل الترجمة.', pt: 'Tradução falhou.', zh: '翻译失败。', hi: 'अनुवाद विफल।' }[lang] ?? 'Failed');
    } finally {
      setLoading(false);
    }
  };

  const copy = () => {
    navigator.clipboard.writeText(translated);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
    toast.success(ui.copy + '!');
  };

  const handleImage = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => setImageFile((reader.result as string).split(',')[1]);
    reader.readAsDataURL(file);
  };

  const GOLD = '#C9A84C';
  const cardStyle = { borderRadius: 16, background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.08)', overflow: 'hidden' };

  return (
    <div style={{ padding: '2rem 1.5rem', maxWidth: 900, margin: '0 auto' }}>
      {/* Header */}
      <div style={{ marginBottom: '2rem' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 4 }}>
          <Languages style={{ width: 16, height: 16, color: GOLD }} />
          <span style={{ fontSize: 12, fontWeight: 600, color: GOLD, textTransform: 'uppercase', letterSpacing: '0.1em' }}>AI Translation</span>
        </div>
        <h1 style={{ fontFamily: 'Playfair Display, serif', fontSize: '2rem', fontWeight: 700, color: '#fff' }}>{ui.title}</h1>
        <p style={{ color: '#6b7280', fontSize: 14 }}>{ui.subtitle}</p>
      </div>

      {/* Language selector row */}
      <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem', marginBottom: '1.5rem', flexWrap: 'wrap' }}>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 4, flex: 1, minWidth: 200 }}>
          <span style={{ fontSize: 11, color: '#6b7280', fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.05em' }}>{ui.from}</span>
          <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}>
            {LANGS.map(l => (
              <button key={l} onClick={() => setFromLang(l)}
                style={{ padding: '7px 14px', borderRadius: 10, fontSize: 12, fontWeight: 600, cursor: 'pointer', border: 'none', background: fromLang === l ? '#7c3aed' : 'rgba(255,255,255,0.06)', color: fromLang === l ? '#fff' : '#9ca3af', transition: 'all 0.15s' }}>
                {l}
              </button>
            ))}
          </div>
        </div>

        <button onClick={swap}
          style={{ padding: 10, borderRadius: 12, background: 'rgba(255,255,255,0.06)', border: '1px solid rgba(255,255,255,0.1)', cursor: 'pointer', color: '#9ca3af', marginTop: 18, flexShrink: 0 }}>
          <ArrowLeftRight style={{ width: 16, height: 16 }} />
        </button>

        <div style={{ display: 'flex', flexDirection: 'column', gap: 4, flex: 1, minWidth: 200 }}>
          <span style={{ fontSize: 11, color: '#6b7280', fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.05em' }}>{ui.to}</span>
          <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}>
            {LANGS.map(l => (
              <button key={l} onClick={() => setToLang(l)}
                style={{ padding: '7px 14px', borderRadius: 10, fontSize: 12, fontWeight: 600, cursor: 'pointer', border: 'none', background: toLang === l ? '#2563eb' : 'rgba(255,255,255,0.06)', color: toLang === l ? '#fff' : '#9ca3af', transition: 'all 0.15s' }}>
                {l}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Image attached banner */}
      {imageFile && (
        <div style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '10px 14px', marginBottom: 12, borderRadius: 12, background: 'rgba(124,58,237,0.12)', border: '1px solid rgba(124,58,237,0.3)' }}>
          <Upload style={{ width: 14, height: 14, color: '#a78bfa' }} />
          <span style={{ fontSize: 13, color: '#a78bfa', flex: 1 }}>{ui.attach}</span>
          <button onClick={() => setImageFile(null)} style={{ background: 'none', border: 'none', cursor: 'pointer', color: '#6b7280' }}><X style={{ width: 14, height: 14 }} /></button>
        </div>
      )}

      {/* Translation panes */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem', marginBottom: '1rem' }}>
        {/* Input */}
        <div style={cardStyle}>
          <div style={{ padding: '0.75rem 1rem', borderBottom: '1px solid rgba(255,255,255,0.06)', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
            <span style={{ fontSize: 12, fontWeight: 700, color: '#9ca3af' }}>{fromLang}</span>
            <div style={{ display: 'flex', gap: 6 }}>
              <label htmlFor={fileInputId} style={{ padding: '5px 10px', borderRadius: 8, fontSize: 11, fontWeight: 600, cursor: 'pointer', background: 'rgba(124,58,237,0.15)', border: '1px solid rgba(124,58,237,0.3)', color: '#a78bfa', display: 'flex', alignItems: 'center', gap: 4 }}>
                <Upload style={{ width: 11, height: 11 }} /> OCR
              </label>
              <input id={fileInputId} type="file" accept="image/*" onChange={handleImage} style={{ display: 'none' }} />
            </div>
          </div>
          <textarea
            value={inputText}
            onChange={e => setInputText(e.target.value)}
            onKeyDown={e => e.key === 'Enter' && e.ctrlKey && translate()}
            placeholder={ui.placeholder}
            style={{ width: '100%', minHeight: 200, padding: '1rem', background: 'transparent', border: 'none', outline: 'none', color: '#fff', fontSize: 15, lineHeight: 1.7, resize: 'vertical', boxSizing: 'border-box' }}
          />
        </div>

        {/* Output */}
        <div style={cardStyle}>
          <div style={{ padding: '0.75rem 1rem', borderBottom: '1px solid rgba(255,255,255,0.06)', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
            <span style={{ fontSize: 12, fontWeight: 700, color: '#9ca3af' }}>{toLang}</span>
            {translated && (
              <button onClick={copy} style={{ padding: '5px 10px', borderRadius: 8, fontSize: 11, fontWeight: 600, cursor: 'pointer', background: 'rgba(16,185,129,0.12)', border: '1px solid rgba(16,185,129,0.3)', color: '#34d399', display: 'flex', alignItems: 'center', gap: 4 }}>
                {copied ? <Check style={{ width: 11, height: 11 }} /> : <Copy style={{ width: 11, height: 11 }} />}
                {ui.copy}
              </button>
            )}
          </div>
          <div style={{ padding: '1rem', minHeight: 200, color: translated ? '#fff' : '#4b5563', fontSize: 15, lineHeight: 1.7, whiteSpace: 'pre-wrap' }}>
            {loading
              ? <div style={{ display: 'flex', alignItems: 'center', gap: 8, color: '#6b7280' }}><Loader2 style={{ width: 16, height: 16, animation: 'spin 1s linear infinite' }} /> Translating…</div>
              : translated || <span style={{ fontStyle: 'italic', fontSize: 13 }}>{ui.result} {ui.from.toLowerCase()} {fromLang} → {toLang}</span>
            }
          </div>
        </div>
      </div>

      {/* Translate button */}
      <div style={{ display: 'flex', justifyContent: 'center' }}>
        <button
          onClick={translate}
          disabled={loading || (!inputText.trim() && !imageFile)}
          style={{
            display: 'flex', alignItems: 'center', gap: 8,
            padding: '12px 32px', borderRadius: 12,
            background: loading || (!inputText.trim() && !imageFile) ? 'rgba(255,255,255,0.06)' : 'linear-gradient(135deg, #7c3aed, #2563eb)',
            border: 'none', cursor: loading || (!inputText.trim() && !imageFile) ? 'not-allowed' : 'pointer',
            color: '#fff', fontSize: 14, fontWeight: 700,
            boxShadow: (!loading && (inputText.trim() || imageFile)) ? '0 0 24px rgba(124,58,237,0.3)' : 'none',
            transition: 'all 0.2s',
          }}>
          {loading
            ? <><Loader2 style={{ width: 16, height: 16, animation: 'spin 1s linear infinite' }} /> Translating…</>
            : <><Sparkles style={{ width: 16, height: 16 }} /> {ui.btn}</>
          }
        </button>
      </div>
      <p style={{ textAlign: 'center', marginTop: '0.75rem', fontSize: 11, color: '#374151' }}>
        Ctrl+Enter to translate · Supports French, English, Arabic, Portuguese, Mandarin, Hindi
      </p>
      <style>{`@keyframes spin{from{transform:rotate(0deg)}to{transform:rotate(360deg)}}`}</style>
    </div>
  );
}
