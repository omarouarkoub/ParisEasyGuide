'use client';
import { useState } from 'react';
import { motion } from 'framer-motion';
import { Sun, Clock, Compass, Camera } from 'lucide-react';
import { FadeIn } from '@/components/shared/PageMotion';

const GOLD = '#C9A84C';

interface LightSpot {
  id: string;
  street: string;
  arrondissement: string;
  direction: string;
  bestSeason: string[];
  bestHours: { morning?: string; afternoon?: string; evening?: string };
  lightType: string;
  lightEmoji: string;
  photographerNotes: string;
  coordinates: string;
  rating: number;
}

const SPOTS: LightSpot[] = [
  {
    id: 'rue_de_rivoli',
    street: 'Rue de Rivoli',
    arrondissement: '1er',
    direction: 'East-West',
    bestSeason: ['Spring', 'Summer'],
    bestHours: { morning: '7h–9h', evening: '18h–20h' },
    lightType: 'Golden Hour Colonnade',
    lightEmoji: '🌅',
    photographerNotes: 'The arcades channel golden light into perfect shadow-stripe compositions at dawn. Summer evenings create cathedral-like beams.',
    coordinates: '48.8632, 2.3411',
    rating: 5,
  },
  {
    id: 'boulevard_haussmann',
    street: 'Boulevard Haussmann',
    arrondissement: '8e–9e',
    direction: 'Northeast-Southwest',
    bestSeason: ['Autumn', 'Winter'],
    bestHours: { afternoon: '14h–16h', evening: '16h–17h30' },
    lightType: 'Low Winter Rake Light',
    lightEmoji: '🌤️',
    photographerNotes: 'Winter sun cuts low and rakes across zinc rooftops and wrought-iron balconies. October–December peak.',
    coordinates: '48.8764, 2.3380',
    rating: 5,
  },
  {
    id: 'rue_mouffetard',
    street: 'Rue Mouffetard',
    arrondissement: '5e',
    direction: 'North-South (sloping)',
    bestSeason: ['Spring', 'Autumn'],
    bestHours: { morning: '8h–10h', afternoon: '15h–17h' },
    lightType: 'Dappled Market Light',
    lightEmoji: '✨',
    photographerNotes: 'The curved cobblestone descent catches diffused morning light beautifully. Awnings add color contrast. Avoid midday harsh shadows.',
    coordinates: '48.8422, 2.3505',
    rating: 4,
  },
  {
    id: 'place_des_vosges',
    street: 'Place des Vosges',
    arrondissement: '4e',
    direction: 'All cardinal',
    bestSeason: ['All year'],
    bestHours: { morning: '7h30–9h30', afternoon: '16h–18h' },
    lightType: 'Soft Courtyard Bounce',
    lightEmoji: '🌸',
    photographerNotes: 'The symmetrical arcades create perfect reflected fill light. South side gets dramatic morning hits. The garden fountain sparkles year-round.',
    coordinates: '48.8553, 2.3625',
    rating: 5,
  },
  {
    id: 'rue_lepic',
    street: 'Rue Lepic',
    arrondissement: '18e',
    direction: 'West-facing upper section',
    bestSeason: ['Summer', 'Autumn'],
    bestHours: { evening: '19h–21h' },
    lightType: 'Sunset Montmartre Glow',
    lightEmoji: '🌇',
    photographerNotes: 'The winding ascent faces west. In summer, the last 90 minutes of daylight paint the cream Haussmann facades amber-rose.',
    coordinates: '48.8845, 2.3373',
    rating: 4,
  },
  {
    id: 'quai_de_bourbon',
    street: 'Quai de Bourbon',
    arrondissement: '4e (Île Saint-Louis)',
    direction: 'South-facing',
    bestSeason: ['Winter', 'Spring'],
    bestHours: { afternoon: '12h–15h' },
    lightType: 'River-Reflected Brilliance',
    lightEmoji: '💎',
    photographerNotes: 'Seine reflections amplify light onto south-facing mansions. Winter is peak — low sun + ice-clear air. Stunning at any season.',
    coordinates: '48.8520, 2.3553',
    rating: 5,
  },
  {
    id: 'rue_de_bretagne',
    street: 'Rue de Bretagne',
    arrondissement: '3e',
    direction: 'North-South',
    bestSeason: ['Spring', 'Summer'],
    bestHours: { morning: '9h–11h' },
    lightType: 'Marché des Enfants Rouges Glow',
    lightEmoji: '🛒',
    photographerNotes: "The oldest covered market in Paris sits mid-street. Morning light creates a warm glow on the iron-and-glass structure. Chef's market atmosphere.",
    coordinates: '48.8628, 2.3611',
    rating: 4,
  },
  {
    id: 'avenue_de_segur',
    street: 'Avenue de Ségur',
    arrondissement: '7e',
    direction: 'Eiffel Tower axis',
    bestSeason: ['Summer'],
    bestHours: { evening: '20h–22h' },
    lightType: 'Tower Illumination Frame',
    lightEmoji: '🗼',
    photographerNotes: 'The tree-lined avenue frames the Eiffel Tower at end. Summer twilight creates a layered silhouette effect with the tower illumination kicking in.',
    coordinates: '48.8501, 2.3081',
    rating: 4,
  },
];

const SEASONS = ['All year', 'Spring', 'Summer', 'Autumn', 'Winter'];
const TIMES = ['All day', 'Morning (6–12h)', 'Afternoon (12–18h)', 'Evening (18–22h)'];

function StarRating({ value }: { value: number }) {
  return <span>{Array.from({ length: 5 }, (_, i) => <span key={i} style={{ color: i < value ? GOLD : 'rgba(255,255,255,0.2)', fontSize: 12 }}>★</span>)}</span>;
}

function SunPosition({ hour }: { hour: number }) {
  const pct = ((hour - 6) / 16) * 100;
  return (
    <div style={{ position: 'relative', height: 32, background: 'rgba(0,0,0,0.3)', borderRadius: 16, overflow: 'hidden', marginTop: 8 }}>
      <div style={{ position: 'absolute', inset: 0, background: 'linear-gradient(90deg, rgba(30,80,120,0.8) 0%, rgba(255,160,50,0.8) 30%, rgba(255,220,100,0.8) 50%, rgba(255,160,50,0.8) 70%, rgba(30,80,120,0.8) 100%)' }} />
      <motion.div
        initial={{ left: '0%' }}
        animate={{ left: `${pct}%` }}
        transition={{ duration: 1, ease: 'easeOut' }}
        style={{ position: 'absolute', top: '50%', transform: 'translate(-50%,-50%)', fontSize: 18, zIndex: 1 }}>
        ☀️
      </motion.div>
      <div style={{ position: 'absolute', left: 8, top: '50%', transform: 'translateY(-50%)', fontSize: 9, color: 'rgba(255,255,255,0.6)', fontWeight: 700 }}>6h</div>
      <div style={{ position: 'absolute', right: 8, top: '50%', transform: 'translateY(-50%)', fontSize: 9, color: 'rgba(255,255,255,0.6)', fontWeight: 700 }}>22h</div>
    </div>
  );
}

export default function WindowLightPage() {
  const [season, setSeason] = useState('All year');
  const [time, setTime] = useState('All day');
  const [currentHour, setCurrentHour] = useState(new Date().getHours());
  const [selected, setSelected] = useState<string | null>(null);

  const filtered = SPOTS.filter(s => {
    const seasonMatch = season === 'All year' || s.bestSeason.includes(season) || s.bestSeason.includes('All year');
    if (!seasonMatch) return false;
    if (time === 'All day') return true;
    if (time === 'Morning (6–12h)') return !!s.bestHours.morning;
    if (time === 'Afternoon (12–18h)') return !!s.bestHours.afternoon;
    if (time === 'Evening (18–22h)') return !!s.bestHours.evening;
    return true;
  });

  const selectedSpot = SPOTS.find(s => s.id === selected);

  return (
    <div style={{ padding: '2rem 2.5rem', maxWidth: 1100, margin: '0 auto' }}>
      <FadeIn>
        <div style={{ marginBottom: '1.5rem' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 4 }}>
            <Sun style={{ width: 16, height: 16, color: GOLD }} />
            <span style={{ fontSize: 12, fontWeight: 600, color: GOLD, textTransform: 'uppercase', letterSpacing: '0.1em' }}>Haussmann Light Guide</span>
          </div>
          <h1 style={{ fontFamily: 'Playfair Display, serif', fontSize: '2rem', fontWeight: 700, color: '#fff', marginBottom: 6 }}>Window Light Tracker</h1>
          <p style={{ color: '#6b7280', fontSize: 14 }}>Find which Paris streets catch the perfect light right now — golden hour, river reflections, winter rake light.</p>
        </div>

        {/* Live sun tracker */}
        <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }}
          style={{ padding: '1.25rem 1.5rem', borderRadius: 16, background: 'linear-gradient(135deg,rgba(201,168,76,0.08),rgba(0,64,130,0.06))', border: '1px solid rgba(201,168,76,0.2)', marginBottom: '1.5rem' }}>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 6 }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
              <Clock style={{ width: 14, height: 14, color: GOLD }} />
              <span style={{ fontSize: 13, fontWeight: 700, color: '#fff' }}>Current Time in Paris: {String(currentHour).padStart(2,'0')}h00</span>
            </div>
            <div style={{ display: 'flex', gap: 6 }}>
              {[7, 10, 14, 17, 20].map(h => (
                <button key={h} onClick={() => setCurrentHour(h)}
                  style={{ padding: '3px 8px', borderRadius: 8, border: `1px solid ${currentHour === h ? GOLD : 'rgba(255,255,255,0.1)'}`, background: currentHour === h ? 'rgba(201,168,76,0.15)' : 'transparent', color: currentHour === h ? GOLD : '#6b7280', fontSize: 11, fontWeight: 700, cursor: 'pointer' }}>
                  {h}h
                </button>
              ))}
            </div>
          </div>
          <SunPosition hour={currentHour} />
        </motion.div>

        {/* Filters */}
        <div style={{ display: 'flex', gap: '1rem', flexWrap: 'wrap', marginBottom: '1.5rem' }}>
          <div>
            <div style={{ fontSize: 10, color: '#6b7280', marginBottom: 6, fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.08em' }}>Season</div>
            <div style={{ display: 'flex', gap: 6 }}>
              {SEASONS.map(s => (
                <button key={s} onClick={() => setSeason(s)}
                  style={{ padding: '5px 12px', borderRadius: 20, border: `1px solid ${season === s ? GOLD : 'rgba(255,255,255,0.12)'}`, background: season === s ? 'rgba(201,168,76,0.12)' : 'rgba(255,255,255,0.04)', color: season === s ? GOLD : '#9ca3af', fontSize: 11, fontWeight: 600, cursor: 'pointer' }}>
                  {s}
                </button>
              ))}
            </div>
          </div>
          <div>
            <div style={{ fontSize: 10, color: '#6b7280', marginBottom: 6, fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.08em' }}>Time of Day</div>
            <div style={{ display: 'flex', gap: 6 }}>
              {TIMES.map(t => (
                <button key={t} onClick={() => setTime(t)}
                  style={{ padding: '5px 12px', borderRadius: 20, border: `1px solid ${time === t ? '#60a5fa' : 'rgba(255,255,255,0.12)'}`, background: time === t ? 'rgba(96,165,250,0.12)' : 'rgba(255,255,255,0.04)', color: time === t ? '#60a5fa' : '#9ca3af', fontSize: 11, fontWeight: 600, cursor: 'pointer' }}>
                  {t}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Results count */}
        <div style={{ fontSize: 12, color: '#6b7280', marginBottom: '1rem' }}>{filtered.length} light spot{filtered.length !== 1 ? 's' : ''} found</div>

        {/* Spots grid */}
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill,minmax(320px,1fr))', gap: '1rem' }}>
          {filtered.map((spot, i) => {
            const isSelected = selected === spot.id;
            return (
              <motion.div key={spot.id}
                initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.05 }}
                whileHover={{ y: -2 }}
                onClick={() => setSelected(isSelected ? null : spot.id)}
                style={{ padding: '1.25rem', borderRadius: 14, background: isSelected ? 'rgba(201,168,76,0.07)' : 'rgba(255,255,255,0.03)', border: `1px solid ${isSelected ? 'rgba(201,168,76,0.35)' : 'rgba(255,255,255,0.08)'}`, cursor: 'pointer', transition: 'all 0.2s' }}>

                <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', marginBottom: 8 }}>
                  <div>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 4 }}>
                      <span style={{ fontSize: 20 }}>{spot.lightEmoji}</span>
                      <div>
                        <div style={{ fontWeight: 700, color: '#fff', fontSize: 14 }}>{spot.street}</div>
                        <div style={{ fontSize: 11, color: '#6b7280' }}>{spot.arrondissement}</div>
                      </div>
                    </div>
                  </div>
                  <StarRating value={spot.rating} />
                </div>

                <div style={{ display: 'inline-block', padding: '3px 10px', borderRadius: 20, background: 'rgba(201,168,76,0.1)', border: '1px solid rgba(201,168,76,0.25)', fontSize: 11, color: GOLD, fontWeight: 600, marginBottom: 10 }}>
                  {spot.lightType}
                </div>

                <div style={{ display: 'flex', gap: 12, marginBottom: 10, flexWrap: 'wrap' }}>
                  {spot.bestHours.morning && <div style={{ fontSize: 11, color: '#fbbf24' }}>🌅 {spot.bestHours.morning}</div>}
                  {spot.bestHours.afternoon && <div style={{ fontSize: 11, color: '#60a5fa' }}>☀️ {spot.bestHours.afternoon}</div>}
                  {spot.bestHours.evening && <div style={{ fontSize: 11, color: '#c084fc' }}>🌇 {spot.bestHours.evening}</div>}
                </div>

                <div style={{ display: 'flex', gap: 4, flexWrap: 'wrap', marginBottom: 10 }}>
                  {spot.bestSeason.map(s => <span key={s} style={{ padding: '2px 7px', borderRadius: 8, background: 'rgba(0,64,130,0.2)', fontSize: 10, color: '#93c5fd' }}>{s}</span>)}
                </div>

                {isSelected && (
                  <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: 'auto' }} exit={{ opacity: 0, height: 0 }}>
                    <div style={{ borderTop: '1px solid rgba(255,255,255,0.08)', paddingTop: 10, marginTop: 4 }}>
                      <div style={{ display: 'flex', gap: 6, marginBottom: 8 }}>
                        <Camera style={{ width: 13, height: 13, color: GOLD, flexShrink: 0, marginTop: 1 }} />
                        <p style={{ fontSize: 12, color: '#d1d5db', lineHeight: 1.6 }}>{spot.photographerNotes}</p>
                      </div>
                      <div style={{ display: 'flex', gap: 6 }}>
                        <Compass style={{ width: 13, height: 13, color: '#9ca3af', flexShrink: 0, marginTop: 1 }} />
                        <div>
                          <div style={{ fontSize: 10, color: '#6b7280' }}>{spot.direction} · {spot.coordinates}</div>
                        </div>
                      </div>
                    </div>
                  </motion.div>
                )}
              </motion.div>
            );
          })}
        </div>

        {filtered.length === 0 && (
          <div style={{ textAlign: 'center', padding: '4rem 2rem', color: '#6b7280' }}>
            <div style={{ fontSize: 48, marginBottom: 12 }}>🌑</div>
            <div style={{ fontSize: 16, fontWeight: 700, color: '#9ca3af', marginBottom: 6 }}>No spots match your filters</div>
            <div style={{ fontSize: 13 }}>Try changing the season or time of day</div>
          </div>
        )}
      </FadeIn>
    </div>
  );
}
