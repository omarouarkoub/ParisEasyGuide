'use client';
import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Building2, Send, Sparkles, Loader2, AlertCircle, ExternalLink, Calendar, FileText } from 'lucide-react';
import { toast } from 'sonner';
import { FadeIn } from '@/components/shared/PageMotion';

const QUICK_QUESTIONS = [
  { label: 'Titre de Séjour', q: 'How do I renew my titre de séjour as a student in Paris? What documents do I need and how long does it take?', icon: '🪪' },
  { label: 'CAF Housing Aid', q: 'How do I apply for CAF housing aid (APL) as an international student? What are the steps and how much can I get?', icon: '🏠' },
  { label: 'CVEC Payment', q: 'What is the CVEC student contribution, how much is it, and how do I pay it?', icon: '🎓' },
  { label: 'Sécurité Sociale', q: 'How do I register for French Sécurité Sociale (health insurance) as an international student?', icon: '🏥' },
  { label: 'Bank Account', q: 'Which French bank is best for international students? How do I open an account without a French address yet?', icon: '🏦' },
  { label: 'Préfecture Appt', q: 'How do I book a préfecture appointment in Paris? The website is always full — are there tricks?', icon: '📅' },
  { label: 'Tax Declaration', q: 'Do I need to file a French tax declaration as an international student? What are the deadlines?', icon: '📊' },
  { label: 'Parcoursup', q: 'I want to change my university for L2. What are the steps on Parcoursup and what are the key deadlines?', icon: '📚' },
];

const URGENT_LINKS = [
  { label: 'Préfecture Paris', url: 'https://www.prefecturedepolice.fr', note: 'Book titre de séjour' },
  { label: 'CAF Application', url: 'https://www.caf.fr', note: 'Housing aid' },
  { label: 'CVEC Payment', url: 'https://cvec.etudiant.gouv.fr', note: 'Student contribution' },
  { label: 'Campus France', url: 'https://www.campusfrance.org', note: 'Visa & admissions' },
  { label: 'CROUS Housing', url: 'https://www.messervices.etudiant.gouv.fr', note: 'Student dorm application' },
  { label: 'Ameli (Health)', url: 'https://etudiant-etranger.ameli.fr', note: 'Sécurité Sociale' },
];

const NATIONALITIES = ['EU/EEA Citizen', 'Non-EU with French visa', 'Moroccan', 'Algerian', 'Tunisian', 'Senegalese', 'Cameroonian', 'Chinese', 'Brazilian', 'American', 'Other'];

interface Message { role: 'user' | 'assistant'; content: string; }

export default function AdminPage() {
  const [messages, setMessages] = useState<Message[]>([
    { role: 'assistant', content: "Bonjour! 👋 I'm your French administrative expert. I can help with:\n\n• **Titre de séjour** renewal & first-time applications\n• **CAF** housing aid (APL) applications\n• **CVEC** student contribution\n• **Préfecture** appointment booking strategies\n• **French bank accounts** for students\n• **Sécurité Sociale** enrollment\n• **Parcoursup** & university transfers\n\nAsk me anything — in English, French, or Arabic." }
  ]);
  const [input, setInput] = useState('');
  const [nationality, setNationality] = useState('Non-EU with French visa');
  const [arrondissement, setArrondissement] = useState('');
  const [loading, setLoading] = useState(false);

  const send = async (text?: string) => {
    const msg = text || input;
    if (!msg.trim()) return;
    const newMessages: Message[] = [...messages, { role: 'user', content: msg }];
    setMessages(newMessages);
    setInput('');
    setLoading(true);
    try {
      const res = await fetch('/api/admin', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ question: msg, nationality, arrondissement, studentType: 'international student' }),
      });
      const data = await res.json();
      setMessages(prev => [...prev, { role: 'assistant', content: data.answer || 'Sorry, I could not get an answer. Please try again.' }]);
    } catch { toast.error('Connection error. Please try again.'); }
    finally { setLoading(false); }
  };

  const formatAnswer = (text: string) =>
    text.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>').replace(/\n/g, '<br/>').replace(/• /g, '&bull; ');

  return (
    <div style={{ padding: '2rem 2.5rem', maxWidth: 1100, margin: '0 auto' }}>
      <FadeIn>
        <div style={{ marginBottom: '2rem' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 4 }}>
            <Building2 style={{ width: 16, height: 16, color: '#C9A84C' }} />
            <span style={{ fontSize: 12, fontWeight: 600, color: '#C9A84C', textTransform: 'uppercase', letterSpacing: '0.1em' }}>Admin Guide</span>
          </div>
          <h1 style={{ fontFamily: 'Playfair Display, serif', fontSize: '2rem', fontWeight: 700, color: '#fff' }}>French Admin Assistant</h1>
          <p style={{ color: '#6b7280', fontSize: 14 }}>Préfecture, CAF, CVEC, Sécurité Sociale — your AI bureaucracy navigator</p>
        </div>
      </FadeIn>

      <div style={{ display: 'grid', gridTemplateColumns: '280px 1fr', gap: '1.5rem' }}>
        {/* Left sidebar */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
          {/* Profile */}
          <div style={{ padding: '1.1rem', borderRadius: 14, background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.08)' }}>
            <div style={{ fontSize: 12, fontWeight: 700, color: '#9ca3af', marginBottom: 10, textTransform: 'uppercase', letterSpacing: '0.05em' }}>Your Profile</div>
            <div style={{ marginBottom: 10 }}>
              <label style={{ fontSize: 11, color: '#6b7280', display: 'block', marginBottom: 4 }}>Nationality</label>
              <select value={nationality} onChange={e => setNationality(e.target.value)}
                style={{ width: '100%', background: 'rgba(255,255,255,0.06)', border: '1px solid rgba(255,255,255,0.1)', borderRadius: 8, padding: '7px 10px', color: '#fff', fontSize: 12, outline: 'none', cursor: 'pointer' }}>
                {NATIONALITIES.map(n => <option key={n} value={n} style={{ background: '#0d1117' }}>{n}</option>)}
              </select>
            </div>
            <div>
              <label style={{ fontSize: 11, color: '#6b7280', display: 'block', marginBottom: 4 }}>Arrondissement</label>
              <input value={arrondissement} onChange={e => setArrondissement(e.target.value)} placeholder="e.g. 15ème, 93..." style={{ width: '100%', background: 'rgba(255,255,255,0.06)', border: '1px solid rgba(255,255,255,0.1)', borderRadius: 8, padding: '7px 10px', color: '#fff', fontSize: 12, outline: 'none', boxSizing: 'border-box' }} />
            </div>
          </div>

          {/* Quick questions */}
          <div style={{ padding: '1.1rem', borderRadius: 14, background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.08)' }}>
            <div style={{ fontSize: 12, fontWeight: 700, color: '#9ca3af', marginBottom: 10, textTransform: 'uppercase', letterSpacing: '0.05em' }}>Quick Topics</div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 5 }}>
              {QUICK_QUESTIONS.map(q => (
                <motion.button key={q.label} whileHover={{ x: 4 }} whileTap={{ scale: 0.97 }} onClick={() => send(q.q)}
                  style={{ padding: '8px 10px', borderRadius: 10, background: 'rgba(255,255,255,0.03)', border: '1px solid rgba(255,255,255,0.07)', cursor: 'pointer', color: '#e5e7eb', fontSize: 12, fontWeight: 600, display: 'flex', alignItems: 'center', gap: 8, textAlign: 'left' }}>
                  <span>{q.icon}</span>{q.label}
                </motion.button>
              ))}
            </div>
          </div>

          {/* Urgent links */}
          <div style={{ padding: '1.1rem', borderRadius: 14, background: 'rgba(239,68,68,0.05)', border: '1px solid rgba(239,68,68,0.2)' }}>
            <div style={{ fontSize: 12, fontWeight: 700, color: '#fca5a5', marginBottom: 10, display: 'flex', alignItems: 'center', gap: 6 }}>
              <AlertCircle style={{ width: 12, height: 12 }} />OFFICIAL LINKS
            </div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
              {URGENT_LINKS.map(link => (
                <a key={link.label} href={link.url} target="_blank" rel="noreferrer"
                  style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 6, padding: '7px 10px', borderRadius: 8, background: 'rgba(255,255,255,0.03)', border: '1px solid rgba(255,255,255,0.07)', textDecoration: 'none' }}>
                  <div>
                    <div style={{ fontSize: 12, fontWeight: 600, color: '#fff' }}>{link.label}</div>
                    <div style={{ fontSize: 10, color: '#6b7280' }}>{link.note}</div>
                  </div>
                  <ExternalLink style={{ width: 11, height: 11, color: '#6b7280', flexShrink: 0 }} />
                </a>
              ))}
            </div>
          </div>
        </div>

        {/* Chat */}
        <div style={{ display: 'flex', flexDirection: 'column', height: '72vh' }}>
          {/* Messages */}
          <div style={{ flex: 1, overflowY: 'auto', display: 'flex', flexDirection: 'column', gap: '1rem', paddingBottom: '1rem' }}>
            {messages.map((msg, i) => (
              <motion.div key={i} initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.05 }}
                style={{ display: 'flex', justifyContent: msg.role === 'user' ? 'flex-end' : 'flex-start' }}>
                {msg.role === 'assistant' && (
                  <div style={{ width: 32, height: 32, borderRadius: '50%', background: 'rgba(0,64,130,0.3)', border: '1px solid rgba(0,64,130,0.5)', display: 'flex', alignItems: 'center', justifyContent: 'center', marginRight: 8, flexShrink: 0, marginTop: 4 }}>
                    <Building2 style={{ width: 14, height: 14, color: '#C9A84C' }} />
                  </div>
                )}
                <div style={{ maxWidth: '78%', padding: '12px 16px', borderRadius: msg.role === 'user' ? '18px 18px 4px 18px' : '18px 18px 18px 4px', background: msg.role === 'user' ? 'linear-gradient(135deg,#004082,#1a5cb5)' : 'rgba(255,255,255,0.06)', border: msg.role === 'user' ? 'none' : '1px solid rgba(255,255,255,0.1)', color: '#fff', fontSize: 13, lineHeight: 1.75 }}
                  dangerouslySetInnerHTML={{ __html: formatAnswer(msg.content) }} />
              </motion.div>
            ))}
            {loading && (
              <div style={{ display: 'flex', gap: 10, alignItems: 'center' }}>
                <div style={{ width: 32, height: 32, borderRadius: '50%', background: 'rgba(0,64,130,0.3)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                  <Building2 style={{ width: 14, height: 14, color: '#C9A84C' }} />
                </div>
                <div style={{ padding: '12px 16px', borderRadius: '18px 18px 18px 4px', background: 'rgba(255,255,255,0.06)', border: '1px solid rgba(255,255,255,0.1)' }}>
                  <Loader2 style={{ width: 16, height: 16, color: '#C9A84C', animation: 'spin 1s linear infinite' }} />
                </div>
              </div>
            )}
          </div>

          {/* Input */}
          <div style={{ display: 'flex', gap: 8, padding: '12px', borderRadius: 16, background: 'rgba(255,255,255,0.05)', border: '1px solid rgba(255,255,255,0.1)' }}>
            <input value={input} onChange={e => setInput(e.target.value)} onKeyDown={e => e.key === 'Enter' && !e.shiftKey && send()}
              placeholder="Ask about titre de séjour, CAF, préfecture, banks, taxes…"
              style={{ flex: 1, background: 'none', border: 'none', outline: 'none', color: '#fff', fontSize: 14 }} />
            <motion.button whileTap={{ scale: 0.95 }} onClick={() => send()} disabled={loading || !input.trim()}
              style={{ padding: '8px 14px', borderRadius: 10, background: input.trim() ? 'linear-gradient(135deg,#004082,#1a5cb5)' : 'rgba(255,255,255,0.05)', border: 'none', cursor: 'pointer', color: '#fff' }}>
              <Send style={{ width: 16, height: 16 }} />
            </motion.button>
          </div>
        </div>
      </div>
      <style>{`@keyframes spin { from { transform:rotate(0deg) } to { transform:rotate(360deg) } }`}</style>
    </div>
  );
}
