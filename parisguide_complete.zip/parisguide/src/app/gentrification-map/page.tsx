'use client';
import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { TrendingUp, TrendingDown, Minus, AlertTriangle, Coffee, Home } from 'lucide-react';
import { FadeIn } from '@/components/shared/PageMotion';

const GOLD = '#C9A84C';
const RED = '#EE2436';
const BLUE = '#004082';

type GentLevel = 'gentrified' | 'gentrifying' | 'resistant' | 'mixed';

interface Neighbourhood {
  id: string;
  name: string;
  arrondissement: string;
  gentLevel: GentLevel;
  rentChange: string; // e.g. "+87% since 2000"
  bistrosLost: number;
  bistrosRemaining: number;
  waveYear: string; // when gentrification peaked
  originalCharacter: string;
  nowKnownFor: string;
  disappearing: string[];
  survivors: string[];
  residentVoice: string;
  historicNote: string;
  genScore: number; // 0–100
}

const NEIGHBOURHOODS: Neighbourhood[] = [
  {
    id: 'marais',
    name: 'Le Marais',
    arrondissement: '3e–4e',
    gentLevel: 'gentrified',
    rentChange: '+140% since 1995',
    bistrosLost: 34,
    bistrosRemaining: 8,
    waveYear: '1995–2005',
    originalCharacter: 'Jewish quarter, artisan workshops, gay village, working-class',
    nowKnownFor: 'Luxury boutiques, art galleries, €18 avocado toast, tourists',
    disappearing: ['Kosher delis', 'Jewish bookshops', 'Artisan cobblers', 'Cheap falafel (<€6)'],
    survivors: ['L\'As du Fallafel', 'Bretzel & Co', 'Café des Musées'],
    residentVoice: '"My family\'s deli closed after 60 years. Now it\'s a concept store for €300 sneakers." — Maurice, 71',
    historicNote: 'The Marais was saved from Haussmann\'s bulldozers by Malraux\'s 1964 preservation law. Ironic that "saving" it led to pricing out its soul.',
    genScore: 92,
  },
  {
    id: 'oberkampf',
    name: 'Oberkampf / Ménilmontant',
    arrondissement: '11e',
    gentLevel: 'gentrifying',
    rentChange: '+65% since 2010',
    bistrosLost: 12,
    bistrosRemaining: 19,
    waveYear: '2010–present',
    originalCharacter: 'Working-class Belleville edge, immigrant communities, artist squats',
    nowKnownFor: 'Natural wine bars, bobo cafés, "creative class" co-working, weekend brunch queues',
    disappearing: ['Boucheries chevalines', 'Tabacs', 'PMU betting bars', 'Algerian épiceries staying open till 2am'],
    survivors: ['Café Charbon', 'Aux Folies', 'Various Tunisian rotisseries on Ramponeau'],
    residentVoice: '"When the first coffee shop charging €5 for a flat white opened, we knew it was over." — Rachida, 44',
    historicNote: 'The historic Oberkampf textile factories gave the street its name. The last artisan workshops closed in 2018.',
    genScore: 62,
  },
  {
    id: 'belleville',
    name: 'Belleville',
    arrondissement: '19e–20e',
    gentLevel: 'mixed',
    rentChange: '+48% since 2015',
    bistrosLost: 7,
    bistrosRemaining: 31,
    waveYear: '2015–present',
    originalCharacter: 'North African & Asian immigrant hub, ateliers d\'artistes, Piaf\'s birthplace',
    nowKnownFor: 'Paris\'s most diverse market, emerging gallery scene, cheaper than the 11e (for now)',
    disappearing: ['Salle de jeux chinoises', 'Coiffeurs africains below street level', 'Le Zorba (Greek resto, est. 1972)'],
    survivors: ['Aux Folies (terrace institution)', 'La Maroquinerie', 'Marché de Belleville Tuesday/Friday'],
    residentVoice: '"Five years ago this café was a Chinese gambling den. Now it has exposed brick and serves matcha lattes." — Thao, 38',
    historicNote: 'Belleville was an independent commune until 1860, absorbed by Haussmann\'s annexation. It has resisted full gentrification longer than most due to its immigrant community density.',
    genScore: 44,
  },
  {
    id: 'pigalle',
    name: 'South Pigalle (SoPi)',
    arrondissement: '9e',
    gentLevel: 'gentrified',
    rentChange: '+95% since 2008',
    bistrosLost: 22,
    bistrosRemaining: 11,
    waveYear: '2008–2016',
    originalCharacter: 'Sex shops, cabarets, strip clubs, working-class bars, immigrant workers',
    nowKnownFor: '"SoPi" — natural wine, trendy tapas, concept stores, New York Times coverage',
    disappearing: ['Peep shows', 'Old PMU bars', 'Le Mansart (legendary dive)', 'Kabyle grocery workers\' restaurants'],
    survivors: ['Au P\'tit Douai', 'Cave des Abbesses', 'Bal Blomet (revived)'],
    residentVoice: '"They rebranded the red-light district as \'SoPi\' and now it costs €14 for a glass of orange wine." — Stéphane, 52',
    historicNote: 'Toulouse-Lautrec documented Pigalle\'s original character obsessively. The Moulin Rouge still turns but everything around it is a gastro-bar.',
    genScore: 78,
  },
  {
    id: 'canal_saint_martin',
    name: 'Canal Saint-Martin',
    arrondissement: '10e',
    gentLevel: 'gentrified',
    rentChange: '+110% since 2005',
    bistrosLost: 18,
    bistrosRemaining: 14,
    waveYear: '2005–2012',
    originalCharacter: 'Industrial canal district, zinc workshops, hospital workers\' bars',
    nowKnownFor: 'Paris Mise en Seine (film), Amélie Poulain tourism, brunch, picnics with rosé',
    disappearing: ['Zinc worker\'s canteen Le Verre Volé (original era)', 'Hospital staff cafés', 'Ferronniers'],
    survivors: ['Hôpital Saint-Louis gardens (public)', 'Marché Saint-Quentin', 'Point Éphémère'],
    residentVoice: '"Amélie was filmed here in 2001. By 2010 the rents had doubled. By 2015 tripled. Thank you, Jeunet." — Claude, 63',
    historicNote: 'Napoleon ordered the canal built in 1802 to bring clean water to Paris. It was nearly paved over in 1970 for a motorway — saved by public protest. Now gentrified anyway.',
    genScore: 85,
  },
  {
    id: 'goutte_dor',
    name: 'La Goutte d\'Or',
    arrondissement: '18e',
    gentLevel: 'resistant',
    rentChange: '+22% since 2015',
    bistrosLost: 2,
    bistrosRemaining: 41,
    waveYear: 'Holding',
    originalCharacter: 'West & North African immigrant hub, Malian, Senegalese, Algerian communities',
    nowKnownFor: 'Still the most authentically working-class neighbourhood in central Paris',
    disappearing: ['Slowly: some Algerian cafés catering halls', 'Cheap residential hotels'],
    survivors: ['Marché Dejean', 'Tati (now Primark)', 'Mosque and halal butchers en masse', 'African fabric shops'],
    residentVoice: '"Gentrifiers come, look around, and leave. Our community is too strong." — Aminata, 55',
    historicNote: 'Named after a vine that once grew here. Has absorbed waves of immigration since the 1950s — Algerian, then Malian, then West African — with each wave strengthening community ties.',
    genScore: 18,
  },
  {
    id: 'batignolles',
    name: 'Les Batignolles',
    arrondissement: '17e',
    gentLevel: 'gentrifying',
    rentChange: '+55% since 2012',
    bistrosLost: 9,
    bistrosRemaining: 22,
    waveYear: '2012–present',
    originalCharacter: 'Quiet provincial village feel, artisan bakers, local wine merchants',
    nowKnownFor: 'Eco-district, Parc Martin Luther King, young families, organic market Saturdays',
    disappearing: ['Long-standing cave à vins family shops', 'Old-school charcuteries', 'Bar tabac PMU culture'],
    survivors: ['Marché Batignolles (organic Sat)', 'La Fourmi Ailée', 'Le Petit Chambord'],
    residentVoice: '"The eco-district brought the tramway and the tramway brought the bobos. Progress." — Jean-Michel, 59, ironic',
    historicNote: 'Manet lived and painted here. His circle — the "Batignolles Group" — defined French Realism. Today the realism is artisanal avocado oil.',
    genScore: 51,
  },
];

const LEVEL_CONFIG: Record<GentLevel, { color: string; label: string; emoji: string; bg: string }> = {
  gentrified:  { color: RED,     label: 'Fully Gentrified',  emoji: '🔴', bg: 'rgba(238,36,54,0.08)' },
  gentrifying: { color: '#f97316', label: 'Actively Changing', emoji: '🟠', bg: 'rgba(249,115,22,0.08)' },
  mixed:       { color: GOLD,    label: 'Mixed / In Flux',   emoji: '🟡', bg: 'rgba(201,168,76,0.08)' },
  resistant:   { color: '#34d399', label: 'Culturally Resistant', emoji: '🟢', bg: 'rgba(52,211,153,0.08)' },
};

function GenScore({ score }: { score: number }) {
  const color = score > 75 ? RED : score > 50 ? '#f97316' : score > 30 ? GOLD : '#34d399';
  return (
    <div>
      <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 4 }}>
        <span style={{ fontSize: 10, color: '#6b7280', fontWeight: 700 }}>GENTRIFICATION INDEX</span>
        <span style={{ fontSize: 11, fontWeight: 700, color }}>{score}/100</span>
      </div>
      <div style={{ height: 6, borderRadius: 3, background: 'rgba(255,255,255,0.08)', overflow: 'hidden' }}>
        <motion.div initial={{ width: 0 }} animate={{ width: `${score}%` }} transition={{ duration: 1, ease: 'easeOut' }}
          style={{ height: '100%', borderRadius: 3, background: `linear-gradient(90deg, #34d399, ${color})` }} />
      </div>
    </div>
  );
}

export default function GentrificationMapPage() {
  const [filter, setFilter] = useState<GentLevel | 'all'>('all');
  const [selected, setSelected] = useState<string | null>(null);
  const [view, setView] = useState<'grid' | 'timeline'>('grid');

  const filtered = NEIGHBOURHOODS.filter(n => filter === 'all' || n.gentLevel === filter);
  const selectedNeighbourhood = NEIGHBOURHOODS.find(n => n.id === selected);

  return (
    <div style={{ padding: '2rem 2.5rem', maxWidth: 1100, margin: '0 auto' }}>
      <FadeIn>
        {/* Header */}
        <div style={{ marginBottom: '1.5rem' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 4 }}>
            <span style={{ fontSize: 16 }}>🏙️</span>
            <span style={{ fontSize: 12, fontWeight: 600, color: GOLD, textTransform: 'uppercase', letterSpacing: '0.1em' }}>Neighbourhood Change</span>
          </div>
          <h1 style={{ fontFamily: 'Playfair Display, serif', fontSize: '2rem', fontWeight: 700, color: '#fff', marginBottom: 6 }}>Gentrification Map</h1>
          <p style={{ color: '#6b7280', fontSize: 14 }}>Track how Paris neighbourhoods change over time — disappearing bistros, rent evolution, vanishing cultures, and the places that refuse to bend.</p>
        </div>

        {/* Summary stats */}
        <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }}
          style={{ display: 'grid', gridTemplateColumns: 'repeat(4,1fr)', gap: '1rem', marginBottom: '1.5rem' }}>
          {[
            { label: 'Bistros Lost (tracked)', value: NEIGHBOURHOODS.reduce((a,n) => a+n.bistrosLost, 0), color: RED, emoji: '🥩', sub: 'since 2000' },
            { label: 'Still Surviving', value: NEIGHBOURHOODS.reduce((a,n) => a+n.bistrosRemaining, 0), color: '#34d399', emoji: '☕', sub: 'tracked spots' },
            { label: 'Avg Rent Increase', value: '+75%', color: GOLD, emoji: '📈', sub: 'since 2000' },
            { label: 'Resistant Areas', value: NEIGHBOURHOODS.filter(n => n.gentLevel === 'resistant').length, color: '#60a5fa', emoji: '🛡️', sub: 'holding out' },
          ].map(s => (
            <div key={s.label} style={{ padding: '1rem', borderRadius: 12, background: 'rgba(255,255,255,0.03)', border: '1px solid rgba(255,255,255,0.08)', textAlign: 'center' }}>
              <div style={{ fontSize: 20, marginBottom: 4 }}>{s.emoji}</div>
              <div style={{ fontSize: '1.5rem', fontWeight: 800, color: s.color, fontFamily: 'Playfair Display, serif' }}>{s.value}</div>
              <div style={{ fontSize: 10, color: '#6b7280', marginTop: 2 }}>{s.label}</div>
              <div style={{ fontSize: 9, color: '#4b5563', marginTop: 2 }}>{s.sub}</div>
            </div>
          ))}
        </motion.div>

        {/* Filter bar */}
        <div style={{ display: 'flex', gap: 8, marginBottom: '1.5rem', flexWrap: 'wrap', alignItems: 'center', justifyContent: 'space-between' }}>
          <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
            {([['all','All Areas','#9ca3af'], ['gentrified','Gentrified',RED], ['gentrifying','Changing','#f97316'], ['mixed','Mixed',GOLD], ['resistant','Resistant','#34d399']] as const).map(([key, label, color]) => (
              <button key={key} onClick={() => setFilter(key)}
                style={{ padding: '6px 14px', borderRadius: 20, border: `1px solid ${filter === key ? color : 'rgba(255,255,255,0.1)'}`, background: filter === key ? `${color}20` : 'rgba(255,255,255,0.04)', color: filter === key ? color : '#9ca3af', fontSize: 12, fontWeight: 600, cursor: 'pointer' }}>
                {label}
              </button>
            ))}
          </div>
        </div>

        {/* Grid */}
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill,minmax(320px,1fr))', gap: '1rem' }}>
          {filtered.map((n, i) => {
            const cfg = LEVEL_CONFIG[n.gentLevel];
            const isSelected = selected === n.id;
            return (
              <motion.div key={n.id}
                initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.06 }}
                onClick={() => setSelected(isSelected ? null : n.id)}
                style={{ borderRadius: 14, background: isSelected ? cfg.bg : 'rgba(255,255,255,0.02)', border: `1px solid ${isSelected ? cfg.color + '50' : 'rgba(255,255,255,0.07)'}`, cursor: 'pointer', overflow: 'hidden', transition: 'all 0.2s' }}>

                <div style={{ padding: '1.25rem' }}>
                  {/* Header row */}
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 10 }}>
                    <div>
                      <div style={{ fontWeight: 700, fontSize: 15, color: '#fff', marginBottom: 2 }}>{n.name}</div>
                      <div style={{ fontSize: 11, color: '#6b7280' }}>{n.arrondissement}</div>
                    </div>
                    <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'flex-end', gap: 4 }}>
                      <span style={{ padding: '3px 9px', borderRadius: 20, fontSize: 10, fontWeight: 700, color: cfg.color, background: cfg.bg, border: `1px solid ${cfg.color}40` }}>{cfg.emoji} {cfg.label}</span>
                      <span style={{ fontSize: 11, fontWeight: 700, color: GOLD }}>{n.rentChange}</span>
                    </div>
                  </div>

                  <GenScore score={n.genScore} />

                  <div style={{ display: 'flex', gap: '1.5rem', marginTop: 12 }}>
                    <div style={{ textAlign: 'center' }}>
                      <div style={{ fontSize: '1.25rem', fontWeight: 800, color: RED }}>{n.bistrosLost}</div>
                      <div style={{ fontSize: 9, color: '#6b7280' }}>BISTROS LOST</div>
                    </div>
                    <div style={{ textAlign: 'center' }}>
                      <div style={{ fontSize: '1.25rem', fontWeight: 800, color: '#34d399' }}>{n.bistrosRemaining}</div>
                      <div style={{ fontSize: 9, color: '#6b7280' }}>SURVIVING</div>
                    </div>
                    <div style={{ flex: 1 }}>
                      <div style={{ fontSize: 10, color: '#6b7280', marginBottom: 3 }}>PEAK CHANGE</div>
                      <div style={{ fontSize: 12, color: '#9ca3af', fontWeight: 600 }}>{n.waveYear}</div>
                    </div>
                  </div>
                </div>

                {/* Expanded detail */}
                <AnimatePresence>
                  {isSelected && (
                    <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: 'auto', opacity: 1 }} exit={{ height: 0, opacity: 0 }} transition={{ duration: 0.3 }}
                      style={{ overflow: 'hidden', borderTop: `1px solid ${cfg.color}25` }}>
                      <div style={{ padding: '1.25rem', display: 'flex', flexDirection: 'column', gap: '1rem' }}>
                        <div>
                          <div style={{ fontSize: 10, fontWeight: 700, color: '#6b7280', textTransform: 'uppercase', letterSpacing: '0.08em', marginBottom: 4 }}>Original Character</div>
                          <div style={{ fontSize: 12, color: '#d1d5db', lineHeight: 1.5 }}>{n.originalCharacter}</div>
                        </div>
                        <div>
                          <div style={{ fontSize: 10, fontWeight: 700, color: '#6b7280', textTransform: 'uppercase', letterSpacing: '0.08em', marginBottom: 4 }}>Now Known For</div>
                          <div style={{ fontSize: 12, color: '#d1d5db', lineHeight: 1.5 }}>{n.nowKnownFor}</div>
                        </div>
                        <div>
                          <div style={{ fontSize: 10, fontWeight: 700, color: RED, textTransform: 'uppercase', letterSpacing: '0.08em', marginBottom: 6 }}>⚠ Disappearing</div>
                          {n.disappearing.map(d => <div key={d} style={{ fontSize: 11, color: '#f87171', marginBottom: 3, paddingLeft: 12, borderLeft: `2px solid ${RED}40` }}>• {d}</div>)}
                        </div>
                        <div>
                          <div style={{ fontSize: 10, fontWeight: 700, color: '#34d399', textTransform: 'uppercase', letterSpacing: '0.08em', marginBottom: 6 }}>✓ Still Here</div>
                          {n.survivors.map(s => <div key={s} style={{ fontSize: 11, color: '#6ee7b7', marginBottom: 3, paddingLeft: 12, borderLeft: '2px solid rgba(52,211,153,0.4)' }}>• {s}</div>)}
                        </div>
                        <div style={{ padding: '12px', borderRadius: 10, background: 'rgba(0,0,0,0.25)', borderLeft: `3px solid ${cfg.color}` }}>
                          <div style={{ fontSize: 11, color: '#e5e7eb', lineHeight: 1.6, fontStyle: 'italic' }}>{n.residentVoice}</div>
                        </div>
                        <div style={{ fontSize: 11, color: '#6b7280', lineHeight: 1.6 }}>{n.historicNote}</div>
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </motion.div>
            );
          })}
        </div>
      </FadeIn>
    </div>
  );
}
