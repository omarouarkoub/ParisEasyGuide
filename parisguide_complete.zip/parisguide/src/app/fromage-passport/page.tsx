'use client';
import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Loader2, Star, Wine, Wheat, Plus, CheckCircle2, ChevronDown, ChevronUp, Trophy } from 'lucide-react';
import { FadeIn } from '@/components/shared/PageMotion';
import { fireBadgeToast } from '@/components/quest/BadgeUnlockToast';

const GOLD = '#C9A84C';
const BLUE = '#004082';
const RED = '#EE2436';

interface Cheese {
  id: string;
  name: string;
  region: string;
  regionEmoji: string;
  type: string;
  emoji: string;
  description: string;
  intensity: number; // 1–5
  rarity: 'common' | 'rare' | 'legendary';
  badge?: string;
}

const CHEESES: Cheese[] = [
  { id: 'brie', name: 'Brie de Meaux', region: 'Île-de-France', regionEmoji: '🗼', type: 'Soft', emoji: '🧀', description: 'King of cheeses. Creamy, buttery heart with a white bloomy rind.', intensity: 2, rarity: 'common', badge: 'brie_master' },
  { id: 'camembert', name: 'Camembert de Normandie', region: 'Normandy', regionEmoji: '🐄', type: 'Soft', emoji: '🧀', description: 'Earthy, mushroomy, with a rich oozy paste. The soul of Normandy.', intensity: 3, rarity: 'common' },
  { id: 'roquefort', name: 'Roquefort', region: 'Occitanie', regionEmoji: '🏔️', type: 'Blue', emoji: '🧀', description: 'Pungent, salty blue cheese aged in Combalou caves. AOP since 1925.', intensity: 5, rarity: 'rare', badge: 'roquefort_royale' },
  { id: 'comte', name: 'Comté', region: 'Franche-Comté', regionEmoji: '⛰️', type: 'Hard', emoji: '🧀', description: 'Nutty, fruity, complex. Aged 12–36 months in mountain caves.', intensity: 3, rarity: 'common' },
  { id: 'epoisses', name: 'Époisses', region: 'Burgundy', regionEmoji: '🍷', type: 'Washed Rind', emoji: '🧀', description: 'Washed in Marc de Bourgogne. Powerfully pungent, luxuriously creamy inside.', intensity: 5, rarity: 'legendary', badge: 'epoisses_legend' },
  { id: 'munster', name: 'Munster', region: 'Alsace', regionEmoji: '🏰', type: 'Washed Rind', emoji: '🧀', description: 'Soft, orange-crusted, aromatic. Deeply savory and distinctly Alsatian.', intensity: 4, rarity: 'rare' },
  { id: 'reblochon', name: 'Reblochon', region: 'Savoie', regionEmoji: '🎿', type: 'Semi-soft', emoji: '🧀', description: 'Alpine cheese with a hazelnut sweetness. Essential in tartiflette.', intensity: 3, rarity: 'common' },
  { id: 'morbier', name: 'Morbier', region: 'Jura', regionEmoji: '🌿', type: 'Semi-soft', emoji: '🧀', description: 'Recognizable by its layer of ash. Mild, fruity, slightly elastic.', intensity: 2, rarity: 'common' },
  { id: 'livarot', name: 'Livarot', region: 'Normandy', regionEmoji: '🐄', type: 'Washed Rind', emoji: '🧀', description: "\"Le Colonel\" — ringed with reeds, boldly flavored, robust character.", intensity: 4, rarity: 'rare', badge: 'colonel_cheese' },
  { id: 'vacherin', name: 'Vacherin Mont d\'Or', region: 'Franche-Comté', regionEmoji: '⛰️', type: 'Soft', emoji: '🧀', description: 'Seasonal (Oct–Mar). Bake the whole box and eat with a spoon. Pure luxury.', intensity: 3, rarity: 'legendary', badge: 'vacherin_legend' },
  { id: 'beaufort', name: 'Beaufort', region: 'Savoie', regionEmoji: '🎿', type: 'Hard', emoji: '🧀', description: 'Prince of Gruyères. Sweet, buttery, slightly fruity. Molded in a cloth.', intensity: 2, rarity: 'common' },
  { id: 'saint_nectaire', name: 'Saint-Nectaire', region: 'Auvergne', regionEmoji: '🌋', type: 'Semi-soft', emoji: '🧀', description: 'Aged on rye straw. Earthy, mushroomy, distinctly volcanic terroir.', intensity: 3, rarity: 'rare' },
];

const REGIONS = ['All', 'Île-de-France', 'Normandy', 'Occitanie', 'Franche-Comté', 'Burgundy', 'Alsace', 'Savoie', 'Jura', 'Auvergne'];

const rarityConfig = {
  common:    { color: '#9ca3af', label: 'Common',    xp: 50 },
  rare:      { color: '#60a5fa', label: 'Rare',      xp: 150 },
  legendary: { color: '#fbbf24', label: 'Legendary', xp: 400 },
};

function IntensityBar({ value }: { value: number }) {
  return (
    <div style={{ display: 'flex', gap: 3 }}>
      {[1,2,3,4,5].map(i => (
        <div key={i} style={{ width: 16, height: 6, borderRadius: 3, background: i <= value ? GOLD : 'rgba(255,255,255,0.1)' }} />
      ))}
    </div>
  );
}

export default function FromagePassportPage() {
  const [tasted, setTasted] = useState<string[]>([]);
  const [region, setRegion] = useState('All');
  const [expanded, setExpanded] = useState<string | null>(null);
  const [pairings, setPairings] = useState<Record<string, string>>({});
  const [pairingLoading, setPairingLoading] = useState<string | null>(null);

  useEffect(() => {
    const saved = localStorage.getItem('fromage_tasted');
    if (saved) setTasted(JSON.parse(saved));
  }, []);

  const toggleTasted = (id: string, cheese: Cheese) => {
    const next = tasted.includes(id) ? tasted.filter(x => x !== id) : [...tasted, id];
    setTasted(next);
    localStorage.setItem('fromage_tasted', JSON.stringify(next));

    if (!tasted.includes(id) && cheese.badge) {
      const rc = rarityConfig[cheese.rarity];
      fireBadgeToast({
        id: cheese.badge,
        emoji: '🧀',
        name: `${cheese.name} Connoisseur`,
        description: `You tasted ${cheese.name}!`,
        rarity: cheese.rarity,
        xp: rc.xp,
      });
    }
  };

  const fetchPairing = async (cheese: Cheese) => {
    if (pairings[cheese.id] || pairingLoading) return;
    setPairingLoading(cheese.id);
    try {
      const res = await fetch('https://api.anthropic.com/v1/messages', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          model: 'claude-sonnet-4-6',
          max_tokens: 1000,
          messages: [{
            role: 'user',
            content: `You are a passionate French fromager and sommelier. For the cheese "${cheese.name}" from ${cheese.region} (type: ${cheese.type}, intensity: ${cheese.intensity}/5), provide:
1. Best wine pairing (1-2 specific wines with brief reason, max 40 words)
2. Best bread pairing (specific bread type with brief reason, max 30 words)
3. One pro serving tip (max 25 words)

Format your response as JSON: { "wine": "...", "bread": "...", "tip": "..." }
Respond ONLY with the JSON, no preamble.`
          }]
        })
      });
      const data = await res.json();
      const text = data.content?.map((b: { type: string; text?: string }) => b.type === 'text' ? b.text : '').join('') || '{}';
      const clean = text.replace(/```json|```/g, '').trim();
      const parsed = JSON.parse(clean);
      setPairings(prev => ({ ...prev, [cheese.id]: JSON.stringify(parsed) }));
    } catch {
      setPairings(prev => ({ ...prev, [cheese.id]: JSON.stringify({ wine: 'Try a local vin de pays', bread: 'A classic baguette tradition works beautifully', tip: 'Serve at room temperature for best flavor' }) }));
    }
    setPairingLoading(null);
  };

  const filtered = CHEESES.filter(c => region === 'All' || c.region === region);
  const totalXP = tasted.reduce((acc, id) => {
    const c = CHEESES.find(ch => ch.id === id);
    return acc + (c ? rarityConfig[c.rarity].xp : 0);
  }, 0);
  const pct = Math.round((tasted.length / CHEESES.length) * 100);

  return (
    <div style={{ padding: '2rem 2.5rem', maxWidth: 1100, margin: '0 auto' }}>
      <FadeIn>
        {/* Header */}
        <div style={{ marginBottom: '1.5rem' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 4 }}>
            <span style={{ fontSize: 20 }}>🧀</span>
            <span style={{ fontSize: 12, fontWeight: 600, color: GOLD, textTransform: 'uppercase', letterSpacing: '0.1em' }}>Gamified Cheese Journey</span>
          </div>
          <h1 style={{ fontFamily: 'Playfair Display, serif', fontSize: '2rem', fontWeight: 700, color: '#fff', marginBottom: 6 }}>Fromage Passport</h1>
          <p style={{ color: '#6b7280', fontSize: 14 }}>Taste your way through France's finest cheeses. Earn XP, unlock badges, get AI wine & bread pairings.</p>
        </div>

        {/* Progress banner */}
        <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }}
          style={{ padding: '1.25rem 1.5rem', borderRadius: 16, background: 'linear-gradient(135deg,rgba(201,168,76,0.1),rgba(238,36,54,0.06))', border: `1px solid rgba(201,168,76,0.3)`, marginBottom: '1.5rem', display: 'grid', gridTemplateColumns: '1fr auto', gap: '1rem', alignItems: 'center' }}>
          <div>
            <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 10 }}>
              <Trophy style={{ width: 16, height: 16, color: GOLD }} />
              <span style={{ fontWeight: 700, color: '#fff', fontSize: 14 }}>{tasted.length}/{CHEESES.length} cheeses tasted · {pct}% complete</span>
              <span style={{ padding: '2px 8px', borderRadius: 20, background: 'rgba(201,168,76,0.15)', fontSize: 11, color: GOLD, fontWeight: 700 }}>{totalXP} XP</span>
            </div>
            <div style={{ height: 8, borderRadius: 4, background: 'rgba(255,255,255,0.08)', overflow: 'hidden' }}>
              <motion.div initial={{ width: 0 }} animate={{ width: `${pct}%` }} transition={{ duration: 1.2, ease: 'easeOut' }}
                style={{ height: '100%', borderRadius: 4, background: 'linear-gradient(90deg,#C9A84C,#EE2436)' }} />
            </div>
          </div>
          <div style={{ textAlign: 'center' }}>
            <div style={{ fontSize: '2rem' }}>{pct >= 100 ? '🏆' : pct >= 50 ? '🥇' : '🧀'}</div>
            <div style={{ fontSize: 10, color: '#9ca3af', fontWeight: 700 }}>{pct >= 100 ? 'Maître Fromager!' : pct >= 50 ? 'Affineur' : 'Apprenti'}</div>
          </div>
        </motion.div>

        {/* Region filter */}
        <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap', marginBottom: '1.5rem' }}>
          {REGIONS.map(r => (
            <button key={r} onClick={() => setRegion(r)}
              style={{ padding: '6px 14px', borderRadius: 20, border: `1px solid ${region === r ? GOLD : 'rgba(255,255,255,0.12)'}`, background: region === r ? 'rgba(201,168,76,0.15)' : 'rgba(255,255,255,0.04)', color: region === r ? GOLD : '#9ca3af', fontSize: 12, fontWeight: 600, cursor: 'pointer', transition: 'all 0.15s' }}>
              {r}
            </button>
          ))}
        </div>

        {/* Cheese grid */}
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill,minmax(300px,1fr))', gap: '1rem' }}>
          {filtered.map((cheese, i) => {
            const isTasted = tasted.includes(cheese.id);
            const rc = rarityConfig[cheese.rarity];
            const isExpanded = expanded === cheese.id;
            const pairing = pairings[cheese.id] ? JSON.parse(pairings[cheese.id]) : null;
            const isLoadingPair = pairingLoading === cheese.id;

            return (
              <motion.div key={cheese.id}
                initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.04 }}
                style={{ borderRadius: 14, background: isTasted ? 'rgba(201,168,76,0.06)' : 'rgba(255,255,255,0.03)', border: `1px solid ${isTasted ? 'rgba(201,168,76,0.3)' : 'rgba(255,255,255,0.08)'}`, overflow: 'hidden', transition: 'border-color 0.2s' }}>

                {/* Card top */}
                <div style={{ padding: '1rem 1.25rem' }}>
                  <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', marginBottom: 10 }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                      <div style={{ fontSize: 28, filter: isTasted ? 'none' : 'saturate(0.4)' }}>{cheese.emoji}</div>
                      <div>
                        <div style={{ fontWeight: 700, color: isTasted ? '#fff' : '#9ca3af', fontSize: 14, marginBottom: 2 }}>{cheese.name}</div>
                        <div style={{ fontSize: 11, color: '#6b7280' }}>{cheese.regionEmoji} {cheese.region} · {cheese.type}</div>
                      </div>
                    </div>
                    <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'flex-end', gap: 4 }}>
                      <span style={{ padding: '2px 7px', borderRadius: 10, fontSize: 10, fontWeight: 700, color: rc.color, background: `${rc.color}20`, border: `1px solid ${rc.color}40` }}>{rc.label}</span>
                      <span style={{ fontSize: 10, color: GOLD, fontWeight: 700 }}>+{rc.xp} XP</span>
                    </div>
                  </div>

                  <p style={{ fontSize: 12, color: '#9ca3af', lineHeight: 1.6, marginBottom: 10 }}>{cheese.description}</p>

                  <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 12 }}>
                    <div>
                      <div style={{ fontSize: 10, color: '#6b7280', marginBottom: 4 }}>Intensity</div>
                      <IntensityBar value={cheese.intensity} />
                    </div>
                    {isTasted && <div style={{ display: 'flex', alignItems: 'center', gap: 4, fontSize: 11, color: GOLD, fontWeight: 700 }}><CheckCircle2 style={{ width: 13, height: 13 }} /> Tasted</div>}
                  </div>

                  <div style={{ display: 'flex', gap: 8 }}>
                    <button onClick={() => toggleTasted(cheese.id, cheese)}
                      style={{ flex: 1, padding: '8px 0', borderRadius: 10, border: `1px solid ${isTasted ? GOLD : 'rgba(255,255,255,0.15)'}`, background: isTasted ? 'rgba(201,168,76,0.15)' : 'rgba(255,255,255,0.06)', color: isTasted ? GOLD : '#9ca3af', fontSize: 12, fontWeight: 700, cursor: 'pointer', transition: 'all 0.15s' }}>
                      {isTasted ? '✓ Tasted' : '+ Mark Tasted'}
                    </button>
                    <button onClick={() => {
                      setExpanded(isExpanded ? null : cheese.id);
                      if (!isExpanded) fetchPairing(cheese);
                    }}
                      style={{ padding: '8px 12px', borderRadius: 10, border: '1px solid rgba(0,64,130,0.4)', background: 'rgba(0,64,130,0.15)', color: '#60a5fa', fontSize: 12, fontWeight: 700, cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 4 }}>
                      <Wine style={{ width: 12, height: 12 }} />
                      Pairings
                      {isExpanded ? <ChevronUp style={{ width: 12, height: 12 }} /> : <ChevronDown style={{ width: 12, height: 12 }} />}
                    </button>
                  </div>
                </div>

                {/* AI Pairing panel */}
                <AnimatePresence>
                  {isExpanded && (
                    <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: 'auto', opacity: 1 }} exit={{ height: 0, opacity: 0 }} transition={{ duration: 0.25 }}
                      style={{ overflow: 'hidden', borderTop: '1px solid rgba(0,64,130,0.2)' }}>
                      <div style={{ padding: '1rem 1.25rem', background: 'rgba(0,64,130,0.08)' }}>
                        {isLoadingPair ? (
                          <div style={{ display: 'flex', alignItems: 'center', gap: 8, color: '#9ca3af', fontSize: 12 }}>
                            <Loader2 style={{ width: 14, height: 14, animation: 'spin 1s linear infinite' }} />
                            Marcel is consulting his cave…
                          </div>
                        ) : pairing ? (
                          <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
                            <div style={{ display: 'flex', gap: 8 }}>
                              <Wine style={{ width: 14, height: 14, color: '#c084fc', flexShrink: 0, marginTop: 1 }} />
                              <div><div style={{ fontSize: 10, fontWeight: 700, color: '#c084fc', marginBottom: 2 }}>WINE</div><div style={{ fontSize: 12, color: '#e5e7eb', lineHeight: 1.5 }}>{pairing.wine}</div></div>
                            </div>
                            <div style={{ display: 'flex', gap: 8 }}>
                              <Wheat style={{ width: 14, height: 14, color: GOLD, flexShrink: 0, marginTop: 1 }} />
                              <div><div style={{ fontSize: 10, fontWeight: 700, color: GOLD, marginBottom: 2 }}>BREAD</div><div style={{ fontSize: 12, color: '#e5e7eb', lineHeight: 1.5 }}>{pairing.bread}</div></div>
                            </div>
                            <div style={{ display: 'flex', gap: 8 }}>
                              <Star style={{ width: 14, height: 14, color: '#34d399', flexShrink: 0, marginTop: 1 }} />
                              <div><div style={{ fontSize: 10, fontWeight: 700, color: '#34d399', marginBottom: 2 }}>PRO TIP</div><div style={{ fontSize: 12, color: '#e5e7eb', lineHeight: 1.5 }}>{pairing.tip}</div></div>
                            </div>
                          </div>
                        ) : null}
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </motion.div>
            );
          })}
        </div>
      </FadeIn>
      <style>{`@keyframes spin { from { transform:rotate(0deg) } to { transform:rotate(360deg) } }`}</style>
    </div>
  );
}
