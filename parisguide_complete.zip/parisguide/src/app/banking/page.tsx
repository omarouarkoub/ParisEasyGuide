'use client';
import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { CreditCard, Sparkles, Loader2, ExternalLink, TrendingUp, Euro } from 'lucide-react';
import { useLanguage, LANGUAGES } from '@/lib/i18n/LanguageContext';
import { toast } from 'sonner';
import { FadeIn } from '@/components/shared/PageMotion';

const BANKS = [
  { name: 'Revolut', type: 'Neo-bank', fee: 'Free / €2.99/mo', best: 'Multi-currency, travel, instant transfers', color: '#1a1a2e', docs: 'Passport only', url: 'https://www.revolut.com', emoji: '⚡' },
  { name: 'N26', type: 'Neo-bank', fee: 'Free / €4.90/mo', best: 'EU residents, sleek app, free ATM withdrawals', color: '#1f1f1f', docs: 'Passport + EU address', url: 'https://www.n26.com', emoji: '🖤' },
  { name: 'Wise', type: 'Multi-currency', fee: '~0.4% transfers', best: 'International transfers, holds 40+ currencies', color: '#9fe870', docs: 'Passport + selfie', url: 'https://wise.com', emoji: '🌍' },
  { name: 'Boursorama', type: 'Traditional online', fee: 'Free (conditions)', best: 'Full French bank, CAF accepted, Livret A', color: '#004082', docs: 'Passport + proof of address', url: 'https://www.boursorama.com', emoji: '🏦' },
  { name: 'BNP Paribas', type: 'Traditional', fee: '€6–9/mo', best: 'Branches everywhere, student accounts (Esprit Libre)', color: '#004082', docs: 'Passport + proof of address + income', url: 'https://mabanque.bnpparibas.com', emoji: '🏛️' },
  { name: 'La Banque Postale', type: 'Post office bank', fee: '~€3/mo', best: '"Droit au compte" bank — cannot refuse you by law', color: '#fbbf24', docs: 'Passport + any address proof', url: 'https://www.labanquepostale.fr', emoji: '📮' },
];

const SAVINGS = [
  { name: 'Livret A', rate: '2.4% (2025)', limit: '€22,950', tax: 'Tax-free', note: 'Open at any French bank. Most popular savings account.', emoji: '🏦' },
  { name: 'LDDS', rate: '2.4% (2025)', limit: '€12,000', tax: 'Tax-free', note: 'Like Livret A, for solidarity/ecology projects.', emoji: '🌱' },
  { name: 'PEA', rate: 'Variable (stocks)', limit: '€150,000', tax: 'Tax-free after 5 years', note: 'EU stocks investment account. Not for US persons.', emoji: '📈' },
  { name: 'Assurance Vie', rate: '~3–6%', limit: 'Unlimited', tax: 'Favourable after 8 years', note: 'Long-term investment. Ask your bank.', emoji: '💼' },
];

const BUDGET_TABLE = [
  { category: 'Rent (studio, inner Paris)', min: 900, max: 1400, emoji: '🏠' },
  { category: 'Rent (studio, banlieue)', min: 600, max: 900, emoji: '🏘️' },
  { category: 'Navigo pass (all zones)', min: 86, max: 86, emoji: '🚇' },
  { category: 'Groceries', min: 150, max: 300, emoji: '🛒' },
  { category: 'Restaurants / eating out', min: 100, max: 300, emoji: '🍽️' },
  { category: 'Phone plan', min: 5, max: 30, emoji: '📱' },
  { category: 'Internet box', min: 20, max: 40, emoji: '📶' },
  { category: 'Gym', min: 15, max: 60, emoji: '💪' },
  { category: 'Entertainment / going out', min: 50, max: 200, emoji: '🎭' },
  { category: 'Health (top-up mutuelle)', min: 20, max: 80, emoji: '🏥' },
];

export default function BankingPage() {
  const { lang } = useLanguage();
  const langLabel = LANGUAGES.find(l => l.code === lang)?.label ?? "English";
  const [activeTab, setActiveTab] = useState<'banks' | 'savings' | 'budget' | 'tips'>('banks');
  const [question, setQuestion] = useState('');
  const [answer, setAnswer] = useState('');
  const [loading, setLoading] = useState(false);

  const QUICK = [
    'How do I open a bank account without a French address?',
    'What is a RIB and why do I need it?',
    'How does CAF housing aid affect my budget?',
    'What is the "droit au compte" procedure?',
  ];

  const ask = async (q?: string) => {
    const query = q || question;
    if (!query.trim()) return;
    setLoading(true); setAnswer('');
    try {
      const res = await fetch('/api/banking', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ question: query }) });
      const data = await res.json();
      setAnswer(data.answer || '');
    } catch { toast.error('Connection error'); }
    finally { setLoading(false); }
  };

  const TABS = [
    { id: 'banks', label: '🏦 Banks', color: '#004082' },
    { id: 'savings', label: '📈 Savings', color: '#059669' },
    { id: 'budget', label: '💶 Budget', color: '#d97706' },
    { id: 'tips', label: '💡 AI Advisor', color: '#8b5cf6' },
  ] as const;

  return (
    <div style={{ padding: '2rem 2.5rem', maxWidth: 1100, margin: '0 auto' }}>
      <FadeIn>
        <div style={{ marginBottom: '2rem' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 4 }}>
            <CreditCard style={{ width: 16, height: 16, color: '#C9A84C' }} />
            <span style={{ fontSize: 12, fontWeight: 600, color: '#C9A84C', textTransform: 'uppercase', letterSpacing: '0.1em' }}>Banking & Finance</span>
          </div>
          <h1 style={{ fontFamily: 'Playfair Display, serif', fontSize: '2rem', fontWeight: 700, color: '#fff' }}>Money & Banking in Paris</h1>
          <p style={{ color: '#6b7280', fontSize: 14 }}>Banks, savings, realistic budgets & financial tips for expats</p>
        </div>
      </FadeIn>

      <div style={{ display: 'flex', gap: 6, marginBottom: '1.25rem', flexWrap: 'wrap' }}>
        {TABS.map(tab => (
          <button key={tab.id} onClick={() => setActiveTab(tab.id)}
            style={{ padding: '8px 16px', borderRadius: 20, fontSize: 13, fontWeight: 700, cursor: 'pointer', border: `1px solid ${activeTab === tab.id ? tab.color + '66' : 'rgba(255,255,255,0.08)'}`, background: activeTab === tab.id ? `${tab.color}15` : 'rgba(255,255,255,0.03)', color: activeTab === tab.id ? '#fff' : '#9ca3af', transition: 'all 0.2s' }}>
            {tab.label}
          </button>
        ))}
      </div>

      <AnimatePresence mode="wait">
        {activeTab === 'banks' && (
          <motion.div key="banks" initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}>
            <div style={{ padding: '0.75rem 1rem', borderRadius: 10, background: 'rgba(201,168,76,0.08)', border: '1px solid rgba(201,168,76,0.2)', marginBottom: '1.25rem', fontSize: 12, color: '#fbbf24' }}>
              💡 <strong>Pro Tip:</strong> Open Revolut or Wise immediately upon arrival for day-1 spending. Then open Boursorama for your French RIB (needed for CAF, salary, rent). Most landlords require a French bank account.
            </div>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(300px, 1fr))', gap: '1rem' }}>
              {BANKS.map(b => (
                <motion.div key={b.name} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }}
                  style={{ padding: '1.25rem', borderRadius: 16, background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.08)' }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '0.75rem' }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                      <span style={{ fontSize: '1.4rem' }}>{b.emoji}</span>
                      <div>
                        <div style={{ fontWeight: 700, color: '#fff', fontSize: 14 }}>{b.name}</div>
                        <div style={{ fontSize: 10, color: '#6b7280' }}>{b.type}</div>
                      </div>
                    </div>
                    <a href={b.url} target="_blank" rel="noreferrer" style={{ color: '#60a5fa' }}>
                      <ExternalLink style={{ width: 14, height: 14 }} />
                    </a>
                  </div>
                  <div style={{ fontSize: 12, color: '#34d399', fontWeight: 700, marginBottom: 4 }}>💶 {b.fee}</div>
                  <div style={{ fontSize: 12, color: '#9ca3af', marginBottom: 4 }}>{b.best}</div>
                  <div style={{ fontSize: 11, color: '#6b7280' }}>📄 Docs: {b.docs}</div>
                </motion.div>
              ))}
            </div>
          </motion.div>
        )}

        {activeTab === 'savings' && (
          <motion.div key="savings" initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '0.75rem', marginBottom: '1.25rem' }}>
              {SAVINGS.map(s => (
                <div key={s.name} style={{ padding: '1.1rem 1.25rem', borderRadius: 14, background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(5,150,105,0.2)', display: 'flex', gap: '1rem', alignItems: 'center' }}>
                  <span style={{ fontSize: '1.5rem' }}>{s.emoji}</span>
                  <div style={{ flex: 1 }}>
                    <div style={{ fontWeight: 700, color: '#fff', fontSize: 14, marginBottom: 2 }}>{s.name}</div>
                    <div style={{ fontSize: 12, color: '#9ca3af' }}>{s.note}</div>
                  </div>
                  <div style={{ textAlign: 'right', flexShrink: 0 }}>
                    <div style={{ fontSize: 16, fontWeight: 800, color: '#34d399' }}>{s.rate}</div>
                    <div style={{ fontSize: 10, color: '#6b7280' }}>Limit: {s.limit}</div>
                    <div style={{ fontSize: 10, color: '#fbbf24' }}>{s.tax}</div>
                  </div>
                </div>
              ))}
            </div>
            <div style={{ padding: '1rem', borderRadius: 12, background: 'rgba(239,68,68,0.06)', border: '1px solid rgba(239,68,68,0.2)', fontSize: 12, color: '#fca5a5' }}>
              ⚠️ <strong>US Persons:</strong> FATCA restrictions apply. PEA and Assurance Vie may be problematic. Consult a tax advisor familiar with US-France treaties. The Livret A is generally fine.
            </div>
          </motion.div>
        )}

        {activeTab === 'budget' && (
          <motion.div key="budget" initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}>
            <div style={{ padding: '1.25rem', borderRadius: 16, background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.08)' }}>
              <div style={{ fontWeight: 700, color: '#fff', marginBottom: '1rem', fontSize: 15 }}>📊 Realistic Monthly Costs in Paris (2025)</div>
              <div style={{ display: 'flex', flexDirection: 'column', gap: '0.5rem' }}>
                {BUDGET_TABLE.map(item => (
                  <div key={item.category} style={{ display: 'flex', alignItems: 'center', gap: '0.75rem', padding: '10px 12px', borderRadius: 10, background: 'rgba(255,255,255,0.03)' }}>
                    <span style={{ fontSize: '1.1rem', width: 24 }}>{item.emoji}</span>
                    <span style={{ flex: 1, fontSize: 13, color: '#e5e7eb' }}>{item.category}</span>
                    <span style={{ fontSize: 13, fontWeight: 700, color: '#34d399' }}>€{item.min}{item.min !== item.max ? `–${item.max}` : ''}</span>
                  </div>
                ))}
              </div>
              <div style={{ marginTop: '1rem', padding: '12px 16px', borderRadius: 10, background: 'rgba(201,168,76,0.08)', border: '1px solid rgba(201,168,76,0.2)' }}>
                <div style={{ fontSize: 13, fontWeight: 700, color: '#fbbf24' }}>💡 Total range: €1,950–3,500/month</div>
                <div style={{ fontSize: 12, color: '#9ca3af', marginTop: 4 }}>With CAF (housing aid) you could save €100–350/month on rent. Register immediately at caf.fr.</div>
              </div>
            </div>
          </motion.div>
        )}

        {activeTab === 'tips' && (
          <motion.div key="tips" initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}>
            <div style={{ padding: '1.5rem', borderRadius: 16, background: 'rgba(139,92,246,0.06)', border: '1px solid rgba(139,92,246,0.2)' }}>
              <div style={{ fontSize: 13, fontWeight: 700, color: '#a78bfa', marginBottom: '0.75rem' }}>🤖 AI Finance Advisor</div>
              <div style={{ display: 'flex', gap: 8, marginBottom: '0.75rem' }}>
                <input value={question} onChange={e => setQuestion(e.target.value)} onKeyDown={e => e.key === 'Enter' && ask()}
                  placeholder="Ask about banking, taxes, savings, RIB, transfers…"
                  style={{ flex: 1, background: 'rgba(255,255,255,0.06)', border: '1px solid rgba(255,255,255,0.1)', borderRadius: 10, padding: '10px 14px', color: '#fff', fontSize: 14, outline: 'none' }} />
                <button onClick={() => ask()} disabled={loading}
                  style={{ padding: '10px 18px', borderRadius: 10, background: 'linear-gradient(135deg,#7c3aed,#5b21b6)', border: 'none', cursor: 'pointer', color: '#fff', fontWeight: 700, fontSize: 13 }}>
                  {loading ? <Loader2 style={{ width: 16, height: 16, animation: 'spin 1s linear infinite' }} /> : 'Ask'}
                </button>
              </div>
              <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap', marginBottom: '1rem' }}>
                {QUICK.map(q => (
                  <button key={q} onClick={() => { setQuestion(q); ask(q); }}
                    style={{ padding: '5px 10px', borderRadius: 20, fontSize: 11, cursor: 'pointer', border: '1px solid rgba(139,92,246,0.25)', background: 'rgba(139,92,246,0.06)', color: '#a78bfa' }}>
                    {q}
                  </button>
                ))}
              </div>
              {answer && (
                <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }}
                  style={{ padding: '1rem', borderRadius: 12, background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.08)', fontSize: 13, color: '#e5e7eb', lineHeight: 1.7 }}
                  dangerouslySetInnerHTML={{ __html: answer.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>').replace(/\n/g, '<br/>') }} />
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
      <style>{`@keyframes spin { from { transform:rotate(0deg) } to { transform:rotate(360deg) } }`}</style>
    </div>
  );
}
