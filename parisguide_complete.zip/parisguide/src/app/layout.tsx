import type { Metadata } from 'next';
import './globals.css';
import { Toaster } from 'sonner';
import QueryProvider from '@/components/QueryProvider';
import BadgeUnlockToastProvider from '@/components/quest/BadgeUnlockToast';
import { LanguageProvider } from '@/lib/i18n/LanguageContext';
import LangGate from '@/components/LangGate';

export const metadata: Metadata = {
  title: 'ParisEasyGuide+ | Your AI Paris Companion',
  description: 'AI-powered guide for Paris & Ile-de-France',
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>
        <LanguageProvider>
          <LangGate />
          <QueryProvider>
            {children}
            <BadgeUnlockToastProvider />
            <Toaster richColors position="bottom-center" />
          </QueryProvider>
        </LanguageProvider>
      </body>
    </html>
  );
}
