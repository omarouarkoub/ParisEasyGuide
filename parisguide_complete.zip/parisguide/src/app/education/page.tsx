'use client';
import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { GraduationCap, Loader2, ExternalLink } from 'lucide-react';
import { useLanguage, LANGUAGES } from '@/lib/i18n/LanguageContext';
import { toast } from 'sonner';
import { FadeIn } from '@/components/shared/PageMotion';

const SCHOOL_SYSTEM = [
  { age: '0–3', name: 'Crèche', type: 'Childcare', desc: 'Public (CAF-subsidised) or private nursery. Apply via your mairie. Waitlists can be 1–2 years — apply as early as possible.', color: '#f97316' },
  { age: '3–6', name: 'École Maternelle', type: 'Preschool (free)', desc: 'Compulsory since 2019. Assigned by "carte scolaire" (school map). Enroll at mairie from January for September entry.', color: '#fbbf24' },
  { age: '6–11', name: 'École Élémentaire', type: 'Primary (free)', desc: 'CP → CM2. Assigned school by address. Private "sous contrat" schools follow same curriculum but have more flexibility.', color: '#34d399' },
  { age: '11–15', name: 'Collège', type: 'Middle School (free)', desc: '6ème → 3ème. Ends with Brevet des Collèges exam. Choose options (foreign languages, arts, sport sections).', color: '#3b82f6' },
  { age: '15–18', name: 'Lycée', type: 'High School (free)', desc: 'Général (academic), Technologique, or Professionnel. Ends with the Baccalauréat. Application via Affelnet platform.', color: '#8b5cf6' },
  { age: '18+', name: 'Université / Grandes Écoles', type: 'Higher Education', desc: 'Parcoursup for university applications. Grandes Écoles require competitive "classes prépa". CROUS for student housing.', color: '#ec4899' },
];

const INTERNATIONAL_SCHOOLS = [
  { name: 'International School of Paris (ISP)', curriculum: 'IB', area: '16ème', tuition: '~€30–35k/year', url: 'https://www.isparis.edu' },
  { name: 'American School of Paris (ASP)', curriculum: 'US + IB', area: 'Saint-Cloud (92)', tuition: '~€30–38k/year', url: 'https://www.asparis.org' },
  { name: 'British School of Paris', curriculum: 'UK National', area: 'Croissy-sur-Seine (78)', tuition: '~€20–28k/year', url: 'https://www.britishschool.fr' },
  { name: 'École Active Bilingue Jeannine Manuel', curriculum: 'French+English bilingual', area: '15ème & others', tuition: '~€8–15k/year', url: 'https://www.jeanninemanuel.fr' },
  { name: 'Lycée International de Saint-Germain-en-Laye', curriculum: 'French + international sections', area: 'Saint-Germain (78)', tuition: 'Partial public funding', url: '' },
];

const CAF_BENEFITS = [
  { name: 'Allocations Familiales', desc: 'Monthly payment for families with 2+ children. Universal for residents.', emoji: '👨‍👩‍👧‍👦' },
  { name: 'PAJE (Prestation d\'Accueil du Jeune Enfant)', desc: 'Birth grant + monthly allowance until age 3. Income-tested.', emoji: '👶' },
  { name: 'Complément Mode de Garde (CMG)', desc: 'CAF pays part of your childcare costs for registered childminders.', emoji: '🍼' },
  { name: 'ARS (Allocation de Rentrée Scolaire)', desc: 'Back-to-school allowance paid every August. €400–500 per child.', emoji: '🎒' },
  { name: 'APL / ALF / ALS (Housing Aid)', desc: 'Housing allowance — families with children may get more than singles.', emoji: '🏠' },
];

export default function EducationPage() {
  const { lang } = useLanguage();
  const langLabel = LANGUAGES.find(l => l.code === lang)?.label ?? "English";
  const [activeTab, setActiveTab] = useState<'school' | 'intl' | 'university' | 'family' | 'childcare'>('school');
  const [question, setQuestion] = useState('');
  const [answer, setAnswer] = useState('');
  const [loading, setLoading] = useState(false);

  const ask = async (q?: string) => {
    const query = q || question;
    if (!query.trim()) return;
    setLoading(true); setAnswer('');
    try {
      const res = await fetch('/api/education', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ question: query }) });
      const data = await res.json();
      setAnswer(data.answer || '');
    } catch { toast.error('Connection error'); }
    finally { setLoading(false); }
  };

  const QUICK = ['How do I enroll my child in a Paris school?', 'How to apply for CROUS student housing?', 'What is Parcoursup and when are deadlines?', 'How to find a crèche in Paris?'];

  const TABS = [
    { id: 'school', label: '🏫 School System', color: '#3b82f6' },
    { id: 'intl', label: '🌍 Intl Schools', color: '#8b5cf6' },
    { id: 'university', label: '🎓 University', color: '#ec4899' },
    { id: 'childcare', label: '👶 Childcare', color: '#f97316' },
    { id: 'family', label: '💶 Family Benefits', color: '#059669' },
  ] as const;

  return (
    <div style={{ padding: '2rem 2.5rem', maxWidth: 1100, margin: '0 auto' }}>
      <FadeIn>
        <div style={{ marginBottom: '2rem' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 4 }}>
            <GraduationCap style={{ width: 16, height: 16, color: '#C9A84C' }} />
            <span style={{ fontSize: 12, fontWeight: 600, color: '#C9A84C', textTransform: 'uppercase', letterSpacing: '0.1em' }}>Education & Family</span>
          </div>
          <h1 style={{ fontFamily: 'Playfair Display, serif', fontSize: '2rem', fontWeight: 700, color: '#fff' }}>Education & Family Life</h1>
          <p style={{ color: '#6b7280', fontSize: 14 }}>Schools, childcare, universities, international schools & family benefits</p>
        </div>
      </FadeIn>

      <div style={{ display: 'flex', gap: 6, marginBottom: '1.25rem', flexWrap: 'wrap' }}>
        {TABS.map(tab => (
          <button key={tab.id} onClick={() => setActiveTab(tab.id)}
            style={{ padding: '8px 16px', borderRadius: 20, fontSize: 13, fontWeight: 700, cursor: 'pointer', border: `1px solid ${activeTab === tab.id ? tab.color + '66' : 'rgba(255,255,255,0.08)'}`, background: activeTab === tab.id ? `${tab.color}15` : 'rgba(255,255,255,0.03)', color: activeTab === tab.id ? '#fff' : '#9ca3af', transition: 'all 0.2s' }}>
            {tab.label}
          </button>
        ))}
      </div>

      <AnimatePresence mode="wait">
        {activeTab === 'school' && (
          <motion.div key="school" initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '0.75rem' }}>
              {SCHOOL_SYSTEM.map(s => (
                <div key={s.name} style={{ padding: '1.1rem 1.25rem', borderRadius: 14, background: `${s.color}08`, border: `1px solid ${s.color}30`, display: 'flex', gap: '1rem', alignItems: 'flex-start' }}>
                  <div style={{ padding: '4px 10px', borderRadius: 20, background: `${s.color}20`, fontSize: 11, fontWeight: 700, color: s.color, flexShrink: 0, alignSelf: 'flex-start' }}>{s.age}</div>
                  <div style={{ flex: 1 }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 4 }}>
                      <span style={{ fontWeight: 700, color: '#fff', fontSize: 14 }}>{s.name}</span>
                      <span style={{ fontSize: 11, color: s.color }}>{s.type}</span>
                    </div>
                    <div style={{ fontSize: 12, color: '#9ca3af', lineHeight: 1.6 }}>{s.desc}</div>
                  </div>
                </div>
              ))}
            </div>
            <div style={{ marginTop: '1rem', padding: '1rem', borderRadius: 12, background: 'rgba(201,168,76,0.08)', border: '1px solid rgba(201,168,76,0.2)', fontSize: 12, color: '#fbbf24' }}>
              💡 <strong>Pro Tip:</strong> Check your "carte scolaire" school zone at education.gouv.fr — your address determines which public school your child attends. Derogations (changing zones) are possible but competitive.
            </div>
          </motion.div>
        )}

        {activeTab === 'intl' && (
          <motion.div key="intl" initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '0.75rem' }}>
              {INTERNATIONAL_SCHOOLS.map(s => (
                <div key={s.name} style={{ padding: '1.1rem 1.25rem', borderRadius: 14, background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(139,92,246,0.2)' }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 4 }}>
                    <span style={{ fontWeight: 700, color: '#fff', fontSize: 14 }}>{s.name}</span>
                    {s.url && <a href={s.url} target="_blank" rel="noreferrer"><ExternalLink style={{ width: 13, height: 13, color: '#6b7280' }} /></a>}
                  </div>
                  <div style={{ display: 'flex', gap: '1rem', fontSize: 12 }}>
                    <span style={{ color: '#a78bfa' }}>📚 {s.curriculum}</span>
                    <span style={{ color: '#9ca3af' }}>📍 {s.area}</span>
                    <span style={{ color: '#34d399', fontWeight: 700 }}>💶 {s.tuition}</span>
                  </div>
                </div>
              ))}
            </div>
            <div style={{ marginTop: '1rem', padding: '1rem', borderRadius: 12, background: 'rgba(59,130,246,0.06)', border: '1px solid rgba(59,130,246,0.2)', fontSize: 12, color: '#93c5fd' }}>
              💡 <strong>Budget option:</strong> Lycée International de Saint-Germain-en-Laye has national (French) sections plus international sections (British, German, US, etc.) at much lower cost than private schools.
            </div>
          </motion.div>
        )}

        {activeTab === 'university' && (
          <motion.div key="university" initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(260px, 1fr))', gap: '1rem', marginBottom: '1.25rem' }}>
              {[
                { name: 'Campus France', desc: 'Start here for all international student admissions and visa support.', url: 'https://www.campusfrance.org', emoji: '🌍', color: '#004082' },
                { name: 'Parcoursup', desc: 'University application platform (Licence level). Deadlines: Jan–March.', url: 'https://www.parcoursup.fr', emoji: '📝', color: '#3b82f6' },
                { name: 'CROUS', desc: 'Student housing applications and restaurant universitaire (€3.30/meal).', url: 'https://www.messervices.etudiant.gouv.fr', emoji: '🏠', color: '#059669' },
                { name: 'Étudiant.gov.fr', desc: 'One-stop for CVEC, student ID, scholarships and services.', url: 'https://www.etudiant.gouv.fr', emoji: '🎓', color: '#8b5cf6' },
              ].map(item => (
                <a key={item.name} href={item.url} target="_blank" rel="noreferrer"
                  style={{ padding: '1.1rem', borderRadius: 14, background: `${item.color}08`, border: `1px solid ${item.color}30`, textDecoration: 'none', display: 'block' }}>
                  <div style={{ fontSize: '1.5rem', marginBottom: 8 }}>{item.emoji}</div>
                  <div style={{ fontWeight: 700, color: '#fff', fontSize: 14, marginBottom: 4 }}>{item.name}</div>
                  <div style={{ fontSize: 12, color: '#9ca3af' }}>{item.desc}</div>
                </a>
              ))}
            </div>
            <div style={{ display: 'flex', gap: 8, marginBottom: '0.75rem' }}>
              <input value={question} onChange={e => setQuestion(e.target.value)} onKeyDown={e => e.key === 'Enter' && ask()}
                placeholder="Ask about French universities, scholarships, CROUS housing…"
                style={{ flex: 1, background: 'rgba(255,255,255,0.06)', border: '1px solid rgba(255,255,255,0.1)', borderRadius: 10, padding: '10px 14px', color: '#fff', fontSize: 14, outline: 'none' }} />
              <button onClick={() => ask()} disabled={loading}
                style={{ padding: '10px 18px', borderRadius: 10, background: 'linear-gradient(135deg,#ec4899,#be185d)', border: 'none', cursor: 'pointer', color: '#fff', fontWeight: 700 }}>
                {loading ? <Loader2 style={{ width: 16, height: 16, animation: 'spin 1s linear infinite' }} /> : 'Ask'}
              </button>
            </div>
            <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap', marginBottom: '0.75rem' }}>
              {QUICK.map(q => (
                <button key={q} onClick={() => { setQuestion(q); ask(q); }}
                  style={{ padding: '5px 10px', borderRadius: 20, fontSize: 11, cursor: 'pointer', border: '1px solid rgba(236,72,153,0.25)', background: 'rgba(236,72,153,0.06)', color: '#f9a8d4' }}>
                  {q}
                </button>
              ))}
            </div>
            {answer && (
              <div style={{ padding: '1rem', borderRadius: 12, background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.08)', fontSize: 13, color: '#e5e7eb', lineHeight: 1.7 }}
                dangerouslySetInnerHTML={{ __html: answer.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>').replace(/\n/g, '<br/>') }} />
            )}
          </motion.div>
        )}

        {activeTab === 'childcare' && (
          <motion.div key="childcare" initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}>
            {[
              { type: 'Crèche Municipale', desc: 'City-run nursery. Cheapest option. Apply via mairie from pregnancy. Waitlist: 1–2 years. Income-based fees (€0–40/day).', emoji: '🏛️', color: '#f97316' },
              { type: 'Crèche Privée', desc: 'Private nurseries. Easier to get a spot. Higher cost (~€60–100/day before CAF subsidy).', emoji: '🏠', color: '#8b5cf6' },
              { type: 'Assistante Maternelle', desc: 'Registered childminder at their home. Flexible hours. CAF pays a large portion via CMG subsidy. Find them at mon-enfant.fr.', emoji: '👩‍👧', color: '#3b82f6' },
              { type: 'Nounou Partagée', desc: 'Shared nanny between 2–3 families. Split the cost. Find families on Facebook groups "Garde partagée Paris [arrondissement]".', emoji: '🤝', color: '#059669' },
              { type: 'Baby-sitter', desc: 'Occasional babysitting. Platforms: Yoopies, La Compagnie des Familles, Care.com.', emoji: '🌙', color: '#d97706' },
            ].map(item => (
              <div key={item.type} style={{ padding: '1rem 1.25rem', borderRadius: 14, background: `${item.color}08`, border: `1px solid ${item.color}30`, marginBottom: '0.75rem', display: 'flex', gap: '1rem', alignItems: 'flex-start' }}>
                <span style={{ fontSize: '1.5rem', flexShrink: 0 }}>{item.emoji}</span>
                <div>
                  <div style={{ fontWeight: 700, color: '#fff', fontSize: 14, marginBottom: 4 }}>{item.type}</div>
                  <div style={{ fontSize: 12, color: '#9ca3af', lineHeight: 1.6 }}>{item.desc}</div>
                </div>
              </div>
            ))}
            <div style={{ padding: '1rem', borderRadius: 12, background: 'rgba(201,168,76,0.08)', border: '1px solid rgba(201,168,76,0.2)', fontSize: 12, color: '#fbbf24' }}>
              💡 <strong>Pro Tip:</strong> Apply for crèche at your mairie as soon as you know you're pregnant or moving to Paris — lists fill up instantly in September. Don't wait until you have a birth certificate.
            </div>
          </motion.div>
        )}

        {activeTab === 'family' && (
          <motion.div key="family" initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '0.75rem', marginBottom: '1.25rem' }}>
              {CAF_BENEFITS.map(b => (
                <div key={b.name} style={{ padding: '1rem 1.25rem', borderRadius: 14, background: 'rgba(5,150,105,0.08)', border: '1px solid rgba(5,150,105,0.2)', display: 'flex', gap: '1rem', alignItems: 'flex-start' }}>
                  <span style={{ fontSize: '1.5rem', flexShrink: 0 }}>{b.emoji}</span>
                  <div>
                    <div style={{ fontWeight: 700, color: '#fff', fontSize: 14, marginBottom: 4 }}>{b.name}</div>
                    <div style={{ fontSize: 12, color: '#9ca3af', lineHeight: 1.6 }}>{b.desc}</div>
                  </div>
                </div>
              ))}
            </div>
            <a href="https://www.caf.fr" target="_blank" rel="noreferrer"
              style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8, padding: '13px', borderRadius: 12, background: 'linear-gradient(135deg,#059669,#047857)', color: '#fff', fontWeight: 700, fontSize: 14, textDecoration: 'none' }}>
              Apply for Family Benefits on caf.fr →
            </a>
          </motion.div>
        )}
      </AnimatePresence>
      <style>{`@keyframes spin { from { transform:rotate(0deg) } to { transform:rotate(360deg) } }`}</style>
    </div>
  );
}
