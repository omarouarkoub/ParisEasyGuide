'use client';
import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Train, ArrowRight, Loader2, MapPin, Sparkles, RotateCcw, Clock, Zap, Star } from 'lucide-react';
import { toast } from 'sonner';
import { FadeIn, SlideIn } from '@/components/shared/PageMotion';
import ParisMap3D from '@/components/map/ParisMap3D';

interface Section {
  type: string; mode?: string; duration: number;
  from?: { name: string }; to?: { name: string };
  display_informations?: { commercial_mode: string; label: string; color: string };
}
interface Journey { duration: number; nb_transfers: number; departure_date_time: string; arrival_date_time: string; sections: Section[]; }
interface Place { id: string; label: string; lat: number; lng: number; }
interface Result { fromPlace: Place; toPlace: Place; journeys: Journey[]; }

const POPULAR = [
  { from: 'Gare du Nord', to: 'Tour Eiffel', emoji: '🗼' },
  { from: 'République', to: 'Versailles', emoji: '👑' },
  { from: 'Châtelet-Les Halles', to: 'Orly Aéroport', emoji: '✈️' },
  { from: 'Montmartre', to: 'Musée du Louvre', emoji: '🏛️' },
  { from: 'La Défense', to: 'Nation', emoji: '🚇' },
];

const MODE_ICONS: Record<string, string> = {
  'Metro': '🚇', 'RER': '🚆', 'Bus': '🚌', 'Tram': '🚊', 'Transilien': '🚈', 'walking': '🚶', 'transfer': '🔄',
};

function formatTime(dt: string) {
  if (!dt || dt.length < 15) return dt;
  return `${dt.slice(9, 11)}:${dt.slice(11, 13)}`;
}
function formatDuration(secs: number) {
  const m = Math.round(secs / 60);
  return m < 60 ? `${m} min` : `${Math.floor(m / 60)}h ${m % 60}min`;
}

export default function CommutePage() {
  const [from, setFrom] = useState('');
  const [to, setTo] = useState('');
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<Result | null>(null);
  const [selectedJourney, setSelectedJourney] = useState(0);

  const search = async (f?: string, t?: string) => {
    const fv = f ?? from; const tv = t ?? to;
    if (!fv.trim() || !tv.trim()) { toast.error('Please enter both origin and destination.'); return; }
    setLoading(true); setResult(null);
    try {
      const res = await fetch('/api/commute', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ from: fv, to: tv }) });
      const data = await res.json();
      if (data.error) { toast.error(data.error); return; }
      if (!data.journeys?.length) { toast.error('No journeys found. Try different locations.'); return; }
      setResult(data); setSelectedJourney(0);
    } catch { toast.error('Failed to fetch journey.'); }
    finally { setLoading(false); }
  };

  const swap = () => { setFrom(to); setTo(from); setResult(null); };
  const usePop = (r: typeof POPULAR[0]) => { setFrom(r.from); setTo(r.to); setResult(null); search(r.from, r.to); };

  const mapMarkers = result ? [
    { lat: result.fromPlace.lat, lng: result.fromPlace.lng, label: result.fromPlace.label },
    { lat: result.toPlace.lat, lng: result.toPlace.lng, label: result.toPlace.label },
  ] : [];

  return (
    <div style={{ padding: '2rem 2.5rem', maxWidth: 960, margin: '0 auto' }}>
      <FadeIn>
        <div style={{ marginBottom: '2rem' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 4 }}>
            <Train style={{ width: 16, height: 16, color: '#C9A84C' }} />
            <span style={{ fontSize: 12, fontWeight: 600, color: '#C9A84C', textTransform: 'uppercase', letterSpacing: '0.1em' }}>Commute Planner</span>
          </div>
          <h1 style={{ fontFamily: 'Playfair Display, serif', fontSize: '2rem', fontWeight: 700, color: '#fff' }}>IDFM Journey Planner</h1>
          <p style={{ color: '#6b7280', fontSize: 14 }}>Métro, RER & Bus — powered by Île-de-France Mobilités</p>
        </div>
      </FadeIn>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '2rem' }}>
        {/* Left: input + results */}
        <div>
          <SlideIn from="left">
            <div style={{ padding: '1.5rem', borderRadius: 16, background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.08)', marginBottom: '1.5rem' }}>
              <div style={{ display: 'flex', gap: '0.75rem', alignItems: 'center', marginBottom: '1rem' }}>
                <div style={{ flex: 1, display: 'flex', flexDirection: 'column', gap: 8 }}>
                  <div style={{ position: 'relative' }}>
                    <div style={{ position: 'absolute', left: 12, top: '50%', transform: 'translateY(-50%)', width: 10, height: 10, borderRadius: '50%', background: '#22c55e' }} />
                    <input value={from} onChange={e => setFrom(e.target.value)} onKeyDown={e => e.key === 'Enter' && search()} placeholder="From: e.g. Gare du Nord…"
                      style={{ width: '100%', background: 'rgba(255,255,255,0.06)', border: '1px solid rgba(255,255,255,0.1)', borderRadius: 10, padding: '10px 14px 10px 30px', color: '#fff', fontSize: 14, outline: 'none', boxSizing: 'border-box' }} />
                  </div>
                  <div style={{ position: 'relative' }}>
                    <div style={{ position: 'absolute', left: 12, top: '50%', transform: 'translateY(-50%)', width: 10, height: 10, borderRadius: 3, background: '#EE2436' }} />
                    <input value={to} onChange={e => setTo(e.target.value)} onKeyDown={e => e.key === 'Enter' && search()} placeholder="To: e.g. Tour Eiffel…"
                      style={{ width: '100%', background: 'rgba(255,255,255,0.06)', border: '1px solid rgba(255,255,255,0.1)', borderRadius: 10, padding: '10px 14px 10px 30px', color: '#fff', fontSize: 14, outline: 'none', boxSizing: 'border-box' }} />
                  </div>
                </div>
                <motion.button whileTap={{ scale: 0.9 }} onClick={swap} style={{ padding: 10, borderRadius: 10, background: 'rgba(255,255,255,0.06)', border: '1px solid rgba(255,255,255,0.1)', cursor: 'pointer', color: '#9ca3af', flexShrink: 0 }}>
                  <RotateCcw style={{ width: 16, height: 16 }} />
                </motion.button>
              </div>
              <motion.button whileTap={{ scale: 0.97 }} onClick={() => search()} disabled={loading}
                style={{ width: '100%', padding: '12px', borderRadius: 12, background: loading ? 'rgba(37,99,235,0.3)' : 'linear-gradient(135deg,#1d4ed8,#2563eb)', border: 'none', cursor: 'pointer', color: '#fff', fontWeight: 700, fontSize: 14, display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8 }}>
                {loading ? <><Loader2 style={{ width: 16, height: 16, animation: 'spin 1s linear infinite' }} />Searching…</> : <><Train style={{ width: 16, height: 16 }} />Find Route</>}
              </motion.button>
            </div>
          </SlideIn>

          {/* Popular routes */}
          {!result && !loading && (
            <FadeIn delay={0.15}>
              <div style={{ marginBottom: '1.5rem' }}>
                <div style={{ fontSize: 11, fontWeight: 700, color: '#6b7280', textTransform: 'uppercase', letterSpacing: '0.06em', marginBottom: 10 }}>Popular Routes</div>
                <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
                  {POPULAR.map((r, i) => (
                    <motion.button key={i} whileHover={{ x: 4 }} whileTap={{ scale: 0.97 }} onClick={() => usePop(r)}
                      style={{ padding: '10px 14px', borderRadius: 12, background: 'rgba(37,99,235,0.06)', border: '1px solid rgba(37,99,235,0.2)', cursor: 'pointer', color: '#93c5fd', fontSize: 13, display: 'flex', alignItems: 'center', gap: 8, textAlign: 'left' }}>
                      <span>{r.emoji}</span>
                      <span style={{ flex: 1 }}>{r.from}</span>
                      <ArrowRight style={{ width: 12, height: 12, color: '#4b5563' }} />
                      <span>{r.to}</span>
                    </motion.button>
                  ))}
                </div>
              </div>
            </FadeIn>
          )}

          {/* Results */}
          <AnimatePresence>
            {result && (
              <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}>
                <div style={{ fontSize: 12, color: '#9ca3af', marginBottom: '1rem' }}>
                  <strong style={{ color: '#fff' }}>{result.journeys.length} routes</strong> found
                </div>
                <div style={{ display: 'flex', flexDirection: 'column', gap: '0.75rem' }}>
                  {result.journeys.map((j, i) => (
                    <motion.div key={i} initial={{ opacity: 0, x: -12 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: i * 0.08 }}
                      onClick={() => setSelectedJourney(i)} style={{ padding: '1.1rem', borderRadius: 14, background: selectedJourney === i ? 'rgba(37,99,235,0.1)' : 'rgba(255,255,255,0.03)', border: `1px solid ${selectedJourney === i ? 'rgba(37,99,235,0.4)' : 'rgba(255,255,255,0.08)'}`, cursor: 'pointer', transition: 'all 0.2s' }}>
                      {i === 0 && <div style={{ fontSize: 10, fontWeight: 700, color: '#3b82f6', textTransform: 'uppercase', marginBottom: 8, display: 'flex', alignItems: 'center', gap: 4 }}><Zap style={{ width: 10, height: 10 }} />Fastest</div>}
                      <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '0.75rem' }}>
                        <div style={{ display: 'flex', gap: '1.25rem' }}>
                          <div><div style={{ fontSize: '1.1rem', fontWeight: 700, color: '#fff' }}>{formatTime(j.departure_date_time)}</div><div style={{ fontSize: 10, color: '#6b7280' }}>Depart</div></div>
                          <div style={{ display: 'flex', alignItems: 'center', color: '#374151' }}><ArrowRight style={{ width: 14, height: 14 }} /></div>
                          <div><div style={{ fontSize: '1.1rem', fontWeight: 700, color: '#fff' }}>{formatTime(j.arrival_date_time)}</div><div style={{ fontSize: 10, color: '#6b7280' }}>Arrive</div></div>
                        </div>
                        <div style={{ textAlign: 'right' }}>
                          <div style={{ fontSize: '1rem', fontWeight: 700, color: '#60a5fa' }}>{formatDuration(j.duration)}</div>
                          <div style={{ fontSize: 10, color: '#6b7280' }}>{j.nb_transfers} transfer{j.nb_transfers !== 1 ? 's' : ''}</div>
                        </div>
                      </div>
                      <div style={{ display: 'flex', gap: 4, flexWrap: 'wrap' }}>
                        {j.sections.filter(s => s.type !== 'waiting').map((s, si) => {
                          const mode = s.display_informations?.commercial_mode || s.mode || s.type;
                          const icon = MODE_ICONS[mode] || (s.type === 'street_network' ? '🚶' : '🔄');
                          const lineColor = s.display_informations?.color ? `#${s.display_informations.color}` : '#4b5563';
                          return (
                            <span key={si} style={{ fontSize: 11, padding: '3px 8px', borderRadius: 20, background: s.display_informations ? `${lineColor}22` : 'rgba(255,255,255,0.06)', border: `1px solid ${s.display_informations ? lineColor + '55' : 'rgba(255,255,255,0.1)'}`, color: s.display_informations ? lineColor : '#9ca3af' }}>
                              {icon} {s.display_informations?.label || mode} · {formatDuration(s.duration)}
                            </span>
                          );
                        })}
                      </div>
                    </motion.div>
                  ))}
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {/* Right: 3D map */}
        <SlideIn from="right">
          <div style={{ position: 'sticky', top: '2rem' }}>
            <ParisMap3D markers={mapMarkers} pins={[]} routeColor="#2563eb" height="420px" accentColor="#2563eb" />
            {result && (
              <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3 }}
                style={{ marginTop: '1rem', padding: '1rem', borderRadius: 14, background: 'rgba(37,99,235,0.07)', border: '1px solid rgba(37,99,235,0.2)' }}>
                <div style={{ fontWeight: 600, color: '#fff', marginBottom: 6, fontSize: 13, display: 'flex', alignItems: 'center', gap: 6 }}>
                  <MapPin style={{ width: 14, height: 14, color: '#22c55e' }} />{result.fromPlace.label}
                </div>
                <div style={{ height: 1, background: 'rgba(255,255,255,0.08)', margin: '8px 0' }} />
                <div style={{ fontWeight: 600, color: '#fff', fontSize: 13, display: 'flex', alignItems: 'center', gap: 6 }}>
                  <MapPin style={{ width: 14, height: 14, color: '#EE2436' }} />{result.toPlace.label}
                </div>
              </motion.div>
            )}
          </div>
        </SlideIn>
      </div>
      <style>{`@keyframes spin { from { transform:rotate(0deg) } to { transform:rotate(360deg) } }`}</style>
    </div>
  );
}
