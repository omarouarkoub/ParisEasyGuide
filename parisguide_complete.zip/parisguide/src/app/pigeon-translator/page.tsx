'use client';
import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Loader2, Volume2, ThumbsUp, RefreshCw } from 'lucide-react';
import { FadeIn } from '@/components/shared/PageMotion';

const GOLD = '#C9A84C';
const RED = '#EE2436';

interface CueExample {
  cue: string;
  context: string;
  emoji: string;
  category: string;
}

const COMMON_CUES: CueExample[] = [
  { cue: 'Bof', emoji: '🤷', context: 'Waiter responds to your compliment on the food', category: 'Expression' },
  { cue: 'The slow eye roll', emoji: '🙄', context: 'You ask if the kitchen is still serving at 14h05', category: 'Body Language' },
  { cue: 'The upward lip puff (pffft)', emoji: '💨', context: 'You ask for ketchup with your steak', category: 'Sound' },
  { cue: 'La bise timing confusion', emoji: '😬', context: 'You go in for the second cheek too early', category: 'Social Ritual' },
  { cue: '"C\'est pas mal"', emoji: '😐', context: 'Your Parisian friend reviews your apartment', category: 'Expression' },
  { cue: 'The long silence after your French attempt', emoji: '⏸️', context: 'You order in French and the waiter stares', category: 'Silence' },
  { cue: '"Voilà" with a full stop energy', emoji: '✋', context: 'The pharmacist hands you your prescription', category: 'Expression' },
  { cue: 'The double cheek air-kiss ghost', emoji: '👻', context: 'A Parisienne breezes past without making contact', category: 'Social Ritual' },
  { cue: '"On verra"', emoji: '🌫️', context: 'Asked if they\'ll come to your dinner party', category: 'Expression' },
  { cue: 'Sucking air through teeth', emoji: '😬', context: 'Plumber looking at your pipes', category: 'Body Language' },
];

interface TranslationResult {
  literal: string;
  actualMeaning: string;
  subtext: string;
  correctResponse: string;
  survivalTip: string;
  dangerLevel: number;
}

export default function PigeonTranslatorPage() {
  const [input, setInput] = useState('');
  const [context, setContext] = useState('');
  const [result, setResult] = useState<TranslationResult | null>(null);
  const [loading, setLoading] = useState(false);
  const [history, setHistory] = useState<Array<{ cue: string; result: TranslationResult }>>([]);

  const translate = async (cue: string, ctx: string) => {
    if (!cue.trim()) return;
    setLoading(true);
    setResult(null);

    try {
      const res = await fetch('https://api.anthropic.com/v1/messages', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          model: 'claude-sonnet-4-6',
          max_tokens: 1000,
          messages: [{
            role: 'user',
            content: `You are a deadpan expert in Parisian social semiotics — part anthropologist, part comedian. Translate this Parisian social cue/gesture/expression into plain English for a confused tourist.

Cue: "${cue}"
Context: "${ctx || 'General Parisian interaction'}"

Respond ONLY with valid JSON in this exact format:
{
  "literal": "What it literally appears to mean (max 15 words)",
  "actualMeaning": "What it ACTUALLY means in Paris (max 25 words, be honest and slightly funny)",
  "subtext": "The deeper social message being communicated (max 30 words)",
  "correctResponse": "The ideal tourist response to this cue (max 25 words, practical)",
  "survivalTip": "One dry, useful tip to avoid this situation in future (max 30 words)",
  "dangerLevel": 3
}

dangerLevel is 1 (harmless misread) to 5 (could ruin your evening). Be witty, culturally accurate, and slightly wry. No preamble.`
          }]
        })
      });
      const data = await res.json();
      const text = data.content?.map((b: { type: string; text?: string }) => b.type === 'text' ? b.text : '').join('') || '{}';
      const clean = text.replace(/```json|```/g, '').trim();
      const parsed: TranslationResult = JSON.parse(clean);
      setResult(parsed);
      setHistory(prev => [{ cue, result: parsed }, ...prev.slice(0, 4)]);
    } catch {
      setResult({
        literal: 'Something vaguely dismissive',
        actualMeaning: 'You have committed a minor social faux pas. The pigeon flies free.',
        subtext: 'Paris remains inscrutable. This is by design.',
        correctResponse: 'Nod knowingly, order another café, and pretend nothing happened.',
        survivalTip: 'When in doubt, a slight eyebrow raise and a quiet "ah oui" works in 80% of Parisian encounters.',
        dangerLevel: 2,
      });
    }
    setLoading(false);
  };

  const handleSubmit = () => translate(input, context);
  const handleExample = (ex: CueExample) => {
    setInput(ex.cue);
    setContext(ex.context);
    translate(ex.cue, ex.context);
  };

  const dangerColors = ['', '#34d399', '#84cc16', '#fbbf24', '#f97316', RED];
  const dangerLabels = ['', 'Harmless', 'Minor', 'Moderate', 'Dangerous', 'Code Rouge'];

  return (
    <div style={{ padding: '2rem 2.5rem', maxWidth: 900, margin: '0 auto' }}>
      <FadeIn>
        {/* Header */}
        <div style={{ marginBottom: '1.5rem' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 4 }}>
            <span style={{ fontSize: 16 }}>🐦</span>
            <span style={{ fontSize: 12, fontWeight: 600, color: GOLD, textTransform: 'uppercase', letterSpacing: '0.1em' }}>Social Cue Decoder</span>
          </div>
          <h1 style={{ fontFamily: 'Playfair Display, serif', fontSize: '2rem', fontWeight: 700, color: '#fff', marginBottom: 6 }}>Paris Pigeon Translator</h1>
          <p style={{ color: '#6b7280', fontSize: 14 }}>Decode waiter eye rolls, Gallic shrugs, mysterious silences, and other Parisian social signals. AI-powered, culturally accurate, mildly alarming.</p>
        </div>

        {/* Input panel */}
        <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }}
          style={{ padding: '1.5rem', borderRadius: 16, background: 'rgba(255,255,255,0.03)', border: '1px solid rgba(255,255,255,0.1)', marginBottom: '1.5rem' }}>
          <div style={{ marginBottom: '1rem' }}>
            <label style={{ display: 'block', fontSize: 12, fontWeight: 700, color: '#9ca3af', marginBottom: 6, textTransform: 'uppercase', letterSpacing: '0.08em' }}>The Cue / Gesture / Expression</label>
            <input
              value={input}
              onChange={e => setInput(e.target.value)}
              onKeyDown={e => e.key === 'Enter' && handleSubmit()}
              placeholder="e.g. Bof, the long stare, C'est pas mal..."
              style={{ width: '100%', padding: '10px 14px', borderRadius: 10, border: '1px solid rgba(255,255,255,0.12)', background: 'rgba(255,255,255,0.05)', color: '#fff', fontSize: 14, outline: 'none', boxSizing: 'border-box' }}
            />
          </div>
          <div style={{ marginBottom: '1rem' }}>
            <label style={{ display: 'block', fontSize: 12, fontWeight: 700, color: '#9ca3af', marginBottom: 6, textTransform: 'uppercase', letterSpacing: '0.08em' }}>Context (optional)</label>
            <input
              value={context}
              onChange={e => setContext(e.target.value)}
              placeholder='e.g. "At a brasserie when I asked for the wifi password"'
              style={{ width: '100%', padding: '10px 14px', borderRadius: 10, border: '1px solid rgba(255,255,255,0.12)', background: 'rgba(255,255,255,0.05)', color: '#fff', fontSize: 14, outline: 'none', boxSizing: 'border-box' }}
            />
          </div>
          <button onClick={handleSubmit} disabled={loading || !input.trim()}
            style={{ padding: '10px 24px', borderRadius: 10, background: loading || !input.trim() ? 'rgba(201,168,76,0.2)' : 'rgba(201,168,76,0.9)', color: '#000', fontWeight: 700, fontSize: 14, border: 'none', cursor: loading || !input.trim() ? 'not-allowed' : 'pointer', display: 'flex', alignItems: 'center', gap: 8 }}>
            {loading ? <><Loader2 style={{ width: 14, height: 14, animation: 'spin 1s linear infinite' }} /> Consulting the pigeons…</> : '🐦 Translate Cue'}
          </button>
        </motion.div>

        {/* Result panel */}
        <AnimatePresence>
          {result && !loading && (
            <motion.div key="result" initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -10 }}
              style={{ padding: '1.5rem', borderRadius: 16, background: 'linear-gradient(135deg,rgba(238,36,54,0.07),rgba(0,64,130,0.07))', border: '1px solid rgba(201,168,76,0.25)', marginBottom: '1.5rem' }}>

              {/* Danger level */}
              <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: '1.25rem' }}>
                <div style={{ fontSize: 10, fontWeight: 700, color: '#6b7280', textTransform: 'uppercase', letterSpacing: '0.1em' }}>Danger Level</div>
                <div style={{ display: 'flex', gap: 4 }}>
                  {[1,2,3,4,5].map(n => (
                    <div key={n} style={{ width: 20, height: 8, borderRadius: 4, background: n <= result.dangerLevel ? dangerColors[result.dangerLevel] : 'rgba(255,255,255,0.1)', transition: 'background 0.3s' }} />
                  ))}
                </div>
                <span style={{ fontSize: 11, fontWeight: 700, color: dangerColors[result.dangerLevel] }}>{dangerLabels[result.dangerLevel]}</span>
              </div>

              <div style={{ display: 'grid', gap: '1rem' }}>
                {[
                  { label: '📖 Literal Reading', value: result.literal, color: '#9ca3af' },
                  { label: '🎯 Actual Meaning', value: result.actualMeaning, color: '#fff' },
                  { label: '🧠 Subtext', value: result.subtext, color: '#d1d5db' },
                  { label: '✅ Your Correct Response', value: result.correctResponse, color: '#34d399' },
                  { label: '🛡️ Survival Tip', value: result.survivalTip, color: GOLD },
                ].map(row => (
                  <div key={row.label} style={{ padding: '12px 16px', borderRadius: 10, background: 'rgba(0,0,0,0.2)', border: '1px solid rgba(255,255,255,0.06)' }}>
                    <div style={{ fontSize: 10, fontWeight: 700, color: '#6b7280', textTransform: 'uppercase', letterSpacing: '0.08em', marginBottom: 4 }}>{row.label}</div>
                    <div style={{ fontSize: 14, color: row.color, lineHeight: 1.6 }}>{row.value}</div>
                  </div>
                ))}
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Common cues */}
        <div>
          <div style={{ fontSize: 12, fontWeight: 700, color: '#6b7280', textTransform: 'uppercase', letterSpacing: '0.1em', marginBottom: '1rem' }}>Instant Decode — Common Situations</div>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill,minmax(260px,1fr))', gap: '0.75rem' }}>
            {COMMON_CUES.map((cue, i) => (
              <motion.button key={cue.cue}
                initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.05 * i }}
                onClick={() => handleExample(cue)}
                style={{ padding: '12px 14px', borderRadius: 12, border: '1px solid rgba(255,255,255,0.08)', background: 'rgba(255,255,255,0.03)', cursor: 'pointer', textAlign: 'left', transition: 'all 0.15s' }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 4 }}>
                  <span style={{ fontSize: 18 }}>{cue.emoji}</span>
                  <span style={{ fontSize: 13, fontWeight: 700, color: '#fff' }}>{cue.cue}</span>
                </div>
                <div style={{ fontSize: 11, color: '#6b7280', lineHeight: 1.4 }}>{cue.context}</div>
                <div style={{ marginTop: 6, fontSize: 10, color: GOLD, fontWeight: 700 }}>{cue.category}</div>
              </motion.button>
            ))}
          </div>
        </div>

        {history.length > 0 && (
          <div style={{ marginTop: '2rem' }}>
            <div style={{ fontSize: 12, fontWeight: 700, color: '#6b7280', textTransform: 'uppercase', letterSpacing: '0.1em', marginBottom: '1rem' }}>Recent Translations</div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '0.5rem' }}>
              {history.slice(1).map((h, i) => (
                <motion.div key={i} initial={{ opacity: 0 }} animate={{ opacity: 1 }}
                  style={{ padding: '10px 14px', borderRadius: 10, background: 'rgba(255,255,255,0.02)', border: '1px solid rgba(255,255,255,0.06)', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                  <div>
                    <div style={{ fontSize: 13, color: '#fff', fontWeight: 600 }}>{h.cue}</div>
                    <div style={{ fontSize: 11, color: '#6b7280' }}>{h.result.actualMeaning}</div>
                  </div>
                  <button onClick={() => { setInput(h.cue); setResult(h.result); }}
                    style={{ padding: '4px 10px', borderRadius: 8, border: '1px solid rgba(255,255,255,0.1)', background: 'transparent', color: '#9ca3af', fontSize: 11, cursor: 'pointer' }}>
                    View
                  </button>
                </motion.div>
              ))}
            </div>
          </div>
        )}
      </FadeIn>
      <style>{`@keyframes spin { from{transform:rotate(0deg)} to{transform:rotate(360deg)} }`}</style>
    </div>
  );
}
