import type { Metadata } from 'next';
import AppShell from '@/components/layout/AppShell';
export const metadata: Metadata = { title: 'Pigeon Translator | ParisEasyGuide+' };
export default function Layout({ children }: { children: React.ReactNode }) {
  return <AppShell>{children}</AppShell>;
}
