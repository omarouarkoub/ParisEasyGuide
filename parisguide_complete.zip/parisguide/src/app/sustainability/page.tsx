'use client';
import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Leaf, ExternalLink, Loader2 } from 'lucide-react';
import { toast } from 'sonner';
import { FadeIn } from '@/components/shared/PageMotion';

const RECYCLING_RULES = [
  { bin: 'Yellow Lid', what: 'Paper, cardboard, plastic bottles/cartons, metal cans, tetra-paks', color: '#fbbf24', emoji: '🟡' },
  { bin: 'White/Clear Bin', what: 'Glass bottles and jars ONLY. No caps, no ceramics, no light bulbs.', color: '#e5e7eb', emoji: '⬜' },
  { bin: 'Green/Dark Lid', what: 'All other non-recyclable waste (food scraps, non-recyclable packaging).', color: '#059669', emoji: '🟢' },
  { bin: 'Brown Bin (where available)', what: 'Food and organic waste for composting. Expanding across Paris.', color: '#92400e', emoji: '🟤' },
];

const REPAIR_REUSE = [
  { name: 'Repair Cafés Paris', desc: 'Free workshops where volunteers fix electronics, clothing, bikes — no cost. Find nearest at repaircafe.org.', url: 'https://www.repaircafe.org', emoji: '🔧' },
  { name: 'Emmaüs', desc: 'Second-hand shops & donation centres. Founded in Paris. Accepts furniture, clothing, electronics.', url: 'https://emmaus-france.org', emoji: '♻️' },
  { name: 'La Recyclerie', desc: 'Iconic Paris eco-space: workshop, urban farm, café at Porte de Clignancourt (18ème).', url: 'https://www.larecyclerie.com', emoji: '🌱' },
  { name: 'Ressourceries', desc: 'Social economy second-hand shops. Search for your nearest one at federec.fr.', url: '', emoji: '🏪' },
  { name: 'Give-boxes (Boîtes à Dons)', desc: 'Free sharing boxes in many Paris courtyards. Leave or take anything free. Check Dans Ma Rue app for locations.', url: '', emoji: '📦' },
  { name: 'Vinted', desc: 'Second-hand fashion app — huge in France. Buy or sell clothing, shoes, accessories.', url: 'https://www.vinted.fr', emoji: '👗' },
];

const ECO_FOOD = [
  { name: 'Too Good To Go', desc: 'Buy unsold food from restaurants/shops at 50–70% discount. Reduces waste.', url: 'https://www.toogoodtogo.com', emoji: '🍱' },
  { name: 'AMAP', desc: 'Direct farm-to-table basket subscription. Weekly seasonal vegetables from local farmers.', url: 'https://www.amap-idf.org', emoji: '🥕' },
  { name: 'La Ruche qui dit Oui!', desc: 'Short-circuit food delivery from local producers. Order weekly.', url: 'https://laruchequiditoui.fr', emoji: '🐝' },
  { name: 'Biocoop / Naturalia', desc: 'Organic supermarkets with bulk (en vrac) sections. Bring your own containers.', url: 'https://www.biocoop.fr', emoji: '🌿' },
  { name: 'Day by Day', desc: 'Zero-waste bulk shop. Bring jars. Fill exactly what you need.', url: 'https://www.daybyday.fr', emoji: '🫙' },
];

const ENERGY_TIPS = [
  'Apply for a free "bilan énergétique" (home energy audit) at faire.fr to identify savings.',
  'MaPrimeRénov\': government subsidy up to €20,000 for home energy renovations (insulation, heat pump). Apply at maprimerenov.gouv.fr.',
  'Switch to a green electricity provider: Enercoop (100% renewable, cooperative model), Ilek, or EkWateur.',
  'Paris has a Vélib\' electric bike fleet — choose electric bikes for zero-emission commuting.',
  'The "plan vélo" includes 1,000km of protected bike lanes — cycling is now genuinely practical across the city.',
];

export default function SustainabilityPage() {
  const [activeTab, setActiveTab] = useState<'recycling' | 'repair' | 'food' | 'energy'>('recycling');
  const [question, setQuestion] = useState('');
  const [answer, setAnswer] = useState('');
  const [loading, setLoading] = useState(false);

  const ask = async (q?: string) => {
    const query = q || question;
    if (!query.trim()) return;
    setLoading(true); setAnswer('');
    try {
      const res = await fetch('/api/sustainability', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ question: query }) });
      const data = await res.json();
      setAnswer(data.answer || '');
    } catch { toast.error('Connection error'); }
    finally { setLoading(false); }
  };

  const TABS = [
    { id: 'recycling', label: '♻️ Recycling', color: '#059669' },
    { id: 'repair', label: '🔧 Repair & Reuse', color: '#f97316' },
    { id: 'food', label: '🌿 Eco Food', color: '#34d399' },
    { id: 'energy', label: '⚡ Energy', color: '#fbbf24' },
  ] as const;

  return (
    <div style={{ padding: '2rem 2.5rem', maxWidth: 1100, margin: '0 auto' }}>
      <FadeIn>
        <div style={{ marginBottom: '2rem' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 4 }}>
            <Leaf style={{ width: 16, height: 16, color: '#C9A84C' }} />
            <span style={{ fontSize: 12, fontWeight: 600, color: '#C9A84C', textTransform: 'uppercase', letterSpacing: '0.1em' }}>Eco Life</span>
          </div>
          <h1 style={{ fontFamily: 'Playfair Display, serif', fontSize: '2rem', fontWeight: 700, color: '#fff' }}>Sustainability & Eco-Life</h1>
          <p style={{ color: '#6b7280', fontSize: 14 }}>Recycling, repair, zero waste, ethical food & green energy in Paris</p>
        </div>
      </FadeIn>

      <div style={{ display: 'flex', gap: 6, marginBottom: '1.25rem', flexWrap: 'wrap' }}>
        {TABS.map(tab => (
          <button key={tab.id} onClick={() => setActiveTab(tab.id)}
            style={{ padding: '8px 16px', borderRadius: 20, fontSize: 13, fontWeight: 700, cursor: 'pointer', border: `1px solid ${activeTab === tab.id ? tab.color + '66' : 'rgba(255,255,255,0.08)'}`, background: activeTab === tab.id ? `${tab.color}15` : 'rgba(255,255,255,0.03)', color: activeTab === tab.id ? '#fff' : '#9ca3af', transition: 'all 0.2s' }}>
            {tab.label}
          </button>
        ))}
      </div>

      <AnimatePresence mode="wait">
        {activeTab === 'recycling' && (
          <motion.div key="recycling" initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '0.75rem', marginBottom: '1.25rem' }}>
              {RECYCLING_RULES.map(r => (
                <div key={r.bin} style={{ padding: '1rem 1.25rem', borderRadius: 14, background: 'rgba(255,255,255,0.04)', border: `1px solid ${r.color}30`, display: 'flex', gap: '1rem', alignItems: 'flex-start' }}>
                  <span style={{ fontSize: '1.5rem', flexShrink: 0 }}>{r.emoji}</span>
                  <div>
                    <div style={{ fontWeight: 700, color: r.color, fontSize: 14, marginBottom: 4 }}>{r.bin}</div>
                    <div style={{ fontSize: 12, color: '#9ca3af', lineHeight: 1.6 }}>{r.what}</div>
                  </div>
                </div>
              ))}
            </div>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '0.75rem', marginBottom: '1rem' }}>
              {[
                { name: 'Guide du Tri', desc: 'Official Paris sorting guide — search any item', url: 'https://www.paris.fr/pages/trier-ses-dechets-a-paris-2456', emoji: '🗺️' },
                { name: 'Dans Ma Rue App', desc: 'Report waste or issues in Paris streets', url: '', emoji: '📱' },
                { name: 'Déchetterie Locator', desc: 'Find your local recycling centre (déchetterie)', url: 'https://www.paris.fr/pages/les-dechetteries-parisiennes-214', emoji: '🏭' },
                { name: 'Compost App', desc: 'Paris offers free compost bins — apply at mairie.paris.fr', url: 'https://www.mairie.paris.fr', emoji: '🌱' },
              ].map(item => (
                <div key={item.name} style={{ padding: '0.75rem 1rem', borderRadius: 12, background: 'rgba(5,150,105,0.06)', border: '1px solid rgba(5,150,105,0.2)', display: 'flex', gap: 10 }}>
                  <span style={{ fontSize: '1.2rem' }}>{item.emoji}</span>
                  <div>
                    <div style={{ fontWeight: 700, color: '#fff', fontSize: 13 }}>{item.name}</div>
                    <div style={{ fontSize: 11, color: '#9ca3af' }}>{item.desc}</div>
                    {item.url && <a href={item.url} target="_blank" rel="noreferrer" style={{ fontSize: 11, color: '#34d399', textDecoration: 'none' }}>Visit →</a>}
                  </div>
                </div>
              ))}
            </div>
            <div style={{ display: 'flex', gap: 8 }}>
              <input value={question} onChange={e => setQuestion(e.target.value)} onKeyDown={e => e.key === 'Enter' && ask()}
                placeholder="Ask about recycling rules, composting, déchetteries…"
                style={{ flex: 1, background: 'rgba(255,255,255,0.06)', border: '1px solid rgba(255,255,255,0.1)', borderRadius: 10, padding: '10px 14px', color: '#fff', fontSize: 14, outline: 'none' }} />
              <button onClick={() => ask()} disabled={loading} style={{ padding: '10px 18px', borderRadius: 10, background: 'linear-gradient(135deg,#059669,#047857)', border: 'none', cursor: 'pointer', color: '#fff', fontWeight: 700 }}>
                {loading ? <Loader2 style={{ width: 16, height: 16, animation: 'spin 1s linear infinite' }} /> : 'Ask'}
              </button>
            </div>
            {answer && <div style={{ marginTop: '1rem', padding: '1rem', borderRadius: 12, background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.08)', fontSize: 13, color: '#e5e7eb', lineHeight: 1.7 }} dangerouslySetInnerHTML={{ __html: answer.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>').replace(/\n/g, '<br/>') }} />}
          </motion.div>
        )}

        {activeTab === 'repair' && (
          <motion.div key="repair" initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '0.75rem' }}>
              {REPAIR_REUSE.map(r => (
                <div key={r.name} style={{ padding: '1rem 1.25rem', borderRadius: 14, background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(249,115,22,0.2)', display: 'flex', gap: '1rem', alignItems: 'flex-start' }}>
                  <span style={{ fontSize: '1.3rem', flexShrink: 0 }}>{r.emoji}</span>
                  <div style={{ flex: 1 }}>
                    <div style={{ fontWeight: 700, color: '#fff', fontSize: 14, marginBottom: 4 }}>{r.name}</div>
                    <div style={{ fontSize: 12, color: '#9ca3af', lineHeight: 1.6 }}>{r.desc}</div>
                    {r.url && <a href={r.url} target="_blank" rel="noreferrer" style={{ fontSize: 11, color: '#fb923c', textDecoration: 'none' }}>Visit →</a>}
                  </div>
                </div>
              ))}
            </div>
          </motion.div>
        )}

        {activeTab === 'food' && (
          <motion.div key="food" initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '0.75rem' }}>
              {ECO_FOOD.map(f => (
                <a key={f.name} href={f.url} target="_blank" rel="noreferrer"
                  style={{ padding: '1rem 1.25rem', borderRadius: 14, background: 'rgba(5,150,105,0.06)', border: '1px solid rgba(52,211,153,0.2)', textDecoration: 'none', display: 'flex', gap: '1rem', alignItems: 'flex-start' }}>
                  <span style={{ fontSize: '1.3rem', flexShrink: 0 }}>{f.emoji}</span>
                  <div style={{ flex: 1 }}>
                    <div style={{ fontWeight: 700, color: '#fff', fontSize: 14, marginBottom: 4 }}>{f.name}</div>
                    <div style={{ fontSize: 12, color: '#9ca3af', lineHeight: 1.6 }}>{f.desc}</div>
                  </div>
                  <ExternalLink style={{ width: 13, height: 13, color: '#6b7280', flexShrink: 0 }} />
                </a>
              ))}
            </div>
          </motion.div>
        )}

        {activeTab === 'energy' && (
          <motion.div key="energy" initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '0.75rem', marginBottom: '1.25rem' }}>
              {ENERGY_TIPS.map((tip, i) => (
                <div key={i} style={{ padding: '12px 16px', borderRadius: 12, background: 'rgba(251,191,36,0.06)', border: '1px solid rgba(251,191,36,0.2)', fontSize: 13, color: '#e5e7eb', lineHeight: 1.6, display: 'flex', gap: 10 }}>
                  <span style={{ color: '#fbbf24', flexShrink: 0 }}>⚡</span>{tip}
                </div>
              ))}
            </div>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '0.75rem' }}>
              {[
                { name: 'MaPrimeRénov\'', url: 'https://www.maprimerenov.gouv.fr', desc: 'Home renovation subsidies' },
                { name: 'Faire.fr', url: 'https://faire.fr', desc: 'Free energy audit booking' },
                { name: 'Enercoop', url: 'https://www.enercoop.fr', desc: 'Green electricity cooperative' },
                { name: 'Paris Vélos', url: 'https://www.paris.fr/pages/le-velo-a-paris-166', desc: 'Cycling infrastructure guide' },
              ].map(l => (
                <a key={l.name} href={l.url} target="_blank" rel="noreferrer"
                  style={{ padding: '0.75rem 1rem', borderRadius: 12, background: 'rgba(251,191,36,0.06)', border: '1px solid rgba(251,191,36,0.2)', textDecoration: 'none' }}>
                  <div style={{ fontWeight: 700, color: '#fff', fontSize: 13 }}>{l.name}</div>
                  <div style={{ fontSize: 11, color: '#9ca3af' }}>{l.desc}</div>
                </a>
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
      <style>{`@keyframes spin { from { transform:rotate(0deg) } to { transform:rotate(360deg) } }`}</style>
    </div>
  );
}
