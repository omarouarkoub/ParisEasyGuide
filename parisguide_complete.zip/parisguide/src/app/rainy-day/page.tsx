'use client';
import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { CloudRain, MapPin, Clock, Coffee, Film, Book, Wine } from 'lucide-react';
import { FadeIn } from '@/components/shared/PageMotion';

const GOLD = '#C9A84C';
const BLUE = '#004082';

type Category = 'all' | 'passage' | 'wine' | 'cinema' | 'bookshop' | 'café';

interface RainySpot {
  id: string;
  name: string;
  category: Category;
  arrondissement: string;
  address: string;
  description: string;
  rainyPerk: string;
  hours: string;
  priceRange: string;
  emoji: string;
  tip: string;
  indoorScore: number; // how good is it when it rains 1–5
}

const SPOTS: RainySpot[] = [
  { id: 'galerie_vivienne', name: 'Galerie Vivienne', category: 'passage', arrondissement: '2e', address: '6 Rue Vivienne', description: 'The most elegant of Paris\'s 19th-century covered passages. Mosaic floors, sculpted ceilings, a wine bar, and a tearoom.', rainyPerk: 'Completely covered 200m gallery. Gauthier vintage bookshop and A Priori Thé are perfect rain refuges.', hours: 'Open daily 8h30–20h30', priceRange: 'Free to browse', emoji: '🏛️', tip: 'Walk the full length twice — the ceilings change.', indoorScore: 5 },
  { id: 'passage_des_panoramas', name: 'Passage des Panoramas', category: 'passage', arrondissement: '2e', address: '11 Blvd Montmartre', description: 'First gas-lit passage in Paris (1817). Now hosts stamp dealers, vintage poster shops, and some legendary old-school restaurants.', rainyPerk: 'Oldest surviving passage — atmospheric in rain, feels like stepping into the 1850s.', hours: 'Mon–Sat 7h–22h, Sun 10h–20h', priceRange: 'Free to browse', emoji: '🏛️', tip: 'Stern, the engraving shop at #47, has been here since 1840.', indoorScore: 5 },
  { id: 'galerie_colbert', name: 'Galerie Colbert', category: 'passage', arrondissement: '2e', address: '2 Rue Vivienne', description: 'A BnF-managed passage with a spectacular rotunda, used for exhibitions and events. Quieter than Vivienne.', rainyPerk: 'Often has a free architecture or photography exhibition inside the rotunda.', hours: 'Mon–Sat 9h–18h (gallery); café until later', priceRange: 'Free', emoji: '🔭', tip: 'Connected to Galerie Vivienne — do both in one loop.', indoorScore: 4 },
  { id: 'cave_bourguignon', name: 'La Cave Bourguignon', category: 'wine', arrondissement: '1er', address: '48 Rue François-Miron', description: 'Hidden gem wine bar near the Marais. Walls of Burgundy bottles, low lighting, cheese boards, and wine by the glass.', rainyPerk: 'The ultimate cave à vin for a rainy afternoon. Stone walls, candles, no rush.', hours: 'Tue–Sat 12h–22h', priceRange: '€6–€14 per glass', emoji: '🍷', tip: 'Ask for the Chablis premier cru by the glass — excellent value.', indoorScore: 5 },
  { id: 'willi_wine', name: 'Willi\'s Wine Bar', category: 'wine', arrondissement: '1er', address: '13 Rue des Petits Champs', description: 'Iconic English-owned wine bar in Paris since 1980. Vintage wine posters line the walls. Superb Côtes du Rhône selection.', rainyPerk: 'Dark wood, quiet jazz, 300+ wines by the bottle, excellent plats du jour.', hours: 'Mon–Sat 12h–23h', priceRange: '€8–€20 per glass', emoji: '🍷', tip: 'Reserve for lunch — the formule is excellent value.', indoorScore: 4 },
  { id: 'mk2_bibliothèque', name: 'MK2 Bibliothèque', category: 'cinema', arrondissement: '13e', address: '128 Ave de France', description: 'Arthouse cinema next to the BnF with 14 screens, a great bar, and frequent English-language screenings with VO.', rainyPerk: 'Park the whole afternoon — film, then drinks in the bar. Programming is excellent.', hours: 'Daily from 11h30', priceRange: '€11–€14', emoji: '🎬', tip: 'Under 26? €8 for VO screenings before 17h.', indoorScore: 5 },
  { id: 'cinéma_le_champo', name: 'Le Champo', category: 'cinema', arrondissement: '5e', address: '51 Rue des Écoles', description: 'Legendary Saint-Germain arthouse. The oldest repertory cinema in Paris. Woody Allen, Truffaut, Kubrick retrospectives.', rainyPerk: 'Perfect rainy afternoon — a Truffaut double bill in a 1930s cinema.', hours: 'Daily from 14h30', priceRange: '€9–€12', emoji: '🎞️', tip: 'The tiny bar in the lobby serves excellent espresso and crêpes.', indoorScore: 5 },
  { id: 'shakespeare_co', name: 'Shakespeare and Company', category: 'bookshop', arrondissement: '5e', address: '37 Rue de la Bûcherie', description: 'The legendary English bookshop facing Notre-Dame. Reading nooks, hidden staircases, cats, and the best literary atmosphere in Paris.', rainyPerk: 'Could spend 3 hours here — multiple reading nooks, a piano, a children\'s room, and now a café next door.', hours: 'Daily 10h–22h', priceRange: 'Free to browse; books €12–€30', emoji: '📚', tip: 'The upstairs library is free to read in; the beds belong to "Tumbleweeds" who volunteer.', indoorScore: 5 },
  { id: 'librairie_galignani', name: 'Librairie Galignani', category: 'bookshop', arrondissement: '1er', address: '224 Rue de Rivoli', description: 'First English bookshop in Europe (1801), under the Rivoli arcades. Art books, literature, and philosophy in a hushed, carpeted elegance.', rainyPerk: 'Already under arcades — doubly sheltered. The art book section is world-class.', hours: 'Mon–Sat 10h–19h', priceRange: 'Free to browse', emoji: '📖', tip: 'The Tuileries gardens are visible from inside through the arcade arches.', indoorScore: 5 },
  { id: 'café_de_flore', name: 'Café de Flore', category: 'café', arrondissement: '6e', address: '172 Blvd Saint-Germain', description: 'The most famous café in Paris. Sartre wrote here. Beauvoir held court here. Now tourists and Parisians co-exist over hot chocolate.', rainyPerk: 'The upstairs room is quieter. Order the chocolat chaud — it arrives in a pot, thick as velvet.', hours: 'Daily 7h30–1h30', priceRange: '€5–€12', emoji: '☕', tip: 'Sit upstairs — less touristy, same history, better acoustics in rain.', indoorScore: 4 },
  { id: 'café_procope', name: 'Le Procope', category: 'café', arrondissement: '6e', address: '13 Rue de l\'Ancienne Comédie', description: 'Oldest café in Paris (1686). Voltaire, Rousseau, and Napoleon all drank here. Now a classic brasserie with tremendous heritage.', rainyPerk: 'Multiple vaulted rooms across 3 floors. The oldest upstairs rooms feel like a private library.', hours: 'Daily 12h–23h', priceRange: '€15–€30 (formule)', emoji: '🏺', tip: 'Ask to see Napoleon\'s hat (replica) kept behind glass.', indoorScore: 4 },
  { id: 'passage_jouffroy', name: 'Passage Jouffroy', category: 'passage', arrondissement: '9e', address: '10 Blvd Montmartre', description: 'Quirky passage with wax museum, antique walking stick shops, a hotel from the 19th century, and the wonderful Pain d\'Épices toy shop.', rainyPerk: 'Leads directly into Passage Verdeau — double the rainy-day passage walk.', hours: 'Daily 7h–22h', priceRange: 'Free', emoji: '🎩', tip: 'Visit the doll hospital at #34 — both charming and slightly eerie.', indoorScore: 4 },
];

const CATEGORIES = [
  { key: 'all', label: 'All', emoji: '🌧️' },
  { key: 'passage', label: 'Covered Passages', emoji: '🏛️' },
  { key: 'wine', label: 'Caves à Vin', emoji: '🍷' },
  { key: 'cinema', label: 'Cinemas', emoji: '🎬' },
  { key: 'bookshop', label: 'Bookshops', emoji: '📚' },
  { key: 'café', label: 'Historic Cafés', emoji: '☕' },
];

const CATEGORY_ICONS: Record<string, React.ReactNode> = {
  passage:  <MapPin style={{ width: 13, height: 13 }} />,
  wine:     <Wine style={{ width: 13, height: 13 }} />,
  cinema:   <Film style={{ width: 13, height: 13 }} />,
  bookshop: <Book style={{ width: 13, height: 13 }} />,
  café:     <Coffee style={{ width: 13, height: 13 }} />,
};

function RainAnimation() {
  return (
    <div style={{ position: 'relative', overflow: 'hidden', borderRadius: 16, padding: '1.5rem', background: 'linear-gradient(180deg, rgba(0,30,60,0.95) 0%, rgba(0,15,35,0.95) 100%)', border: '1px solid rgba(96,165,250,0.2)', marginBottom: '1.5rem' }}>
      {Array.from({ length: 20 }).map((_, i) => (
        <motion.div key={i} animate={{ y: ['-10%', '120%'], opacity: [0, 0.6, 0] }} transition={{ duration: 1.2 + Math.random() * 0.8, delay: Math.random() * 2, repeat: Infinity, ease: 'linear' }}
          style={{ position: 'absolute', top: 0, left: `${(i/20)*100}%`, width: 1, height: 14, background: 'rgba(148,187,255,0.6)', borderRadius: 1 }} />
      ))}
      <div style={{ position: 'relative', zIndex: 1 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 8 }}>
          <CloudRain style={{ width: 20, height: 20, color: '#93c5fd' }} />
          <span style={{ fontSize: 14, fontWeight: 700, color: '#93c5fd' }}>Rainy Day Mode Activated</span>
        </div>
        <div style={{ fontSize: 12, color: 'rgba(148,187,255,0.7)', lineHeight: 1.6 }}>
          Paris is at its most cinematic in the rain. Every covered passage becomes a sanctuary, every cave à vin a refuge. Here's where to go.
        </div>
      </div>
    </div>
  );
}

export default function RainyDayPage() {
  const [category, setCategory] = useState<Category>('all');
  const [saved, setSaved] = useState<string[]>([]);

  useEffect(() => {
    const s = localStorage.getItem('rainy_saved');
    if (s) setSaved(JSON.parse(s));
  }, []);

  const toggleSave = (id: string) => {
    const next = saved.includes(id) ? saved.filter(x => x !== id) : [...saved, id];
    setSaved(next);
    localStorage.setItem('rainy_saved', JSON.stringify(next));
  };

  const filtered = SPOTS.filter(s => category === 'all' || s.category === category);

  return (
    <div style={{ padding: '2rem 2.5rem', maxWidth: 1100, margin: '0 auto' }}>
      <FadeIn>
        <div style={{ marginBottom: '1.5rem' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 4 }}>
            <CloudRain style={{ width: 16, height: 16, color: '#93c5fd' }} />
            <span style={{ fontSize: 12, fontWeight: 600, color: '#93c5fd', textTransform: 'uppercase', letterSpacing: '0.1em' }}>Weather-Aware Mode</span>
          </div>
          <h1 style={{ fontFamily: 'Playfair Display, serif', fontSize: '2rem', fontWeight: 700, color: '#fff', marginBottom: 6 }}>Rainy Day Paris</h1>
          <p style={{ color: '#6b7280', fontSize: 14 }}>Covered passages, cozy wine caves, arthouse cinemas, legendary bookshops. When it rains, Paris gets interesting.</p>
        </div>

        <RainAnimation />

        {/* Category filter */}
        <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap', marginBottom: '1.5rem' }}>
          {CATEGORIES.map(c => (
            <button key={c.key} onClick={() => setCategory(c.key as Category)}
              style={{ padding: '7px 14px', borderRadius: 20, border: `1px solid ${category === c.key ? '#93c5fd' : 'rgba(255,255,255,0.12)'}`, background: category === c.key ? 'rgba(147,197,253,0.12)' : 'rgba(255,255,255,0.04)', color: category === c.key ? '#93c5fd' : '#9ca3af', fontSize: 12, fontWeight: 600, cursor: 'pointer' }}>
              {c.emoji} {c.label}
            </button>
          ))}
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill,minmax(320px,1fr))', gap: '1rem' }}>
          {filtered.map((spot, i) => {
            const isSaved = saved.includes(spot.id);
            return (
              <motion.div key={spot.id}
                initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.05 }}
                style={{ borderRadius: 14, background: 'rgba(0,20,50,0.6)', border: '1px solid rgba(96,165,250,0.15)', overflow: 'hidden', transition: 'border-color 0.2s' }}>
                <div style={{ padding: '1.25rem' }}>
                  <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', marginBottom: 10 }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                      <span style={{ fontSize: 24 }}>{spot.emoji}</span>
                      <div>
                        <div style={{ fontWeight: 700, color: '#fff', fontSize: 14, marginBottom: 2 }}>{spot.name}</div>
                        <div style={{ fontSize: 11, color: '#6b7280' }}>{spot.arrondissement} · {spot.address}</div>
                      </div>
                    </div>
                    <button onClick={() => toggleSave(spot.id)}
                      style={{ padding: '5px 10px', borderRadius: 8, border: `1px solid ${isSaved ? GOLD : 'rgba(255,255,255,0.1)'}`, background: isSaved ? 'rgba(201,168,76,0.15)' : 'transparent', color: isSaved ? GOLD : '#6b7280', fontSize: 14, cursor: 'pointer', flexShrink: 0 }}>
                      {isSaved ? '★' : '☆'}
                    </button>
                  </div>

                  {/* Indoor score */}
                  <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginBottom: 10 }}>
                    {[1,2,3,4,5].map(n => <span key={n} style={{ color: n <= spot.indoorScore ? '#93c5fd' : 'rgba(255,255,255,0.12)', fontSize: 12 }}>☔</span>)}
                    <span style={{ fontSize: 10, color: '#6b7280', fontWeight: 700 }}>RAINY DAY RATING</span>
                  </div>

                  <p style={{ fontSize: 12, color: '#9ca3af', lineHeight: 1.6, marginBottom: 10 }}>{spot.description}</p>

                  <div style={{ padding: '10px 12px', borderRadius: 10, background: 'rgba(0,64,130,0.2)', border: '1px solid rgba(96,165,250,0.15)', marginBottom: 10 }}>
                    <div style={{ fontSize: 10, fontWeight: 700, color: '#93c5fd', marginBottom: 4, display: 'flex', alignItems: 'center', gap: 4 }}>
                      <CloudRain style={{ width: 11, height: 11 }} /> RAINY DAY PERK
                    </div>
                    <div style={{ fontSize: 12, color: '#bfdbfe', lineHeight: 1.5 }}>{spot.rainyPerk}</div>
                  </div>

                  <div style={{ display: 'flex', gap: '1rem', fontSize: 11, color: '#6b7280', flexWrap: 'wrap' }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 4 }}><Clock style={{ width: 11, height: 11 }} />{spot.hours}</div>
                    <div style={{ color: '#34d399', fontWeight: 600 }}>{spot.priceRange}</div>
                  </div>

                  <div style={{ marginTop: 10, padding: '8px 12px', borderRadius: 8, background: 'rgba(201,168,76,0.07)', border: '1px solid rgba(201,168,76,0.15)' }}>
                    <span style={{ fontSize: 10, fontWeight: 700, color: GOLD }}>💡 </span>
                    <span style={{ fontSize: 11, color: '#d1d5db' }}>{spot.tip}</span>
                  </div>
                </div>
              </motion.div>
            );
          })}
        </div>
      </FadeIn>
    </div>
  );
}
