import { NextRequest, NextResponse } from 'next/server';
import Anthropic from '@anthropic-ai/sdk';

const client = new Anthropic();

export async function POST(req: NextRequest) {
  try {
    const { neighbourhood, lang } = await req.json();

    const prompt = `You are a hyper-local Paris neighbourhood expert for international students.
Write a deep-dive guide for: "${neighbourhood}"
${lang ? `Respond in ${lang}.` : ''}

Return ONLY raw JSON:
{
  "name": "neighbourhood name",
  "arrondissement": "Xème arr.",
  "tagline": "one evocative sentence",
  "vibe": "2-3 sentences on the character and feel",
  "student_score": 8.5,
  "safety_score": 8.0,
  "affordability_score": 7.0,
  "transport_score": 9.0,
  "metro_lines": ["Line X", "Line Y"],
  "rer_lines": ["RER X"],
  "avg_studio_rent": "€X–Y/month",
  "avg_meal_cost": "€X",
  "must_know": [
    { "emoji": "🥖", "title": "thing to know", "detail": "specific detail" }
  ],
  "hidden_gems": [
    { "name": "place name", "type": "café/park/market/etc", "why": "why students love it", "address": "street" }
  ],
  "student_life": {
    "universities_nearby": ["list"],
    "coworking_spaces": ["name — address — price/day"],
    "best_study_cafes": ["name — wifi quality — avg spend"]
  },
  "food_guide": {
    "cheapest_meal": { "place": "name", "dish": "what", "price": "€X" },
    "best_bakery": { "name": "name", "specialty": "what", "address": "street" },
    "halal_options": "specific recommendation",
    "vegetarian_options": "specific recommendation",
    "supermarkets": ["name — hours — note"]
  },
  "admin_offices": [
    { "type": "CAF/Préfecture/etc", "address": "address", "note": "tip" }
  ],
  "seasonal_tips": {
    "summer": "tip",
    "winter": "tip",
    "avoid": "what to avoid or be careful about"
  }
}`;

    const response = await client.messages.create({
      model: 'claude-sonnet-4-20250514',
      max_tokens: 2000,
      messages: [{ role: 'user', content: prompt }],
    });

    const raw = response.content
      .filter((b) => b.type === 'text')
      .map((b) => (b as { type: 'text'; text: string }).text)
      .join('');

    const guide = JSON.parse(raw.replace(/```json|```/g, '').trim());
    return NextResponse.json({ guide });
  } catch (error) {
    console.error('Neighbourhood API error:', error);
    return NextResponse.json({ error: 'Failed to load neighbourhood guide' }, { status: 500 });
  }
}
