import { NextRequest, NextResponse } from 'next/server';
import Anthropic from '@anthropic-ai/sdk';

const anthropic = new Anthropic();

export async function POST(req: NextRequest) {
  try {
    const { question, lang } = await req.json();
    const resp = await anthropic.messages.create({
      model: 'claude-sonnet-4-6',
      max_tokens: 800,
      system: `French banking and finance expert for expats in Paris. Advise on opening bank accounts, online banks (N26, Revolut, Wise), Livret A savings, credit cards, wire transfers, and managing finances in France. Respond in ${lang || 'English'}.`,
      messages: [{ role: 'user', content: question }],
    });
    const answer = resp.content.filter((b: any) => b.type === 'text').map((b: any) => b.text).join('');
    return NextResponse.json({ answer: answer || '' });
  } catch {
    return NextResponse.json({ error: 'Failed to get banking advice' }, { status: 500 });
  }
}
