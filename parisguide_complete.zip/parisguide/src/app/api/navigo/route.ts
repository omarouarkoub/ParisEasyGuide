import { NextRequest, NextResponse } from 'next/server';
import Anthropic from '@anthropic-ai/sdk';

const client = new Anthropic();

export async function POST(req: NextRequest) {
  try {
    const { homeAddress, schoolAddress, workAddress, travelDays, currentPass } = await req.json();

    const prompt = `You are a Navigo expert for Île-de-France Mobilités (IDFM).
Analyze this student's travel pattern and recommend the optimal Navigo pass.

Home: ${homeAddress}
School/University: ${schoolAddress}
Work/Internship: ${workAddress || 'none'}
Days traveling per week: ${travelDays}
Current pass: ${currentPass || 'none'}

Paris Metro zones: Zone 1 = Paris center, Zone 2 = inner suburbs, Zone 3-5 = outer suburbs, CDG = Zone 5.
Key prices (monthly):
- Navigo Mois Zone 1-2: €86.40/month (covers ALL Paris metro, RER inside Paris)
- Navigo Mois Zone 1-5: €130.40/month (covers EVERYTHING including Versailles, CDG, Orly)
- Navigo Liberté+: pay-per-trip, capped at €28.80/week
- Imagine'R (student under 26): Zone 1-2 €350/year = €29.17/month HUGE SAVING
- Navigo Jeunes Weekend: €4.50 flat for unlimited weekend travel

IMPORTANT: Navigo Mois always resets on the 1st — if bought mid-month, it expires on the 1st next month.

Return ONLY raw JSON:
{
  "home_zone": "Zone X",
  "school_zone": "Zone X",
  "recommended_pass": "exact pass name",
  "monthly_cost": "€XX.XX",
  "annual_cost": "€XXX",
  "savings_vs_current": "€XX/month saved",
  "key_insight": "most important insight for this student",
  "imagine_r_eligible": true,
  "imagine_r_saving": "€XX/month vs Navigo Mois",
  "when_to_buy": "specific advice on timing",
  "zones_covered": ["list of what they can reach"],
  "alternatives": [
    { "name": "pass name", "cost": "€XX/month", "best_for": "when this makes sense" }
  ],
  "traps": ["common mistake students make with this zone/pass"],
  "activation_steps": [
    "step 1: where to buy the Navigo card",
    "step 2: what ID to bring",
    "step 3: how to load the pass"
  ]
}`;

    const response = await client.messages.create({
      model: 'claude-sonnet-4-20250514',
      max_tokens: 1500,
      messages: [{ role: 'user', content: prompt }],
    });

    const raw = response.content
      .filter((b) => b.type === 'text')
      .map((b) => (b as { type: 'text'; text: string }).text)
      .join('');

    const plan = JSON.parse(raw.replace(/```json|```/g, '').trim());
    return NextResponse.json({ plan });
  } catch (error) {
    console.error('Navigo API error:', error);
    return NextResponse.json({ error: 'Failed to analyze Navigo' }, { status: 500 });
  }
}
