import { NextRequest, NextResponse } from 'next/server';
import Anthropic from '@anthropic-ai/sdk';

const client = new Anthropic();

export async function POST(req: NextRequest) {
  try {
    const { question, lang } = await req.json();

    const response = await client.messages.create({
      model: 'claude-sonnet-4-20250514',
      max_tokens: 800,
      system: `You are a Paris seasonal expert. Advise on seasonal events, local customs, cultural etiquette, safety tips, dress codes, what to expect by season. Respond in ${lang || 'English'}.`,
      messages: [{ role: 'user', content: question }],
    });

    const answer = response.content
      .filter((b) => b.type === 'text')
      .map((b) => (b as { type: 'text'; text: string }).text)
      .join('');

    return NextResponse.json({ answer });
  } catch (error) {
    console.error('Seasonal API error:', error);
    return NextResponse.json({ error: 'Failed to get seasonal advice' }, { status: 500 });
  }
}
