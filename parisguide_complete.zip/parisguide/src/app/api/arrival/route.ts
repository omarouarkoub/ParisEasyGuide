import { NextRequest, NextResponse } from 'next/server';
import Anthropic from '@anthropic-ai/sdk';

const client = new Anthropic();

function getStudentCalendarContext(): string {
  const month = new Date().getMonth() + 1;
  const contexts: Record<number, string> = {
    1:  'January: Parcoursup opens Feb 15. S2 semester starts. Tax declaration season begins.',
    2:  'February: Parcoursup opens this month. Internship applications peak.',
    3:  'March: Internship season peak. CAF housing aid renewal due.',
    4:  'April: Parcoursup choices lock. Easter holidays, fewer admin appointments.',
    5:  'May: Exams begin. Préfecture appointments hard to get before summer.',
    6:  'June: URGENT — book all préfecture appointments NOW before August closure.',
    7:  'July: Préfecture partially closed. CROUS applications close. Book titre de séjour renewal immediately.',
    8:  'August: Most préfectures CLOSED. Emergency services only.',
    9:  'September: Rentrée. CVEC fee due. Campus France registration. S1 starts.',
    10: 'October: CVEC deadline Oct 15. CAF housing aid application window.',
    11: 'November: L2/L3 application research season. Internship search begins.',
    12: 'December: Parcoursup prep. University enrollment renewal.',
  };
  return contexts[month] || '';
}

export async function POST(req: NextRequest) {
  try {
    const { destination, terminal, arrivalTime, profile, lang } = await req.json();
    const calendarCtx = getStudentCalendarContext();

    const prompt = `You are a hyper-local Paris arrival expert for international students.
A student just landed at ${terminal || 'CDG Airport'} and is going to: "${destination}" in Paris.
Arrival time: ${arrivalTime || 'now'}.
Student profile: ${profile || 'international student, first time in Paris, luggage, budget-conscious'}.
Current admin context: ${calendarCtx}
${lang ? `Respond in ${lang}.` : ''}

Return ONLY raw JSON (no markdown) with this exact structure:
{
  "transport": {
    "recommendation": "best route name",
    "line": "e.g. RER B",
    "cost": "€XX.XX",
    "duration": "XX minutes",
    "departure_tip": "specific platform/car tip",
    "navigo_advice": "whether to buy Navigo today or not, and why",
    "validation_warning": "critical validation reminder"
  },
  "steps": [
    { "step": 1, "icon": "emoji", "action": "clear action", "french_phrase": "phrase they need", "critical": true, "fine": "fine amount if rule broken" }
  ],
  "neighbourhood_intel": {
    "nearest_supermarket": "name + address + hours",
    "nearest_pharmacy": "name + note about English speakers",
    "nearest_prefecture": "address + booking url + current wait weeks",
    "sim_card": "best option for newcomers",
    "nearest_bank": "student-friendly bank + address"
  },
  "tonight": {
    "meal": "specific affordable restaurant or street",
    "wifi": "how to get internet tonight",
    "emergency_numbers": { "samu": "15", "police": "17", "pompiers": "18", "eu_emergency": "112" }
  },
  "urgent_admin": [
    { "task": "task name", "deadline": "when", "url": "link if applicable", "priority": "high/medium" }
  ],
  "welcome_message": "warm 1-sentence welcome in their language"
}`;

    const response = await client.messages.create({
      model: 'claude-sonnet-4-20250514',
      max_tokens: 2000,
      messages: [{ role: 'user', content: prompt }],
    });

    const raw = response.content
      .filter((b) => b.type === 'text')
      .map((b) => (b as { type: 'text'; text: string }).text)
      .join('');

    const plan = JSON.parse(raw.replace(/```json|```/g, '').trim());
    return NextResponse.json({ plan });
  } catch (error) {
    console.error('Arrival API error:', error);
    return NextResponse.json({ error: 'Failed to generate arrival plan' }, { status: 500 });
  }
}
