import { NextRequest, NextResponse } from 'next/server';
import Anthropic from '@anthropic-ai/sdk';

const _anthropic = new Anthropic();

const FALLBACK_TIMELINE = {
  welcome_message: "Bienvenue à Paris! I've built you a personalised plan to get settled quickly and confidently.",
  settled_score: 15,
  settled_score_label: "Just Landing",
  critical_next: [
    { id: 'sejour', title: 'Validate your titre de séjour', description: 'Within 3 months of arrival, visit the préfecture or book online.', urgency: 'urgent', deadline: 'Within 3 months', category: 'admin', link_label: 'Book online', link_url: 'https://administration-etrangers-en-france.interieur.gouv.fr', days_from_arrival: 7, emoji: '🏛️' },
    { id: 'bank', title: 'Open a bank account', description: 'Start with Revolut (passport only) or BNP Paribas student account.', urgency: 'urgent', deadline: 'Within 2 weeks', category: 'banking', link_label: 'Open Revolut', link_url: 'https://www.revolut.com/fr-FR/', days_from_arrival: 3, emoji: '🏦' },
    { id: 'ameli', title: 'Register for Sécurité Sociale', description: 'Create your account at ameli.fr to get health coverage.', urgency: 'soon', deadline: 'Within 1 month', category: 'healthcare', link_label: 'Register on Ameli', link_url: 'https://www.ameli.fr', days_from_arrival: 14, emoji: '❤️‍🩹' },
    { id: 'navigo', title: 'Get your Navigo card', description: 'Buy a Navigo Easy or personalised Navigo at any metro station.', urgency: 'urgent', deadline: 'ASAP', category: 'transport', link_label: 'Navigo info', link_url: 'https://www.navigo.fr', days_from_arrival: 1, emoji: '🚇' },
    { id: 'caf', title: 'Apply for CAF housing aid', description: 'APL can reduce your rent by €80-250/month. Apply within 3 months.', urgency: 'soon', deadline: 'Within 3 months', category: 'housing', link_label: 'Apply on CAF', link_url: 'https://www.caf.fr', days_from_arrival: 30, emoji: '🏠' },
  ],
  timeline_weeks: [
    { week: 'Week 1', theme: 'Survival & Essentials', tasks: ['Get a Navigo card at any metro station', 'Open a Revolut account', 'Get a SIM card'] },
    { week: 'Week 2', theme: 'Getting Official', tasks: ['Book préfecture appointment', 'Register at ameli.fr', 'Find nearest pharmacy'] },
    { week: 'Month 1', theme: 'Settling In', tasks: ['Apply for CAF housing aid', 'Set up internet box', 'Declare a médecin traitant'] },
    { week: 'Month 3', theme: 'Thriving', tasks: ['Join a French conversation group', 'Explore free museum Sundays', 'Build your social network'] },
  ],
  insider_tips: ['Book préfecture appointments at 8:00am sharp — slots fill in minutes', 'Monoprix discounts fresh food after 7pm', 'Most Paris museums are free the first Sunday of each month'],
  modules_for_them: [
    { path: '/admin', label: 'Admin Guide', emoji: '🏛️', reason: 'Your most urgent priority — navigate French bureaucracy step by step.' },
    { path: '/banking', label: 'Banking', emoji: '💳', reason: 'You need a French bank account before almost anything else works.' },
    { path: '/healthcare', label: 'Healthcare', emoji: '❤️‍🩹', reason: 'Register for Sécurité Sociale and find your médecin traitant.' },
    { path: '/navigo', label: 'Navigo', emoji: '🚇', reason: 'Stop overpaying — find your optimal metro pass.' },
  ],
};

export async function POST(req: NextRequest) {
  try {
    const { profile } = await req.json();

    const arrivalDate = profile.arrival_date
      ? new Date(profile.arrival_date).toLocaleDateString('en-GB', { day: 'numeric', month: 'long', year: 'numeric' })
      : 'recently';

    const prompt = `You are Marcel, a hyper-expert AI companion for newcomers to Paris and Île-de-France. 
A user just completed onboarding. Build them a personalised to-do timeline.

USER PROFILE:
- Name: ${profile.name}
- Profile type: ${profile.profile_type}
- Visa type: ${profile.visa_type}
- Arrived: ${arrivalDate}
- Area: ${profile.arrondissement}
- French level: ${profile.french_level}
- Housing status: ${profile.housing_status}
- Has children: ${profile.has_children}
- Has pets: ${profile.has_pets}
- Top priorities: ${profile.goals?.join(', ')}

Return ONLY raw JSON (no markdown, no code blocks) with this exact structure:
{
  "welcome_message": "Personalised warm welcome in 2 sentences mentioning their name and specific situation",
  "settled_score": 15,
  "settled_score_label": "Just landing",
  "critical_next": [
    {
      "id": "unique_id",
      "title": "Task title",
      "description": "1-2 sentence specific description with exact URLs or addresses when relevant",
      "urgency": "urgent|soon|when_ready",
      "deadline": "ASAP|Within 3 months|Within 1 year|No deadline",
      "category": "admin|housing|healthcare|banking|transport|culture|work|language|family|pets",
      "link_label": "Button label",
      "link_url": "https://...",
      "days_from_arrival": 3,
      "emoji": "🏛️"
    }
  ],
  "timeline_weeks": [
    { "week": "Week 1", "theme": "Survival & Essentials", "tasks": ["task 1", "task 2", "task 3"] },
    { "week": "Week 2", "theme": "Getting Official", "tasks": ["...", "...", "..."] },
    { "week": "Month 1", "theme": "Settling In", "tasks": ["...", "...", "..."] },
    { "week": "Month 3", "theme": "Thriving", "tasks": ["...", "...", "..."] }
  ],
  "insider_tips": ["Hyper-specific Paris tip relevant to their profile"],
  "modules_for_them": [
    { "path": "/admin", "label": "Admin Guide", "emoji": "🏛️", "reason": "Why this is their top priority module" }
  ]
}

Rules:
- critical_next: 5-8 tasks tailored EXACTLY to their profile
- urgent = do within 2 weeks. soon = 1-3 months. when_ready = eventually
- If non-EU visa: make titre de séjour validation the first urgent task
- If they have children: include école/crèche tasks. If pets: include vet/pet passport tasks.
- All URLs must be real, working French government or service URLs`;

    const _anthropicResp = await _anthropic.messages.create({
      model: 'claude-sonnet-4-20250514',
      max_tokens: 3000,
      messages: [{ role: 'user', content: prompt }],
    });
    const _anthropicRaw = _anthropicResp.content.filter((b: any) => b.type === 'text').map((b: any) => b.text).join('');
    const raw = _anthropicRaw || '{}';
    const timeline = JSON.parse(raw.replace(/```json|```/g, '').trim());
    return NextResponse.json({ timeline, success: true });
  } catch (error) {
    console.error('Onboarding API error:', error);
    return NextResponse.json({ success: false, timeline: FALLBACK_TIMELINE });
  }
}
