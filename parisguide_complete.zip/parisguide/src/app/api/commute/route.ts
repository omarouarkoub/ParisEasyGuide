import { NextRequest, NextResponse } from 'next/server';
import { geocodePlace, getJourneys } from '@/lib/idfmApi';

export async function POST(req: NextRequest) {
  try {
    const { from, to, datetime } = await req.json();

    const [fromPlace, toPlace] = await Promise.all([
      geocodePlace(from),
      geocodePlace(to),
    ]);

    if (!fromPlace || !toPlace) {
      return NextResponse.json({ error: 'Could not find one or both locations. Try a more specific address or station name.' }, { status: 404 });
    }

    const journeys = await getJourneys(fromPlace.id, toPlace.id, datetime);
    return NextResponse.json({ fromPlace, toPlace, journeys });
  } catch (error) {
    console.error('Commute API error:', error);
    return NextResponse.json({ error: 'Failed to get journey information' }, { status: 500 });
  }
}
