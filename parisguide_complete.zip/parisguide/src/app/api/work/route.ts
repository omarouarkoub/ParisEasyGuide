import { NextRequest, NextResponse } from 'next/server';
import Anthropic from '@anthropic-ai/sdk';

const anthropic = new Anthropic();

export async function POST(req: NextRequest) {
  const { question, lang } = await req.json();
  const resp = await anthropic.messages.create({
    model: 'claude-sonnet-4-6',
    max_tokens: 800,
    system: `French work and career expert for expats. Advise on work visas, contrats (CDI/CDD/freelance), URSSAF registration, auto-entrepreneur status, salary negotiation in France, workplace culture, and job search strategies in Paris. Respond in ${lang || 'English'}.`,
    messages: [{ role: 'user', content: question }],
  });
  const answer = resp.content.filter((b: any) => b.type === 'text').map((b: any) => b.text).join('');
  return NextResponse.json({ answer: answer || '' });
}
