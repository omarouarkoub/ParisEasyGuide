import { NextRequest, NextResponse } from 'next/server';
import { createClient } from '@/lib/supabase/server';
import { BADGE_CATALOG, XP_PER_RARITY } from '@/lib/questBadges';

export async function GET() {
  try {
    const supabase = await createClient();
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return NextResponse.json({ badges: [] });
    const { data } = await supabase.from('quest_badges').select('*').eq('user_id', user.id).order('earned_at', { ascending: false });
    return NextResponse.json({ badges: data || [] });
  } catch (error) {
    return NextResponse.json({ error: 'Failed to fetch badges' }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const supabase = await createClient();
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

    const { badge_id } = await req.json();
    const catalog = BADGE_CATALOG.find((b) => b.badge_id === badge_id);
    if (!catalog) return NextResponse.json({ error: 'Unknown badge' }, { status: 400 });

    // Upsert (ignore if already earned)
    const { data, error } = await supabase.from('quest_badges').upsert({
      user_id: user.id,
      badge_id: catalog.badge_id,
      badge_name: catalog.name,
      rarity: catalog.rarity as string,
      xp: XP_PER_RARITY[catalog.rarity],
      category: catalog.category,
    } as any, { onConflict: 'user_id,badge_id', ignoreDuplicates: true }).select().single();

    if (error && error.code !== '23505') {
      return NextResponse.json({ error: error.message }, { status: 500 });
    }

    return NextResponse.json({ badge: data, catalog });
  } catch (error) {
    return NextResponse.json({ error: 'Failed to award badge' }, { status: 500 });
  }
}
