import { NextRequest, NextResponse } from 'next/server';
import Anthropic from '@anthropic-ai/sdk';

const _anthropic = new Anthropic();

export async function POST(req: NextRequest) {
  try {
    const { query, arrondissement, category, lang } = await req.json();
    const langInstruction = lang ? `Respond in ${lang}.` : 'Respond in English.';

    const prompt = `You are a hyper-local Paris explorer guide. ${langInstruction}
User is exploring: "${query || 'hidden gems in Paris'}"
Area: ${arrondissement || 'All Paris'}  Category: ${category || 'general'}

Return ONLY raw JSON:
{
  "title": "catchy exploration title",
  "intro": "2-sentence intro",
  "places": [
    {
      "name": "place name",
      "type": "café/museum/market/park/etc",
      "address": "specific address",
      "arrondissement": "Xème",
      "why": "why it is special — 1-2 sentences",
      "best_time": "when to visit",
      "cost": "free or €X",
      "insider_tip": "something only locals know",
      "lat": 48.8566,
      "lng": 2.3522,
      "emoji": "emoji"
    }
  ],
  "transport_tip": "how to get around",
  "best_day": "best day of week and why"
}`;

    const _anthropicResp = await _anthropic.messages.create({
      model: 'claude-sonnet-4-20250514',
      max_tokens: 2000,
      messages: [{ role: 'user', content: prompt }],
    });
    const _anthropicRaw = _anthropicResp.content.filter((b: any) => b.type === 'text').map((b: any) => b.text).join('');
    // (Anthropic SDK throws on errors — no ok check needed)
    const raw = _anthropicRaw || '{}';
    const result = JSON.parse(raw.replace(/```json|```/g, '').trim());
    return NextResponse.json({ result });
  } catch (error) {
    console.error('Explore API error:', error);
    return NextResponse.json({ error: 'Failed to generate exploration guide' }, { status: 500 });
  }
}
