import { NextRequest, NextResponse } from 'next/server';
import { createClient } from '@/lib/supabase/server';
import Anthropic from '@anthropic-ai/sdk';

const client = new Anthropic();

const SYSTEM_PROMPT = `You are Marcel, an expert AI companion for Paris and the Île-de-France region.

You speak English, French, Arabic, Portuguese, Mandarin (Chinese), and Hindi fluently.
CRITICAL: Always detect and respond in the SAME language the user is writing in — if they write in Arabic, reply in Arabic; if they write in Mandarin, reply in Mandarin; etc.
If a preferred language is specified in the system context, use that language for your response.

You help with: transport (Métro, RER, Bus, Navigo card), tourist attractions, restaurants,
administrative tasks (CAF, Préfecture, AMELI, titre de séjour), cultural tips, budget advice,
housing, banking, healthcare, education, and anything related to life in Paris and Île-de-France.

When given a location, provide tailored local tips. Be warm, concise, and practical.
Always give actionable advice with specific street names, arrondissements, or station names when relevant.
Format responses clearly — use bullet points and line breaks for readability.`;

export async function POST(req: NextRequest) {
  try {
    const { messages, image, lang } = await req.json();
    const lastUserMsg = messages[messages.length - 1];

    const langInstruction = lang
      ? `\n\nThe user's preferred language is: ${lang}. Please respond in ${lang} unless they write in a different language.`
      : '';

    // Build the last user message content (with optional image)
    let lastContent: Anthropic.MessageParam['content'];
    if (image) {
      lastContent = [
        {
          type: 'image',
          source: { type: 'base64', media_type: 'image/jpeg', data: image },
        },
        {
          type: 'text',
          text: lastUserMsg.content || 'What does this say? Translate and explain it.',
        },
      ];
    } else {
      lastContent = lastUserMsg.content;
    }

    // Build history (all but last message)
    const history: Anthropic.MessageParam[] = messages.slice(0, -1).map(
      (m: { role: string; content: string }) => ({
        role: m.role as 'user' | 'assistant',
        content: m.content,
      })
    );

    const response = await client.messages.create({
      model: 'claude-sonnet-4-20250514',
      max_tokens: 1024,
      system: SYSTEM_PROMPT + langInstruction,
      messages: [
        ...history,
        { role: 'user', content: lastContent },
      ],
    });

    const text = response.content
      .filter((b) => b.type === 'text')
      .map((b) => (b as { type: 'text'; text: string }).text)
      .join('');

    // Persist to Supabase (non-blocking, best effort)
    try {
      const supabase = await createClient();
      const { data: { user } } = await supabase.auth.getUser();
      if (user) {
        const supabaseAny = supabase as unknown as { from: (t: string) => { insert: (r: object[]) => Promise<void> } };
        await supabaseAny.from('chat_messages').insert([
          { user_id: user.id, role: 'user', content: lastUserMsg.content },
          { user_id: user.id, role: 'assistant', content: text },
        ]);
      }
    } catch { /* Supabase optional — silently skip */ }

    return NextResponse.json({ content: text });
  } catch (error) {
    console.error('Chat API error:', error);
    return NextResponse.json({ error: 'Failed to get response from AI' }, { status: 500 });
  }
}
