import { NextRequest, NextResponse } from 'next/server';
import Anthropic from '@anthropic-ai/sdk';

const client = new Anthropic();

export async function POST(req: NextRequest) {
  try {
    const { location, duration, budget, interests, lang } = await req.json();

    const prompt = `Create a detailed Paris itinerary for someone starting from "${location || 'central Paris'}".
Duration: ${duration}
Budget: ${budget}
Interests: ${interests.join(', ')}
${lang ? `Language: Respond with place names and tips in ${lang}.` : ''}

Return a JSON object with this exact structure (no markdown, just raw JSON):
{
  "title": "string — catchy itinerary title",
  "summary": "string — 1 sentence overview",
  "steps": [
    {
      "time": "string — e.g. 9:00",
      "place": "string — place name",
      "address": "string — address or arrondissement",
      "description": "string — what to do/see",
      "duration": "string — e.g. 45 min",
      "cost": "string — e.g. Free or €15",
      "tip": "string — insider tip",
      "lat": 48.8566,
      "lng": 2.3522
    }
  ],
  "transport_tip": "string — how to get around for this itinerary",
  "total_cost": "string — estimated total cost"
}`;

    const response = await client.messages.create({
      model: 'claude-sonnet-4-20250514',
      max_tokens: 2048,
      messages: [{ role: 'user', content: prompt }],
    });

    const raw = response.content
      .filter((b) => b.type === 'text')
      .map((b) => (b as { type: 'text'; text: string }).text)
      .join('');

    const itinerary = JSON.parse(raw.replace(/```json|```/g, '').trim());
    return NextResponse.json({ itinerary });
  } catch (error) {
    console.error('Itinerary API error:', error);
    return NextResponse.json({ error: 'Failed to generate itinerary' }, { status: 500 });
  }
}
