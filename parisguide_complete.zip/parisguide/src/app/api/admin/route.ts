import { NextRequest, NextResponse } from 'next/server';
import Anthropic from '@anthropic-ai/sdk';

const anthropic = new Anthropic();

const ADMIN_SYSTEM = `You are an expert French administrative assistant specialising in Paris & Île-de-France procedures for international residents and students. You know:
- Titre de séjour (residence permit) procedures by nationality
- Préfecture de Police de Paris and all sub-préfectures
- CAF (housing aid) applications
- CROUS student housing, CVEC payment, Parcoursup and university enrolment
- French bank account opening (La Banque Postale, Société Générale student)
- Assurance Maladie (Sécurité Sociale) registration for students
- Campus France procedures and French tax declaration for students

Always be specific: give exact document names, URLs, wait times, costs, and office addresses.
When a procedure involves a préfecture, always warn about wait times (currently 6–10 weeks for most appointments).
Respond in the same language the user writes in (French, English, Arabic, Portuguese, Mandarin, or Hindi).`;

export async function POST(req: NextRequest) {
  try {
    const { question, nationality, arrondissement, studentType } = await req.json();
    const context = `User context: Nationality: ${nationality || 'unknown'}, Lives in: ${arrondissement || 'Paris'}, Student type: ${studentType || 'international student'}`;
    const resp = await anthropic.messages.create({
      model: 'claude-sonnet-4-6',
      max_tokens: 1500,
      system: ADMIN_SYSTEM,
      messages: [{ role: 'user', content: `${context}\n\nQuestion: ${question}` }],
    });
    const answer = resp.content.filter((b: any) => b.type === 'text').map((b: any) => b.text).join('');
    return NextResponse.json({ answer: answer || '' });
  } catch {
    return NextResponse.json({ error: 'Failed to get admin help' }, { status: 500 });
  }
}
