import { NextRequest, NextResponse } from 'next/server';
import Anthropic from '@anthropic-ai/sdk';

const _anthropic = new Anthropic();
export async function POST(req: NextRequest) {
  const { question, lang} = await req.json();
  const _anthropicResp = await _anthropic.messages.create({
      model: 'claude-sonnet-4-20250514',
      max_tokens: 800,
      system: 'Paris culture, leisure and social life expert. Give detailed, practical advice about entertainment, language learning, social life, LGBTQ+ scene, nightlife in Paris.',
      messages: [{ role: 'user', content: question }],
    });
  const _anthropicRaw = _anthropicResp.content.filter((b: any) => b.type ==='text').map((b: any) => b.text).join('');
  return NextResponse.json({ answer: _anthropicRaw || '' });
}
