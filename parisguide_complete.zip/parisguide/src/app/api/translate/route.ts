import { NextRequest, NextResponse } from 'next/server';
import Anthropic from '@anthropic-ai/sdk';

const client = new Anthropic();

export async function POST(req: NextRequest) {
  try {
    const { text, fromLang, toLang, image } = await req.json();

    let content: Anthropic.MessageParam['content'];

    if (image) {
      content = [
        {
          type: 'image',
          source: { type: 'base64', media_type: 'image/jpeg', data: image },
        },
        {
          type: 'text',
          text: `Extract all text from this image then translate it from ${fromLang} to ${toLang}. Return: first the extracted text labeled "Extracted:", then the translation labeled "Translation:". Keep formatting.`,
        },
      ];
    } else {
      content = `Translate the following text from ${fromLang} to ${toLang}. Return only the translated text, nothing else.\n\nText: ${text}`;
    }

    const response = await client.messages.create({
      model: 'claude-sonnet-4-20250514',
      max_tokens: 1024,
      messages: [{ role: 'user', content }],
    });

    const result = response.content
      .filter((b) => b.type === 'text')
      .map((b) => (b as { type: 'text'; text: string }).text)
      .join('');

    return NextResponse.json({ result });
  } catch (error) {
    console.error('Translate API error:', error);
    return NextResponse.json({ error: 'Translation failed' }, { status: 500 });
  }
}
