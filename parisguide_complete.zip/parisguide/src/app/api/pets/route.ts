import { NextRequest, NextResponse } from 'next/server';
import Anthropic from '@anthropic-ai/sdk';

const anthropic = new Anthropic();

export async function POST(req: NextRequest) {
  const { question, lang } = await req.json();
  const resp = await anthropic.messages.create({
    model: 'claude-sonnet-4-6',
    max_tokens: 800,
    system: `Pet ownership expert for Paris and France. Advise on pet import rules, veterinarians, pet-friendly housing, dog-friendly spaces, vaccinations, and pet registration in France. Respond in ${lang || 'English'}.`,
    messages: [{ role: 'user', content: question }],
  });
  const answer = resp.content.filter((b: any) => b.type === 'text').map((b: any) => b.text).join('');
  return NextResponse.json({ answer: answer || '' });
}
