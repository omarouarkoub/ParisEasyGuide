import { NextRequest, NextResponse } from 'next/server';
import Anthropic from '@anthropic-ai/sdk';

const _anthropic = new Anthropic();

export async function POST(req: NextRequest) {
  try {
    const { expenses, budget, total } = await req.json();
    const prompt = `You are a Paris budget advisor. The user has a daily budget of €${budget} and has spent €${total.toFixed(2)} so far.
Expenses: ${JSON.stringify(expenses)}

Give 3 brief, practical Paris-specific tips to save money or optimise their spending. 
Be specific (mention actual Paris stores, markets, or strategies). Return as a JSON array of strings, max 2 sentences each.
Example: ["Tip 1", "Tip 2", "Tip 3"]`;

    const _anthropicResp = await _anthropic.messages.create({
      model: 'claude-sonnet-4-20250514',
      max_tokens: 512,
      messages: [{ role: 'user', content: prompt }],
    });
    // data replaced by Anthropic
    const raw = _anthropicResp.content.filter((b: any) => b.type === 'text').map((b: any) => b.text).join('');
    const clean = raw.replace(/```json|```/g, '').trim();
    const tips = JSON.parse(clean);
    return NextResponse.json({ tips });
  } catch (error) {
    console.error('Budget API error:', error);
    return NextResponse.json({ error: 'Failed to get tips' }, { status: 500 });
  }
}
