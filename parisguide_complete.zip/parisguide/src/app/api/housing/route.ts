import { NextRequest, NextResponse } from 'next/server';
import Anthropic from '@anthropic-ai/sdk';

const _anthropic = new Anthropic();

export async function POST(req: NextRequest) {
  try {
    const { budget, arrondissements, roomType, university, moveInDate, lang} = await req.json();

    const prompt = `You are a Paris student housing expert. Give hyper-specific, actionable advice.

Student profile:
- Budget: ${budget}/month
- Preferred areas: ${arrondissements?.join(', ') || 'flexible'}
- Room type: ${roomType || 'studio'}
- University: ${university || 'not specified'}
- Move-in: ${moveInDate || 'ASAP'}

Return ONLY raw JSON:
{
  "budget_analysis": {
    "realistic": true,
    "verdict": "one sentence assessment",
    "average_rent": "€X–Y/month for this type in these areas",
    "caf_eligible": true,
    "caf_estimate": "€XX–XX/month reduction via CAF housing aid"
  },
  "best_platforms": [
    { "name": "platform name", "url": "url", "best_for": "why use this", "tip": "insider tip", "free": true }
  ],
  "neighbourhood_picks": [
    { "name": "arrondissement or area", "avg_rent": "€X/month", "vibe": "character in 1 sentence", "commute_to_center": "X min", "student_density": "high/medium/low", "safety": "good/average", "emoji": "emoji" }
  ],
  "crous_info": {
    "available": true,
    "application_url": "url",
    "deadline": "date or season",
    "wait_time": "X months typical",
    "tip": "insider advice"
  },
  "scam_warnings": ["specific scam to watch for in Paris rental market"],
  "required_documents": ["document name — what it is"],
  "garant_options": [
    { "name": "option", "cost": "€X/month or % of rent", "url": "url", "best_for": "who this suits" }
  ],
  "action_plan": [
    { "day": "Day 1", "action": "specific action", "url": "link if applicable" }
  ]
}`;

    const _anthropicResp = await _anthropic.messages.create({
      model: 'claude-sonnet-4-20250514',
      max_tokens: 2000,
      messages: [{ role: 'user', content: prompt }],
    });
    const _anthropicRaw = _anthropicResp.content.filter((b: any) => b.type === 'text').map((b: any) => b.text).join('');
    const raw = _anthropicRaw || '{}';
    const plan = JSON.parse(raw.replace(/```json|```/g, '').trim());
    return NextResponse.json({ plan });
  } catch (error) {
    return NextResponse.json({ error: 'Failed to get housing advice' }, { status: 500 });
  }
}
