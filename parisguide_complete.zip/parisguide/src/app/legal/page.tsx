'use client';
import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Scale, Loader2, ExternalLink, AlertTriangle } from 'lucide-react';
import { useLanguage, LANGUAGES } from '@/lib/i18n/LanguageContext';
import { toast } from 'sonner';
import { FadeIn } from '@/components/shared/PageMotion';

const LOST_DOCS = [
  { doc: 'Passport', steps: ['File a "déclaration de perte ou vol" at the nearest police station (commissariat)', 'Contact your consulate/embassy immediately — they issue emergency travel documents', 'In Paris, find your consulate at diplomatie.gouv.fr or your country\'s embassy website', 'Emergency passport can be issued within 24–72h by most embassies'], color: '#3b82f6', emoji: '🛂' },
  { doc: 'Titre de Séjour / Carte de Séjour', steps: ['File a police declaration (déclaration de perte) — get a "récépissé" copy', 'Book a préfecture appointment immediately on the ANEF platform (anef.immigration.interieur.gouv.fr)', 'The récépissé serves as temporary proof of legal status', 'Bring: ID, photos, declaration, all original documents for replacement'], color: '#8b5cf6', emoji: '🪪' },
  { doc: 'Credit Card / Bank Card', steps: ['Call your bank\'s 24h opposition number immediately (on back of card)', 'Universal card cancellation: 0892 705 705 (€0.34/min)', 'Revolut/N26: freeze instantly in app, then request replacement', 'File a police declaration if stolen for insurance claim'], color: '#f59e0b', emoji: '💳' },
  { doc: 'Phone', steps: ['Call your operator to suspend the SIM: Free 3244, Orange 3900, SFR 1023', 'Use "Find My" (iOS) or Google Find My Device to locate/wipe remotely', 'File a police declaration for insurance', 'Your IMEI (on original box or receipt) is needed for operator blacklisting'], color: '#ef4444', emoji: '📱' },
];

const TENANT_RIGHTS = [
  { right: 'Trêve Hivernale', desc: 'Winter eviction ban: Nov 1 – Mar 31. No evictions during this period, regardless of rent arrears. Call ADIL (0805 160 075) if threatened.', color: '#3b82f6', emoji: '❄️' },
  { right: 'Deposit Return', desc: 'Landlord must return deposit within 1 month (no damage) or 2 months (with damage). They must itemise deductions. File with ADIL if refused.', color: '#059669', emoji: '💶' },
  { right: 'Repairs', desc: 'Major repairs (heating, water, roof) are landlord\'s responsibility. Document everything by registered letter (lettre recommandée). Use ADIL for disputes.', color: '#f59e0b', emoji: '🔧' },
  { right: 'Rent Increase', desc: 'Capped by Indice de Référence des Loyers (IRL). Landlord must give 3 months\' notice. Increases outside IRL cap are illegal — contest at ADIL.', color: '#8b5cf6', emoji: '📈' },
  { right: 'Rental Insurance (assurance habitation)', desc: 'Mandatory in France. Tenants must have it. Covers fire, water damage, theft. From €5–15/month.', color: '#ea580c', emoji: '🛡️' },
];

const CONSUMER_RIGHTS = [
  { name: 'Garantie Légale de Conformité', desc: '2-year legal guarantee on all goods sold in France. If product fails within 2 years, seller must repair, replace, or refund. No receipt needed (bank statement suffices).', emoji: '✅' },
  { name: 'Droit de Rétractation', desc: '14-day right to cancel any online/distance purchase. No reason needed. Full refund within 14 days.', emoji: '↩️' },
  { name: 'SignalConso', desc: 'Government platform to report any commercial fraud, scam, or unfair practice. signal.conso.gouv.fr', url: 'https://signal.conso.gouv.fr', emoji: '🚨' },
  { name: 'UFC-Que Choisir', desc: 'France\'s leading consumer protection association. Free advice, legal templates, dispute help.', url: 'https://www.quechoisir.org', emoji: '🔍' },
  { name: 'Médiateur', desc: 'Free mediation service for disputes with banks, insurance, telecoms. Faster than court. Each sector has its own mediator.', emoji: '⚖️' },
];

const LEGAL_AID = [
  { name: 'Aide Juridictionnelle', desc: 'Free or reduced-cost legal representation for low-income residents. Apply at the tribunal judiciaire near you.', url: 'https://www.justice.fr', emoji: '🏛️' },
  { name: 'Maison de la Justice et du Droit (MJD)', desc: 'Free legal consultations with lawyers, social workers, notaires. Found in every arrondissement.', url: 'https://www.justice.gouv.fr', emoji: '⚖️' },
  { name: 'ADIL (Housing Legal Aid)', desc: 'Free specialised advice on housing law, landlord-tenant disputes, rent, deposits. Call 0805 160 075.', url: 'https://www.anil.org', emoji: '🏠' },
  { name: 'Prud\'hommes', desc: 'Labour court — free, handles all employment disputes. No lawyer required. Effective for wage theft, unfair dismissal.', url: 'https://www.conseil-prud-hommes.fr', emoji: '👔' },
];

export default function LegalPage() {
  const { lang } = useLanguage();
  const langLabel = LANGUAGES.find(l => l.code === lang)?.label ?? "English";
  const [activeTab, setActiveTab] = useState<'lost' | 'tenant' | 'consumer' | 'aid' | 'ai'>('lost');
  const [question, setQuestion] = useState('');
  const [answer, setAnswer] = useState('');
  const [loading, setLoading] = useState(false);
  const [expandedDoc, setExpandedDoc] = useState<string | null>(null);

  const ask = async (q?: string) => {
    const query = q || question;
    if (!query.trim()) return;
    setLoading(true); setAnswer('');
    try {
      const res = await fetch('/api/legal', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ question: query }) });
      const data = await res.json();
      setAnswer(data.answer || '');
    } catch { toast.error('Connection error'); }
    finally { setLoading(false); }
  };

  const QUICK = ['My landlord won\'t return my deposit', 'I was pickpocketed — what do I do?', 'My employer hasn\'t paid my salary', 'I received a product that doesn\'t work — what are my rights?', 'How do I file a police report in France?'];

  const TABS = [
    { id: 'lost', label: '🆘 Lost Documents', color: '#ef4444' },
    { id: 'tenant', label: '🏠 Tenant Rights', color: '#3b82f6' },
    { id: 'consumer', label: '🛒 Consumer Rights', color: '#059669' },
    { id: 'aid', label: '⚖️ Legal Aid', color: '#8b5cf6' },
    { id: 'ai', label: '🤖 AI Legal Help', color: '#d97706' },
  ] as const;

  return (
    <div style={{ padding: '2rem 2.5rem', maxWidth: 1100, margin: '0 auto' }}>
      <FadeIn>
        <div style={{ marginBottom: '2rem' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 4 }}>
            <Scale style={{ width: 16, height: 16, color: '#C9A84C' }} />
            <span style={{ fontSize: 12, fontWeight: 600, color: '#C9A84C', textTransform: 'uppercase', letterSpacing: '0.1em' }}>Legal & Emergency</span>
          </div>
          <h1 style={{ fontFamily: 'Playfair Display, serif', fontSize: '2rem', fontWeight: 700, color: '#fff' }}>Legal & Emergency Situations</h1>
          <p style={{ color: '#6b7280', fontSize: 14 }}>Lost documents, tenant rights, consumer protection & legal aid in Paris</p>
        </div>
      </FadeIn>

      <div style={{ padding: '0.75rem 1.25rem', borderRadius: 12, background: 'rgba(239,68,68,0.08)', border: '1px solid rgba(239,68,68,0.25)', marginBottom: '1.25rem', fontSize: 12, color: '#fca5a5', display: 'flex', gap: 8, alignItems: 'center' }}>
        <AlertTriangle style={{ width: 14, height: 14, flexShrink: 0 }} />
        For real emergencies: 17 (Police), 15 (SAMU medical), 18 (Pompiers), 112 (EU universal). This guide provides general information — consult a professional for serious legal situations.
      </div>

      <div style={{ display: 'flex', gap: 6, marginBottom: '1.25rem', flexWrap: 'wrap' }}>
        {TABS.map(tab => (
          <button key={tab.id} onClick={() => setActiveTab(tab.id)}
            style={{ padding: '8px 16px', borderRadius: 20, fontSize: 13, fontWeight: 700, cursor: 'pointer', border: `1px solid ${activeTab === tab.id ? tab.color + '66' : 'rgba(255,255,255,0.08)'}`, background: activeTab === tab.id ? `${tab.color}15` : 'rgba(255,255,255,0.03)', color: activeTab === tab.id ? '#fff' : '#9ca3af', transition: 'all 0.2s' }}>
            {tab.label}
          </button>
        ))}
      </div>

      <AnimatePresence mode="wait">
        {activeTab === 'lost' && (
          <motion.div key="lost" initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '0.75rem' }}>
              {LOST_DOCS.map(d => (
                <div key={d.doc}>
                  <motion.button onClick={() => setExpandedDoc(expandedDoc === d.doc ? null : d.doc)} style={{ width: '100%', padding: '1rem 1.25rem', borderRadius: expandedDoc === d.doc ? '14px 14px 0 0' : 14, background: `${d.color}08`, border: `1px solid ${d.color}35`, cursor: 'pointer', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                      <span style={{ fontSize: '1.3rem' }}>{d.emoji}</span>
                      <span style={{ fontWeight: 700, color: '#fff', fontSize: 14 }}>Lost/Stolen: {d.doc}</span>
                    </div>
                    <span style={{ color: d.color, fontSize: 16 }}>{expandedDoc === d.doc ? '▲' : '▼'}</span>
                  </motion.button>
                  <AnimatePresence>
                    {expandedDoc === d.doc && (
                      <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: 'auto' }} exit={{ opacity: 0, height: 0 }}
                        style={{ padding: '1rem 1.25rem', background: `${d.color}05`, border: `1px solid ${d.color}25`, borderTop: 'none', borderRadius: '0 0 14px 14px' }}>
                        {d.steps.map((step, i) => (
                          <div key={i} style={{ display: 'flex', gap: 10, marginBottom: 8, fontSize: 13 }}>
                            <span style={{ color: d.color, fontWeight: 700, flexShrink: 0 }}>{i + 1}.</span>
                            <span style={{ color: '#e5e7eb', lineHeight: 1.6 }}>{step}</span>
                          </div>
                        ))}
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>
              ))}
            </div>
            <div style={{ marginTop: '1rem', padding: '1rem', borderRadius: 12, background: 'rgba(201,168,76,0.08)', border: '1px solid rgba(201,168,76,0.2)', fontSize: 12, color: '#fbbf24' }}>
              💡 <strong>Pro Tip:</strong> Keep a photo of all important documents (passport, carte de séjour, insurance cards) in a secure cloud folder. This speeds up all replacement processes enormously.
            </div>
          </motion.div>
        )}

        {activeTab === 'tenant' && (
          <motion.div key="tenant" initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '0.75rem', marginBottom: '1.25rem' }}>
              {TENANT_RIGHTS.map(r => (
                <div key={r.right} style={{ padding: '1rem 1.25rem', borderRadius: 14, background: `${r.color}08`, border: `1px solid ${r.color}30`, display: 'flex', gap: '1rem', alignItems: 'flex-start' }}>
                  <span style={{ fontSize: '1.3rem', flexShrink: 0 }}>{r.emoji}</span>
                  <div>
                    <div style={{ fontWeight: 700, color: r.color, fontSize: 14, marginBottom: 4 }}>{r.right}</div>
                    <div style={{ fontSize: 12, color: '#9ca3af', lineHeight: 1.6 }}>{r.desc}</div>
                  </div>
                </div>
              ))}
            </div>
            <a href="https://www.anil.org" target="_blank" rel="noreferrer"
              style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8, padding: '13px', borderRadius: 12, background: 'linear-gradient(135deg,#1d4ed8,#1e40af)', color: '#fff', fontWeight: 700, fontSize: 14, textDecoration: 'none' }}>
              Free Housing Legal Advice → ADIL (0805 160 075)
            </a>
          </motion.div>
        )}

        {activeTab === 'consumer' && (
          <motion.div key="consumer" initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '0.75rem' }}>
              {CONSUMER_RIGHTS.map(r => (
                <div key={r.name} style={{ padding: '1rem 1.25rem', borderRadius: 14, background: 'rgba(5,150,105,0.06)', border: '1px solid rgba(5,150,105,0.2)', display: 'flex', gap: '1rem', alignItems: 'flex-start' }}>
                  <span style={{ fontSize: '1.3rem', flexShrink: 0 }}>{r.emoji}</span>
                  <div style={{ flex: 1 }}>
                    <div style={{ fontWeight: 700, color: '#fff', fontSize: 14, marginBottom: 4 }}>{r.name}</div>
                    <div style={{ fontSize: 12, color: '#9ca3af', lineHeight: 1.6 }}>{r.desc}</div>
                    {('url' in r) && r.url && <a href={r.url as string} target="_blank" rel="noreferrer" style={{ fontSize: 11, color: '#34d399', textDecoration: 'none' }}>Visit →</a>}
                  </div>
                </div>
              ))}
            </div>
          </motion.div>
        )}

        {activeTab === 'aid' && (
          <motion.div key="aid" initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '0.75rem' }}>
              {LEGAL_AID.map(l => (
                <a key={l.name} href={l.url} target="_blank" rel="noreferrer"
                  style={{ padding: '1rem 1.25rem', borderRadius: 14, background: 'rgba(139,92,246,0.06)', border: '1px solid rgba(139,92,246,0.2)', textDecoration: 'none', display: 'flex', gap: '1rem', alignItems: 'flex-start' }}>
                  <span style={{ fontSize: '1.3rem', flexShrink: 0 }}>{l.emoji}</span>
                  <div style={{ flex: 1 }}>
                    <div style={{ fontWeight: 700, color: '#fff', fontSize: 14, marginBottom: 4 }}>{l.name}</div>
                    <div style={{ fontSize: 12, color: '#9ca3af', lineHeight: 1.6 }}>{l.desc}</div>
                  </div>
                  <ExternalLink style={{ width: 13, height: 13, color: '#6b7280', flexShrink: 0 }} />
                </a>
              ))}
            </div>
          </motion.div>
        )}

        {activeTab === 'ai' && (
          <motion.div key="ai" initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}>
            <div style={{ padding: '1rem', borderRadius: 12, background: 'rgba(217,119,6,0.08)', border: '1px solid rgba(217,119,6,0.25)', marginBottom: '1rem', fontSize: 12, color: '#fbbf24' }}>
              ℹ️ This AI provides general information only — not legal advice. For serious matters, consult a lawyer via the Maison de la Justice et du Droit or apply for Aide Juridictionnelle.
            </div>
            <div style={{ display: 'flex', gap: 8, marginBottom: '0.75rem' }}>
              <input value={question} onChange={e => setQuestion(e.target.value)} onKeyDown={e => e.key === 'Enter' && ask()}
                placeholder="Describe your legal situation or question…"
                style={{ flex: 1, background: 'rgba(255,255,255,0.06)', border: '1px solid rgba(255,255,255,0.1)', borderRadius: 10, padding: '10px 14px', color: '#fff', fontSize: 14, outline: 'none' }} />
              <button onClick={() => ask()} disabled={loading} style={{ padding: '10px 18px', borderRadius: 10, background: 'linear-gradient(135deg,#d97706,#b45309)', border: 'none', cursor: 'pointer', color: '#fff', fontWeight: 700 }}>
                {loading ? <Loader2 style={{ width: 16, height: 16, animation: 'spin 1s linear infinite' }} /> : 'Ask'}
              </button>
            </div>
            <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap', marginBottom: '1rem' }}>
              {QUICK.map(q => (<button key={q} onClick={() => { setQuestion(q); ask(q); }} style={{ padding: '5px 10px', borderRadius: 20, fontSize: 11, cursor: 'pointer', border: '1px solid rgba(217,119,6,0.25)', background: 'rgba(217,119,6,0.06)', color: '#fbbf24' }}>{q}</button>))}
            </div>
            {answer && <div style={{ padding: '1rem', borderRadius: 12, background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.08)', fontSize: 13, color: '#e5e7eb', lineHeight: 1.7 }} dangerouslySetInnerHTML={{ __html: answer.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>').replace(/\n/g, '<br/>') }} />}
          </motion.div>
        )}
      </AnimatePresence>
      <style>{`@keyframes spin { from { transform:rotate(0deg) } to { transform:rotate(360deg) } }`}</style>
    </div>
  );
}
