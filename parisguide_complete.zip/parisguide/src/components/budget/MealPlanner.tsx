'use client';
import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { UtensilsCrossed, Sparkles, ChevronDown, ChevronUp, ShoppingCart, Loader2, RefreshCw, Euro } from 'lucide-react';

const DAYS = ['Lundi', 'Mardi', 'Mercredi', 'Jeudi', 'Vendredi', 'Samedi', 'Dimanche'];
const MEAL_SLOTS = ['breakfast', 'lunch', 'dinner'] as const;
type MealSlot = typeof MEAL_SLOTS[number];
const SLOT_LABELS: Record<MealSlot, string> = { breakfast: '🌅 Breakfast', lunch: '☀️ Lunch', dinner: '🌙 Dinner' };
const SLOT_EMOJI: Record<MealSlot, string> = { breakfast: '🌅', lunch: '☀️', dinner: '🌙' };

interface Meal { name: string; description: string; cost: string; calories: string; isParisian?: boolean; }
type WeekPlan = Record<string, Record<MealSlot, Meal>>;

const DIETS = ['Balanced', 'Vegetarian', 'Vegan', 'French Classic', 'Budget (<€10/day)', 'High-protein'];

export default function MealPlanner() {
  const [diet, setDiet] = useState('French Classic');
  const [budget, setBudget] = useState('€15–25/day');
  const [weekPlan, setWeekPlan] = useState<WeekPlan | null>(null);
  const [groceries, setGroceries] = useState<string[]>([]);
  const [loading, setLoading] = useState(false);
  const [expandedDay, setExpandedDay] = useState<string | null>('Lundi');
  const [tab, setTab] = useState<'plan' | 'groceries'>('plan');

  const generate = async () => {
    setLoading(true);
    setWeekPlan(null);
    setGroceries([]);
    try {
      const prompt = `Create a 7-day Paris meal plan (${diet}, budget ${budget}).
For each day (Lundi through Dimanche) and each slot (breakfast, lunch, dinner), return a JSON object.
Each meal: { name, description (1 sentence, very brief), cost (€X.XX), calories (e.g. 420 kcal), isParisian (true if it's a classic French/Parisian dish) }.
Also include a "groceries" array of 12–15 items to buy at a Paris supermarché.

Return ONLY raw JSON, no markdown, exactly this shape:
{
  "plan": {
    "Lundi": { "breakfast": {...}, "lunch": {...}, "dinner": {...} },
    ...all 7 days...
  },
  "groceries": ["item1", "item2", ...]
}`;

      const res = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ messages: [{ role: 'user', content: prompt }] }),
      });
      const data = await res.json();
      const raw = (data.content || '').replace(/```json|```/g, '').trim();
      const parsed = JSON.parse(raw);
      setWeekPlan(parsed.plan);
      setGroceries(parsed.groceries || []);
      setExpandedDay('Lundi');
    } catch (e) {
      console.error('Meal planner error:', e);
    } finally {
      setLoading(false);
    }
  };

  const totalDays = weekPlan ? Object.keys(weekPlan).length : 0;

  return (
    <div style={{ borderRadius: 20, background: 'rgba(255,255,255,0.03)', border: '1px solid rgba(255,255,255,0.08)', overflow: 'hidden' }}>
      {/* Header */}
      <div style={{ padding: '1.25rem 1.5rem', borderBottom: '1px solid rgba(255,255,255,0.06)', display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexWrap: 'wrap', gap: '0.75rem' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
          <div style={{ width: 36, height: 36, borderRadius: 10, background: 'rgba(234,88,12,0.15)', border: '1px solid rgba(234,88,12,0.3)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            <UtensilsCrossed style={{ width: 18, height: 18, color: '#fb923c' }} />
          </div>
          <div>
            <div style={{ fontWeight: 700, color: '#fff', fontSize: 15 }}>Weekly Meal Planner</div>
            <div style={{ fontSize: 11, color: '#6b7280' }}>AI-generated Paris-style meals</div>
          </div>
        </div>
        <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}>
          {DIETS.map(d => (
            <button key={d} onClick={() => setDiet(d)} style={{ padding: '5px 12px', borderRadius: 20, fontSize: 11, fontWeight: 600, cursor: 'pointer', border: 'none', background: diet === d ? '#ea580c' : 'rgba(255,255,255,0.06)', color: diet === d ? '#fff' : '#9ca3af', transition: 'all 0.2s' }}>
              {d}
            </button>
          ))}
        </div>
      </div>

      {/* Controls */}
      <div style={{ padding: '1rem 1.5rem', display: 'flex', gap: '0.75rem', alignItems: 'center', flexWrap: 'wrap', borderBottom: '1px solid rgba(255,255,255,0.06)' }}>
        <div style={{ display: 'flex', gap: 6, flex: 1, flexWrap: 'wrap' }}>
          {['€10–15/day', '€15–25/day', '€25–40/day'].map(b => (
            <button key={b} onClick={() => setBudget(b)} style={{ padding: '6px 14px', borderRadius: 20, fontSize: 12, fontWeight: 600, cursor: 'pointer', border: `1px solid ${budget === b ? 'rgba(234,88,12,0.6)' : 'rgba(255,255,255,0.1)'}`, background: budget === b ? 'rgba(234,88,12,0.15)' : 'rgba(255,255,255,0.03)', color: budget === b ? '#fb923c' : '#9ca3af' }}>
              <Euro style={{ width: 10, height: 10, display: 'inline', marginRight: 3 }} />{b}
            </button>
          ))}
        </div>
        <button onClick={generate} disabled={loading}
          style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '9px 20px', borderRadius: 12, background: loading ? 'rgba(234,88,12,0.2)' : 'linear-gradient(135deg,#ea580c,#c2410c)', border: 'none', cursor: 'pointer', color: '#fff', fontWeight: 700, fontSize: 13, flexShrink: 0 }}>
          {loading ? <Loader2 style={{ width: 14, height: 14, animation: 'spin 1s linear infinite' }} /> : weekPlan ? <RefreshCw style={{ width: 14, height: 14 }} /> : <Sparkles style={{ width: 14, height: 14 }} />}
          {loading ? 'Generating…' : weekPlan ? 'Regenerate' : 'Generate Week'}
        </button>
      </div>

      {/* Loading state */}
      {loading && (
        <div style={{ padding: '3rem', display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '1rem' }}>
          <motion.div animate={{ rotate: 360 }} transition={{ repeat: Infinity, duration: 2, ease: 'linear' }}>
            <UtensilsCrossed style={{ width: 32, height: 32, color: '#fb923c' }} />
          </motion.div>
          <div style={{ fontSize: 14, color: '#9ca3af' }}>Crafting your Parisian meal plan…</div>
          <div style={{ display: 'flex', gap: 4 }}>
            {['🥐', '🥗', '🧀', '🥖', '🍷'].map((e, i) => (
              <motion.span key={i} animate={{ y: [0, -8, 0] }} transition={{ repeat: Infinity, duration: 1.2, delay: i * 0.15 }} style={{ fontSize: 20 }}>{e}</motion.span>
            ))}
          </div>
        </div>
      )}

      {/* Results */}
      {weekPlan && !loading && (
        <>
          {/* Tab switcher */}
          <div style={{ display: 'flex', borderBottom: '1px solid rgba(255,255,255,0.06)' }}>
            {[{ key: 'plan', label: `📅 Weekly Plan (${totalDays} days)` }, { key: 'groceries', label: `🛒 Shopping List (${groceries.length} items)` }].map(t => (
              <button key={t.key} onClick={() => setTab(t.key as any)} style={{ flex: 1, padding: '12px', fontSize: 13, fontWeight: 600, cursor: 'pointer', border: 'none', borderBottom: `2px solid ${tab === t.key ? '#ea580c' : 'transparent'}`, background: 'transparent', color: tab === t.key ? '#fb923c' : '#6b7280', transition: 'all 0.2s' }}>
                {t.label}
              </button>
            ))}
          </div>

          {tab === 'plan' && (
            <div style={{ padding: '1rem' }}>
              {DAYS.filter(d => weekPlan[d]).map((day, di) => {
                const isOpen = expandedDay === day;
                return (
                  <motion.div key={day} initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: di * 0.05 }}
                    style={{ marginBottom: '0.5rem', borderRadius: 14, border: `1px solid ${isOpen ? 'rgba(234,88,12,0.3)' : 'rgba(255,255,255,0.06)'}`, overflow: 'hidden', background: isOpen ? 'rgba(234,88,12,0.04)' : 'rgba(255,255,255,0.02)', transition: 'all 0.2s' }}>
                    <button onClick={() => setExpandedDay(isOpen ? null : day)}
                      style={{ width: '100%', padding: '12px 16px', display: 'flex', alignItems: 'center', justifyContent: 'space-between', background: 'none', border: 'none', cursor: 'pointer', color: '#fff' }}>
                      <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                        <div style={{ width: 28, height: 28, borderRadius: 8, background: isOpen ? '#ea580c' : 'rgba(255,255,255,0.08)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 12, fontWeight: 700, color: '#fff', transition: 'all 0.2s' }}>
                          {di + 1}
                        </div>
                        <span style={{ fontWeight: 600, fontSize: 14 }}>{day}</span>
                        {weekPlan[day] && (
                          <div style={{ display: 'flex', gap: 4 }}>
                            {MEAL_SLOTS.map(slot => weekPlan[day]?.[slot]?.isParisian && (
                              <span key={slot} title="Parisian dish" style={{ fontSize: 10, padding: '1px 6px', borderRadius: 20, background: 'rgba(0,64,130,0.25)', color: '#60a5fa', border: '1px solid rgba(0,64,130,0.3)' }}>🇫🇷</span>
                            ))}
                          </div>
                        )}
                      </div>
                      {isOpen ? <ChevronUp style={{ width: 16, height: 16, color: '#fb923c' }} /> : <ChevronDown style={{ width: 16, height: 16, color: '#6b7280' }} />}
                    </button>

                    <AnimatePresence>
                      {isOpen && weekPlan[day] && (
                        <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: 'auto', opacity: 1 }} exit={{ height: 0, opacity: 0 }} transition={{ duration: 0.25 }}
                          style={{ borderTop: '1px solid rgba(255,255,255,0.06)', overflow: 'hidden' }}>
                          <div style={{ padding: '1rem', display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: '0.75rem' }}>
                            {MEAL_SLOTS.map(slot => {
                              const meal = weekPlan[day]?.[slot];
                              if (!meal) return null;
                              return (
                                <div key={slot} style={{ padding: '0.875rem', borderRadius: 12, background: 'rgba(255,255,255,0.03)', border: '1px solid rgba(255,255,255,0.07)' }}>
                                  <div style={{ fontSize: 11, fontWeight: 700, color: '#6b7280', marginBottom: 6, textTransform: 'uppercase', letterSpacing: '0.05em' }}>
                                    {SLOT_EMOJI[slot]} {slot}
                                  </div>
                                  <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', gap: 6, marginBottom: 4 }}>
                                    <div style={{ fontWeight: 700, fontSize: 13, color: '#fff', flex: 1 }}>{meal.name}</div>
                                    {meal.isParisian && <span style={{ fontSize: 10, flexShrink: 0 }}>🇫🇷</span>}
                                  </div>
                                  <div style={{ fontSize: 12, color: '#9ca3af', lineHeight: 1.5, marginBottom: 8 }}>{meal.description}</div>
                                  <div style={{ display: 'flex', gap: 8 }}>
                                    <span style={{ fontSize: 11, color: '#34d399', fontWeight: 600 }}>{meal.cost}</span>
                                    <span style={{ fontSize: 11, color: '#6b7280' }}>·</span>
                                    <span style={{ fontSize: 11, color: '#9ca3af' }}>{meal.calories}</span>
                                  </div>
                                </div>
                              );
                            })}
                          </div>
                        </motion.div>
                      )}
                    </AnimatePresence>
                  </motion.div>
                );
              })}
            </div>
          )}

          {tab === 'groceries' && groceries.length > 0 && (
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} style={{ padding: '1.25rem' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: '1rem' }}>
                <ShoppingCart style={{ width: 16, height: 16, color: '#fb923c' }} />
                <span style={{ fontWeight: 600, color: '#fff', fontSize: 14 }}>Shopping List — Paris Supermarché</span>
              </div>
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(160px, 1fr))', gap: '0.5rem' }}>
                {groceries.map((item, i) => (
                  <motion.div key={i} initial={{ opacity: 0, x: -8 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: i * 0.04 }}
                    style={{ padding: '8px 12px', borderRadius: 10, background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.07)', fontSize: 13, color: '#e5e7eb', display: 'flex', alignItems: 'center', gap: 8 }}>
                    <span style={{ width: 6, height: 6, borderRadius: '50%', background: '#ea580c', flexShrink: 0, display: 'block' }} />
                    {item}
                  </motion.div>
                ))}
              </div>
              <div style={{ marginTop: '1rem', padding: '10px 14px', borderRadius: 10, background: 'rgba(0,64,130,0.1)', border: '1px solid rgba(0,64,130,0.2)', fontSize: 12, color: '#9ca3af' }}>
                💡 <strong style={{ color: '#fff' }}>Tip:</strong> Shop at Carrefour City, Franprix, or Monoprix for the best prices. Marché Bastille (Thursdays & Sundays) is great for fresh produce.
              </div>
            </motion.div>
          )}
        </>
      )}

      {/* Empty state */}
      {!weekPlan && !loading && (
        <div style={{ padding: '3rem', textAlign: 'center' }}>
          <div style={{ fontSize: '3rem', marginBottom: '1rem' }}>🥗</div>
          <div style={{ fontWeight: 600, color: '#fff', marginBottom: 6 }}>No meal plan yet</div>
          <div style={{ fontSize: 13, color: '#6b7280' }}>Choose your diet and click Generate Week to get started</div>
        </div>
      )}
      <style>{`@keyframes spin { from { transform:rotate(0deg) } to { transform:rotate(360deg) } }`}</style>
    </div>
  );
}
