'use client';
import { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Star, Sparkles } from 'lucide-react';

interface BadgeToastData {
  id: string;
  emoji: string;
  name: string;
  description: string;
  rarity: 'common' | 'rare' | 'legendary';
  xp: number;
}

const RARITY_CONFIG = {
  common:    { border: '#64748b', glow: 'rgba(100,116,139,0.3)', bg: 'rgba(15,23,42,0.97)', label: '🔹 Common',    star: '#94a3b8' },
  rare:      { border: '#3b82f6', glow: 'rgba(59,130,246,0.4)',  bg: 'rgba(10,20,40,0.98)', label: '💎 Rare',      star: '#60a5fa' },
  legendary: { border: '#f59e0b', glow: 'rgba(245,158,11,0.5)',  bg: 'rgba(20,15,5,0.98)',  label: '⭐ Legendary', star: '#fbbf24' },
};

// Global queue
let listeners: ((badge: BadgeToastData) => void)[] = [];
export function fireBadgeToast(badge: BadgeToastData) {
  listeners.forEach(fn => fn(badge));
}

export default function BadgeUnlockToastProvider() {
  const [queue, setQueue] = useState<BadgeToastData[]>([]);

  useEffect(() => {
    const handler = (badge: BadgeToastData) =>
      setQueue(prev => prev.find(b => b.id === badge.id) ? prev : [...prev, badge]);
    listeners.push(handler);
    return () => { listeners = listeners.filter(fn => fn !== handler); };
  }, []);

  const dismiss = (id: string) => setQueue(prev => prev.filter(b => b.id !== id));

  // Auto-dismiss after 5s
  useEffect(() => {
    if (!queue.length) return;
    const timer = setTimeout(() => dismiss(queue[0].id), 5000);
    return () => clearTimeout(timer);
  }, [queue]);

  const current = queue[0];
  if (!current) return null;
  const cfg = RARITY_CONFIG[current.rarity];

  return (
    <div style={{ position: 'fixed', top: 20, right: 20, zIndex: 9999, pointerEvents: 'none' }}>
      <AnimatePresence mode="wait">
        <motion.div key={current.id}
          initial={{ opacity: 0, x: 80, scale: 0.85 }}
          animate={{ opacity: 1, x: 0, scale: 1 }}
          exit={{ opacity: 0, x: 80, scale: 0.85 }}
          transition={{ type: 'spring', stiffness: 420, damping: 28 }}
          style={{ pointerEvents: 'all', width: 320, borderRadius: 18, background: cfg.bg, border: `1.5px solid ${cfg.border}`, boxShadow: `0 0 0 1px ${cfg.border}33, 0 8px 40px rgba(0,0,0,0.8), 0 0 60px ${cfg.glow}`, overflow: 'hidden' }}>

          {/* Shimmer bar */}
          <motion.div
            initial={{ x: '-100%' }} animate={{ x: '200%' }} transition={{ duration: 1.2, delay: 0.3 }}
            style={{ position: 'absolute', top: 0, left: 0, right: 0, height: 2, background: `linear-gradient(90deg, transparent, ${cfg.border}, transparent)` }} />

          {/* Progress bar */}
          <motion.div
            initial={{ scaleX: 1 }} animate={{ scaleX: 0 }} transition={{ duration: 5, ease: 'linear' }}
            style={{ height: 2, background: cfg.border, transformOrigin: 'left', opacity: 0.5 }} />

          <div style={{ padding: '1.25rem' }}>
            <div style={{ display: 'flex', gap: '1rem', alignItems: 'flex-start' }}>
              {/* Emoji burst */}
              <motion.div
                initial={{ scale: 0, rotate: -20 }} animate={{ scale: [0, 1.3, 1], rotate: [-20, 8, 0] }}
                transition={{ duration: 0.5, delay: 0.15 }}
                style={{ width: 56, height: 56, borderRadius: 16, background: `${cfg.border}18`, border: `1.5px solid ${cfg.border}44`, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 28, flexShrink: 0, position: 'relative' }}>
                {current.emoji}
                {/* Sparkle dots */}
                {current.rarity === 'legendary' && [0, 60, 120, 180, 240, 300].map((deg, i) => (
                  <motion.div key={i}
                    initial={{ opacity: 0, scale: 0 }}
                    animate={{ opacity: [0, 1, 0], scale: [0, 1, 0], x: Math.cos((deg * Math.PI) / 180) * 28, y: Math.sin((deg * Math.PI) / 180) * 28 }}
                    transition={{ duration: 0.8, delay: 0.3 + i * 0.06 }}
                    style={{ position: 'absolute', width: 4, height: 4, borderRadius: '50%', background: cfg.star }} />
                ))}
              </motion.div>

              <div style={{ flex: 1, minWidth: 0 }}>
                <motion.div initial={{ opacity: 0, y: -6 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }}>
                  <div style={{ fontSize: 10, fontWeight: 700, color: cfg.star, textTransform: 'uppercase', letterSpacing: '0.1em', marginBottom: 2, display: 'flex', alignItems: 'center', gap: 4 }}>
                    <Sparkles style={{ width: 10, height: 10 }} /> Badge Unlocked!
                  </div>
                  <div style={{ fontWeight: 800, fontSize: 15, color: '#fff', marginBottom: 2 }}>{current.name}</div>
                  <div style={{ fontSize: 12, color: '#9ca3af', lineHeight: 1.5 }}>{current.description}</div>
                </motion.div>

                <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.4 }}
                  style={{ display: 'flex', alignItems: 'center', gap: 8, marginTop: 8 }}>
                  <span style={{ fontSize: 11, padding: '2px 8px', borderRadius: 20, background: `${cfg.border}18`, border: `1px solid ${cfg.border}33`, color: cfg.star, fontWeight: 600 }}>{cfg.label}</span>
                  <span style={{ fontSize: 11, fontWeight: 700, color: '#C9A84C' }}>+{current.xp} XP</span>
                </motion.div>
              </div>

              <button onClick={() => dismiss(current.id)} style={{ background: 'none', border: 'none', cursor: 'pointer', color: '#4b5563', padding: 4, flexShrink: 0 }}>
                <X style={{ width: 14, height: 14 }} />
              </button>
            </div>
          </div>
        </motion.div>
      </AnimatePresence>
    </div>
  );
}
