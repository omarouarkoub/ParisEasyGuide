'use client';
import { motion } from 'framer-motion';
import { ReactNode } from 'react';

interface PageMotionProps {
  children: ReactNode;
  className?: string;
  style?: React.CSSProperties;
}

export default function PageMotion({ children, style }: PageMotionProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 16 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -8 }}
      transition={{ duration: 0.35, ease: [0.4, 0, 0.2, 1] }}
      style={style}
    >
      {children}
    </motion.div>
  );
}

export function FadeIn({ children, delay = 0, style }: { children: ReactNode; delay?: number; style?: React.CSSProperties }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4, delay, ease: 'easeOut' }}
      style={style}
    >
      {children}
    </motion.div>
  );
}

export function SlideIn({ children, delay = 0, from = 'right' }: { children: ReactNode; delay?: number; from?: 'left' | 'right' | 'bottom' }) {
  const x = from === 'left' ? -24 : from === 'right' ? 24 : 0;
  const y = from === 'bottom' ? 24 : 0;
  return (
    <motion.div
      initial={{ opacity: 0, x, y }}
      animate={{ opacity: 1, x: 0, y: 0 }}
      transition={{ duration: 0.4, delay, ease: 'easeOut' }}
    >
      {children}
    </motion.div>
  );
}

export function ScaleIn({ children, delay = 0 }: { children: ReactNode; delay?: number }) {
  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.92 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ duration: 0.35, delay, type: 'spring', stiffness: 300, damping: 24 }}
    >
      {children}
    </motion.div>
  );
}

export function StaggerList({ children, className }: { children: ReactNode[]; className?: string }) {
  return (
    <motion.div
      className={className}
      initial="hidden"
      animate="visible"
      variants={{ visible: { transition: { staggerChildren: 0.07 } } }}
    >
      {children.map((child, i) => (
        <motion.div key={i} variants={{ hidden: { opacity: 0, y: 12 }, visible: { opacity: 1, y: 0 } }}>
          {child}
        </motion.div>
      ))}
    </motion.div>
  );
}

export function PulseGlow({ color = '#004082', children }: { color?: string; children: ReactNode }) {
  return (
    <motion.div
      animate={{ boxShadow: [`0 0 0px ${color}00`, `0 0 24px ${color}66`, `0 0 0px ${color}00`] }}
      transition={{ duration: 2.5, repeat: Infinity, ease: 'easeInOut' }}
    >
      {children}
    </motion.div>
  );
}
