'use client';
import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import Link from 'next/link';
import { CheckCircle2, Circle, ChevronRight, ExternalLink, Sparkles, ArrowRight, RefreshCw } from 'lucide-react';
import { useLanguage } from '@/lib/i18n/LanguageContext';
import { translations as tr } from '@/lib/i18n/translations';

const GOLD = '#C9A84C';

interface TimelineTask {
  id: string;
  title: string;
  description: string;
  urgency: 'urgent' | 'soon' | 'when_ready';
  deadline: string;
  category: string;
  link_label?: string;
  link_url?: string;
  days_from_arrival: number;
  emoji: string;
}

interface Timeline {
  welcome_message: string;
  settled_score: number;
  settled_score_label: string;
  critical_next: TimelineTask[];
  timeline_weeks: { week: string; theme: string; tasks: string[] }[];
  insider_tips: string[];
  modules_for_them: { path: string; label: string; emoji: string; reason: string }[];
}

interface Profile {
  name: string;
  profile_type: string;
  arrondissement: string;
  visa_type: string;
  goals: string[];
}

export default function MarcelDashboard() {
  const { t } = useLanguage();
  const [profile, setProfile] = useState<Profile | null>(null);
  const [timeline, setTimeline] = useState<Timeline | null>(null);
  const [completed, setCompleted] = useState<string[]>([]);
  const [activeTab, setActiveTab] = useState<'tasks' | 'timeline' | 'tips'>('tasks');
  const [expanded, setExpanded] = useState<string | null>(null);

  useEffect(() => {
    try {
      const p = localStorage.getItem('paris_profile');
      const tl = localStorage.getItem('paris_timeline');
      const c = localStorage.getItem('paris_completed');
      if (p) setProfile(JSON.parse(p));
      if (tl) setTimeline(JSON.parse(tl));
      if (c) setCompleted(JSON.parse(c));
    } catch {}
  }, []);

  const toggleComplete = (id: string) => {
    const next = completed.includes(id) ? completed.filter(c => c !== id) : [...completed, id];
    setCompleted(next);
    localStorage.setItem('paris_completed', JSON.stringify(next));
  };

  if (!profile || !timeline) return null;

  const tasks = timeline.critical_next || [];
  const doneCount = tasks.filter(task => completed.includes(task.id)).length;

  // ── NaN fix: coerce settled_score to a number before arithmetic ──
  const rawScore = Number(timeline.settled_score) || 0;
  const settledScore = Math.min(100, rawScore + Math.round((doneCount / Math.max(tasks.length, 1)) * 30));
  const scoreColor = settledScore < 30 ? '#ef4444' : settledScore < 60 ? '#f59e0b' : '#22c55e';

  const URGENCY_STYLE = {
    urgent:     { bg: 'rgba(239,68,68,0.12)',  border: 'rgba(239,68,68,0.3)',  text: '#ef4444', label: t(tr.marcel.urgency.urgent)     },
    soon:       { bg: 'rgba(245,158,11,0.12)', border: 'rgba(245,158,11,0.3)', text: '#f59e0b', label: t(tr.marcel.urgency.soon)       },
    when_ready: { bg: 'rgba(99,102,241,0.10)', border: 'rgba(99,102,241,0.25)', text: '#818cf8', label: t(tr.marcel.urgency.when_ready) },
  };

  return (
    <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }}
      style={{ marginBottom: '2rem' }}>

      {/* Marcel Header */}
      <div style={{ padding: '1.25rem 1.5rem', borderRadius: 16, background: 'linear-gradient(135deg,rgba(0,64,130,0.15),rgba(201,168,76,0.06))', border: '1px solid rgba(0,64,130,0.3)', marginBottom: '1rem', position: 'relative', overflow: 'hidden' }}>
        <div style={{ position: 'absolute', top: -20, right: -20, width: 120, height: 120, borderRadius: '50%', background: 'radial-gradient(circle,rgba(0,64,130,0.2),transparent)', pointerEvents: 'none' }} />
        <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', gap: '1rem', flexWrap: 'wrap' }}>
          <div style={{ display: 'flex', gap: '0.875rem', alignItems: 'flex-start' }}>
            <div style={{ width: 40, height: 40, borderRadius: 12, background: 'linear-gradient(135deg,#004082,#1a5cb5)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 20, flexShrink: 0 }}>
              🤖
            </div>
            <div>
              <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginBottom: 4 }}>
                <Sparkles style={{ width: 13, height: 13, color: GOLD }} />
                <span style={{ fontSize: 11, fontWeight: 700, color: GOLD, textTransform: 'uppercase', letterSpacing: '0.08em' }}>{t(tr.marcel.header.title)}</span>
              </div>
              <p style={{ color: '#e5e7eb', fontSize: 13.5, lineHeight: 1.6, maxWidth: 480 }}>
                {timeline.welcome_message}
              </p>
            </div>
          </div>

          {/* Settled-in score */}
          <div style={{ textAlign: 'center', flexShrink: 0 }}>
            <div style={{ position: 'relative', width: 64, height: 64 }}>
              <svg width="64" height="64" style={{ transform: 'rotate(-90deg)' }}>
                <circle cx="32" cy="32" r="26" fill="none" stroke="rgba(255,255,255,0.08)" strokeWidth="5" />
                <circle cx="32" cy="32" r="26" fill="none" stroke={scoreColor} strokeWidth="5"
                  strokeDasharray={`${(settledScore / 100) * 163.4} 163.4`}
                  strokeLinecap="round" style={{ transition: 'stroke-dasharray 1s ease' }} />
              </svg>
              <div style={{ position: 'absolute', inset: 0, display: 'flex', alignItems: 'center', justifyContent: 'center', flexDirection: 'column' }}>
                <span style={{ fontSize: 14, fontWeight: 800, color: scoreColor }}>{settledScore}</span>
              </div>
            </div>
            <div style={{ fontSize: 10, color: '#9ca3af', marginTop: 4 }}>{t(tr.marcel.header.settled)}</div>
          </div>
        </div>

        {/* Progress bar */}
        {tasks.length > 0 && (
          <div style={{ marginTop: '1rem' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 6 }}>
              <span style={{ fontSize: 11, color: '#9ca3af' }}>
                {doneCount} {t(tr.marcel.progress.of)} {tasks.length} {t(tr.marcel.progress.tasksDone)}
              </span>
              <Link href="/onboarding" style={{ fontSize: 11, color: '#3a7bd5', textDecoration: 'none', display: 'flex', alignItems: 'center', gap: 3 }}>
                <RefreshCw style={{ width: 10, height: 10 }} /> {t(tr.marcel.progress.updateProfile)}
              </Link>
            </div>
            <div style={{ height: 5, borderRadius: 3, background: 'rgba(255,255,255,0.08)', overflow: 'hidden' }}>
              <motion.div
                initial={{ width: 0 }}
                animate={{ width: `${tasks.length > 0 ? (doneCount / tasks.length) * 100 : 0}%` }}
                transition={{ duration: 1, ease: 'easeOut', delay: 0.3 }}
                style={{ height: '100%', borderRadius: 3, background: `linear-gradient(90deg, #004082, ${GOLD})` }}
              />
            </div>
          </div>
        )}
      </div>

      {/* Tabs */}
      <div style={{ display: 'flex', gap: '0.5rem', marginBottom: '1rem' }}>
        {([
          { id: 'tasks',    label: `⚡ ${t(tr.marcel.tabs.tasks)} (${tasks.filter(task => !completed.includes(task.id)).length})` },
          { id: 'timeline', label: `📅 ${t(tr.marcel.tabs.timeline)}` },
          { id: 'tips',     label: `💡 ${t(tr.marcel.tabs.tips)}` },
        ] as const).map(tab => (
          <button key={tab.id} onClick={() => setActiveTab(tab.id)}
            style={{ padding: '7px 14px', borderRadius: 20, fontSize: 12, fontWeight: 600, cursor: 'pointer',
              background: activeTab === tab.id ? 'rgba(0,64,130,0.3)' : 'rgba(255,255,255,0.05)',
              color: activeTab === tab.id ? '#fff' : '#9ca3af',
              border: `1px solid ${activeTab === tab.id ? 'rgba(0,64,130,0.5)' : 'rgba(255,255,255,0.08)'}`,
              transition: 'all 0.15s' }}>
            {tab.label}
          </button>
        ))}
      </div>

      <AnimatePresence mode="wait">
        {activeTab === 'tasks' && (
          <motion.div key="tasks" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
            {tasks.length === 0 ? (
              <div style={{ textAlign: 'center', padding: '2rem', color: '#6b7280' }}>{t(tr.marcel.tasks.empty)}</div>
            ) : (
              <div style={{ display: 'flex', flexDirection: 'column', gap: '0.625rem' }}>
                {tasks.map((task, i) => {
                  const isDone = completed.includes(task.id);
                  const urgStyle = URGENCY_STYLE[task.urgency] || URGENCY_STYLE.when_ready;
                  const isExpanded = expanded === task.id;
                  return (
                    <motion.div key={task.id}
                      initial={{ opacity: 0, x: -10 }} animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: i * 0.06 }}
                      style={{ borderRadius: 14, background: isDone ? 'rgba(34,197,94,0.05)' : urgStyle.bg, border: `1px solid ${isDone ? 'rgba(34,197,94,0.2)' : urgStyle.border}`, overflow: 'hidden', transition: 'all 0.2s' }}>

                      <div style={{ padding: '0.875rem 1rem', display: 'flex', alignItems: 'center', gap: '0.75rem', cursor: 'pointer' }}
                        onClick={() => setExpanded(isExpanded ? null : task.id)}>
                        <button onClick={e => { e.stopPropagation(); toggleComplete(task.id); }}
                          style={{ background: 'none', border: 'none', cursor: 'pointer', padding: 0, flexShrink: 0 }}>
                          {isDone
                            ? <CheckCircle2 style={{ width: 20, height: 20, color: '#22c55e' }} />
                            : <Circle style={{ width: 20, height: 20, color: '#4b5563' }} />}
                        </button>
                        <span style={{ fontSize: 20, flexShrink: 0 }}>{task.emoji}</span>
                        <div style={{ flex: 1, minWidth: 0 }}>
                          <div style={{ fontWeight: 700, color: isDone ? '#6b7280' : '#fff', fontSize: 13, textDecoration: isDone ? 'line-through' : 'none' }}>
                            {task.title}
                          </div>
                          <div style={{ fontSize: 10, color: urgStyle.text, fontWeight: 600, marginTop: 2 }}>
                            {urgStyle.label} · {task.deadline}
                          </div>
                        </div>
                        <ChevronRight style={{ width: 14, height: 14, color: '#4b5563', transform: isExpanded ? 'rotate(90deg)' : 'none', transition: 'transform 0.2s', flexShrink: 0 }} />
                      </div>

                      <AnimatePresence>
                        {isExpanded && (
                          <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: 'auto', opacity: 1 }} exit={{ height: 0, opacity: 0 }}
                            style={{ overflow: 'hidden' }}>
                            <div style={{ padding: '0 1rem 0.875rem 3.5rem' }}>
                              <p style={{ fontSize: 12.5, color: '#9ca3af', lineHeight: 1.65, marginBottom: '0.75rem' }}>{task.description}</p>
                              {task.link_url && (
                                <a href={task.link_url} target="_blank" rel="noopener noreferrer"
                                  style={{ display: 'inline-flex', alignItems: 'center', gap: 5, padding: '6px 12px', borderRadius: 8, background: 'rgba(0,64,130,0.2)', border: '1px solid rgba(0,64,130,0.35)', color: '#3a7bd5', fontSize: 12, fontWeight: 600, textDecoration: 'none' }}>
                                  {task.link_label || t(tr.marcel.tasks.openLink)} <ExternalLink style={{ width: 11, height: 11 }} />
                                </a>
                              )}
                            </div>
                          </motion.div>
                        )}
                      </AnimatePresence>
                    </motion.div>
                  );
                })}
              </div>
            )}

            {/* Recommended modules */}
            {timeline.modules_for_them?.length > 0 && (
              <div style={{ marginTop: '1.5rem' }}>
                <div style={{ fontSize: 11, fontWeight: 700, color: '#6b7280', textTransform: 'uppercase', letterSpacing: '0.08em', marginBottom: '0.75rem' }}>
                  🎯 {t(tr.marcel.tasks.recommended)}
                </div>
                <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(180px, 1fr))', gap: '0.5rem' }}>
                  {timeline.modules_for_them.map(mod => (
                    <Link key={mod.path} href={mod.path} style={{ textDecoration: 'none' }}>
                      <motion.div whileHover={{ scale: 1.03 }} whileTap={{ scale: 0.97 }}
                        style={{ padding: '0.875rem 1rem', borderRadius: 12, background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.08)', display: 'flex', alignItems: 'center', gap: 8 }}>
                        <span style={{ fontSize: 18 }}>{mod.emoji}</span>
                        <div style={{ minWidth: 0 }}>
                          <div style={{ fontWeight: 700, color: '#fff', fontSize: 12 }}>{mod.label}</div>
                          <div style={{ fontSize: 10, color: '#9ca3af', lineHeight: 1.4 }}>{mod.reason}</div>
                        </div>
                        <ArrowRight style={{ width: 12, height: 12, color: '#4b5563', flexShrink: 0 }} />
                      </motion.div>
                    </Link>
                  ))}
                </div>
              </div>
            )}
          </motion.div>
        )}

        {activeTab === 'timeline' && (
          <motion.div key="timeline" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '0.875rem' }}>
              {(timeline.timeline_weeks || []).map((week, i) => (
                <motion.div key={i} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.08 }}
                  style={{ padding: '1rem 1.25rem', borderRadius: 14, background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.08)', position: 'relative', overflow: 'hidden' }}>
                  <div style={{ position: 'absolute', left: 0, top: 0, bottom: 0, width: 3, background: `hsl(${220 + i * 30},70%,55%)`, borderRadius: '3px 0 0 3px' }} />
                  <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: '0.625rem' }}>
                    <span style={{ fontWeight: 800, color: '#fff', fontSize: 13 }}>{week.week}</span>
                    <span style={{ fontSize: 11, color: '#9ca3af' }}>· {week.theme}</span>
                  </div>
                  <ul style={{ margin: 0, padding: 0, listStyle: 'none', display: 'flex', flexDirection: 'column', gap: 5 }}>
                    {week.tasks.map((task, j) => (
                      <li key={j} style={{ display: 'flex', alignItems: 'flex-start', gap: 8, fontSize: 12, color: '#d1d5db', lineHeight: 1.55 }}>
                        <span style={{ color: GOLD, flexShrink: 0, marginTop: 1 }}>›</span>
                        {task}
                      </li>
                    ))}
                  </ul>
                </motion.div>
              ))}
            </div>
          </motion.div>
        )}

        {activeTab === 'tips' && (
          <motion.div key="tips" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '0.625rem' }}>
              {(timeline.insider_tips || []).map((tip, i) => (
                <motion.div key={i} initial={{ opacity: 0, x: -8 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: i * 0.07 }}
                  style={{ display: 'flex', gap: '0.75rem', alignItems: 'flex-start', padding: '0.875rem 1rem', borderRadius: 12, background: 'rgba(201,168,76,0.06)', border: '1px solid rgba(201,168,76,0.15)' }}>
                  <div style={{ width: 28, height: 28, borderRadius: 8, background: 'rgba(201,168,76,0.15)', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0, fontSize: 14 }}>
                    💡
                  </div>
                  <p style={{ fontSize: 13, color: '#e5e7eb', lineHeight: 1.65, margin: 0 }}>{tip}</p>
                </motion.div>
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Completion celebration */}
      {doneCount === tasks.length && tasks.length > 0 && (
        <motion.div initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }}
          style={{ marginTop: '1rem', padding: '1.25rem', borderRadius: 14, background: 'linear-gradient(135deg,rgba(34,197,94,0.1),rgba(201,168,76,0.06))', border: '1px solid rgba(34,197,94,0.25)', textAlign: 'center' }}>
          <div style={{ fontSize: '2rem', marginBottom: '0.5rem' }}>🎉</div>
          <div style={{ fontWeight: 800, color: '#22c55e', fontSize: 15, marginBottom: '0.25rem' }}>
            {t(tr.marcel.celebration.title)}
          </div>
          <p style={{ color: '#9ca3af', fontSize: 12 }}>{t(tr.marcel.celebration.subtitle)}</p>
        </motion.div>
      )}
    </motion.div>
  );
}
