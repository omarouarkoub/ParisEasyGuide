'use client';
import { useEffect, useRef, useState } from 'react';
import { motion } from 'framer-motion';
import { LucideIcon } from 'lucide-react';

interface StatCardProps {
  value: number | string;
  label: string;
  icon?: LucideIcon;
  color?: string;
  prefix?: string;
  suffix?: string;
  delay?: number;
  animate?: boolean;
}

export default function StatCard({ value, label, icon: Icon, color = '#3a7bd5', prefix = '', suffix = '', delay = 0, animate = true }: StatCardProps) {
  const [displayed, setDisplayed] = useState(typeof value === 'number' ? 0 : value);
  const hasAnimated = useRef(false);

  useEffect(() => {
    if (!animate || typeof value !== 'number' || hasAnimated.current) return;
    hasAnimated.current = true;
    const start = Date.now();
    const duration = 1200;
    const tick = () => {
      const elapsed = Date.now() - start;
      const progress = Math.min(elapsed / duration, 1);
      const eased = 1 - Math.pow(1 - progress, 3);
      setDisplayed(Math.round(eased * (value as number)));
      if (progress < 1) requestAnimationFrame(tick);
    };
    const timer = setTimeout(() => requestAnimationFrame(tick), delay * 1000);
    return () => clearTimeout(timer);
  }, [value, animate, delay]);

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.9 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ duration: 0.4, delay, type: 'spring', stiffness: 280, damping: 22 }}
      style={{ padding: '1.25rem', borderRadius: 16, background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.08)', backdropFilter: 'blur(20px)', textAlign: 'center', position: 'relative', overflow: 'hidden' }}
    >
      {/* Glow orb */}
      <div style={{ position: 'absolute', top: -20, right: -20, width: 80, height: 80, borderRadius: '50%', background: `radial-gradient(circle, ${color}22, transparent)`, pointerEvents: 'none' }} />
      {Icon && <Icon style={{ width: 20, height: 20, margin: '0 auto 8px', color }} />}
      <div style={{ fontSize: '1.75rem', fontWeight: 800, color }}>
        {prefix}{typeof value === 'number' ? displayed : value}{suffix}
      </div>
      <div style={{ fontSize: 12, color: '#6b7280', marginTop: 4, fontWeight: 500 }}>{label}</div>
    </motion.div>
  );
}
