'use client';
import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ArrowRight, CheckCircle2 } from 'lucide-react';
import { useLanguage, LANGUAGES, translations } from '@/lib/i18n/LanguageContext';

const GOLD = '#C9A84C';
const BLUE = '#004082';
const tr = translations.langGate;

export default function LangGate() {
  const { lang, setLang, t, hasChosenLang, confirmLang } = useLanguage();
  const [hovered, setHovered] = useState<string | null>(null);

  if (hasChosenLang) return null;

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        style={{
          position: 'fixed', inset: 0, zIndex: 9999,
          background: 'hsl(210,30%,4%)',
          display: 'flex', flexDirection: 'column',
          alignItems: 'center', justifyContent: 'center',
          padding: '1.5rem',
          overflow: 'hidden',
        }}
      >
        {/* Background glows */}
        <div style={{ position: 'absolute', inset: 0, pointerEvents: 'none', overflow: 'hidden' }}>
          <div style={{ position: 'absolute', top: '-20%', left: '-10%', width: 700, height: 700, borderRadius: '50%', background: 'rgba(0,64,130,0.12)', filter: 'blur(140px)' }} />
          <div style={{ position: 'absolute', bottom: '-15%', right: '-5%', width: 500, height: 500, borderRadius: '50%', background: 'rgba(201,168,76,0.07)', filter: 'blur(100px)' }} />
        </div>

        <motion.div
          initial={{ y: 24, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.1, duration: 0.5, ease: 'easeOut' }}
          style={{ position: 'relative', width: '100%', maxWidth: 560, textAlign: 'center' }}
        >
          {/* Logo */}
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 10, marginBottom: '2rem' }}>
            <div style={{ width: 40, height: 40, borderRadius: 10, overflow: 'hidden', display: 'flex', border: `1px solid rgba(201,168,76,0.5)`, boxShadow: '0 0 24px rgba(0,64,130,0.4)' }}>
              <div style={{ flex: 1, background: '#002395' }} />
              <div style={{ flex: 1, background: '#FFFFFF' }} />
              <div style={{ flex: 1, background: '#ED2939' }} />
            </div>
            <div style={{ textAlign: 'left' }}>
              <div style={{ fontWeight: 800, fontSize: 16, color: GOLD, lineHeight: 1 }}>ParisEasyGuide+</div>
              <div style={{ fontSize: 10, color: '#4b5563', marginTop: 2 }}>{t(tr.tagline)}</div>
            </div>
          </div>

          {/* Headline */}
          <h1 style={{
            fontFamily: 'Playfair Display, serif',
            fontSize: 'clamp(1.8rem, 5vw, 2.8rem)',
            fontWeight: 700, color: '#fff',
            marginBottom: '0.5rem', lineHeight: 1.2,
          }}>
            {t(tr.welcome)} 🗼
          </h1>
          <p style={{ color: '#6b7280', fontSize: '0.95rem', marginBottom: '2.5rem' }}>
            {t(tr.subtitle)}
          </p>

          {/* Language grid */}
          <div style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(3, 1fr)',
            gap: '0.75rem',
            marginBottom: '2rem',
          }}>
            {LANGUAGES.map(l => {
              const selected = lang === l.code;
              return (
                <motion.button
                  key={l.code}
                  whileHover={{ scale: 1.04 }}
                  whileTap={{ scale: 0.96 }}
                  onClick={() => setLang(l.code)}
                  onMouseEnter={() => setHovered(l.code)}
                  onMouseLeave={() => setHovered(null)}
                  style={{
                    padding: '1.1rem 0.75rem',
                    borderRadius: 16,
                    cursor: 'pointer',
                    textAlign: 'center',
                    background: selected
                      ? 'linear-gradient(135deg, rgba(0,64,130,0.35), rgba(58,123,213,0.2))'
                      : hovered === l.code
                        ? 'rgba(255,255,255,0.06)'
                        : 'rgba(255,255,255,0.03)',
                    border: `1.5px solid ${selected ? '#3a7bd5' : 'rgba(255,255,255,0.08)'}`,
                    boxShadow: selected ? '0 0 24px rgba(0,64,130,0.25)' : 'none',
                    transition: 'all 0.18s ease',
                    position: 'relative',
                  }}
                >
                  {selected && (
                    <div style={{ position: 'absolute', top: 8, right: 8 }}>
                      <CheckCircle2 style={{ width: 13, height: 13, color: '#3a7bd5' }} />
                    </div>
                  )}
                  <div style={{ fontSize: 28, marginBottom: '0.4rem' }}>{l.flag}</div>
                  <div style={{ fontWeight: 700, color: selected ? '#fff' : '#d1d5db', fontSize: 13 }}>{l.native}</div>
                  <div style={{ fontSize: 10, color: '#6b7280', marginTop: 2 }}>{l.label}</div>
                </motion.button>
              );
            })}
          </div>

          {/* CTA */}
          <motion.button
            whileHover={{ scale: 1.03 }}
            whileTap={{ scale: 0.97 }}
            onClick={confirmLang}
            style={{
              display: 'inline-flex', alignItems: 'center', gap: 10,
              padding: '14px 36px', borderRadius: 14,
              background: `linear-gradient(135deg, ${BLUE}, #1a5cb5)`,
              border: 'none', cursor: 'pointer', color: '#fff',
              fontSize: 15, fontWeight: 700,
              boxShadow: '0 0 32px rgba(0,64,130,0.4)',
            }}
          >
            {t(tr.cta)}
            <ArrowRight style={{ width: 16, height: 16 }} />
          </motion.button>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
}
