'use client';
import { useState } from 'react';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import {
  Languages, Wallet, Map, MessageCircle, Compass, Trophy, Menu, X,
  Train, Plane, Building2, Home, MapPin, CreditCard, Heart, Briefcase,
  GraduationCap, Scale, Sun, Leaf, CheckSquare, Music, User, Settings,
  CloudRain, Sunrise, Headphones, Lock,
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { useLanguage, LANGUAGES, translations } from '@/lib/i18n/LanguageContext';

const GOLD = '#C9A84C';
const tr = translations;

const NAV_GROUPS_DEF = [
  {
    labelKey: 'core' as const,
    items: [
      { path: '/dashboard',     icon: Compass,       labelKey: 'dashboard'     as const, color: '#00bfff', emoji: '🧭' },
      { path: '/onboarding',    icon: User,          labelKey: 'profile'       as const, color: '#C9A84C', emoji: '🤖' },
      { path: '/chat',          icon: MessageCircle, labelKey: 'chat'          as const, color: '#ec4899', emoji: '💬' },
      { path: '/translate',     icon: Languages,     labelKey: 'translate'     as const, color: '#8b5cf6', emoji: '🌐' },
      { path: '/itinerary',     icon: Map,           labelKey: 'itinerary'     as const, color: '#f97316', emoji: '🗺️' },
      { path: '/explore',       icon: Compass,       labelKey: 'explore'       as const, color: '#00bfff', emoji: '📍' },
      { path: '/checklist',     icon: CheckSquare,   labelKey: 'checklist'     as const, color: '#C9A84C', emoji: '✅' },
    ],
  },
  {
    labelKey: 'settling' as const,
    items: [
      { path: '/arrival',       icon: Plane,         labelKey: 'arrival'       as const, color: '#004082', emoji: '✈️' },
      { path: '/navigo',        icon: CreditCard,    labelKey: 'navigo'        as const, color: '#2563eb', emoji: '🚇' },
      { path: '/commute',       icon: Train,         labelKey: 'commute'       as const, color: '#3b82f6', emoji: '🚆' },
      { path: '/admin',         icon: Building2,     labelKey: 'admin'         as const, color: '#059669', emoji: '🏛️' },
      { path: '/housing',       icon: Home,          labelKey: 'housing'       as const, color: '#10b981', emoji: '🏠' },
      { path: '/banking',       icon: CreditCard,    labelKey: 'banking'       as const, color: '#34d399', emoji: '💳' },
    ],
  },
  {
    labelKey: 'life' as const,
    items: [
      { path: '/healthcare',    icon: Heart,         labelKey: 'healthcare'    as const, color: '#ef4444', emoji: '❤️‍🩹' },
      { path: '/work',          icon: Briefcase,     labelKey: 'work'          as const, color: '#8b5cf6', emoji: '💼' },
      { path: '/education',     icon: GraduationCap, labelKey: 'education'     as const, color: '#3b82f6', emoji: '🎓' },
      { path: '/culture',       icon: Music,         labelKey: 'culture'       as const, color: '#d97706', emoji: '🎭' },
      { path: '/sustainability', icon: Leaf,          labelKey: 'sustainability' as const, color: '#22c55e', emoji: '🌿' },
      { path: '/pets',          icon: Home,          labelKey: 'pets'          as const, color: '#f97316', emoji: '🐾' },
    ],
  },
  {
    labelKey: 'discover' as const,
    items: [
      { path: '/neighborhoods', icon: MapPin,        labelKey: 'neighborhoods' as const, color: '#f59e0b', emoji: '🏘️' },
      { path: '/budget',        icon: Wallet,        labelKey: 'budget'        as const, color: '#34d399', emoji: '💶' },
      { path: '/seasonal',      icon: Sun,           labelKey: 'seasonal'      as const, color: '#fbbf24', emoji: '🌸' },
      { path: '/legal',         icon: Scale,         labelKey: 'legal'         as const, color: '#dc2626', emoji: '⚖️' },
      { path: '/quest',         icon: Trophy,        labelKey: 'quest'         as const, color: '#d97706', emoji: '🏆' },
      { path: '/settings',      icon: Settings,      labelKey: 'settings'      as const, color: '#6b7280', emoji: '⚙️' },
    ],
  },
  {
    labelKey: 'parisPlus' as const,
    items: [
      { path: '/fromage-passport',   icon: Trophy,       labelKey: 'fromagePassport' as const, color: '#C9A84C', emoji: '🧀' },
      { path: '/window-light',       icon: Sun,          labelKey: 'windowLight'     as const, color: '#fbbf24', emoji: '🌅' },
      { path: '/pigeon-translator',  icon: MessageCircle,labelKey: 'pigeonTranslate' as const, color: '#a78bfa', emoji: '🐦' },
      { path: '/gentrification-map', icon: MapPin,       labelKey: 'gentrifyMap'     as const, color: '#f87171', emoji: '🏙️' },
      { path: '/street-musicians',   icon: Music,        labelKey: 'streetMusicians' as const, color: '#34d399', emoji: '🎵' },
      { path: '/rainy-day',          icon: CloudRain,    labelKey: 'rainyDay'        as const, color: '#93c5fd', emoji: '🌧️' },
      { path: '/secret-paris',       icon: Lock,         labelKey: 'secretParis'     as const, color: '#C9A84C', emoji: '🗝️' },
      { path: '/morning-ritual',     icon: Sunrise,      labelKey: 'morningRitual'   as const, color: '#fb923c', emoji: '☀️' },
      { path: '/soundscape',         icon: Headphones,   labelKey: 'soundscape'      as const, color: '#60a5fa', emoji: '🎧' },
      { path: '/famous-graves',      icon: Trophy,       labelKey: 'famousGraves'    as const, color: '#9ca3af', emoji: '🪦' },
    ],
  },
];

const MOBILE_PATHS = ['/dashboard', '/chat', '/arrival', '/checklist', '/quest', '/settings'];
const SIDEBAR_BG = 'rgba(2,8,20,0.97)';
const SIDEBAR_BORDER = 'rgba(0,64,130,0.25)';

// ─── Compact Language Picker ─────────────────────────────────────────────────
function LanguagePicker() {
  const { lang, setLang, t } = useLanguage();
  const [open, setOpen] = useState(false);
  const current = LANGUAGES.find(l => l.code === lang)!;

  return (
    <div style={{ position: 'relative' }}>
      <button
        onClick={() => setOpen(o => !o)}
        style={{
          display: 'flex', alignItems: 'center', gap: 6,
          width: '100%', padding: '8px 12px', borderRadius: 10,
          background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.1)',
          cursor: 'pointer', color: '#9ca3af', fontSize: 12, fontWeight: 600,
        }}
      >
        <span style={{ fontSize: 16 }}>{current.flag}</span>
        <span>{current.native}</span>
        <span style={{ marginLeft: 'auto', opacity: 0.4, fontSize: 10 }}>{open ? '▲' : '▼'}</span>
      </button>
      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ opacity: 0, y: 4 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: 4 }}
            style={{
              position: 'absolute', bottom: '110%', left: 0, right: 0,
              background: 'rgba(2,8,20,0.99)', border: '1px solid rgba(0,64,130,0.35)',
              borderRadius: 12, overflow: 'hidden', zIndex: 50,
              boxShadow: '0 -8px 32px rgba(0,0,0,0.5)',
            }}
          >
            {LANGUAGES.map(l => (
              <button key={l.code} onClick={() => { setLang(l.code); setOpen(false); }}
                style={{
                  display: 'flex', alignItems: 'center', gap: 8,
                  width: '100%', padding: '9px 14px',
                  background: l.code === lang ? 'rgba(0,64,130,0.25)' : 'transparent',
                  border: 'none', borderBottom: '1px solid rgba(255,255,255,0.04)',
                  cursor: 'pointer', color: l.code === lang ? '#fff' : '#9ca3af',
                  fontSize: 13, fontWeight: l.code === lang ? 700 : 500,
                }}>
                <span style={{ fontSize: 18 }}>{l.flag}</span>
                <span>{l.native}</span>
                {l.code === lang && <span style={{ marginLeft: 'auto', color: GOLD, fontSize: 11 }}>✓</span>}
              </button>
            ))}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

// ─── Mobile lang row (extracted to avoid hook-in-callback) ──────────────────
function MobileLangRow() {
  const { lang, setLang } = useLanguage();
  return (
    <div style={{ padding: '0.75rem', borderTop: 'solid 1px rgba(0,64,130,0.15)', display: 'flex', gap: 6, flexWrap: 'wrap' }}>
      {LANGUAGES.map(l => (
        <button key={l.code} onClick={() => setLang(l.code)}
          style={{ padding: '5px 10px', borderRadius: 8, cursor: 'pointer', fontSize: 12, background: l.code === lang ? 'rgba(0,64,130,0.3)' : 'rgba(255,255,255,0.05)', border: `1px solid ${l.code === lang ? '#3a7bd5' : 'rgba(255,255,255,0.08)'}`, color: l.code === lang ? '#fff' : '#6b7280', fontWeight: l.code === lang ? 700 : 500 }}>
          {l.flag} {l.native}
        </button>
      ))}
    </div>
  );
}

// ─── AppShell ─────────────────────────────────────────────────────────────────
export default function AppShell({ children }: { children: React.ReactNode }) {
  const pathname = usePathname();
  const [mobileOpen, setMobileOpen] = useState(false);
  const { t } = useLanguage();

  const NAV_GROUPS = NAV_GROUPS_DEF.map(group => ({
    label: t(tr.nav.groups[group.labelKey]),
    items: group.items.map(item => ({ ...item, label: t(tr.nav.items[item.labelKey]) })),
  }));

  const ALL_NAV = NAV_GROUPS.flatMap(g => g.items);
  const MOBILE_NAV = MOBILE_PATHS.map(p => ALL_NAV.find(n => n.path === p)!).filter(Boolean);

  const isActive = (path: string) => pathname === path || pathname.startsWith(path + '/');

  const Logo = () => (
    <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
      <div style={{ width: 32, height: 32, borderRadius: 8, overflow: 'hidden', display: 'flex', flexShrink: 0, border: `1px solid rgba(201,168,76,0.4)`, boxShadow: '0 0 14px rgba(0,64,130,0.35)' }}>
        <div style={{ flex: 1, background: '#002395' }} />
        <div style={{ flex: 1, background: '#FFFFFF' }} />
        <div style={{ flex: 1, background: '#ED2939' }} />
      </div>
      <div>
        <p style={{ fontWeight: 700, fontSize: 13, color: GOLD, lineHeight: 1 }}>ParisEasyGuide+</p>
        <p style={{ fontSize: 9, color: '#374151', marginTop: 1 }}>Votre compagnon IA</p>
      </div>
    </div>
  );

  return (
    <div style={{ minHeight: '100vh', display: 'flex' }}>

      {/* ── Desktop sidebar ── */}
      <aside className="md-sidebar" style={{ display: 'none' }}>
        <style>{`@media(min-width:768px){.md-sidebar{display:flex!important;flex-direction:column;width:240px;border-right:1px solid ${SIDEBAR_BORDER};position:fixed;top:0;bottom:0;left:0;z-index:30;background:${SIDEBAR_BG};backdrop-filter:blur(32px);}}`}</style>

        <Link href="/" style={{ display: 'flex', alignItems: 'center', gap: '0.75rem', padding: '1.1rem 1.25rem', borderBottom: `1px solid rgba(0,64,130,0.2)`, textDecoration: 'none' }}>
          <Logo />
        </Link>

        <nav style={{ flex: 1, padding: '0.75rem', overflowY: 'auto', display: 'flex', flexDirection: 'column', gap: '0.25rem' }}>
          {NAV_GROUPS.map(group => (
            <div key={group.label} style={{ marginBottom: '0.5rem' }}>
              <div style={{ fontSize: 9, fontWeight: 700, color: '#374151', textTransform: 'uppercase', letterSpacing: '0.08em', padding: '8px 10px 4px' }}>{group.label}</div>
              {group.items.map(item => {
                const active = isActive(item.path);
                return (
                  <Link key={item.path} href={item.path}
                    style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '9px 12px', borderRadius: 10, textDecoration: 'none', marginBottom: 2, background: active ? `${item.color}15` : 'transparent', border: `1px solid ${active ? item.color + '44' : 'transparent'}`, transition: 'all 0.15s' }}>
                    <span style={{ fontSize: 15 }}>{item.emoji}</span>
                    <span style={{ fontSize: 13, fontWeight: active ? 700 : 500, color: active ? '#fff' : '#6b7280' }}>{item.label}</span>
                    {active && <div style={{ marginLeft: 'auto', width: 5, height: 5, borderRadius: '50%', background: GOLD }} />}
                  </Link>
                );
              })}
            </div>
          ))}
        </nav>

        <div style={{ padding: '0.75rem', borderTop: `1px solid rgba(0,64,130,0.15)` }}>
          <div style={{ fontSize: 9, fontWeight: 700, color: '#374151', textTransform: 'uppercase', letterSpacing: '0.08em', marginBottom: 6, paddingLeft: 2 }}>
            {t(tr.shell.language)}
          </div>
          <LanguagePicker />
        </div>
        <div style={{ padding: '0.5rem 1.25rem 0.75rem', fontSize: 10, color: '#374151' }}>
          {t(tr.shell.rgpd)}
        </div>
      </aside>

      {/* ── Mobile header ── */}
      <div className="mobile-header" style={{ display: 'none' }}>
        <style>{`.mobile-header{display:flex!important;position:fixed;top:0;left:0;right:0;z-index:30;height:52px;align-items:center;justify-content:space-between;padding:0 1rem;background:rgba(2,8,20,0.97);backdrop-filter:blur(24px);border-bottom:1px solid ${SIDEBAR_BORDER};}@media(min-width:768px){.mobile-header{display:none!important;}}`}</style>
        <Link href="/"><Logo /></Link>
        <button onClick={() => setMobileOpen(!mobileOpen)} style={{ background: 'none', border: 'none', cursor: 'pointer', color: '#9ca3af', padding: 4 }}>
          {mobileOpen ? <X style={{ width: 20, height: 20 }} /> : <Menu style={{ width: 20, height: 20 }} />}
        </button>
      </div>

      {/* ── Mobile drawer ── */}
      <AnimatePresence>
        {mobileOpen && (
          <motion.div
            initial={{ opacity: 0, y: -8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -8 }}
            className="mobile-drawer" style={{ display: 'none' }}
          >
            <style>{`.mobile-drawer{display:block!important;position:fixed;top:52px;left:0;right:0;z-index:20;background:rgba(2,8,20,0.98);backdrop-filter:blur(24px);border-bottom:1px solid ${SIDEBAR_BORDER};max-height:70vh;overflow-y:auto;}@media(min-width:768px){.mobile-drawer{display:none!important;}}`}</style>
            <div style={{ padding: '0.75rem' }}>
              {NAV_GROUPS.map(group => (
                <div key={group.label} style={{ marginBottom: '0.75rem' }}>
                  <div style={{ fontSize: 9, fontWeight: 700, color: '#374151', textTransform: 'uppercase', letterSpacing: '0.08em', padding: '4px 8px 6px' }}>{group.label}</div>
                  <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 6 }}>
                    {group.items.map(item => (
                      <Link key={item.path} href={item.path} onClick={() => setMobileOpen(false)}
                        style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '9px 12px', borderRadius: 10, textDecoration: 'none', background: isActive(item.path) ? `${item.color}15` : 'rgba(255,255,255,0.04)', border: `1px solid ${isActive(item.path) ? item.color + '44' : 'rgba(255,255,255,0.07)'}` }}>
                        <span style={{ fontSize: 16 }}>{item.emoji}</span>
                        <span style={{ fontSize: 12, fontWeight: 600, color: isActive(item.path) ? '#fff' : '#9ca3af' }}>{item.label}</span>
                      </Link>
                    ))}
                  </div>
                </div>
              ))}
            </div>
            {/* Language row in mobile drawer */}
            <MobileLangRow />
          </motion.div>
        )}
      </AnimatePresence>

      {/* ── Main content ── */}
      <main className="main-content" style={{ flex: 1, minHeight: '100vh' }}>
        <style>{`.main-content{padding-top:52px!important;padding-bottom:64px;}@media(min-width:768px){.main-content{margin-left:240px!important;padding-top:0!important;padding-bottom:0!important;}}`}</style>
        {children}
      </main>

      {/* ── Mobile bottom bar ── */}
      <nav className="mobile-bottom" style={{ display: 'none' }}>
        <style>{`.mobile-bottom{display:flex!important;position:fixed;bottom:0;left:0;right:0;z-index:30;justify-content:space-around;padding:6px 4px 8px;background:rgba(2,8,20,0.97);backdrop-filter:blur(24px);border-top:1px solid ${SIDEBAR_BORDER};}@media(min-width:768px){.mobile-bottom{display:none!important;}}`}</style>
        {MOBILE_NAV.map(item => {
          const active = isActive(item.path);
          return (
            <Link key={item.path} href={item.path}
              style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 2, padding: '4px 6px', textDecoration: 'none', flex: 1 }}>
              <span style={{ fontSize: 18 }}>{item.emoji}</span>
              <span style={{ fontSize: 9, fontWeight: 700, color: active ? GOLD : '#4b5563' }}>{item.label.split(' ')[0]}</span>
            </Link>
          );
        })}
      </nav>
    </div>
  );
}
