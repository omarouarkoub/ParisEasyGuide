-- ============================================================
-- ParisEasyGuide+ — Supabase PostgreSQL Schema
-- Run this in your Supabase SQL Editor
-- ============================================================

-- Enable UUID extension
create extension if not exists "uuid-ossp";

-- ── Users (extends Supabase auth.users) ──────────────────────
create table if not exists public.profiles (
  id          uuid references auth.users on delete cascade primary key,
  full_name   text,
  avatar_url  text,
  created_at  timestamptz default now()
);
alter table public.profiles enable row level security;
create policy "Users can view own profile" on public.profiles
  for select using (auth.uid() = id);
create policy "Users can update own profile" on public.profiles
  for update using (auth.uid() = id);
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer as $$
begin
  insert into public.profiles (id, full_name, avatar_url)
  values (new.id, new.raw_user_meta_data->>'full_name', new.raw_user_meta_data->>'avatar_url');
  return new;
end;
$$;
drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute procedure public.handle_new_user();

-- ── Expenses (Budget tracker) ────────────────────────────────
create table if not exists public.expenses (
  id          uuid default uuid_generate_v4() primary key,
  user_id     uuid references auth.users on delete cascade not null,
  label       text not null,
  amount      numeric(10,2) not null,
  category    text not null default 'other', -- food | café | ticket | other
  created_at  timestamptz default now()
);
alter table public.expenses enable row level security;
create policy "Users manage own expenses" on public.expenses
  for all using (auth.uid() = user_id);
create index on public.expenses (user_id, created_at desc);

-- ── Commute Routes ────────────────────────────────────────────
create table if not exists public.commute_routes (
  id          uuid default uuid_generate_v4() primary key,
  user_id     uuid references auth.users on delete cascade not null,
  from_label  text not null,
  from_id     text,
  to_label    text not null,
  to_id       text,
  created_at  timestamptz default now()
);
alter table public.commute_routes enable row level security;
create policy "Users manage own routes" on public.commute_routes
  for all using (auth.uid() = user_id);

-- ── Favourite POIs ────────────────────────────────────────────
create table if not exists public.favourite_pois (
  id          uuid default uuid_generate_v4() primary key,
  user_id     uuid references auth.users on delete cascade not null,
  poi_id      text not null,
  poi_name    text not null,
  lat         numeric(9,6),
  lng         numeric(9,6),
  created_at  timestamptz default now(),
  unique(user_id, poi_id)
);
alter table public.favourite_pois enable row level security;
create policy "Users manage own favourites" on public.favourite_pois
  for all using (auth.uid() = user_id);

-- ── Quest Badges ──────────────────────────────────────────────
create table if not exists public.quest_badges (
  id          uuid default uuid_generate_v4() primary key,
  user_id     uuid references auth.users on delete cascade not null,
  badge_id    text not null,
  badge_name  text,
  rarity      text not null default 'common', -- common | rare | legendary
  xp          integer not null default 50,
  category    text,
  earned_at   timestamptz default now(),
  unique(user_id, badge_id)
);
alter table public.quest_badges enable row level security;
create policy "Users manage own badges" on public.quest_badges
  for all using (auth.uid() = user_id);

-- ── Chat history ──────────────────────────────────────────────
create table if not exists public.chat_messages (
  id          uuid default uuid_generate_v4() primary key,
  user_id     uuid references auth.users on delete cascade not null,
  role        text not null check (role in ('user','assistant')),
  content     text not null,
  created_at  timestamptz default now()
);
alter table public.chat_messages enable row level security;
create policy "Users manage own messages" on public.chat_messages
  for all using (auth.uid() = user_id);
create index on public.chat_messages (user_id, created_at asc);
