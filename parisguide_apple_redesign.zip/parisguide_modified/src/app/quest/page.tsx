'use client';
import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Trophy, Zap, Sparkles, Loader2 } from 'lucide-react';
import { BADGE_CATALOG, LEVELS, getLevelInfo, XP_PER_RARITY } from '@/lib/questBadges';
import type { QuestBadge } from '@/types';
import { fireBadgeToast } from '@/components/quest/BadgeUnlockToast';
import { FadeIn } from '@/components/shared/PageMotion';
import StatCard from '@/components/shared/StatCard';

const GOLD = '#FFD700';
const NAVY = '#002654';

const CATEGORY_LABELS: Record<string, string> = {
  landmark:  '🗺️ Landmarks',
  culture:   '🎨 Culture',
  idf:       '🏰 Île-de-France',
  nature:    '🌳 Nature & Parks',
  food:      '🍷 Food & Markets',
  transport: '🚇 Transport',
  language:  '🌐 Language',
  explorer:  '💡 Explorer',
  special:   '⭐ Special',
};

const rarityConfig = (rarity: string) => {
  if (rarity === 'legendary') return {
    border: 'rgba(255,215,0,0.45)', shadow: '0 0 22px rgba(255,215,0,0.18)',
    glow: '#FFD700', label: '⭐ Legendary', bg: 'rgba(255,215,0,0.06)',
  };
  if (rarity === 'rare') return {
    border: 'rgba(100,210,255,0.45)', shadow: '0 0 18px rgba(100,210,255,0.12)',
    glow: '#64D2FF', label: '💎 Rare', bg: 'rgba(100,210,255,0.06)',
  };
  return {
    border: 'rgba(255,255,255,0.09)', shadow: 'none',
    glow: '#8E8E93', label: '🔹 Common', bg: 'rgba(255,255,255,0.04)',
  };
};

export default function QuestPage() {
  const [badges, setBadges]         = useState<QuestBadge[]>([]);
  const [loading, setLoading]       = useState(true);
  const [demoLoading, setDemoLoading] = useState(false);
  const [hovered, setHovered]       = useState<string | null>(null);

  useEffect(() => {
    fetch('/api/badges')
      .then(r => r.json())
      .then(d => { setBadges(d.badges || []); setLoading(false); });
  }, []);

  const earnedIds = badges.map(b => b.badge_id);
  const totalXP   = badges.reduce((s, b) => s + (b.xp || XP_PER_RARITY[b.rarity] || 50), 0);
  const { current: level, next: nextLevel, progress } = getLevelInfo(totalXP);

  const grouped: Record<string, typeof BADGE_CATALOG> = {};
  BADGE_CATALOG.forEach(b => {
    if (!grouped[b.category]) grouped[b.category] = [];
    grouped[b.category].push(b);
  });

  const demoBadge = async () => {
    setDemoLoading(true);
    const unearned = BADGE_CATALOG.filter(b => !earnedIds.includes(b.badge_id));
    const badge = unearned[Math.floor(Math.random() * unearned.length)] || BADGE_CATALOG[0];
    await new Promise(r => setTimeout(r, 400));
    fireBadgeToast({
      id: badge.badge_id, emoji: badge.emoji, name: badge.name,
      description: badge.description, rarity: badge.rarity,
      xp: XP_PER_RARITY[badge.rarity],
    });
    setDemoLoading(false);
  };

  return (
    <div style={{ padding: 'clamp(1.25rem,3vw,2.25rem) clamp(1rem,4vw,2.5rem)', maxWidth: 1100, margin: '0 auto' }}>

      {/* ── Header ──────────────────────────────────────────────────────── */}
      <FadeIn>
        <div style={{
          display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between',
          marginBottom: '2rem', flexWrap: 'wrap', gap: '1rem',
        }}>
          <div>
            <div style={{ display: 'flex', alignItems: 'center', gap: 7, marginBottom: 5 }}>
              <Trophy style={{ width: 15, height: 15, color: GOLD }} />
              <span style={{ fontSize: 10.5, fontWeight: 700, color: GOLD, textTransform: 'uppercase', letterSpacing: '0.12em' }}>
                Quest & Badges
              </span>
            </div>
            <h1 style={{
              fontFamily: 'Playfair Display, serif',
              fontSize: 'clamp(1.8rem, 3.5vw, 2.5rem)',
              fontWeight: 800, color: '#F5F5F7', letterSpacing: '-0.025em', marginBottom: 4,
            }}>
              Your Trophies
            </h1>
            <p style={{ color: '#8E8E93', fontSize: 14 }}>Earn XP and unlock badges as you explore Paris</p>
          </div>

          <motion.button
            whileHover={{ scale: 1.04 }} whileTap={{ scale: 0.96 }}
            onClick={demoBadge} disabled={demoLoading}
            style={{
              display: 'flex', alignItems: 'center', gap: 8,
              padding: '10px 18px', borderRadius: 14,
              background: 'linear-gradient(135deg, #5E5CE6, #4A45D4)',
              border: '1px solid rgba(94,92,230,0.4)',
              cursor: 'pointer', color: '#F5F5F7', fontWeight: 700, fontSize: 13,
              boxShadow: '0 4px 20px rgba(94,92,230,0.3)',
            }}>
            {demoLoading
              ? <Loader2 style={{ width: 14, height: 14, animation: 'spin 1s linear infinite' }} />
              : <Sparkles style={{ width: 14, height: 14 }} />}
            Preview Badge Toast
          </motion.button>
        </div>
      </FadeIn>

      {/* ── XP Level card ───────────────────────────────────────────────── */}
      <motion.div
        initial={{ opacity: 0, scale: 0.97 }} animate={{ opacity: 1, scale: 1 }}
        transition={{ delay: 0.1 }}
        style={{
          padding: '1.4rem 1.6rem', borderRadius: 22,
          background: 'linear-gradient(135deg, rgba(255,215,0,0.07) 0%, rgba(255,159,10,0.03) 100%)',
          border: '1px solid rgba(255,215,0,0.22)',
          marginBottom: '1.5rem',
          display: 'grid', gridTemplateColumns: '1fr auto',
          gap: '1rem', alignItems: 'center',
          backdropFilter: 'blur(20px)',
          boxShadow: '0 4px 32px rgba(0,0,0,0.25)',
          position: 'relative', overflow: 'hidden',
        }}>
        {/* Ambient glow */}
        <div style={{
          position: 'absolute', top: -30, right: -30,
          width: 140, height: 140, borderRadius: '50%',
          background: 'radial-gradient(circle, rgba(255,215,0,0.12), transparent 70%)',
          pointerEvents: 'none',
        }} />

        <div style={{ flex: 1 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 9, marginBottom: 10 }}>
            <Zap style={{ width: 16, height: 16, color: GOLD }} />
            <span style={{
              fontSize: 17, fontWeight: 800, color: GOLD, letterSpacing: '-0.02em',
            }}>
              Level {level.level}
            </span>
            <span style={{
              padding: '3px 12px', borderRadius: 20,
              background: 'rgba(255,215,0,0.12)',
              border: '1px solid rgba(255,215,0,0.25)',
              fontSize: 12, fontWeight: 700, color: GOLD,
            }}>
              {level.title}
            </span>
          </div>

          {/* XP bar */}
          <div style={{
            height: 6, borderRadius: 6,
            background: 'rgba(255,255,255,0.08)', marginBottom: 8, overflow: 'hidden',
          }}>
            <motion.div
              initial={{ width: 0 }}
              animate={{ width: `${progress}%` }}
              transition={{ duration: 1.3, ease: 'easeOut', delay: 0.35 }}
              style={{
                height: '100%', borderRadius: 6,
                background: 'linear-gradient(90deg, #FF9F0A, #FFD700)',
                boxShadow: '0 0 8px rgba(255,215,0,0.5)',
              }}
            />
          </div>

          <div style={{ fontSize: 12, color: '#8E8E93', fontWeight: 500 }}>
            {totalXP.toLocaleString()} XP
            {nextLevel
              ? ` · ${(nextLevel.minXP - totalXP).toLocaleString()} XP to ${nextLevel.title}`
              : ' · Max level reached! 🏆'}
          </div>
        </div>

        <div style={{ textAlign: 'right', flexShrink: 0 }}>
          <div style={{
            fontSize: '2.25rem', fontWeight: 800, color: GOLD,
            letterSpacing: '-0.03em', lineHeight: 1,
          }}>
            {badges.length}
          </div>
          <div style={{ fontSize: 11.5, color: '#8E8E93', marginTop: 4 }}>Badges earned</div>
        </div>
      </motion.div>

      {/* ── Stats ────────────────────────────────────────────────────────── */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3,1fr)', gap: '0.75rem', marginBottom: '2.25rem' }}>
        <StatCard value={badges.filter(b => b.rarity === 'legendary').length} label="Legendary" color="#FFD700" prefix="⭐ " delay={0}    />
        <StatCard value={badges.filter(b => b.rarity === 'rare').length}      label="Rare"      color="#64D2FF" prefix="💎 " delay={0.1}  />
        <StatCard value={badges.filter(b => b.rarity === 'common').length}    label="Common"    color="#8E8E93" prefix="🔹 " delay={0.2}  />
      </div>

      {/* ── Badge grid by category ─────────────────────────────────────── */}
      {loading ? (
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(130px, 1fr))', gap: '0.75rem' }}>
          {Array.from({ length: 12 }).map((_, i) => (
            <div key={i} style={{
              height: 140, borderRadius: 18,
              background: 'rgba(21,26,35,0.5)', border: '1px solid rgba(255,255,255,0.06)',
              animation: 'shimmer 1.8s ease-in-out infinite',
              backgroundImage: 'linear-gradient(90deg, transparent 0%, rgba(255,255,255,0.03) 50%, transparent 100%)',
              backgroundSize: '200% 100%',
            }} />
          ))}
        </div>
      ) : (
        Object.entries(grouped).map(([cat, catBadges]) => (
          <div key={cat} style={{ marginBottom: '2.25rem' }}>
            <h2 style={{
              fontWeight: 700, color: '#F5F5F7', marginBottom: '1rem',
              fontSize: 15, letterSpacing: '-0.01em',
            }}>
              {CATEGORY_LABELS[cat] || cat}
            </h2>

            <div style={{
              display: 'grid',
              gridTemplateColumns: 'repeat(auto-fill, minmax(125px, 1fr))',
              gap: '0.75rem',
            }}>
              {catBadges.map((badge, i) => {
                const earned = earnedIds.includes(badge.badge_id);
                const rc     = rarityConfig(badge.rarity);
                const isHov  = hovered === badge.badge_id;

                return (
                  <motion.div
                    key={badge.badge_id}
                    initial={{ opacity: 0, scale: 0.88, y: 10 }}
                    animate={{ opacity: 1, scale: 1, y: 0 }}
                    transition={{ delay: i * 0.04, type: 'spring', stiffness: 300, damping: 24 }}
                    onHoverStart={() => setHovered(badge.badge_id)}
                    onHoverEnd={() => setHovered(null)}
                    whileHover={{ scale: 1.04, y: -3 }}
                    whileTap={{ scale: 0.96 }}
                    style={{
                      padding: '1rem 0.875rem', borderRadius: 18, textAlign: 'center',
                      background: earned ? rc.bg : 'rgba(21,26,35,0.5)',
                      border: `1px solid ${earned ? rc.border : 'rgba(255,255,255,0.06)'}`,
                      boxShadow: earned && isHov ? rc.shadow : 'none',
                      cursor: 'pointer', position: 'relative', overflow: 'hidden',
                      transition: 'box-shadow 0.25s, border-color 0.25s, background 0.25s',
                    }}>

                    {/* Shimmer overlay for legendary earned */}
                    {earned && badge.rarity === 'legendary' && (
                      <div className="shimmer" style={{
                        position: 'absolute', inset: 0, borderRadius: 18,
                        pointerEvents: 'none', opacity: 0.4,
                      }} />
                    )}

                    {/* Badge emoji */}
                    <div style={{
                      fontSize: '2.25rem', marginBottom: '0.625rem',
                      filter: earned ? 'none' : 'grayscale(1) opacity(0.3)',
                      transition: 'filter 0.25s',
                    }}>
                      {badge.emoji}
                    </div>

                    <div style={{
                      fontWeight: 700, fontSize: 11.5,
                      color: earned ? '#F5F5F7' : '#3A3A3C',
                      lineHeight: 1.35, marginBottom: '0.375rem',
                      letterSpacing: '-0.01em',
                    }}>
                      {badge.name}
                    </div>

                    {earned && (
                      <motion.div
                        initial={{ opacity: 0, scale: 0.8 }}
                        animate={{ opacity: 1, scale: 1 }}
                        style={{
                          fontSize: 10, fontWeight: 700,
                          color: rc.glow, lineHeight: 1,
                          textShadow: `0 0 8px ${rc.glow}60`,
                        }}>
                        {rc.label}
                      </motion.div>
                    )}

                    {!earned && (
                      <div style={{ fontSize: 10, color: '#3A3A3C', fontWeight: 500 }}>
                        Locked
                      </div>
                    )}

                    {/* XP chip */}
                    {earned && (
                      <div style={{
                        marginTop: 6,
                        display: 'inline-flex', alignItems: 'center', gap: 3,
                        padding: '2px 8px', borderRadius: 20,
                        background: 'rgba(255,215,0,0.10)',
                        border: '1px solid rgba(255,215,0,0.2)',
                        fontSize: 9.5, fontWeight: 700, color: GOLD,
                      }}>
                        <Zap style={{ width: 8, height: 8 }} />
                        +{XP_PER_RARITY[badge.rarity]} XP
                      </div>
                    )}
                  </motion.div>
                );
              })}
            </div>
          </div>
        ))
      )}

      <style>{`
        @keyframes spin { from { transform: rotate(0deg) } to { transform: rotate(360deg) } }
      `}</style>
    </div>
  );
}
