'use client';
import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Loader2, ExternalLink } from 'lucide-react';
import { toast } from 'sonner';
import { FadeIn } from '@/components/shared/PageMotion';

const IMPORT_STEPS = [
  { eu: true, step: 'EU Pet Passport', desc: 'Required for all pets traveling within EU. Your vet issues it. Contains vaccination and microchip records.', icon: '📘' },
  { eu: true, step: 'Microchip (ISO 11784/11785)', desc: '15-digit microchip mandatory. Must be implanted BEFORE rabies vaccination to be valid.', icon: '💉' },
  { eu: true, step: 'Rabies Vaccination', desc: 'Must be current. Dog/cat must be ≥12 weeks old at time of vaccination.', icon: '🏥' },
  { eu: false, step: 'Rabies Titre Test (non-EU)', desc: 'Required for pets from outside EU. Blood test ≥30 days after vaccination. Wait 3 months before travel.', icon: '🧪' },
  { eu: false, step: 'Tapeworm Treatment (dogs only, non-EU)', desc: '1–5 days before arrival. Recorded in pet passport by vet.', icon: '🐛' },
  { eu: true, step: 'Health Certificate', desc: 'From an official/accredited vet, issued ≤10 days before travel. For airline cabin pets usually.', icon: '📄' },
];

const DOG_BREED_LAW = [
  { cat: 'Catégorie 1', desc: 'Attack dogs: Staffordshire Terrier, American Staffordshire Terrier, Mastiff-types, Tosa. Must be sterilised, muzzled at all times in public, on leash, owner must have permit (permis de détention). Cannot be imported.', color: '#ef4444' },
  { cat: 'Catégorie 2', desc: 'Guard/defence dogs: American Staffordshire Terrier (pedigree), Rottweiler, Tosa (pedigree). Must be muzzled in public places, on leash. Owner must be 18+, no criminal record, pass training.', color: '#f59e0b' },
];

const PET_TIPS = [
  { tip: 'Dogs on metro & RER', detail: 'Small dogs in a bag travel free. Dogs >6kg pay a child ticket (~€2) and must be muzzled. No dogs on buses.', emoji: '🚇' },
  { tip: 'Dog parks (Espaces canins)', detail: 'Enclosed off-leash areas in most parks. Use Mairie Paris website to find the nearest one.', emoji: '🐕' },
  { tip: 'Leash rules', detail: 'Dogs must be on leash in all public spaces unless in an official "espace canin" (dog park).', emoji: '🐾' },
  { tip: 'Pet-friendly cafés', detail: 'Most Paris café terraces allow well-behaved dogs. Always ask "Les chiens sont acceptés ?"', emoji: '☕' },
  { tip: 'Pet insurance', detail: 'Providers: Dalma, Bulle Bleue, SwissLife. Monthly cost ~€15–50 depending on pet and coverage.', emoji: '🛡️' },
  { tip: 'Cat chips & I-CAD registry', detail: 'All cats born after 2012 must be microchipped and registered in I-CAD (national registry). Your vet registers automatically.', emoji: '🐱' },
];

export default function PetsPage() {
  const [activeTab, setActiveTab] = useState<'import' | 'rules' | 'vets' | 'tips'>('import');
  const [question, setQuestion] = useState('');
  const [answer, setAnswer] = useState('');
  const [loading, setLoading] = useState(false);

  const ask = async (q?: string) => {
    const query = q || question;
    if (!query.trim()) return;
    setLoading(true); setAnswer('');
    try {
      const res = await fetch('/api/pets', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ question: query }) });
      const data = await res.json();
      setAnswer(data.answer || '');
    } catch { toast.error('Connection error'); }
    finally { setLoading(false); }
  };

  const QUICK = ['Can I bring my American Staffordshire Terrier to France?', 'What do I need to bring my cat from the US?', 'Where can I find emergency vets in Paris?', 'Are there dog-friendly restaurants in Paris?'];

  const TABS = [
    { id: 'import', label: '✈️ Importing Pets', color: '#3b82f6' },
    { id: 'rules', label: '⚖️ Breed Laws', color: '#ef4444' },
    { id: 'tips', label: '🐾 Life with Pets', color: '#f97316' },
    { id: 'vets', label: '🏥 Vets & AI Help', color: '#059669' },
  ] as const;

  return (
    <div style={{ padding: '2rem 2.5rem', maxWidth: 1100, margin: '0 auto' }}>
      <FadeIn>
        <div style={{ marginBottom: '2rem' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 4 }}>
            <span style={{ fontSize: 16 }}>🐾</span>
            <span style={{ fontSize: 12, fontWeight: 600, color: '#FFD700', textTransform: 'uppercase', letterSpacing: '0.1em' }}>Pets in Paris</span>
          </div>
          <h1 style={{ fontFamily: 'Playfair Display, serif', fontSize: '2rem', fontWeight: 700, color: '#fff' }}>Pets in Paris</h1>
          <p style={{ color: '#8E8E93', fontSize: 14 }}>Importing pets, breed laws, vets, dog parks & pet-friendly life</p>
        </div>
      </FadeIn>

      <div style={{ display: 'flex', gap: 6, marginBottom: '1.25rem', flexWrap: 'wrap' }}>
        {TABS.map(tab => (
          <button key={tab.id} onClick={() => setActiveTab(tab.id)}
            style={{ padding: '8px 16px', borderRadius: 20, fontSize: 13, fontWeight: 700, cursor: 'pointer', border: `1px solid ${activeTab === tab.id ? tab.color + '66' : 'rgba(255,255,255,0.08)'}`, background: activeTab === tab.id ? `${tab.color}15` : 'rgba(255,255,255,0.03)', color: activeTab === tab.id ? '#fff' : '#9ca3af', transition: 'all 0.2s' }}>
            {tab.label}
          </button>
        ))}
      </div>

      <AnimatePresence mode="wait">
        {activeTab === 'import' && (
          <motion.div key="import" initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '0.75rem', marginBottom: '1rem' }}>
              {[true, false].map(isEU => (
                <div key={String(isEU)} style={{ padding: '0.6rem 1rem', borderRadius: 10, background: isEU ? 'rgba(59,130,246,0.1)' : 'rgba(249,115,22,0.1)', border: `1px solid ${isEU ? 'rgba(59,130,246,0.3)' : 'rgba(249,115,22,0.3)'}`, textAlign: 'center', fontSize: 13, fontWeight: 700, color: isEU ? '#93c5fd' : '#fb923c' }}>
                  {isEU ? '🇪🇺 From EU country' : '🌍 From non-EU country'}
                </div>
              ))}
            </div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '0.6rem' }}>
              {IMPORT_STEPS.map((s, i) => (
                <div key={i} style={{ padding: '0.9rem 1.1rem', borderRadius: 12, background: s.eu ? 'rgba(59,130,246,0.06)' : 'rgba(249,115,22,0.06)', border: `1px solid ${s.eu ? 'rgba(59,130,246,0.2)' : 'rgba(249,115,22,0.25)'}`, display: 'flex', gap: '1rem' }}>
                  <span style={{ fontSize: '1.2rem', flexShrink: 0 }}>{s.icon}</span>
                  <div>
                    <div style={{ fontWeight: 700, color: '#fff', fontSize: 13, marginBottom: 3 }}>{s.step} {!s.eu && <span style={{ fontSize: 10, color: '#fb923c' }}>(NON-EU ONLY)</span>}</div>
                    <div style={{ fontSize: 12, color: '#8E8E93', lineHeight: 1.6 }}>{s.desc}</div>
                  </div>
                </div>
              ))}
            </div>
            <div style={{ marginTop: '1rem', padding: '1rem', borderRadius: 12, background: 'rgba(255,215,0,0.08)', border: '1px solid rgba(255,215,0,0.2)', fontSize: 12, color: '#fbbf24' }}>
              💡 <strong>Pro Tip:</strong> Start the process at least 6 months before travel if coming from a non-EU country. The rabies titre test requires a 3-month wait. Official info at agriculture.gouv.fr.
            </div>
          </motion.div>
        )}

        {activeTab === 'rules' && (
          <motion.div key="rules" initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem', marginBottom: '1.25rem' }}>
              {DOG_BREED_LAW.map(l => (
                <div key={l.cat} style={{ padding: '1.25rem', borderRadius: 14, background: `${l.color}08`, border: `1px solid ${l.color}40` }}>
                  <div style={{ fontWeight: 800, color: l.color, fontSize: 16, marginBottom: 8 }}>{l.cat}</div>
                  <div style={{ fontSize: 13, color: '#e5e7eb', lineHeight: 1.7 }}>{l.desc}</div>
                </div>
              ))}
            </div>
            <div style={{ padding: '1rem', borderRadius: 12, background: 'rgba(59,130,246,0.06)', border: '1px solid rgba(59,130,246,0.2)', fontSize: 12, color: '#93c5fd' }}>
              ℹ️ All dogs must be registered with the <strong>Fichier National d'Identification des Carnivores Domestiques (ICAD)</strong>. Owners of Catégorie 1 or 2 dogs must also carry their permit at all times.
            </div>
          </motion.div>
        )}

        {activeTab === 'tips' && (
          <motion.div key="tips" initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '0.75rem' }}>
              {PET_TIPS.map(t => (
                <div key={t.tip} style={{ padding: '1rem 1.25rem', borderRadius: 14, background: 'rgba(249,115,22,0.06)', border: '1px solid rgba(249,115,22,0.2)', display: 'flex', gap: '1rem' }}>
                  <span style={{ fontSize: '1.3rem', flexShrink: 0 }}>{t.emoji}</span>
                  <div>
                    <div style={{ fontWeight: 700, color: '#fff', fontSize: 14, marginBottom: 4 }}>{t.tip}</div>
                    <div style={{ fontSize: 12, color: '#8E8E93', lineHeight: 1.6 }}>{t.detail}</div>
                  </div>
                </div>
              ))}
            </div>
          </motion.div>
        )}

        {activeTab === 'vets' && (
          <motion.div key="vets" initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '0.75rem', marginBottom: '1.25rem' }}>
              {[
                { name: 'Cabinet vétérinaire de nuit', desc: 'Many Paris vets offer night hours. Search "vétérinaire de garde Paris".', url: '' },
                { name: 'Clinique Vétérinaire Paris Centre', desc: '24h emergency clinic. Multiple locations across Paris.', url: '' },
                { name: 'CRVC (Urgences 24h)', desc: 'Centres Référents en Médecine Vétérinaire. 24h emergency care.', url: '' },
                { name: 'Pet insurance: Dalma', desc: 'Best-rated French pet insurance. App-based claims.', url: 'https://www.dalma.co' },
              ].map(v => (
                <div key={v.name} style={{ padding: '0.9rem 1.1rem', borderRadius: 12, background: 'rgba(5,150,105,0.06)', border: '1px solid rgba(5,150,105,0.2)' }}>
                  <div style={{ fontWeight: 700, color: '#fff', fontSize: 13, marginBottom: 4 }}>{v.name}</div>
                  <div style={{ fontSize: 11, color: '#8E8E93' }}>{v.desc}</div>
                  {v.url && <a href={v.url} target="_blank" rel="noreferrer" style={{ fontSize: 11, color: '#34d399', textDecoration: 'none' }}>Visit →</a>}
                </div>
              ))}
            </div>
            <div style={{ display: 'flex', gap: 8, marginBottom: '0.75rem' }}>
              <input value={question} onChange={e => setQuestion(e.target.value)} onKeyDown={e => e.key === 'Enter' && ask()}
                placeholder="Ask about pet rules, vets, breed laws, travel requirements…"
                style={{ flex: 1, background: 'rgba(255,255,255,0.06)', border: '1px solid rgba(255,255,255,0.1)', borderRadius: 10, padding: '10px 14px', color: '#fff', fontSize: 14, outline: 'none' }} />
              <button onClick={() => ask()} disabled={loading} style={{ padding: '10px 18px', borderRadius: 10, background: 'linear-gradient(135deg,#059669,#047857)', border: 'none', cursor: 'pointer', color: '#fff', fontWeight: 700 }}>
                {loading ? <Loader2 style={{ width: 16, height: 16, animation: 'spin 1s linear infinite' }} /> : 'Ask'}
              </button>
            </div>
            <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap', marginBottom: '0.75rem' }}>
              {QUICK.map(q => (<button key={q} onClick={() => { setQuestion(q); ask(q); }} style={{ padding: '5px 10px', borderRadius: 20, fontSize: 11, cursor: 'pointer', border: '1px solid rgba(5,150,105,0.25)', background: 'rgba(5,150,105,0.06)', color: '#6ee7b7' }}>{q}</button>))}
            </div>
            {answer && <div style={{ padding: '1rem', borderRadius: 12, background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.08)', fontSize: 13, color: '#e5e7eb', lineHeight: 1.7 }} dangerouslySetInnerHTML={{ __html: answer.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>').replace(/\n/g, '<br/>') }} />}
          </motion.div>
        )}
      </AnimatePresence>
      <style>{`@keyframes spin { from { transform:rotate(0deg) } to { transform:rotate(360deg) } }`}</style>
    </div>
  );
}
