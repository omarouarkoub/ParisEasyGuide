'use client';
import { useState, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useRouter } from 'next/navigation';
import {
  Globe, Sun, Moon, Monitor, Bell, BellOff, Shield, Eye, EyeOff,
  Type, Contrast, Zap, User, Trash2, Download, HardDrive, Wifi,
  WifiOff, HelpCircle, MessageSquare, FileText, Lock, ChevronRight,
  CheckCircle2, AlertTriangle, RotateCcw, LogOut, X
} from 'lucide-react';
import { useLanguage, useSettings, LANGUAGES, translations } from '@/lib/i18n/LanguageContext';
import type { Theme, TextSize } from '@/lib/i18n/LanguageContext';

const GOLD = '#FFD700';
const BLUE = '#002654';
const tr = translations.settings;

// ─── Reusable primitives ─────────────────────────────────────────────────────

function SectionHeader({ icon, label }: { icon: React.ReactNode; label: string }) {
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: '0.75rem', marginTop: '0.25rem' }}>
      <div style={{ color: GOLD, display: 'flex' }}>{icon}</div>
      <span style={{ fontSize: 11, fontWeight: 800, color: '#4b5563', textTransform: 'uppercase', letterSpacing: '0.1em' }}>
        {label}
      </span>
    </div>
  );
}

function Card({ children, style }: { children: React.ReactNode; style?: React.CSSProperties }) {
  return (
    <div style={{
      borderRadius: 16, background: 'rgba(255,255,255,0.03)',
      border: '1px solid rgba(255,255,255,0.07)',
      overflow: 'hidden', ...style,
    }}>
      {children}
    </div>
  );
}

function Row({
  icon, label, desc, right, onClick, danger = false, last = false,
}: {
  icon: React.ReactNode; label: string; desc?: string;
  right?: React.ReactNode; onClick?: () => void; danger?: boolean; last?: boolean;
}) {
  return (
    <motion.div
      whileTap={onClick ? { backgroundColor: 'rgba(255,255,255,0.06)' } : undefined}
      onClick={onClick}
      style={{
        display: 'flex', alignItems: 'center', gap: 14,
        padding: '14px 16px',
        borderBottom: last ? 'none' : '1px solid rgba(255,255,255,0.05)',
        cursor: onClick ? 'pointer' : 'default',
        transition: 'background 0.15s',
      }}
    >
      <div style={{
        width: 34, height: 34, borderRadius: 10, flexShrink: 0,
        background: danger ? 'rgba(239,68,68,0.12)' : 'rgba(255,255,255,0.06)',
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        color: danger ? '#ef4444' : '#6b7280',
      }}>
        {icon}
      </div>
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{ fontWeight: 600, color: danger ? '#ef4444' : '#e5e7eb', fontSize: 13, lineHeight: 1.3 }}>{label}</div>
        {desc && <div style={{ fontSize: 11, color: '#8E8E93', marginTop: 2, lineHeight: 1.4 }}>{desc}</div>}
      </div>
      {right && <div style={{ flexShrink: 0 }}>{right}</div>}
      {onClick && !right && <ChevronRight style={{ width: 14, height: 14, color: '#3A3A3C', flexShrink: 0 }} />}
    </motion.div>
  );
}

function Toggle({ value, onChange }: { value: boolean; onChange: (v: boolean) => void }) {
  return (
    <motion.button
      onClick={() => onChange(!value)}
      animate={{ backgroundColor: value ? '#3a7bd5' : 'rgba(255,255,255,0.1)' }}
      transition={{ duration: 0.2 }}
      style={{
        width: 44, height: 24, borderRadius: 12, border: 'none',
        cursor: 'pointer', position: 'relative', flexShrink: 0,
        padding: 0,
      }}
    >
      <motion.div
        animate={{ x: value ? 22 : 2 }}
        transition={{ type: 'spring', stiffness: 500, damping: 35 }}
        style={{
          position: 'absolute', top: 2, width: 20, height: 20,
          borderRadius: '50%', background: '#fff',
          boxShadow: '0 1px 4px rgba(0,0,0,0.3)',
        }}
      />
    </motion.button>
  );
}

function SegmentControl<T extends string>({
  options, value, onChange,
}: {
  options: { value: T; label: string; icon?: React.ReactNode }[];
  value: T; onChange: (v: T) => void;
}) {
  return (
    <div style={{
      display: 'flex', borderRadius: 10,
      background: 'rgba(255,255,255,0.05)',
      border: '1px solid rgba(255,255,255,0.08)',
      padding: 3, gap: 2,
    }}>
      {options.map(opt => (
        <motion.button
          key={opt.value}
          onClick={() => onChange(opt.value)}
          animate={{
            background: value === opt.value ? 'rgba(58,123,213,0.25)' : 'transparent',
            color: value === opt.value ? '#fff' : '#6b7280',
          }}
          style={{
            flex: 1, padding: '6px 8px', borderRadius: 8,
            border: `1px solid ${value === opt.value ? 'rgba(58,123,213,0.5)' : 'transparent'}`,
            cursor: 'pointer', fontSize: 11, fontWeight: 600,
            display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 4,
          }}
        >
          {opt.icon && <span style={{ display: 'flex', opacity: 0.8 }}>{opt.icon}</span>}
          {opt.label}
        </motion.button>
      ))}
    </div>
  );
}

// ─── Confirm Dialog ───────────────────────────────────────────────────────────
function ConfirmDialog({
  title, desc, confirmLabel, danger, onConfirm, onCancel,
}: {
  title: string; desc: string; confirmLabel: string;
  danger?: boolean; onConfirm: () => void; onCancel: () => void;
}) {
  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      style={{
        position: 'fixed', inset: 0, zIndex: 200,
        background: 'rgba(0,0,0,0.7)', backdropFilter: 'blur(8px)',
        display: 'flex', alignItems: 'center', justifyContent: 'center', padding: '1.5rem',
      }}
      onClick={onCancel}
    >
      <motion.div
        initial={{ scale: 0.9, y: 16 }} animate={{ scale: 1, y: 0 }}
        onClick={e => e.stopPropagation()}
        style={{
          background: 'hsl(210,25%,10%)', borderRadius: 20,
          border: '1px solid rgba(255,255,255,0.1)',
          padding: '1.75rem', maxWidth: 380, width: '100%',
          boxShadow: '0 24px 64px rgba(0,0,0,0.6)',
        }}
      >
        <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: '0.875rem' }}>
          <AlertTriangle style={{ width: 20, height: 20, color: danger ? '#ef4444' : GOLD }} />
          <span style={{ fontWeight: 700, color: '#fff', fontSize: 15 }}>{title}</span>
        </div>
        <p style={{ color: '#8E8E93', fontSize: 13, lineHeight: 1.6, marginBottom: '1.5rem' }}>{desc}</p>
        <div style={{ display: 'flex', gap: 10 }}>
          <button onClick={onCancel}
            style={{ flex: 1, padding: '10px', borderRadius: 10, background: 'rgba(255,255,255,0.07)', border: '1px solid rgba(255,255,255,0.1)', color: '#8E8E93', cursor: 'pointer', fontWeight: 600, fontSize: 13 }}>
            Cancel
          </button>
          <button onClick={onConfirm}
            style={{ flex: 1, padding: '10px', borderRadius: 10, background: danger ? 'rgba(239,68,68,0.15)' : 'rgba(0,38,84,0.3)', border: `1px solid ${danger ? '#ef444466' : '#3a7bd566'}`, color: danger ? '#ef4444' : '#60a5fa', cursor: 'pointer', fontWeight: 700, fontSize: 13 }}>
            {confirmLabel}
          </button>
        </div>
      </motion.div>
    </motion.div>
  );
}

// ─── Toast ────────────────────────────────────────────────────────────────────
function Toast({ msg, onDone }: { msg: string; onDone: () => void }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 60 }} animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: 60 }}
      onAnimationComplete={() => setTimeout(onDone, 1800)}
      style={{
        position: 'fixed', bottom: 88, left: '50%', transform: 'translateX(-50%)',
        zIndex: 300, display: 'flex', alignItems: 'center', gap: 8,
        padding: '10px 20px', borderRadius: 12,
        background: 'rgba(22,163,74,0.15)', border: '1px solid rgba(22,163,74,0.35)',
        color: '#4ade80', fontSize: 13, fontWeight: 600,
        backdropFilter: 'blur(12px)', whiteSpace: 'nowrap',
        boxShadow: '0 8px 32px rgba(0,0,0,0.4)',
      }}
    >
      <CheckCircle2 style={{ width: 15, height: 15 }} />
      {msg}
    </motion.div>
  );
}

// ─── Main Settings Page ───────────────────────────────────────────────────────
export default function SettingsPage() {
  const router = useRouter();
  const { lang, setLang, t } = useLanguage();
  const { settings, updateSetting } = useSettings();

  const [toast, setToast] = useState<string | null>(null);
  const [dialog, setDialog] = useState<null | 'resetOnboarding' | 'deleteAccount' | 'clearCache'>(null);
  const [cacheCleared, setCacheCleared] = useState(false);

  const showToast = (msg: string) => { setToast(msg); };

  const handleClearCache = () => {
    const keys = Object.keys(localStorage).filter(k => k.startsWith('paris_') && k !== 'paris_lang' && k !== 'paris_lang_chosen' && k !== 'paris_settings');
    keys.forEach(k => localStorage.removeItem(k));
    setCacheCleared(true);
    setDialog(null);
    showToast(t(tr.storage.cleared));
  };

  const handleResetOnboarding = () => {
    localStorage.removeItem('paris_profile');
    localStorage.removeItem('paris_timeline');
    setDialog(null);
    router.push('/onboarding');
  };

  const handleDeleteAccount = () => {
    Object.keys(localStorage).filter(k => k.startsWith('paris_')).forEach(k => localStorage.removeItem(k));
    setDialog(null);
    router.push('/');
  };

  const cacheSize = typeof window !== 'undefined'
    ? `${(Object.keys(localStorage).filter(k => k.startsWith('paris_')).reduce((a, k) => a + (localStorage.getItem(k)?.length ?? 0), 0) / 1024).toFixed(1)} KB`
    : '—';

  const profile = typeof window !== 'undefined' ? (() => { try { return JSON.parse(localStorage.getItem('paris_profile') || '{}'); } catch { return {}; } })() : {};

  return (
    <div style={{
      minHeight: '100vh', padding: '2rem 1.25rem 6rem',
      maxWidth: 640, margin: '0 auto',
      fontSize: 'var(--app-font-size, 15px)',
    }}>
      {/* Header */}
      <div style={{ marginBottom: '2rem' }}>
        <h1 style={{
          fontFamily: 'Playfair Display, serif',
          fontSize: 'clamp(1.6rem,3vw,2rem)',
          fontWeight: 700, color: '#fff', marginBottom: 4,
        }}>
          ⚙️ {t(tr.title)}
        </h1>
        <p style={{ color: '#8E8E93', fontSize: 13 }}>{t(tr.subtitle)}</p>
      </div>

      <div style={{ display: 'flex', flexDirection: 'column', gap: '1.75rem' }}>

        {/* ── Language ── */}
        <section>
          <SectionHeader icon={<Globe style={{ width: 14, height: 14 }} />} label={t(tr.sections.language)} />
          <Card>
            <div style={{ padding: '14px 16px 10px' }}>
              <div style={{ fontWeight: 600, color: '#e5e7eb', fontSize: 13, marginBottom: 4 }}>{t(tr.language.label)}</div>
              <div style={{ fontSize: 11, color: '#8E8E93', marginBottom: 14 }}>{t(tr.language.desc)}</div>
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 8 }}>
                {LANGUAGES.map(l => (
                  <motion.button key={l.code} whileTap={{ scale: 0.95 }}
                    onClick={() => { setLang(l.code); showToast(t(tr.saved)); }}
                    style={{
                      padding: '10px 6px', borderRadius: 12, cursor: 'pointer', textAlign: 'center',
                      background: lang === l.code ? 'rgba(0,38,84,0.25)' : 'rgba(255,255,255,0.04)',
                      border: `1.5px solid ${lang === l.code ? '#3a7bd5' : 'rgba(255,255,255,0.08)'}`,
                      position: 'relative', transition: 'all 0.15s',
                    }}>
                    {lang === l.code && (
                      <div style={{ position: 'absolute', top: 6, right: 6 }}>
                        <CheckCircle2 style={{ width: 11, height: 11, color: '#3a7bd5' }} />
                      </div>
                    )}
                    <div style={{ fontSize: 22 }}>{l.flag}</div>
                    <div style={{ fontSize: 11, fontWeight: 700, color: lang === l.code ? '#fff' : '#9ca3af', marginTop: 3 }}>{l.native}</div>
                  </motion.button>
                ))}
              </div>
            </div>
          </Card>
        </section>

        {/* ── Appearance ── */}
        <section>
          <SectionHeader icon={<Sun style={{ width: 14, height: 14 }} />} label={t(tr.sections.appearance)} />
          <Card>
            <div style={{ padding: '14px 16px', borderBottom: '1px solid rgba(255,255,255,0.05)' }}>
              <div style={{ fontWeight: 600, color: '#e5e7eb', fontSize: 13, marginBottom: 4 }}>{t(tr.appearance.theme)}</div>
              <div style={{ fontSize: 11, color: '#8E8E93', marginBottom: 12 }}>{t(tr.appearance.desc)}</div>
              <SegmentControl<Theme>
                value={settings.theme}
                onChange={v => { updateSetting('theme', v); showToast(t(tr.saved)); }}
                options={[
                  { value: 'dark',   label: t(tr.appearance.dark),   icon: <Moon   style={{ width: 12, height: 12 }} /> },
                  { value: 'light',  label: t(tr.appearance.light),  icon: <Sun    style={{ width: 12, height: 12 }} /> },
                  { value: 'system', label: t(tr.appearance.system), icon: <Monitor style={{ width: 12, height: 12 }} /> },
                ]}
              />
            </div>
          </Card>
        </section>

        {/* ── Notifications ── */}
        <section>
          <SectionHeader icon={<Bell style={{ width: 14, height: 14 }} />} label={t(tr.sections.notifications)} />
          <Card>
            <Row
              icon={settings.notificationsEnabled ? <Bell style={{ width: 16, height: 16 }} /> : <BellOff style={{ width: 16, height: 16 }} />}
              label={t(tr.notifications.enable)}
              right={<Toggle value={settings.notificationsEnabled} onChange={v => { updateSetting('notificationsEnabled', v); showToast(t(tr.saved)); }} />}
            />
            {settings.notificationsEnabled && (
              <>
                <Row icon={<FileText style={{ width: 16, height: 16 }} />}   label={t(tr.notifications.admin)}     right={<Toggle value={settings.notifAdmin}     onChange={v => updateSetting('notifAdmin', v)}     />} />
                <Row icon={<Zap       style={{ width: 16, height: 16 }} />}  label={t(tr.notifications.tips)}      right={<Toggle value={settings.notifTips}      onChange={v => updateSetting('notifTips', v)}      />} />
                <Row icon={<Globe     style={{ width: 16, height: 16 }} />}  label={t(tr.notifications.transport)} right={<Toggle value={settings.notifTransport} onChange={v => updateSetting('notifTransport', v)} />} />
                <Row icon={<CheckCircle2 style={{ width: 16, height: 16 }} />} label={t(tr.notifications.quest)}   right={<Toggle value={settings.notifQuest}     onChange={v => updateSetting('notifQuest', v)}     />} last />
              </>
            )}
          </Card>
        </section>

        {/* ── Privacy ── */}
        <section>
          <SectionHeader icon={<Shield style={{ width: 14, height: 14 }} />} label={t(tr.sections.privacy)} />
          <Card>
            <Row
              icon={<Eye style={{ width: 16, height: 16 }} />}
              label={t(tr.privacy.analytics)}
              desc={t(tr.privacy.analyticsD)}
              right={<Toggle value={settings.analyticsEnabled} onChange={v => { updateSetting('analyticsEnabled', v); showToast(t(tr.saved)); }} />}
            />
            <Row
              icon={<Globe style={{ width: 16, height: 16 }} />}
              label={t(tr.privacy.location)}
              desc={t(tr.privacy.locationD)}
              right={<Toggle value={settings.locationEnabled} onChange={v => { updateSetting('locationEnabled', v); showToast(t(tr.saved)); }} />}
            />
            <Row
              icon={<Download style={{ width: 16, height: 16 }} />}
              label={t(tr.privacy.dataExport)}
              onClick={() => {
                const data = { profile, settings, lang };
                const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
                const a = document.createElement('a'); a.href = URL.createObjectURL(blob);
                a.download = 'paris-guide-data.json'; a.click();
                showToast(t(tr.common.export));
              }}
              last
            />
          </Card>
        </section>

        {/* ── Accessibility ── */}
        <section>
          <SectionHeader icon={<Type style={{ width: 14, height: 14 }} />} label={t(tr.sections.accessibility)} />
          <Card>
            <div style={{ padding: '14px 16px', borderBottom: '1px solid rgba(255,255,255,0.05)' }}>
              <div style={{ fontWeight: 600, color: '#e5e7eb', fontSize: 13, marginBottom: 12 }}>{t(tr.accessibility.textSize)}</div>
              <SegmentControl<TextSize>
                value={settings.textSize}
                onChange={v => { updateSetting('textSize', v); showToast(t(tr.saved)); }}
                options={[
                  { value: 'small',  label: t(tr.accessibility.small)  },
                  { value: 'medium', label: t(tr.accessibility.medium) },
                  { value: 'large',  label: t(tr.accessibility.large)  },
                ]}
              />
            </div>
            <Row
              icon={<Contrast style={{ width: 16, height: 16 }} />}
              label={t(tr.accessibility.contrast)}
              desc={t(tr.accessibility.contrastD)}
              right={<Toggle value={settings.highContrast} onChange={v => { updateSetting('highContrast', v); showToast(t(tr.saved)); }} />}
            />
            <Row
              icon={<Zap style={{ width: 16, height: 16 }} />}
              label={t(tr.accessibility.reduceMotion)}
              desc={t(tr.accessibility.reduceMotionD)}
              right={<Toggle value={settings.reduceMotion} onChange={v => { updateSetting('reduceMotion', v); showToast(t(tr.saved)); }} />}
              last
            />
          </Card>
        </section>

        {/* ── Account ── */}
        <section>
          <SectionHeader icon={<User style={{ width: 14, height: 14 }} />} label={t(tr.sections.account)} />
          <Card>
            <Row
              icon={<User style={{ width: 16, height: 16 }} />}
              label={t(tr.account.editProfile)}
              desc={profile.name ? `${profile.name} · ${profile.profile_type ?? ''}` : undefined}
              onClick={() => router.push('/onboarding')}
            />
            <Row
              icon={<RotateCcw style={{ width: 16, height: 16 }} />}
              label={t(tr.account.resetProfile)}
              desc={t(tr.account.resetDesc)}
              onClick={() => setDialog('resetOnboarding')}
            />
            <Row
              icon={<Trash2 style={{ width: 16, height: 16 }} />}
              label={t(tr.account.deleteAccount)}
              desc={t(tr.account.deleteDesc)}
              onClick={() => setDialog('deleteAccount')}
              danger
              last
            />
          </Card>
        </section>

        {/* ── Cache & Storage ── */}
        <section>
          <SectionHeader icon={<HardDrive style={{ width: 14, height: 14 }} />} label={t(tr.sections.storage)} />
          <Card>
            <Row
              icon={<HardDrive style={{ width: 16, height: 16 }} />}
              label={t(tr.storage.cacheSize)}
              right={<span style={{ fontSize: 12, color: '#8E8E93', fontWeight: 600 }}>{cacheCleared ? '0 KB' : cacheSize}</span>}
            />
            <Row
              icon={<Trash2 style={{ width: 16, height: 16 }} />}
              label={t(tr.storage.clearCache)}
              onClick={() => setDialog('clearCache')}
            />
            <Row
              icon={settings.offlineMode ? <WifiOff style={{ width: 16, height: 16 }} /> : <Wifi style={{ width: 16, height: 16 }} />}
              label={t(tr.storage.offlineMode)}
              desc={t(tr.storage.offlineDesc)}
              right={<Toggle value={settings.offlineMode} onChange={v => { updateSetting('offlineMode', v); showToast(t(tr.saved)); }} />}
              last
            />
          </Card>
        </section>

        {/* ── Help & Support ── */}
        <section>
          <SectionHeader icon={<HelpCircle style={{ width: 14, height: 14 }} />} label={t(tr.sections.help)} />
          <Card>
            <Row icon={<HelpCircle    style={{ width: 16, height: 16 }} />} label={t(tr.help.faq)}      desc={t(tr.help.faqDesc)}      onClick={() => {}} />
            <Row icon={<MessageSquare style={{ width: 16, height: 16 }} />} label={t(tr.help.feedback)} desc={t(tr.help.feedbackDesc)} onClick={() => router.push('/chat')} />
            <Row icon={<Lock          style={{ width: 16, height: 16 }} />} label={t(tr.help.privacy)}  onClick={() => {}} />
            <Row icon={<FileText      style={{ width: 16, height: 16 }} />} label={t(tr.help.terms)}    onClick={() => {}} last />
          </Card>
          <div style={{ textAlign: 'center', marginTop: '1rem', fontSize: 11, color: '#3A3A3C' }}>
            ParisEasyGuide+ · {t(tr.help.version)} 1.0.0 · 🔒 GDPR
          </div>
        </section>

      </div>

      {/* Dialogs */}
      <AnimatePresence>
        {dialog === 'clearCache' && (
          <ConfirmDialog
            title={t(tr.storage.clearCache)}
            desc="This will remove cached data. Your profile and settings will be kept."
            confirmLabel={t(tr.common.confirm)}
            onConfirm={handleClearCache}
            onCancel={() => setDialog(null)}
          />
        )}
        {dialog === 'resetOnboarding' && (
          <ConfirmDialog
            title={t(tr.account.resetProfile)}
            desc={t(tr.account.resetDesc)}
            confirmLabel={t(tr.common.confirm)}
            onConfirm={handleResetOnboarding}
            onCancel={() => setDialog(null)}
          />
        )}
        {dialog === 'deleteAccount' && (
          <ConfirmDialog
            title={t(tr.account.deleteAccount)}
            desc={t(tr.account.deleteDesc) + ' This cannot be undone.'}
            confirmLabel={t(tr.common.delete)}
            danger
            onConfirm={handleDeleteAccount}
            onCancel={() => setDialog(null)}
          />
        )}
        {toast && <Toast msg={toast} onDone={() => setToast(null)} />}
      </AnimatePresence>
    </div>
  );
}
