'use client';
import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Home, Sparkles, Loader2, ExternalLink, AlertTriangle, CheckCircle2, Euro, MapPin } from 'lucide-react';
import { useLanguage, LANGUAGES } from '@/lib/i18n/LanguageContext';
import { toast } from 'sonner';
import { FadeIn, SlideIn } from '@/components/shared/PageMotion';

const ROOM_TYPES = ['Studio (20–30m²)', 'T1 (30–40m²)', 'Colocation (room)', 'CROUS dorm', 'Résidence étudiante'];
const AREAS = ['1–4ème (Center)', '5–6ème (Latin Quarter)', '7–8ème (Prestige)', '9–11ème (Trendy)', '12–14ème (South)', '15–16ème (West)', '17–19ème (North)', '20ème (East)', '92 Hauts-de-Seine', '93 Seine-Saint-Denis', '94 Val-de-Marne'];
const BUDGETS = ['< €600', '€600–800', '€800–1000', '€1000–1300', '€1300+'];

interface HousingPlan {
  budget_analysis: { realistic: boolean; verdict: string; average_rent: string; caf_eligible: boolean; caf_estimate: string };
  best_platforms: { name: string; url: string; best_for: string; tip: string; free: boolean }[];
  neighbourhood_picks: { name: string; avg_rent: string; vibe: string; commute_to_center: string; student_density: string; safety: string; emoji: string }[];
  crous_info: { available: boolean; application_url: string; deadline: string; wait_time: string; tip: string };
  scam_warnings: string[];
  required_documents: string[];
  garant_options: { name: string; cost: string; url: string; best_for: string }[];
  action_plan: { day: string; action: string; url?: string }[];
}

export default function HousingPage() {
  const { lang } = useLanguage();
  const langLabel = LANGUAGES.find(l => l.code === lang)?.label ?? "English";
  const [budget, setBudget] = useState('€600–800');
  const [selectedAreas, setSelectedAreas] = useState<string[]>(['9–11ème (Trendy)', '12–14ème (South)']);
  const [roomType, setRoomType] = useState(ROOM_TYPES[0]);
  const [university, setUniversity] = useState('');
  const [plan, setPlan] = useState<HousingPlan | null>(null);
  const [loading, setLoading] = useState(false);

  const toggleArea = (a: string) => setSelectedAreas(prev => prev.includes(a) ? prev.filter(x => x !== a) : [...prev, a]);

  const search = async () => {
    setLoading(true); setPlan(null);
    try {
      const res = await fetch('/api/housing', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ budget, arrondissements: selectedAreas, roomType, university }),
      });
      const data = await res.json();
      if (data.plan) { setPlan(data.plan); toast.success('Housing guide ready!'); }
      else toast.error('Could not generate guide.');
    } catch { toast.error('Failed to get housing advice.'); }
    finally { setLoading(false); }
  };

  return (
    <div style={{ padding: '2rem 2.5rem', maxWidth: 1100, margin: '0 auto' }}>
      <FadeIn>
        <div style={{ marginBottom: '2rem' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 4 }}>
            <Home style={{ width: 16, height: 16, color: '#FFD700' }} />
            <span style={{ fontSize: 12, fontWeight: 600, color: '#FFD700', textTransform: 'uppercase', letterSpacing: '0.1em' }}>Housing Finder</span>
          </div>
          <h1 style={{ fontFamily: 'Playfair Display, serif', fontSize: '2rem', fontWeight: 700, color: '#fff' }}>Find Your Paris Home</h1>
          <p style={{ color: '#8E8E93', fontSize: 14 }}>AI-powered housing guide — platforms, CAF, guarantors, scam alerts</p>
        </div>
      </FadeIn>

      {/* Filters */}
      <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }}
        style={{ padding: '1.5rem', borderRadius: 16, background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.08)', marginBottom: '1.5rem' }}>

        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))', gap: '1.25rem', marginBottom: '1.25rem' }}>
          <div>
            <label style={{ fontSize: 11, fontWeight: 700, color: '#8E8E93', textTransform: 'uppercase', letterSpacing: '0.05em', display: 'block', marginBottom: 8 }}>💶 Monthly Budget</label>
            <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}>
              {BUDGETS.map(b => (
                <button key={b} onClick={() => setBudget(b)} style={{ padding: '6px 12px', borderRadius: 20, fontSize: 12, fontWeight: 600, cursor: 'pointer', border: 'none', background: budget === b ? '#059669' : 'rgba(255,255,255,0.06)', color: budget === b ? '#fff' : '#9ca3af' }}>{b}</button>
              ))}
            </div>
          </div>
          <div>
            <label style={{ fontSize: 11, fontWeight: 700, color: '#8E8E93', textTransform: 'uppercase', letterSpacing: '0.05em', display: 'block', marginBottom: 8 }}>🏠 Room Type</label>
            <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}>
              {ROOM_TYPES.map(r => (
                <button key={r} onClick={() => setRoomType(r)} style={{ padding: '6px 12px', borderRadius: 20, fontSize: 11, fontWeight: 600, cursor: 'pointer', border: 'none', background: roomType === r ? '#059669' : 'rgba(255,255,255,0.06)', color: roomType === r ? '#fff' : '#9ca3af' }}>{r}</button>
              ))}
            </div>
          </div>
        </div>

        <div style={{ marginBottom: '1.25rem' }}>
          <label style={{ fontSize: 11, fontWeight: 700, color: '#8E8E93', textTransform: 'uppercase', letterSpacing: '0.05em', display: 'block', marginBottom: 8 }}>📍 Preferred Areas (select multiple)</label>
          <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}>
            {AREAS.map(a => (
              <button key={a} onClick={() => toggleArea(a)} style={{ padding: '6px 12px', borderRadius: 20, fontSize: 11, fontWeight: 600, cursor: 'pointer', border: `1px solid ${selectedAreas.includes(a) ? 'rgba(5,150,105,0.5)' : 'rgba(255,255,255,0.1)'}`, background: selectedAreas.includes(a) ? 'rgba(5,150,105,0.15)' : 'rgba(255,255,255,0.03)', color: selectedAreas.includes(a) ? '#34d399' : '#9ca3af' }}>{a}</button>
            ))}
          </div>
        </div>

        <div style={{ marginBottom: '1.25rem' }}>
          <label style={{ fontSize: 11, fontWeight: 700, color: '#8E8E93', textTransform: 'uppercase', letterSpacing: '0.05em', display: 'block', marginBottom: 8 }}>🎓 University / School (optional)</label>
          <input value={university} onChange={e => setUniversity(e.target.value)} placeholder="e.g. Sciences Po, Université Paris-Saclay, ESCP…"
            style={{ width: '100%', background: 'rgba(255,255,255,0.06)', border: '1px solid rgba(255,255,255,0.1)', borderRadius: 10, padding: '10px 14px', color: '#fff', fontSize: 14, outline: 'none', boxSizing: 'border-box' }} />
        </div>

        <motion.button whileTap={{ scale: 0.97 }} onClick={search} disabled={loading}
          style={{ width: '100%', padding: '13px', borderRadius: 12, background: loading ? 'rgba(5,150,105,0.3)' : 'linear-gradient(135deg,#059669,#047857)', border: 'none', cursor: 'pointer', color: '#fff', fontWeight: 700, fontSize: 14, display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8 }}>
          {loading ? <><Loader2 style={{ width: 16, height: 16, animation: 'spin 1s linear infinite' }} />Finding your options…</> : <><Sparkles style={{ width: 16, height: 16 }} />Find My Paris Home</>}
        </motion.button>
      </motion.div>

      {/* Results */}
      <AnimatePresence>
        {plan && !loading && (
          <motion.div key="results" initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
            {/* Budget verdict */}
            <div style={{ padding: '1.25rem', borderRadius: 14, background: plan.budget_analysis.realistic ? 'rgba(5,150,105,0.08)' : 'rgba(251,191,36,0.08)', border: `1px solid ${plan.budget_analysis.realistic ? 'rgba(5,150,105,0.3)' : 'rgba(251,191,36,0.3)'}`, marginBottom: '1.5rem', display: 'flex', gap: '1rem', alignItems: 'center' }}>
              {plan.budget_analysis.realistic ? <CheckCircle2 style={{ width: 22, height: 22, color: '#34d399', flexShrink: 0 }} /> : <AlertTriangle style={{ width: 22, height: 22, color: '#fbbf24', flexShrink: 0 }} />}
              <div>
                <div style={{ fontWeight: 700, color: '#fff', marginBottom: 2 }}>{plan.budget_analysis.verdict}</div>
                <div style={{ fontSize: 12, color: '#8E8E93' }}>Average: {plan.budget_analysis.average_rent} · {plan.budget_analysis.caf_eligible ? `✅ CAF eligible — save ${plan.budget_analysis.caf_estimate}/month` : '❌ Check CAF eligibility'}</div>
              </div>
            </div>

            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))', gap: '1.25rem' }}>
              {/* Platforms */}
              <div style={{ padding: '1.25rem', borderRadius: 16, background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.08)' }}>
                <h3 style={{ fontWeight: 700, color: '#fff', marginBottom: '1rem', fontSize: 14 }}>🏘 Best Platforms</h3>
                <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
                  {plan.best_platforms?.map((p, i) => (
                    <motion.div key={i} initial={{ opacity: 0, x: -8 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: i * 0.07 }}
                      style={{ padding: '10px 12px', borderRadius: 10, background: 'rgba(255,255,255,0.03)', border: '1px solid rgba(255,255,255,0.07)' }}>
                      <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 3 }}>
                        <div style={{ fontWeight: 700, fontSize: 13, color: '#fff' }}>{p.name} {p.free && <span style={{ fontSize: 10, color: '#34d399', marginLeft: 4 }}>FREE</span>}</div>
                        <a href={p.url} target="_blank" rel="noreferrer" style={{ color: '#60a5fa' }}><ExternalLink style={{ width: 13, height: 13 }} /></a>
                      </div>
                      <div style={{ fontSize: 12, color: '#8E8E93', marginBottom: 3 }}>{p.best_for}</div>
                      <div style={{ fontSize: 11, color: '#fbbf24' }}>💡 {p.tip}</div>
                    </motion.div>
                  ))}
                </div>
              </div>

              {/* Area picks */}
              <div style={{ padding: '1.25rem', borderRadius: 16, background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.08)' }}>
                <h3 style={{ fontWeight: 700, color: '#fff', marginBottom: '1rem', fontSize: 14 }}>📍 Best Areas For You</h3>
                <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
                  {plan.neighbourhood_picks?.map((n, i) => (
                    <div key={i} style={{ padding: '10px 12px', borderRadius: 10, background: 'rgba(255,255,255,0.03)', border: '1px solid rgba(255,255,255,0.07)' }}>
                      <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 2 }}>
                        <div style={{ fontWeight: 700, fontSize: 13, color: '#fff' }}>{n.emoji} {n.name}</div>
                        <div style={{ fontSize: 12, fontWeight: 700, color: '#34d399' }}>{n.avg_rent}</div>
                      </div>
                      <div style={{ fontSize: 12, color: '#8E8E93', marginBottom: 4 }}>{n.vibe}</div>
                      <div style={{ display: 'flex', gap: 8 }}>
                        <span style={{ fontSize: 10, color: '#8E8E93' }}>🚇 {n.commute_to_center}</span>
                        <span style={{ fontSize: 10, color: '#8E8E93' }}>👨‍🎓 {n.student_density} students</span>
                        <span style={{ fontSize: 10, color: '#8E8E93' }}>🛡 {n.safety}</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Scam warnings */}
              {plan.scam_warnings?.length > 0 && (
                <div style={{ padding: '1.25rem', borderRadius: 16, background: 'rgba(239,68,68,0.05)', border: '1px solid rgba(239,68,68,0.2)' }}>
                  <h3 style={{ fontWeight: 700, color: '#fca5a5', marginBottom: '1rem', fontSize: 14, display: 'flex', alignItems: 'center', gap: 6 }}>
                    <AlertTriangle style={{ width: 14, height: 14 }} /> Scam Warnings
                  </h3>
                  {plan.scam_warnings.map((w, i) => (
                    <div key={i} style={{ fontSize: 12, color: '#fca5a5', lineHeight: 1.7, display: 'flex', gap: 8, marginBottom: 6 }}>
                      <span>⚠️</span><span>{w}</span>
                    </div>
                  ))}
                </div>
              )}

              {/* Documents */}
              <div style={{ padding: '1.25rem', borderRadius: 16, background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.08)' }}>
                <h3 style={{ fontWeight: 700, color: '#fff', marginBottom: '1rem', fontSize: 14 }}>📄 Required Documents</h3>
                {plan.required_documents?.map((d, i) => (
                  <div key={i} style={{ fontSize: 12, color: '#8E8E93', lineHeight: 1.7, display: 'flex', gap: 8 }}>
                    <CheckCircle2 style={{ width: 12, height: 12, color: '#059669', flexShrink: 0, marginTop: 2 }} />{d}
                  </div>
                ))}
              </div>

              {/* Garant options */}
              <div style={{ padding: '1.25rem', borderRadius: 16, background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.08)' }}>
                <h3 style={{ fontWeight: 700, color: '#fff', marginBottom: '1rem', fontSize: 14 }}>🤝 Guarantor Options</h3>
                {plan.garant_options?.map((g, i) => (
                  <div key={i} style={{ padding: '10px 12px', borderRadius: 10, background: 'rgba(255,255,255,0.03)', marginBottom: 8 }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 2 }}>
                      <span style={{ fontWeight: 600, fontSize: 13, color: '#fff' }}>{g.name}</span>
                      <span style={{ fontSize: 12, color: '#fbbf24' }}>{g.cost}</span>
                    </div>
                    <div style={{ fontSize: 11, color: '#8E8E93' }}>{g.best_for}</div>
                  </div>
                ))}
              </div>

              {/* Action plan */}
              <div style={{ padding: '1.25rem', borderRadius: 16, background: 'rgba(0,38,84,0.08)', border: '1px solid rgba(0,38,84,0.25)' }}>
                <h3 style={{ fontWeight: 700, color: '#fff', marginBottom: '1rem', fontSize: 14 }}>🗺 Action Plan</h3>
                {plan.action_plan?.map((step, i) => (
                  <div key={i} style={{ display: 'flex', gap: 10, marginBottom: 10 }}>
                    <div style={{ fontSize: 10, fontWeight: 700, color: '#60a5fa', flexShrink: 0, paddingTop: 2, minWidth: 38 }}>{step.day}</div>
                    <div style={{ flex: 1 }}>
                      <div style={{ fontSize: 12, color: '#e5e7eb', lineHeight: 1.6 }}>{step.action}</div>
                      {step.url && <a href={step.url} target="_blank" rel="noreferrer" style={{ fontSize: 11, color: '#60a5fa', textDecoration: 'none' }}>Open →</a>}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
      <style>{`@keyframes spin { from { transform:rotate(0deg) } to { transform:rotate(360deg) } }`}</style>
    </div>
  );
}
