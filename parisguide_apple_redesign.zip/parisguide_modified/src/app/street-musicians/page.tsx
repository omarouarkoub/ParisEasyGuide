'use client';
import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Music, Plus, MapPin, Star, Trash2, X } from 'lucide-react';
import { FadeIn } from '@/components/shared/PageMotion';
import { fireBadgeToast } from '@/components/quest/BadgeUnlockToast';

const GOLD = '#FFD700';
const RED = '#ED2939';

const METRO_LINES = ['1','2','3','3b','4','5','6','7','7b','8','9','10','11','12','13','14', 'RER A','RER B','RER C', 'Street'];
const GENRES = ['Jazz','Classical','Accordion','Guitar','Violin','Flute','Drum/Percussion','Electronic','World Music','Opera','Pop/Rock','Latin','Gypsy Jazz','Folk','Other'];

const METRO_COLORS: Record<string, string> = {
  '1':'#FFCC00','2':'#003399','3':'#9F9825','3b':'#98D4E2','4':'#CC0088','5':'#FF7E2E',
  '6':'#75C695','7':'#F2A4B7','7b':'#83C491','8':'#CEADD2','9':'#D5C900','10':'#E3B32A',
  '11':'#8D5E2A','12':'#00814F','13':'#98D4E2','14':'#662D91',
  'RER A':'#E2231A','RER B':'#5191CE','RER C':'#FFCC00','Street':'#9ca3af',
};

const KNOWN_SPOTS = [
  { station: 'Châtelet', line: '1', note: 'Largest intersection hub — rotating classical ensembles' },
  { station: 'Montparnasse–Bienvenüe', line: '6', note: 'Legendary accordion players on the mezzanine' },
  { station: 'Saint-Germain-des-Prés', line: '4', note: 'Jazz guitarists weekday evenings' },
  { station: 'Abbesses', line: '12', note: 'Montmartre charm — folk, chanson française' },
  { station: 'Bastille', line: '1', note: 'Platform end has great acoustics for violin' },
  { station: 'Nation', line: '1', note: 'Gypsy jazz duo on the RER platform weekend mornings' },
  { station: 'Pont de l\'Alma', line: 'RER C', note: 'Cellist on the Seine-side exit Sunday afternoons' },
  { station: 'Rue de Rivoli', line: 'Street', note: 'Under the arcades — accordion most evenings' },
];

interface BuskerLog {
  id: string;
  date: string;
  station: string;
  line: string;
  genre: string;
  instrument: string;
  rating: number;
  notes: string;
  memorable: boolean;
}

function StarPicker({ value, onChange }: { value: number; onChange: (v: number) => void }) {
  return (
    <div style={{ display: 'flex', gap: 4 }}>
      {[1,2,3,4,5].map(n => (
        <button key={n} onClick={() => onChange(n)} style={{ background: 'none', border: 'none', cursor: 'pointer', fontSize: 22, color: n <= value ? GOLD : 'rgba(255,255,255,0.2)', padding: 2, transition: 'color 0.1s' }}>★</button>
      ))}
    </div>
  );
}

export default function StreetMusiciansPage() {
  const [logs, setLogs] = useState<BuskerLog[]>([]);
  const [showAdd, setShowAdd] = useState(false);
  const [activeTab, setActiveTab] = useState<'log' | 'heatmap' | 'hotspots'>('log');

  // Form state
  const [form, setForm] = useState({ station: '', line: '1', genre: 'Jazz', instrument: '', rating: 4, notes: '', memorable: false });

  useEffect(() => {
    const saved = localStorage.getItem('busker_logs');
    if (saved) setLogs(JSON.parse(saved));
  }, []);

  const saveLogs = (next: BuskerLog[]) => {
    setLogs(next);
    localStorage.setItem('busker_logs', JSON.stringify(next));
  };

  const addLog = () => {
    if (!form.station.trim()) return;
    const log: BuskerLog = {
      id: Date.now().toString(),
      date: new Date().toISOString().split('T')[0],
      station: form.station,
      line: form.line,
      genre: form.genre,
      instrument: form.instrument,
      rating: form.rating,
      notes: form.notes,
      memorable: form.memorable,
    };
    const next = [log, ...logs];
    saveLogs(next);
    setShowAdd(false);
    setForm({ station: '', line: '1', genre: 'Jazz', instrument: '', rating: 4, notes: '', memorable: false });

    if (next.length === 1) {
      fireBadgeToast({ id: 'busker_1', emoji: '🎵', name: 'First Busker Logged', description: 'You started your musical map of Paris!', rarity: 'common', xp: 50 });
    } else if (next.length === 10) {
      fireBadgeToast({ id: 'busker_10', emoji: '🎼', name: 'Musico-Cartographer', description: '10 buskers logged — you\'re an expert!', rarity: 'rare', xp: 150 });
    }
  };

  const deleteLog = (id: string) => saveLogs(logs.filter(l => l.id !== id));
  const toggleMemorable = (id: string) => saveLogs(logs.map(l => l.id === id ? { ...l, memorable: !l.memorable } : l));

  // Heatmap by metro line
  const lineCounts = logs.reduce((acc: Record<string, number>, l) => {
    acc[l.line] = (acc[l.line] || 0) + 1;
    return acc;
  }, {});
  const maxCount = Math.max(...Object.values(lineCounts), 1);

  // Genre distribution
  const genreCounts = logs.reduce((acc: Record<string, number>, l) => {
    acc[l.genre] = (acc[l.genre] || 0) + 1;
    return acc;
  }, {});
  const topGenres = Object.entries(genreCounts).sort((a,b) => b[1]-a[1]).slice(0,5);

  const avgRating = logs.length ? (logs.reduce((a,l) => a+l.rating, 0)/logs.length).toFixed(1) : '–';

  return (
    <div style={{ padding: '2rem 2.5rem', maxWidth: 1100, margin: '0 auto' }}>
      <FadeIn>
        {/* Header */}
        <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', marginBottom: '1.5rem' }}>
          <div>
            <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 4 }}>
              <Music style={{ width: 16, height: 16, color: GOLD }} />
              <span style={{ fontSize: 12, fontWeight: 600, color: GOLD, textTransform: 'uppercase', letterSpacing: '0.1em' }}>Metro & Street Music</span>
            </div>
            <h1 style={{ fontFamily: 'Playfair Display, serif', fontSize: '2rem', fontWeight: 700, color: '#fff', marginBottom: 6 }}>Street Musician Logbook</h1>
            <p style={{ color: '#8E8E93', fontSize: 14 }}>Log the buskers you encounter, rate them, and build a personal heatmap of Paris's musical hotspots.</p>
          </div>
          <button onClick={() => setShowAdd(true)}
            style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '10px 18px', borderRadius: 12, background: 'rgba(255,215,0,0.9)', color: '#000', fontWeight: 700, fontSize: 13, border: 'none', cursor: 'pointer' }}>
            <Plus style={{ width: 16, height: 16 }} /> Log Busker
          </button>
        </div>

        {/* Stats row */}
        <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }}
          style={{ display: 'grid', gridTemplateColumns: 'repeat(4,1fr)', gap: '1rem', marginBottom: '1.5rem' }}>
          {[
            { label: 'Total Logged', value: logs.length, emoji: '🎵' },
            { label: 'Memorable', value: logs.filter(l=>l.memorable).length, emoji: '⭐' },
            { label: 'Lines Covered', value: Object.keys(lineCounts).length, emoji: '🗺️' },
            { label: 'Avg Rating', value: avgRating, emoji: '🏆' },
          ].map(s => (
            <div key={s.label} style={{ padding: '1rem', borderRadius: 12, background: 'rgba(255,255,255,0.03)', border: '1px solid rgba(255,255,255,0.08)', textAlign: 'center' }}>
              <div style={{ fontSize: 20 }}>{s.emoji}</div>
              <div style={{ fontSize: '1.5rem', fontWeight: 800, color: GOLD, fontFamily: 'Playfair Display, serif' }}>{s.value}</div>
              <div style={{ fontSize: 10, color: '#8E8E93' }}>{s.label}</div>
            </div>
          ))}
        </motion.div>

        {/* Tabs */}
        <div style={{ display: 'flex', gap: 4, marginBottom: '1.5rem', borderBottom: '1px solid rgba(255,255,255,0.08)', paddingBottom: '1rem' }}>
          {(['log', 'heatmap', 'hotspots'] as const).map(tab => (
            <button key={tab} onClick={() => setActiveTab(tab)}
              style={{ padding: '8px 20px', borderRadius: 10, border: 'none', background: activeTab === tab ? 'rgba(255,215,0,0.15)' : 'transparent', color: activeTab === tab ? GOLD : '#6b7280', fontWeight: 700, fontSize: 13, cursor: 'pointer', textTransform: 'capitalize' }}>
              {tab === 'log' ? '📖 My Log' : tab === 'heatmap' ? '🗺️ Heatmap' : '📍 Hotspots'}
            </button>
          ))}
        </div>

        {/* Log tab */}
        {activeTab === 'log' && (
          <div>
            {logs.length === 0 ? (
              <div style={{ textAlign: 'center', padding: '4rem 2rem', color: '#8E8E93' }}>
                <div style={{ fontSize: 48, marginBottom: 12 }}>🎷</div>
                <div style={{ fontSize: 16, fontWeight: 700, color: '#8E8E93', marginBottom: 6 }}>No buskers logged yet</div>
                <div style={{ fontSize: 13, marginBottom: 20 }}>Next time you hear music in the metro, tap "Log Busker"</div>
                <button onClick={() => setShowAdd(true)} style={{ padding: '10px 24px', borderRadius: 12, background: 'rgba(255,215,0,0.2)', border: `1px solid ${GOLD}`, color: GOLD, fontWeight: 700, cursor: 'pointer' }}>Log Your First Busker</button>
              </div>
            ) : (
              <div style={{ display: 'flex', flexDirection: 'column', gap: '0.75rem' }}>
                {logs.map((log, i) => (
                  <motion.div key={log.id} initial={{ opacity: 0, x: -10 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: i * 0.04 }}
                    style={{ padding: '1rem 1.25rem', borderRadius: 12, background: log.memorable ? 'rgba(255,215,0,0.06)' : 'rgba(255,255,255,0.03)', border: `1px solid ${log.memorable ? 'rgba(255,215,0,0.3)' : 'rgba(255,255,255,0.07)'}`, display: 'grid', gridTemplateColumns: '1fr auto', gap: '1rem', alignItems: 'center' }}>
                    <div>
                      <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 4 }}>
                        <div style={{ width: 24, height: 24, borderRadius: 6, background: METRO_COLORS[log.line] || '#9ca3af', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 10, fontWeight: 800, color: '#000', flexShrink: 0 }}>{log.line}</div>
                        <span style={{ fontWeight: 700, color: '#fff', fontSize: 14 }}>{log.station}</span>
                        <span style={{ fontSize: 11, color: '#8E8E93' }}>· {log.genre} · {log.instrument || 'Unknown instrument'}</span>
                      </div>
                      <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                        <div style={{ display: 'flex', gap: 2 }}>{[1,2,3,4,5].map(n => <span key={n} style={{ color: n <= log.rating ? GOLD : 'rgba(255,255,255,0.15)', fontSize: 13 }}>★</span>)}</div>
                        <span style={{ fontSize: 11, color: '#8E8E93' }}>{log.date}</span>
                        {log.notes && <span style={{ fontSize: 11, color: '#8E8E93', fontStyle: 'italic' }}>"{log.notes}"</span>}
                      </div>
                    </div>
                    <div style={{ display: 'flex', gap: 8 }}>
                      <button onClick={() => toggleMemorable(log.id)}
                        style={{ padding: '6px 10px', borderRadius: 8, border: `1px solid ${log.memorable ? GOLD : 'rgba(255,255,255,0.1)'}`, background: log.memorable ? 'rgba(255,215,0,0.15)' : 'transparent', color: log.memorable ? GOLD : '#6b7280', fontSize: 14, cursor: 'pointer' }}>
                        ⭐
                      </button>
                      <button onClick={() => deleteLog(log.id)}
                        style={{ padding: '6px 10px', borderRadius: 8, border: '1px solid rgba(238,36,54,0.2)', background: 'transparent', color: '#f87171', fontSize: 12, cursor: 'pointer' }}>
                        <Trash2 style={{ width: 13, height: 13 }} />
                      </button>
                    </div>
                  </motion.div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* Heatmap tab */}
        {activeTab === 'heatmap' && (
          <div>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1.5rem' }}>
              <div style={{ padding: '1.5rem', borderRadius: 14, background: 'rgba(255,255,255,0.03)', border: '1px solid rgba(255,255,255,0.08)' }}>
                <div style={{ fontSize: 13, fontWeight: 700, color: '#8E8E93', marginBottom: '1rem' }}>🗺️ Buskers by Metro Line</div>
                {logs.length === 0 ? <div style={{ fontSize: 12, color: '#8E8E93' }}>Log buskers to build your heatmap</div> : (
                  <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
                    {Object.entries(lineCounts).sort((a,b) => b[1]-a[1]).map(([line, count]) => (
                      <div key={line} style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                        <div style={{ width: 28, height: 28, borderRadius: 8, background: METRO_COLORS[line] || '#9ca3af', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 11, fontWeight: 800, color: '#000', flexShrink: 0 }}>{line}</div>
                        <div style={{ flex: 1 }}>
                          <div style={{ height: 8, borderRadius: 4, background: 'rgba(255,255,255,0.07)', overflow: 'hidden' }}>
                            <motion.div initial={{ width: 0 }} animate={{ width: `${(count/maxCount)*100}%` }} transition={{ duration: 0.8, ease: 'easeOut' }}
                              style={{ height: '100%', borderRadius: 4, background: METRO_COLORS[line] || '#9ca3af' }} />
                          </div>
                        </div>
                        <span style={{ fontSize: 12, fontWeight: 700, color: '#8E8E93', minWidth: 24 }}>{count}</span>
                      </div>
                    ))}
                  </div>
                )}
              </div>
              <div style={{ padding: '1.5rem', borderRadius: 14, background: 'rgba(255,255,255,0.03)', border: '1px solid rgba(255,255,255,0.08)' }}>
                <div style={{ fontSize: 13, fontWeight: 700, color: '#8E8E93', marginBottom: '1rem' }}>🎸 Top Genres Heard</div>
                {topGenres.length === 0 ? <div style={{ fontSize: 12, color: '#8E8E93' }}>Log buskers to see genre trends</div> : (
                  <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
                    {topGenres.map(([genre, count]) => (
                      <div key={genre} style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                        <div style={{ fontSize: 12, color: '#8E8E93', minWidth: 100 }}>{genre}</div>
                        <div style={{ flex: 1 }}>
                          <div style={{ height: 8, borderRadius: 4, background: 'rgba(255,255,255,0.07)', overflow: 'hidden' }}>
                            <motion.div initial={{ width: 0 }} animate={{ width: `${(count/logs.length)*100}%` }} transition={{ duration: 0.8 }}
                              style={{ height: '100%', borderRadius: 4, background: 'linear-gradient(90deg,#FFD700,#ED2939)' }} />
                          </div>
                        </div>
                        <span style={{ fontSize: 12, fontWeight: 700, color: '#8E8E93', minWidth: 24 }}>{count}</span>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          </div>
        )}

        {/* Hotspots tab */}
        {activeTab === 'hotspots' && (
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill,minmax(280px,1fr))', gap: '1rem' }}>
            {KNOWN_SPOTS.map((spot, i) => (
              <motion.div key={spot.station} initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.05 }}
                style={{ padding: '1.25rem', borderRadius: 12, background: 'rgba(255,255,255,0.03)', border: '1px solid rgba(255,255,255,0.08)' }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 8 }}>
                  <div style={{ width: 28, height: 28, borderRadius: 8, background: METRO_COLORS[spot.line] || '#9ca3af', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 11, fontWeight: 800, color: '#000', flexShrink: 0 }}>{spot.line}</div>
                  <div style={{ fontWeight: 700, color: '#fff', fontSize: 14 }}>{spot.station}</div>
                </div>
                <div style={{ fontSize: 12, color: '#8E8E93', lineHeight: 1.5 }}>{spot.note}</div>
                <button onClick={() => { setForm(f => ({...f, station: spot.station, line: spot.line})); setShowAdd(true); }}
                  style={{ marginTop: 10, padding: '5px 12px', borderRadius: 8, border: `1px solid rgba(255,215,0,0.3)`, background: 'rgba(255,215,0,0.08)', color: GOLD, fontSize: 11, fontWeight: 700, cursor: 'pointer' }}>
                  + Log Here
                </button>
              </motion.div>
            ))}
          </div>
        )}

        {/* Add busker modal */}
        <AnimatePresence>
          {showAdd && (
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
              onClick={() => setShowAdd(false)}
              style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.7)', zIndex: 1000, display: 'flex', alignItems: 'center', justifyContent: 'center', padding: '2rem' }}>
              <motion.div initial={{ scale: 0.9, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} exit={{ scale: 0.9, opacity: 0 }}
                onClick={e => e.stopPropagation()}
                style={{ background: '#111827', border: '1px solid rgba(255,215,0,0.3)', borderRadius: 16, padding: '2rem', maxWidth: 480, width: '100%' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1.5rem' }}>
                  <h3 style={{ fontFamily: 'Playfair Display, serif', color: '#fff', fontSize: '1.25rem', margin: 0 }}>Log a Busker</h3>
                  <button onClick={() => setShowAdd(false)} style={{ background: 'none', border: 'none', color: '#8E8E93', cursor: 'pointer' }}><X /></button>
                </div>
                <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
                  {[
                    { label: 'Station / Location', key: 'station', placeholder: 'e.g. Châtelet, Rue de Rivoli…' },
                    { label: 'Instrument', key: 'instrument', placeholder: 'e.g. Violin, Accordion, Guitar…' },
                    { label: 'Notes', key: 'notes', placeholder: 'What made them special? Song played?' },
                  ].map(f => (
                    <div key={f.key}>
                      <label style={{ display: 'block', fontSize: 11, fontWeight: 700, color: '#8E8E93', marginBottom: 5, textTransform: 'uppercase', letterSpacing: '0.07em' }}>{f.label}</label>
                      <input value={(form as any)[f.key]} onChange={e => setForm(ff => ({...ff, [f.key]: e.target.value}))}
                        placeholder={f.placeholder}
                        style={{ width: '100%', padding: '9px 12px', borderRadius: 8, border: '1px solid rgba(255,255,255,0.12)', background: 'rgba(255,255,255,0.05)', color: '#fff', fontSize: 13, outline: 'none', boxSizing: 'border-box' }} />
                    </div>
                  ))}
                  <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem' }}>
                    <div>
                      <label style={{ display: 'block', fontSize: 11, fontWeight: 700, color: '#8E8E93', marginBottom: 5, textTransform: 'uppercase', letterSpacing: '0.07em' }}>Metro Line</label>
                      <select value={form.line} onChange={e => setForm(f => ({...f, line: e.target.value}))}
                        style={{ width: '100%', padding: '9px 12px', borderRadius: 8, border: '1px solid rgba(255,255,255,0.12)', background: '#1f2937', color: '#fff', fontSize: 13, outline: 'none' }}>
                        {METRO_LINES.map(l => <option key={l} value={l}>{l}</option>)}
                      </select>
                    </div>
                    <div>
                      <label style={{ display: 'block', fontSize: 11, fontWeight: 700, color: '#8E8E93', marginBottom: 5, textTransform: 'uppercase', letterSpacing: '0.07em' }}>Genre</label>
                      <select value={form.genre} onChange={e => setForm(f => ({...f, genre: e.target.value}))}
                        style={{ width: '100%', padding: '9px 12px', borderRadius: 8, border: '1px solid rgba(255,255,255,0.12)', background: '#1f2937', color: '#fff', fontSize: 13, outline: 'none' }}>
                        {GENRES.map(g => <option key={g} value={g}>{g}</option>)}
                      </select>
                    </div>
                  </div>
                  <div>
                    <label style={{ display: 'block', fontSize: 11, fontWeight: 700, color: '#8E8E93', marginBottom: 5, textTransform: 'uppercase', letterSpacing: '0.07em' }}>Rating</label>
                    <StarPicker value={form.rating} onChange={v => setForm(f => ({...f, rating: v}))} />
                  </div>
                  <label style={{ display: 'flex', alignItems: 'center', gap: 10, cursor: 'pointer' }}>
                    <input type="checkbox" checked={form.memorable} onChange={e => setForm(f => ({...f, memorable: e.target.checked}))} style={{ width: 16, height: 16 }} />
                    <span style={{ fontSize: 13, color: '#d1d5db' }}>⭐ Memorable — worth going back for</span>
                  </label>
                  <button onClick={addLog}
                    style={{ padding: '12px', borderRadius: 10, background: 'rgba(255,215,0,0.9)', color: '#000', fontWeight: 700, fontSize: 14, border: 'none', cursor: 'pointer' }}>
                    Save to Logbook
                  </button>
                </div>
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>
      </FadeIn>
    </div>
  );
}
