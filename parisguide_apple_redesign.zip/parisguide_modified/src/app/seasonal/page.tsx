'use client';
import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Sun, Loader2 } from 'lucide-react';
import { useLanguage, LANGUAGES } from '@/lib/i18n/LanguageContext';
import { toast } from 'sonner';
import { FadeIn } from '@/components/shared/PageMotion';

const SEASONS = [
  {
    season: 'Spring 🌸', months: 'March – May', temp: '8–20°C', color: '#34d399',
    pack: ['Light layers — weather changes daily', 'A waterproof jacket (April showers are real)', 'Comfortable walking shoes', 'Sunglasses (the light returns beautifully)'],
    events: ['Salon du Livre (March)', 'Nuit Européenne des Musées (May)', 'French Open / Roland Garros (May–June)', 'Gardens in bloom — Monet\'s Giverny worth a day trip'],
    tips: 'Perfect time to explore — fewer tourists, moderate prices, beautiful gardens.',
  },
  {
    season: 'Summer ☀️', months: 'June – August', temp: '18–35°C', color: '#fbbf24',
    pack: ['Light linen or cotton clothing', 'Comfortable sandals + sneakers', 'Refillable water bottle (free fountains everywhere)', 'Sun protection — Paris at 48°N still burns'],
    events: ['Fête de la Musique (June 21)', 'Paris Pride / Marche des Fiertés (late June)', 'Bastille Day / Fête Nationale (July 14)', 'Paris Plages (July–August)', 'Cinéma en Plein Air at Villette (July–August)'],
    tips: 'July–August: Parisians leave for holidays. City is quieter but tourist sites are packed. Book museums in advance.',
  },
  {
    season: 'Autumn 🍂', months: 'September – November', temp: '8–20°C', color: '#f97316',
    pack: ['Medium-weight jacket', 'Scarf (essential from October)', 'Waterproof boots', 'Layers for temperature swings'],
    events: ['Nuit Blanche (early October)', 'FIAC / Paris+ Art Fair (October)', 'Salon de l\'Auto (October, even years)', 'Beaujolais Nouveau (3rd Thursday of November)', 'Christmas markets begin (late November)'],
    tips: 'La Rentrée (September) brings energy back to the city. Best season for museums and galleries.',
  },
  {
    season: 'Winter ❄️', months: 'December – February', temp: '0–8°C', color: '#60a5fa',
    pack: ['Heavy coat (wool preferred over puffer for Parisian style)', 'Scarf, hat, gloves', 'Warm waterproof boots', 'Layers: Paris buildings are often overheated inside'],
    events: ['Christmas markets (Champs-Élysées, La Défense)', 'Réveillon / New Year (Dec 31 on Champs-Élysées)', 'Salon de l\'Agriculture (late February)', 'Fashion Week (Paris, January & February)'],
    tips: 'Winter sales (Soldes d\'hiver) begin in January — 20–70% off. Ideal for shopping.',
  },
];

const PUBLIC_HOLIDAYS = [
  { date: 'Jan 1', name: 'New Year\'s Day / Jour de l\'An', emoji: '🎆' },
  { date: 'Variable (April)', name: 'Easter Monday / Lundi de Pâques', emoji: '🐣' },
  { date: 'May 1', name: 'Labour Day / Fête du Travail', emoji: '✊' },
  { date: 'May 8', name: 'Victory in Europe Day / Armistice 1945', emoji: '🕊️' },
  { date: 'Variable (May)', name: 'Ascension Thursday', emoji: '✝️' },
  { date: 'Variable (May/June)', name: 'Whit Monday / Lundi de Pentecôte', emoji: '✝️' },
  { date: 'July 14', name: 'Bastille Day / Fête Nationale', emoji: '🎇' },
  { date: 'Aug 15', name: 'Assumption / Assomption', emoji: '✝️' },
  { date: 'Nov 1', name: 'All Saints\' Day / Toussaint', emoji: '🕯️' },
  { date: 'Nov 11', name: 'Armistice Day / Armistice 1918', emoji: '🌺' },
  { date: 'Dec 25', name: 'Christmas Day / Noël', emoji: '🎄' },
];

const SCHOOL_ZONES = {
  'Zone C (Paris & Île-de-France)': {
    autumn: 'Oct 19 – Nov 3, 2025',
    christmas: 'Dec 20, 2025 – Jan 5, 2026',
    winter: 'Feb 15 – Mar 2, 2026',
    spring: 'Apr 11 – Apr 27, 2026',
    summer: 'Jul 5, 2026',
  }
};

const SAFETY = [
  { area: 'Gare du Nord / Gare de l\'Est', risk: 'Pickpocketing, scams targeting travellers', advice: 'Keep bags in front. Beware "friendship bracelet" forcers and petition signers.' },
  { area: 'Sacré-Cœur / Montmartre steps', risk: 'Bracelet scammers, aggressive vendors', advice: 'Walk past quickly. "Non merci" firmly. Don\'t stop.' },
  { area: 'Champs-Élysées area', risk: 'Pickpockets in crowds, fake petitions', advice: 'Secure your phone. Avoid distraction scams.' },
  { area: 'RER B (CDG line)', risk: 'Phone theft, luggage theft', advice: 'Hold luggage between legs. Keep phone away when seated.' },
  { area: 'Châtelet-Les Halles', risk: 'Pickpocketing in busy corridors', advice: 'Extra vigilance during rush hours. Wear bag on chest.' },
];

export default function SeasonalPage() {
  const { lang } = useLanguage();
  const langLabel = LANGUAGES.find(l => l.code === lang)?.label ?? "English";
  const [activeSeason, setActiveSeason] = useState(0);
  const [activeTab, setActiveTab] = useState<'seasons' | 'holidays' | 'safety' | 'customs'>('seasons');
  const [question, setQuestion] = useState('');
  const [answer, setAnswer] = useState('');
  const [loading, setLoading] = useState(false);

  const ask = async (q?: string) => {
    const query = q || question;
    if (!query.trim()) return;
    setLoading(true); setAnswer('');
    try {
      const res = await fetch('/api/seasonal', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ question: query }) });
      const data = await res.json();
      setAnswer(data.answer || '');
    } catch { toast.error('Connection error'); }
    finally { setLoading(false); }
  };

  const LOCAL_CUSTOMS = [
    { custom: 'Always say Bonjour first', detail: 'Entering a shop, elevator, or doctor\'s office — greet everyone with "Bonjour Madame/Monsieur". Skipping this is considered extremely rude.', emoji: '👋' },
    { custom: 'Dinner starts at 8pm', detail: 'Going to a restaurant at 6pm? You\'ll often find it empty or closed. Most Parisians eat dinner between 7:30–10pm.', emoji: '🍽️' },
    { custom: 'The baguette tradition', detail: 'A "baguette tradition" (not just "baguette") from a boulangerie is made fresh and best eaten within 4 hours. Ask for it "bien cuite" (well-baked) for a crunchier crust.', emoji: '🥖' },
    { custom: 'Dress to go out', detail: 'Parisians dress elegantly even for casual outings. Sportswear outside of the gym or sports context stands out. Smart casual is the daily default.', emoji: '👗' },
    { custom: 'Long lunches', detail: 'The "pause déjeuner" (12–2pm) is sacred. Many businesses reduce service or close. Banks, administrations, and small shops often close between 12–2pm.', emoji: '🕐' },
    { custom: 'Pont (long weekends)', detail: 'When a public holiday falls on Thursday/Tuesday, many French take the "pont" (bridge day) off too. Plan travel in advance around these dates.', emoji: '🌉' },
    { custom: 'La Rentrée', detail: 'September "back to school" is huge culturally — new courses, job offers, political season, cultural events all restart simultaneously. The city comes alive.', emoji: '📚' },
    { custom: 'Bisous (cheek kisses)', detail: 'In social settings, cheek kisses (1 or 2 in Paris — usually 2) replace handshakes. Professional settings use handshakes. Follow the other person\'s lead.', emoji: '😘' },
  ];

  const TABS = [
    { id: 'seasons', label: '🌸 Seasons', color: '#34d399' },
    { id: 'holidays', label: '🗓️ Holidays', color: '#3b82f6' },
    { id: 'safety', label: '🛡️ Safety', color: '#ef4444' },
    { id: 'customs', label: '🥖 Customs', color: '#f97316' },
  ] as const;

  return (
    <div style={{ padding: '2rem 2.5rem', maxWidth: 1100, margin: '0 auto' }}>
      <FadeIn>
        <div style={{ marginBottom: '2rem' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 4 }}>
            <Sun style={{ width: 16, height: 16, color: '#FFD700' }} />
            <span style={{ fontSize: 12, fontWeight: 600, color: '#FFD700', textTransform: 'uppercase', letterSpacing: '0.1em' }}>Seasonal Guide</span>
          </div>
          <h1 style={{ fontFamily: 'Playfair Display, serif', fontSize: '2rem', fontWeight: 700, color: '#fff' }}>Seasonal & Local Tips</h1>
          <p style={{ color: '#8E8E93', fontSize: 14 }}>Paris by season, holidays, safety hotspots & essential local customs</p>
        </div>
      </FadeIn>

      <div style={{ display: 'flex', gap: 6, marginBottom: '1.25rem', flexWrap: 'wrap' }}>
        {TABS.map(tab => (
          <button key={tab.id} onClick={() => setActiveTab(tab.id)}
            style={{ padding: '8px 16px', borderRadius: 20, fontSize: 13, fontWeight: 700, cursor: 'pointer', border: `1px solid ${activeTab === tab.id ? tab.color + '66' : 'rgba(255,255,255,0.08)'}`, background: activeTab === tab.id ? `${tab.color}15` : 'rgba(255,255,255,0.03)', color: activeTab === tab.id ? '#fff' : '#9ca3af', transition: 'all 0.2s' }}>
            {tab.label}
          </button>
        ))}
      </div>

      <AnimatePresence mode="wait">
        {activeTab === 'seasons' && (
          <motion.div key="seasons" initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}>
            <div style={{ display: 'flex', gap: 6, marginBottom: '1.25rem' }}>
              {SEASONS.map((s, i) => (
                <button key={s.season} onClick={() => setActiveSeason(i)}
                  style={{ flex: 1, padding: '10px 4px', borderRadius: 12, fontSize: 12, fontWeight: 700, cursor: 'pointer', border: `1px solid ${activeSeason === i ? s.color + '66' : 'rgba(255,255,255,0.08)'}`, background: activeSeason === i ? `${s.color}15` : 'rgba(255,255,255,0.03)', color: activeSeason === i ? '#fff' : '#9ca3af', transition: 'all 0.2s' }}>
                  {s.season.split(' ')[1]} {s.season.split(' ')[0]}
                </button>
              ))}
            </div>
            <AnimatePresence mode="wait">
              <motion.div key={activeSeason} initial={{ opacity: 0, y: 6 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}>
                <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))', gap: '1rem' }}>
                  <div style={{ padding: '1.25rem', borderRadius: 16, background: `${SEASONS[activeSeason].color}08`, border: `1px solid ${SEASONS[activeSeason].color}30` }}>
                    <div style={{ fontWeight: 700, color: SEASONS[activeSeason].color, marginBottom: '0.75rem', fontSize: 15 }}>🌡️ Temperature: {SEASONS[activeSeason].temp}</div>
                    <div style={{ fontWeight: 700, color: '#8E8E93', fontSize: 12, marginBottom: 8, textTransform: 'uppercase', letterSpacing: '0.05em' }}>What to Pack</div>
                    {SEASONS[activeSeason].pack.map((item, i) => (
                      <div key={i} style={{ display: 'flex', gap: 8, marginBottom: 6, fontSize: 13, color: '#e5e7eb' }}>
                        <span style={{ color: SEASONS[activeSeason].color }}>•</span>{item}
                      </div>
                    ))}
                  </div>
                  <div style={{ padding: '1.25rem', borderRadius: 16, background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.08)' }}>
                    <div style={{ fontWeight: 700, color: '#8E8E93', fontSize: 12, marginBottom: 8, textTransform: 'uppercase', letterSpacing: '0.05em' }}>Events</div>
                    {SEASONS[activeSeason].events.map((event, i) => (
                      <div key={i} style={{ display: 'flex', gap: 8, marginBottom: 8, fontSize: 13, color: '#e5e7eb' }}>
                        <span style={{ color: '#fbbf24' }}>★</span>{event}
                      </div>
                    ))}
                    <div style={{ marginTop: '0.75rem', padding: '10px 12px', borderRadius: 10, background: 'rgba(255,215,0,0.08)', border: '1px solid rgba(255,215,0,0.2)', fontSize: 12, color: '#fbbf24' }}>
                      💡 {SEASONS[activeSeason].tips}
                    </div>
                  </div>
                </div>
              </motion.div>
            </AnimatePresence>
          </motion.div>
        )}

        {activeTab === 'holidays' && (
          <motion.div key="holidays" initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '0.5rem', marginBottom: '1.5rem' }}>
              {PUBLIC_HOLIDAYS.map(h => (
                <div key={h.date} style={{ padding: '10px 14px', borderRadius: 12, background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.08)', display: 'flex', alignItems: 'center', gap: '1rem' }}>
                  <span style={{ fontSize: '1.2rem' }}>{h.emoji}</span>
                  <span style={{ fontSize: 12, fontWeight: 700, color: '#3b82f6', minWidth: 80 }}>{h.date}</span>
                  <span style={{ fontSize: 13, color: '#e5e7eb' }}>{h.name}</span>
                </div>
              ))}
            </div>
            <div style={{ padding: '1.25rem', borderRadius: 16, background: 'rgba(59,130,246,0.06)', border: '1px solid rgba(59,130,246,0.2)' }}>
              <div style={{ fontWeight: 700, color: '#93c5fd', marginBottom: '0.75rem', fontSize: 14 }}>🏫 Zone C School Holidays (Paris)</div>
              {Object.entries(SCHOOL_ZONES['Zone C (Paris & Île-de-France)']).map(([period, dates]) => (
                <div key={period} style={{ display: 'flex', justifyContent: 'space-between', padding: '6px 0', borderBottom: '1px solid rgba(255,255,255,0.06)', fontSize: 13 }}>
                  <span style={{ color: '#8E8E93', textTransform: 'capitalize' }}>{period}</span>
                  <span style={{ color: '#fff', fontWeight: 600 }}>{dates}</span>
                </div>
              ))}
            </div>
          </motion.div>
        )}

        {activeTab === 'safety' && (
          <motion.div key="safety" initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}>
            <div style={{ padding: '0.75rem 1rem', borderRadius: 10, background: 'rgba(239,68,68,0.08)', border: '1px solid rgba(239,68,68,0.2)', marginBottom: '1rem', fontSize: 12, color: '#fca5a5' }}>
              🛡️ Paris is generally safe but has active pickpocket networks, particularly at tourist hotspots. Violent crime is rare. Stay alert in crowded areas and on public transport.
            </div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '0.75rem', marginBottom: '1.25rem' }}>
              {SAFETY.map(s => (
                <div key={s.area} style={{ padding: '1rem 1.25rem', borderRadius: 14, background: 'rgba(239,68,68,0.06)', border: '1px solid rgba(239,68,68,0.2)' }}>
                  <div style={{ fontWeight: 700, color: '#fca5a5', fontSize: 14, marginBottom: 2 }}>📍 {s.area}</div>
                  <div style={{ fontSize: 11, color: '#f59e0b', marginBottom: 6 }}>⚠️ {s.risk}</div>
                  <div style={{ fontSize: 12, color: '#8E8E93' }}>💡 {s.advice}</div>
                </div>
              ))}
            </div>
            <div style={{ display: 'flex', gap: 8 }}>
              <input value={question} onChange={e => setQuestion(e.target.value)} onKeyDown={e => e.key === 'Enter' && ask()}
                placeholder="Ask about Paris safety, scams, neighbourhoods…"
                style={{ flex: 1, background: 'rgba(255,255,255,0.06)', border: '1px solid rgba(255,255,255,0.1)', borderRadius: 10, padding: '10px 14px', color: '#fff', fontSize: 14, outline: 'none' }} />
              <button onClick={() => ask()} disabled={loading} style={{ padding: '10px 18px', borderRadius: 10, background: 'linear-gradient(135deg,#dc2626,#b91c1c)', border: 'none', cursor: 'pointer', color: '#fff', fontWeight: 700 }}>
                {loading ? <Loader2 style={{ width: 16, height: 16, animation: 'spin 1s linear infinite' }} /> : 'Ask'}
              </button>
            </div>
            {answer && <div style={{ marginTop: '1rem', padding: '1rem', borderRadius: 12, background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.08)', fontSize: 13, color: '#e5e7eb', lineHeight: 1.7 }} dangerouslySetInnerHTML={{ __html: answer.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>').replace(/\n/g, '<br/>') }} />}
          </motion.div>
        )}

        {activeTab === 'customs' && (
          <motion.div key="customs" initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '0.75rem' }}>
              {LOCAL_CUSTOMS.map(c => (
                <div key={c.custom} style={{ padding: '1rem 1.25rem', borderRadius: 14, background: 'rgba(249,115,22,0.06)', border: '1px solid rgba(249,115,22,0.2)', display: 'flex', gap: '1rem', alignItems: 'flex-start' }}>
                  <span style={{ fontSize: '1.3rem', flexShrink: 0 }}>{c.emoji}</span>
                  <div>
                    <div style={{ fontWeight: 700, color: '#fb923c', fontSize: 14, marginBottom: 4 }}>{c.custom}</div>
                    <div style={{ fontSize: 12, color: '#8E8E93', lineHeight: 1.6 }}>{c.detail}</div>
                  </div>
                </div>
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
      <style>{`@keyframes spin { from { transform:rotate(0deg) } to { transform:rotate(360deg) } }`}</style>
    </div>
  );
}
