'use client';
import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Music, Loader2, ExternalLink, Heart } from 'lucide-react';
import { useLanguage, LANGUAGES } from '@/lib/i18n/LanguageContext';
import { toast } from 'sonner';
import { FadeIn } from '@/components/shared/PageMotion';

const FREE_ACTIVITIES = [
  { name: 'Museum Free First Sundays', desc: 'Louvre, Musée d\'Orsay, Pompidou — all free on the first Sunday of each month (except July–August for Louvre).', emoji: '🏛️', url: 'https://www.louvre.fr' },
  { name: 'Cinéma en Plein Air', desc: 'Free outdoor cinema in Parc de la Villette every summer. Bring a blanket.', emoji: '🎬', url: 'https://www.villette.com' },
  { name: 'Paris Plages', desc: 'Free beach along the Seine in summer (July–August). Sand, deckchairs, games.', emoji: '🏖️', url: 'https://quefaire.paris.fr' },
  { name: 'Fête de la Musique', desc: 'June 21st — free concerts everywhere in Paris. Streets, courtyards, parks.', emoji: '🎸', url: 'https://fetedelamusique.culture.gouv.fr' },
  { name: 'Nuit Blanche', desc: 'October — all-night contemporary art event. Installations city-wide, free entry.', emoji: '🌙', url: 'https://quefaire.paris.fr' },
  { name: 'Jardins du Palais Royal', desc: 'Free beautiful garden, Colonnes de Buren. A local favourite.', emoji: '🌿', url: '' },
  { name: 'Parc des Buttes-Chaumont', desc: '25-hectare park, lake, temple on a hill. Best park in Paris for a Sunday stroll.', emoji: '⛰️', url: '' },
  { name: 'Jardin du Luxembourg', desc: 'Senate gardens — iconic green chairs, pond, puppet shows. Free entry.', emoji: '🌳', url: '' },
];

const LANGUAGE_LEARNING = [
  { name: 'Mairie de Paris Language Courses', desc: 'Subsidised French courses for Paris residents. Very affordable. Check paris.fr/cours-municipaux.', url: 'https://www.paris.fr/pages/cours-municipaux-d-adultes-2917', emoji: '🏛️' },
  { name: 'Alliance Française Paris', desc: 'Gold-standard French school. All levels. Official DELF/DALF exam centre.', url: 'https://www.alliancefr.org', emoji: '🎓' },
  { name: 'Franglish', desc: 'Weekly language exchange events (French-English conversation, speed-networking format). Very social.', url: 'https://www.franglish.eu', emoji: '🤝' },
  { name: 'Tandem App', desc: 'Language exchange app — find native French speakers wanting to learn your language.', url: 'https://www.tandem.net', emoji: '📱' },
  { name: 'Meetup.com French practice', desc: 'Search "French conversation Paris" for free weekly meetups.', url: 'https://www.meetup.com', emoji: '☕' },
  { name: 'Duolingo / Babbel / Pimsleur', desc: 'Apps for daily practice. Pimsleur is best for pronunciation.', url: 'https://www.duolingo.com', emoji: '🦜' },
];

const EXPAT_COMMUNITIES = [
  { name: 'Americans in Paris', platform: 'Facebook Group', members: '50k+', emoji: '🇺🇸' },
  { name: 'Expats in Paris', platform: 'Facebook Group', members: '30k+', emoji: '🌍' },
  { name: 'Australians in France', platform: 'Facebook Group', members: '10k+', emoji: '🇦🇺' },
  { name: 'Internations Paris', platform: 'App + Events', members: 'Large network', emoji: '🌐' },
  { name: 'WICE (Women\'s international club)', platform: 'Organisation', members: 'Founded 1978', emoji: '👩' },
  { name: 'Paris Anglo Info', platform: 'Forum + Events', members: 'Long-running', emoji: '🇬🇧' },
];

const LGBTQ = [
  'Le Marais (3ème & 4ème) is the historic LGBTQ+ neighbourhood — bars, cafés, community spaces.',
  'Marche des Fiertés (Paris Pride) — June, one of the largest in Europe. Route varies each year.',
  'Association Le Refuge: support for young LGBTQ+ people, housing and counselling (0800 811 414 free).',
  'Centre LGBTQI+ Paris Île-de-France: community centre, events, legal & health support.',
  'Bar highlights: Cox, Open Café, Le Duplex, Scream Club (nights).',
  'Trans support: OUTrans collective provides peer support and legal/medical guidance.',
];

export default function CulturePage() {
  const { lang } = useLanguage();
  const langLabel = LANGUAGES.find(l => l.code === lang)?.label ?? "English";
  const [activeTab, setActiveTab] = useState<'free' | 'language' | 'expats' | 'lgbtq' | 'etiquette'>('free');
  const [question, setQuestion] = useState('');
  const [answer, setAnswer] = useState('');
  const [loading, setLoading] = useState(false);

  const ask = async (q?: string) => {
    const query = q || question;
    if (!query.trim()) return;
    setLoading(true); setAnswer('');
    try {
      const res = await fetch('/api/culture', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ question: query }) });
      const data = await res.json();
      setAnswer(data.answer || '');
    } catch { toast.error('Connection error'); }
    finally { setLoading(false); }
  };

  const ETIQUETTE = [
    { rule: 'Always say "Bonjour"', detail: 'Enter any shop, bakery, or office — greet everyone with "Bonjour" first. Not doing so is considered rude.', emoji: '👋' },
    { rule: 'La bise greeting', detail: '1 or 2 cheek kisses (depending on region — Paris is usually 2). Handshake in professional settings.', emoji: '😘' },
    { rule: 'Meal times', detail: 'Lunch 12–2pm, dinner 8–10pm. Arriving at 6pm to a restaurant is very unusual. Most places open at 7:30pm.', emoji: '🍽️' },
    { rule: '"Vous" vs "Tu"', detail: 'Use "vous" with strangers and seniors. "Tu" with friends, peers, children. When in doubt, use "vous".', emoji: '🗣️' },
    { rule: 'Dress code', detail: 'Parisians dress elegantly and avoid sportswear in daily life (outside the gym). Classic, understated fashion is valued.', emoji: '👗' },
    { rule: 'Queue etiquette', detail: 'Queuing is taken seriously. Never cut in line. Form an orderly queue even if unmarked.', emoji: '🚶' },
    { rule: 'Restaurant service', detail: 'Service is included in the bill (service compris). Additional tipping is appreciated but not mandatory. Round up or leave €2–5.', emoji: '🧾' },
  ];

  const TABS = [
    { id: 'free', label: '🎭 Free Activities', color: '#f97316' },
    { id: 'language', label: '🗣️ Language', color: '#002654' },
    { id: 'etiquette', label: '🤝 Etiquette', color: '#d97706' },
    { id: 'expats', label: '🌍 Expat Life', color: '#8b5cf6' },
    { id: 'lgbtq', label: '🏳️‍🌈 LGBTQ+', color: '#ec4899' },
  ] as const;

  return (
    <div style={{ padding: '2rem 2.5rem', maxWidth: 1100, margin: '0 auto' }}>
      <FadeIn>
        <div style={{ marginBottom: '2rem' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 4 }}>
            <Music style={{ width: 16, height: 16, color: '#FFD700' }} />
            <span style={{ fontSize: 12, fontWeight: 600, color: '#FFD700', textTransform: 'uppercase', letterSpacing: '0.1em' }}>Culture & Social Life</span>
          </div>
          <h1 style={{ fontFamily: 'Playfair Display, serif', fontSize: '2rem', fontWeight: 700, color: '#fff' }}>Culture, Leisure & Social Life</h1>
          <p style={{ color: '#8E8E93', fontSize: 14 }}>Free activities, language learning, etiquette, expat communities & nightlife</p>
        </div>
      </FadeIn>

      <div style={{ display: 'flex', gap: 6, marginBottom: '1.25rem', flexWrap: 'wrap' }}>
        {TABS.map(tab => (
          <button key={tab.id} onClick={() => setActiveTab(tab.id)}
            style={{ padding: '8px 16px', borderRadius: 20, fontSize: 13, fontWeight: 700, cursor: 'pointer', border: `1px solid ${activeTab === tab.id ? tab.color + '66' : 'rgba(255,255,255,0.08)'}`, background: activeTab === tab.id ? `${tab.color}15` : 'rgba(255,255,255,0.03)', color: activeTab === tab.id ? '#fff' : '#9ca3af', transition: 'all 0.2s' }}>
            {tab.label}
          </button>
        ))}
      </div>

      <AnimatePresence mode="wait">
        {activeTab === 'free' && (
          <motion.div key="free" initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(280px, 1fr))', gap: '1rem' }}>
              {FREE_ACTIVITIES.map(a => (
                <div key={a.name} style={{ padding: '1.1rem', borderRadius: 14, background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.08)' }}>
                  <div style={{ fontSize: '1.5rem', marginBottom: 8 }}>{a.emoji}</div>
                  <div style={{ fontWeight: 700, color: '#fff', fontSize: 14, marginBottom: 4 }}>{a.name}</div>
                  <div style={{ fontSize: 12, color: '#8E8E93', lineHeight: 1.6, marginBottom: 6 }}>{a.desc}</div>
                  {a.url && <a href={a.url} target="_blank" rel="noreferrer" style={{ fontSize: 11, color: '#60a5fa', textDecoration: 'none' }}>Learn more →</a>}
                </div>
              ))}
            </div>
          </motion.div>
        )}

        {activeTab === 'language' && (
          <motion.div key="language" initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '0.75rem', marginBottom: '1.25rem' }}>
              {LANGUAGE_LEARNING.map(r => (
                <a key={r.name} href={r.url} target="_blank" rel="noreferrer"
                  style={{ padding: '1rem 1.25rem', borderRadius: 14, background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(0,38,84,0.2)', textDecoration: 'none', display: 'flex', gap: '1rem', alignItems: 'flex-start' }}>
                  <span style={{ fontSize: '1.3rem', flexShrink: 0 }}>{r.emoji}</span>
                  <div style={{ flex: 1 }}>
                    <div style={{ fontWeight: 700, color: '#fff', fontSize: 14, marginBottom: 4 }}>{r.name}</div>
                    <div style={{ fontSize: 12, color: '#8E8E93', lineHeight: 1.6 }}>{r.desc}</div>
                  </div>
                  <ExternalLink style={{ width: 13, height: 13, color: '#8E8E93', flexShrink: 0 }} />
                </a>
              ))}
            </div>
            <div style={{ display: 'flex', gap: 8 }}>
              <input value={question} onChange={e => setQuestion(e.target.value)} onKeyDown={e => e.key === 'Enter' && ask()}
                placeholder="Ask about language learning tips, French culture, social customs…"
                style={{ flex: 1, background: 'rgba(255,255,255,0.06)', border: '1px solid rgba(255,255,255,0.1)', borderRadius: 10, padding: '10px 14px', color: '#fff', fontSize: 14, outline: 'none' }} />
              <button onClick={() => ask()} disabled={loading}
                style={{ padding: '10px 18px', borderRadius: 10, background: 'linear-gradient(135deg,#004082,#0052A5)', border: 'none', cursor: 'pointer', color: '#fff', fontWeight: 700 }}>
                {loading ? <Loader2 style={{ width: 16, height: 16, animation: 'spin 1s linear infinite' }} /> : 'Ask AI'}
              </button>
            </div>
            {answer && (
              <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} style={{ marginTop: '1rem', padding: '1rem', borderRadius: 12, background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.08)', fontSize: 13, color: '#e5e7eb', lineHeight: 1.7 }}
                dangerouslySetInnerHTML={{ __html: answer.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>').replace(/\n/g, '<br/>') }} />
            )}
          </motion.div>
        )}

        {activeTab === 'etiquette' && (
          <motion.div key="etiquette" initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '0.75rem' }}>
              {ETIQUETTE.map(e => (
                <div key={e.rule} style={{ padding: '1rem 1.25rem', borderRadius: 14, background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,215,0,0.15)', display: 'flex', gap: '1rem', alignItems: 'flex-start' }}>
                  <span style={{ fontSize: '1.3rem', flexShrink: 0 }}>{e.emoji}</span>
                  <div>
                    <div style={{ fontWeight: 700, color: '#fbbf24', fontSize: 14, marginBottom: 4 }}>{e.rule}</div>
                    <div style={{ fontSize: 12, color: '#8E8E93', lineHeight: 1.6 }}>{e.detail}</div>
                  </div>
                </div>
              ))}
            </div>
          </motion.div>
        )}

        {activeTab === 'expats' && (
          <motion.div key="expats" initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(250px, 1fr))', gap: '1rem', marginBottom: '1.25rem' }}>
              {EXPAT_COMMUNITIES.map(c => (
                <div key={c.name} style={{ padding: '1.1rem', borderRadius: 14, background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(139,92,246,0.2)' }}>
                  <div style={{ fontSize: '1.5rem', marginBottom: 8 }}>{c.emoji}</div>
                  <div style={{ fontWeight: 700, color: '#fff', fontSize: 14, marginBottom: 2 }}>{c.name}</div>
                  <div style={{ fontSize: 11, color: '#a78bfa', marginBottom: 2 }}>{c.platform}</div>
                  <div style={{ fontSize: 11, color: '#8E8E93' }}>{c.members}</div>
                </div>
              ))}
            </div>
            <div style={{ padding: '1rem', borderRadius: 12, background: 'rgba(255,215,0,0.08)', border: '1px solid rgba(255,215,0,0.2)', fontSize: 12, color: '#fbbf24' }}>
              💡 <strong>Pro Tip:</strong> Meetup.com has hundreds of English-language groups in Paris: hiking, board games, tech, book clubs, professional networking. Search "English Paris" to browse.
            </div>
          </motion.div>
        )}

        {activeTab === 'lgbtq' && (
          <motion.div key="lgbtq" initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '0.75rem', marginBottom: '1.25rem' }}>
              {LGBTQ.map((item, i) => (
                <div key={i} style={{ padding: '12px 16px', borderRadius: 12, background: 'rgba(236,72,153,0.06)', border: '1px solid rgba(236,72,153,0.2)', fontSize: 13, color: '#e5e7eb', lineHeight: 1.6 }}>
                  <span style={{ marginRight: 8 }}>🏳️‍🌈</span>{item}
                </div>
              ))}
            </div>
            <div style={{ display: 'flex', gap: 8 }}>
              <input value={question} onChange={e => setQuestion(e.target.value)} onKeyDown={e => e.key === 'Enter' && ask()}
                placeholder="Ask about LGBTQ+ resources, events, community in Paris…"
                style={{ flex: 1, background: 'rgba(255,255,255,0.06)', border: '1px solid rgba(255,255,255,0.1)', borderRadius: 10, padding: '10px 14px', color: '#fff', fontSize: 14, outline: 'none' }} />
              <button onClick={() => ask()} disabled={loading}
                style={{ padding: '10px 18px', borderRadius: 10, background: 'linear-gradient(135deg,#ec4899,#be185d)', border: 'none', cursor: 'pointer', color: '#fff', fontWeight: 700 }}>
                {loading ? <Loader2 style={{ width: 16, height: 16, animation: 'spin 1s linear infinite' }} /> : 'Ask'}
              </button>
            </div>
            {answer && (
              <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} style={{ marginTop: '1rem', padding: '1rem', borderRadius: 12, background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.08)', fontSize: 13, color: '#e5e7eb', lineHeight: 1.7 }}
                dangerouslySetInnerHTML={{ __html: answer.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>').replace(/\n/g, '<br/>') }} />
            )}
          </motion.div>
        )}
      </AnimatePresence>
      <style>{`@keyframes spin { from { transform:rotate(0deg) } to { transform:rotate(360deg) } }`}</style>
    </div>
  );
}
