import type { Metadata } from 'next';
import './globals.css';
import { Toaster } from 'sonner';
import QueryProvider from '@/components/QueryProvider';
import BadgeUnlockToastProvider from '@/components/quest/BadgeUnlockToast';
import { LanguageProvider } from '@/lib/i18n/LanguageContext';
import LangGate from '@/components/LangGate';

export const metadata: Metadata = {
  title: 'ParisEasyGuide+ | Votre Compagnon IA',
  description: 'AI-powered guide for students, expats & new arrivals in Paris & Île-de-France',
  themeColor: '#0B0E14',
  viewport: 'width=device-width, initial-scale=1, viewport-fit=cover',
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" style={{ colorScheme: 'dark' }}>
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
      </head>
      <body>
        <LanguageProvider>
          <LangGate />
          <QueryProvider>
            {children}
            <BadgeUnlockToastProvider />
            <Toaster
              richColors
              position="bottom-center"
              toastOptions={{
                style: {
                  background: 'rgba(21,26,35,0.96)',
                  backdropFilter: 'blur(24px)',
                  border: '1px solid rgba(255,255,255,0.1)',
                  color: '#F5F5F7',
                  borderRadius: '14px',
                  fontSize: '13px',
                  fontWeight: '500',
                },
              }}
            />
          </QueryProvider>
        </LanguageProvider>
      </body>
    </html>
  );
}
