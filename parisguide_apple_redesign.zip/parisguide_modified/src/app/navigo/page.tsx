'use client';
import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Train, Sparkles, Loader2, AlertTriangle, CheckCircle2, Euro, TrendingDown, Info } from 'lucide-react';
import { toast } from 'sonner';
import { FadeIn, SlideIn } from '@/components/shared/PageMotion';

const DAYS_OPTIONS = ['1–2 days/week', '3 days/week', '4 days/week', '5 days/week (daily)'];
const PASS_OPTIONS = ['None', 'Navigo Mois Zone 1–2', 'Navigo Mois Zone 1–5', 'Navigo Liberté+', 'Imagine\'R', 'Ticket carnet (t+)'];

interface NavigoResult {
  home_zone: string; school_zone: string; recommended_pass: string;
  monthly_cost: string; annual_cost: string; savings_vs_current: string;
  key_insight: string; imagine_r_eligible: boolean; imagine_r_saving: string;
  when_to_buy: string; zones_covered: string[]; alternatives: { name: string; cost: string; best_for: string }[];
  traps: string[]; activation_steps: string[];
}

const ZONE_COLORS: Record<string, string> = {
  'Zone 1': '#002654', 'Zone 2': '#059669', 'Zone 3': '#7c3aed', 'Zone 4': '#ea580c', 'Zone 5': '#db2777',
};

export default function NavigoPage() {
  const [homeAddress, setHomeAddress] = useState('');
  const [schoolAddress, setSchoolAddress] = useState('');
  const [workAddress, setWorkAddress] = useState('');
  const [travelDays, setTravelDays] = useState(DAYS_OPTIONS[4]);
  const [currentPass, setCurrentPass] = useState(PASS_OPTIONS[0]);
  const [result, setResult] = useState<NavigoResult | null>(null);
  const [loading, setLoading] = useState(false);

  const analyze = async () => {
    if (!homeAddress.trim() || !schoolAddress.trim()) { toast.error('Please enter home and school addresses'); return; }
    setLoading(true); setResult(null);
    try {
      const res = await fetch('/api/navigo', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ homeAddress, schoolAddress, workAddress, travelDays, currentPass }),
      });
      const data = await res.json();
      if (data.plan) { setResult(data.plan); toast.success('Navigo analysis complete!'); }
      else toast.error('Could not analyze. Please try again.');
    } catch { toast.error('Failed to analyze Navigo'); }
    finally { setLoading(false); }
  };

  return (
    <div style={{ padding: '2rem 2.5rem', maxWidth: 1000, margin: '0 auto' }}>
      <FadeIn>
        <div style={{ marginBottom: '2rem' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 4 }}>
            <Train style={{ width: 16, height: 16, color: '#FFD700' }} />
            <span style={{ fontSize: 12, fontWeight: 600, color: '#FFD700', textTransform: 'uppercase', letterSpacing: '0.1em' }}>Navigo Optimizer</span>
          </div>
          <h1 style={{ fontFamily: 'Playfair Display, serif', fontSize: '2rem', fontWeight: 700, color: '#fff' }}>Navigo Pass Advisor</h1>
          <p style={{ color: '#8E8E93', fontSize: 14 }}>Stop overpaying — find your optimal Île-de-France pass</p>
        </div>
      </FadeIn>

      {/* Zone map visual */}
      <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.1 }}
        style={{ padding: '1rem 1.25rem', borderRadius: 14, background: 'rgba(255,255,255,0.03)', border: '1px solid rgba(255,255,255,0.08)', marginBottom: '1.5rem', display: 'flex', alignItems: 'center', gap: '1rem', flexWrap: 'wrap' }}>
        <span style={{ fontSize: 12, color: '#8E8E93', fontWeight: 600 }}>Île-de-France Zones:</span>
        {Object.entries(ZONE_COLORS).map(([zone, color]) => (
          <div key={zone} style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
            <div style={{ width: 12, height: 12, borderRadius: '50%', background: color }} />
            <span style={{ fontSize: 12, color: '#d1d5db' }}>{zone}</span>
          </div>
        ))}
        <span style={{ fontSize: 11, color: '#8E8E93' }}>· CDG = Zone 5 · Versailles = Zone 4 · Orly = Zone 4</span>
      </motion.div>

      <div style={{ display: 'grid', gridTemplateColumns: result ? '420px 1fr' : '1fr', gap: '2rem' }}>
        {/* Input form */}
        <SlideIn from="left">
          <div style={{ padding: '1.5rem', borderRadius: 16, background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.08)' }}>
            <h2 style={{ fontWeight: 700, color: '#fff', marginBottom: '1.25rem', fontSize: 15 }}>Your Travel Profile</h2>

            {[
              { label: 'Home Address', value: homeAddress, set: setHomeAddress, placeholder: 'e.g. 24 rue Lecourbe, 75015', icon: '🏠' },
              { label: 'School / University', value: schoolAddress, set: setSchoolAddress, placeholder: 'e.g. Université Paris-Saclay, 91400', icon: '🎓' },
              { label: 'Work / Internship (optional)', value: workAddress, set: setWorkAddress, placeholder: 'e.g. La Défense, 92400', icon: '💼' },
            ].map(field => (
              <div key={field.label} style={{ marginBottom: '1.1rem' }}>
                <label style={{ fontSize: 11, fontWeight: 700, color: '#8E8E93', textTransform: 'uppercase', letterSpacing: '0.05em', display: 'block', marginBottom: 6 }}>
                  {field.icon} {field.label}
                </label>
                <input value={field.value} onChange={e => field.set(e.target.value)}
                  placeholder={field.placeholder}
                  style={{ width: '100%', background: 'rgba(255,255,255,0.06)', border: '1px solid rgba(255,255,255,0.1)', borderRadius: 10, padding: '10px 14px', color: '#fff', fontSize: 13, outline: 'none', boxSizing: 'border-box' }} />
              </div>
            ))}

            <div style={{ marginBottom: '1.1rem' }}>
              <label style={{ fontSize: 11, fontWeight: 700, color: '#8E8E93', textTransform: 'uppercase', letterSpacing: '0.05em', display: 'block', marginBottom: 8 }}>📅 Travel Frequency</label>
              <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}>
                {DAYS_OPTIONS.map(d => (
                  <button key={d} onClick={() => setTravelDays(d)}
                    style={{ padding: '6px 12px', borderRadius: 20, fontSize: 12, fontWeight: 600, cursor: 'pointer', border: 'none', background: travelDays === d ? '#002654' : 'rgba(255,255,255,0.06)', color: travelDays === d ? '#fff' : '#9ca3af' }}>
                    {d}
                  </button>
                ))}
              </div>
            </div>

            <div style={{ marginBottom: '1.5rem' }}>
              <label style={{ fontSize: 11, fontWeight: 700, color: '#8E8E93', textTransform: 'uppercase', letterSpacing: '0.05em', display: 'block', marginBottom: 8 }}>🎫 Current Pass</label>
              <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}>
                {PASS_OPTIONS.map(p => (
                  <button key={p} onClick={() => setCurrentPass(p)}
                    style={{ padding: '6px 12px', borderRadius: 20, fontSize: 12, fontWeight: 600, cursor: 'pointer', border: `1px solid ${currentPass === p ? 'rgba(0,38,84,0.6)' : 'rgba(255,255,255,0.1)'}`, background: currentPass === p ? 'rgba(0,38,84,0.2)' : 'rgba(255,255,255,0.03)', color: currentPass === p ? '#60a5fa' : '#9ca3af' }}>
                    {p}
                  </button>
                ))}
              </div>
            </div>

            <motion.button whileTap={{ scale: 0.97 }} onClick={analyze} disabled={loading}
              style={{ width: '100%', padding: '13px', borderRadius: 12, background: loading ? 'rgba(0,38,84,0.3)' : 'linear-gradient(135deg,#004082,#0052A5)', border: 'none', cursor: 'pointer', color: '#fff', fontWeight: 700, fontSize: 14, display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8 }}>
              {loading ? <><Loader2 style={{ width: 16, height: 16, animation: 'spin 1s linear infinite' }} />Analyzing your zones…</> : <><Sparkles style={{ width: 16, height: 16 }} />Find My Optimal Pass</>}
            </motion.button>
          </div>
        </SlideIn>

        {/* Results */}
        <AnimatePresence>
          {result && (
            <motion.div key="result" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>

              {/* Recommendation hero */}
              <motion.div initial={{ scale: 0.96 }} animate={{ scale: 1 }}
                style={{ padding: '1.5rem', borderRadius: 16, background: 'linear-gradient(135deg,rgba(0,38,84,0.15),rgba(255,215,0,0.05))', border: '1px solid rgba(0,38,84,0.35)' }}>
                <div style={{ fontSize: 11, fontWeight: 700, color: '#FFD700', textTransform: 'uppercase', letterSpacing: '0.1em', marginBottom: 8 }}>✓ Recommended Pass</div>
                <div style={{ fontSize: '1.4rem', fontWeight: 800, color: '#fff', marginBottom: 4 }}>{result.recommended_pass}</div>
                <div style={{ display: 'flex', gap: '1.5rem', marginBottom: '0.75rem' }}>
                  <div><span style={{ fontSize: '1.2rem', fontWeight: 700, color: '#FFD700' }}>{result.monthly_cost}</span><span style={{ fontSize: 12, color: '#8E8E93' }}>/month</span></div>
                  <div><span style={{ fontSize: '1.2rem', fontWeight: 700, color: '#34d399' }}>{result.annual_cost}</span><span style={{ fontSize: 12, color: '#8E8E93' }}>/year</span></div>
                  {result.savings_vs_current !== '€0/month saved' && (
                    <div style={{ display: 'flex', alignItems: 'center', gap: 4 }}><TrendingDown style={{ width: 14, height: 14, color: '#34d399' }} /><span style={{ fontSize: 13, fontWeight: 700, color: '#34d399' }}>{result.savings_vs_current}</span></div>
                  )}
                </div>
                <p style={{ fontSize: 13, color: '#d1d5db', lineHeight: 1.7 }}>💡 {result.key_insight}</p>
              </motion.div>

              {/* Imagine'R alert */}
              {result.imagine_r_eligible && (
                <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.15 }}
                  style={{ padding: '1rem 1.25rem', borderRadius: 14, background: 'rgba(5,150,105,0.1)', border: '1px solid rgba(5,150,105,0.35)' }}>
                  <div style={{ fontWeight: 700, color: '#34d399', marginBottom: 4, display: 'flex', alignItems: 'center', gap: 6, fontSize: 13 }}>
                    <CheckCircle2 style={{ width: 14, height: 14 }} /> You qualify for Imagine'R!
                  </div>
                  <p style={{ fontSize: 13, color: '#6ee7b7' }}>Students under 26 save {result.imagine_r_saving} with the annual Imagine'R pass vs monthly Navigo. Apply at a RATP agency with your student card.</p>
                </motion.div>
              )}

              {/* Zones */}
              <div style={{ padding: '1.1rem 1.25rem', borderRadius: 14, background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.08)' }}>
                <div style={{ fontSize: 12, fontWeight: 700, color: '#8E8E93', marginBottom: 8 }}>ZONES COVERED</div>
                <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap', marginBottom: 10 }}>
                  {result.zones_covered?.map(z => (
                    <span key={z} style={{ padding: '4px 10px', borderRadius: 20, fontSize: 12, fontWeight: 700, background: `${ZONE_COLORS[z] || '#374151'}22`, border: `1px solid ${ZONE_COLORS[z] || '#374151'}55`, color: ZONE_COLORS[z] || '#9ca3af' }}>{z}</span>
                  ))}
                </div>
                <div style={{ fontSize: 12, color: '#fbbf24' }}>⏰ {result.when_to_buy}</div>
              </div>

              {/* Traps */}
              {result.traps?.length > 0 && (
                <div style={{ padding: '1.1rem 1.25rem', borderRadius: 14, background: 'rgba(239,68,68,0.05)', border: '1px solid rgba(239,68,68,0.2)' }}>
                  <div style={{ fontWeight: 700, color: '#fca5a5', marginBottom: '0.75rem', display: 'flex', alignItems: 'center', gap: 6, fontSize: 13 }}>
                    <AlertTriangle style={{ width: 14, height: 14 }} /> Common Traps to Avoid
                  </div>
                  <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
                    {result.traps.map((t, i) => (
                      <div key={i} style={{ fontSize: 12, color: '#fca5a5', lineHeight: 1.6, display: 'flex', gap: 8 }}>
                        <span>⚠️</span><span>{t}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Alternatives */}
              {result.alternatives?.length > 0 && (
                <div style={{ padding: '1.1rem 1.25rem', borderRadius: 14, background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.08)' }}>
                  <div style={{ fontSize: 12, fontWeight: 700, color: '#8E8E93', marginBottom: '0.75rem' }}>OTHER OPTIONS</div>
                  <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
                    {result.alternatives.map((alt, i) => (
                      <div key={i} style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', gap: 8 }}>
                        <div><div style={{ fontSize: 13, fontWeight: 600, color: '#fff' }}>{alt.name}</div><div style={{ fontSize: 12, color: '#8E8E93' }}>{alt.best_for}</div></div>
                        <div style={{ fontSize: 13, fontWeight: 700, color: '#60a5fa', flexShrink: 0 }}>{alt.cost}/mo</div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Activation steps */}
              {result.activation_steps?.length > 0 && (
                <div style={{ padding: '1.1rem 1.25rem', borderRadius: 14, background: 'rgba(0,38,84,0.08)', border: '1px solid rgba(0,38,84,0.2)' }}>
                  <div style={{ fontSize: 12, fontWeight: 700, color: '#60a5fa', marginBottom: '0.75rem' }}>HOW TO GET YOUR PASS</div>
                  {result.activation_steps.map((s, i) => (
                    <div key={i} style={{ display: 'flex', gap: 10, marginBottom: 8 }}>
                      <div style={{ width: 20, height: 20, borderRadius: '50%', background: '#002654', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 11, fontWeight: 700, color: '#fff', flexShrink: 0 }}>{i + 1}</div>
                      <span style={{ fontSize: 12, color: '#d1d5db', lineHeight: 1.6 }}>{s}</span>
                    </div>
                  ))}
                </div>
              )}
            </motion.div>
          )}
        </AnimatePresence>
      </div>
      <style>{`@keyframes spin { from { transform:rotate(0deg) } to { transform:rotate(360deg) } }`}</style>
    </div>
  );
}
