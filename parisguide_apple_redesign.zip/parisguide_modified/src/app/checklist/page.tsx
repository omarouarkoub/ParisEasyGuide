'use client';
import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { CheckSquare, Square, Trophy, Star } from 'lucide-react';
import { FadeIn } from '@/components/shared/PageMotion';

const CHECKLIST: { day: string; tasks: { id: string; task: string; detail: string; url?: string; critical?: boolean; emoji: string }[] }[] = [
  {
    day: 'Day 1–2: Arrival Essentials',
    tasks: [
      { id: 'sim', task: 'Get a French SIM card', detail: 'Free Mobile (free.fr) or Orange at CDG/Orly airport. Pay-as-you-go, then switch to monthly plan.', url: 'https://www.free.fr', emoji: '📱', critical: true },
      { id: 'cash', task: 'Withdraw some cash', detail: 'Many small businesses are cash-only. €50–100 to start.', emoji: '💶' },
      { id: 'transport', task: 'Get a Navigo Liberté+ or Navigo Mensuel', detail: 'Available at metro stations. Add zones based on your address.', url: 'https://www.iledefrance-mobilites.fr', emoji: '🚇', critical: true },
      { id: 'accommodation', task: 'Confirm temporary accommodation', detail: 'Make sure you have an address to receive mail — needed for nearly everything.', emoji: '🏠', critical: true },
    ],
  },
  {
    day: 'Week 1: Core Administration',
    tasks: [
      { id: 'bank', task: 'Open a bank account', detail: 'Start with Revolut/Wise for immediate use. Open Boursorama for French RIB ASAP.', url: 'https://www.boursorama.com', emoji: '🏦', critical: true },
      { id: 'prefecture', task: 'Book préfecture appointment (non-EU only)', detail: 'Titre de séjour applications often have 4–8 week waits. Book NOW on anef.immigration.interieur.gouv.fr.', url: 'https://administration-etrangers-en-france.interieur.gouv.fr', emoji: '🪪', critical: true },
      { id: 'consulate', task: 'Register at your country\'s consulate', detail: 'Many countries require expat registration. Check your embassy website.', emoji: '🏛️' },
      { id: 'photos', task: 'Get passport photos (photos d\'identité)', detail: 'Photo booths (cabines photos) in most metro stations — you\'ll need 4–8 copies for admin.', emoji: '📸' },
      { id: 'mairie', task: 'Visit your local Mairie', detail: 'Register your address. Pick up local info. Ask about crèche applications (if applicable).', emoji: '🏛️' },
    ],
  },
  {
    day: 'Week 1–2: Health Coverage',
    tasks: [
      { id: 'ameli', task: 'Register for Sécurité Sociale on Ameli.fr', detail: 'PUMA universal health coverage. Go to etudiant-etranger.ameli.fr if you\'re a student.', url: 'https://www.ameli.fr', emoji: '🏥', critical: true },
      { id: 'cvec', task: 'Pay CVEC (students only)', detail: 'Student contribution ~€103. Required before university inscription. cvec.etudiant.gouv.fr', url: 'https://cvec.etudiant.gouv.fr', emoji: '🎓' },
      { id: 'medecin', task: 'Declare a médecin traitant (GP)', detail: 'Book on Doctolib, then declare them on Ameli.fr. Increases reimbursement from 30% to 70%.', url: 'https://www.doctolib.fr', emoji: '🩺' },
      { id: 'mutuelle', task: 'Get a mutuelle (top-up insurance)', detail: 'Covers the 30–40% Sécurité Sociale doesn\'t. From €20/month for students.', emoji: '🛡️' },
    ],
  },
  {
    day: 'Week 2: Housing & Finances',
    tasks: [
      { id: 'caf', task: 'Apply for CAF housing aid (APL)', detail: 'Apply at caf.fr the day you move into permanent accommodation. Retroactive to first month.', url: 'https://www.caf.fr', emoji: '💶', critical: true },
      { id: 'internet', task: 'Set up home internet (box)', detail: 'Free, SFR, Orange, Bouygues. 2–3 weeks for installation. Order early.', emoji: '📶' },
      { id: 'insurance', task: 'Get home insurance (assurance habitation)', detail: 'Mandatory as a tenant. From €5–15/month. Needed to sign a lease.', emoji: '🏠', critical: true },
      { id: 'utilities', task: 'Set up electricity (EDF / alternatives)', detail: 'Contact EDF or alternative provider with your RIB and address.', url: 'https://www.edf.fr', emoji: '⚡' },
    ],
  },
  {
    day: 'Week 2–3: Explore & Settle',
    tasks: [
      { id: 'supermarche', task: 'Discover your local supermarket', detail: 'Monoprix, Franprix, Carrefour City, or Lidl/Aldi for budget shopping.', emoji: '🛒' },
      { id: 'boulangerie', task: 'Find your boulangerie', detail: 'The best one is usually on your street. Try the baguette tradition — judge the crust.', emoji: '🥖' },
      { id: 'pharmacy', task: 'Register with a local pharmacie', detail: 'They can treat minor issues and will know your medication history.', emoji: '💊' },
      { id: 'velib', task: 'Subscribe to Vélib\'', detail: 'Monthly subscription from €19.99 (mechanical) or €38.80 (electric). Invaluable for city living.', url: 'https://www.velib-metropole.fr', emoji: '🚲' },
    ],
  },
  {
    day: 'Week 3–4: Integration',
    tasks: [
      { id: 'impots', task: 'Get your numéro fiscal', detail: 'Even if income is zero, register at impots.gouv.fr. Needed for many applications.', url: 'https://www.impots.gouv.fr', emoji: '📊' },
      { id: 'language', task: 'Start French lessons', detail: 'Mairie de Paris subsidised classes, Alliance Française, or Meetup language exchange (Franglish).', url: 'https://www.paris.fr/pages/cours-municipaux-d-adultes-2917', emoji: '🗣️' },
      { id: 'cpf', task: 'Create your CPF account', detail: 'Compte Personnel de Formation — up to €800/year for training. mon.compte.formation.gouv.fr', url: 'https://www.moncompteformation.gouv.fr', emoji: '📚' },
      { id: 'neighbours', task: 'Introduce yourself to neighbours', detail: 'Say "Bonjour" in the lift/hallway. A good relationship with neighbours is invaluable in France.', emoji: '🤝' },
      { id: 'explore', task: 'Explore your arrondissement', detail: 'Walk without GPS for 30 minutes. Find the local market, parc, café. Make it your home.', emoji: '🗺️' },
    ],
  },
];

const GOLD = '#FFD700';

export default function ChecklistPage() {
  const [completed, setCompleted] = useState<Set<string>>(new Set());
  const [confetti, setConfetti] = useState(false);

  const totalTasks = CHECKLIST.flatMap(g => g.tasks).length;
  const criticalTasks = CHECKLIST.flatMap(g => g.tasks).filter(t => t.critical).length;
  const completedCritical = CHECKLIST.flatMap(g => g.tasks).filter(t => t.critical && completed.has(t.id)).length;
  const pct = Math.round((completed.size / totalTasks) * 100);

  const toggle = (id: string) => {
    setCompleted(prev => {
      const next = new Set(prev);
      if (next.has(id)) { next.delete(id); } else {
        next.add(id);
        if (next.size === totalTasks) setConfetti(true);
      }
      return next;
    });
  };

  return (
    <div style={{ padding: '2rem 2.5rem', maxWidth: 900, margin: '0 auto' }}>
      <FadeIn>
        <div style={{ marginBottom: '2rem' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 4 }}>
            <CheckSquare style={{ width: 16, height: 16, color: GOLD }} />
            <span style={{ fontSize: 12, fontWeight: 600, color: GOLD, textTransform: 'uppercase', letterSpacing: '0.1em' }}>30-Day Plan</span>
          </div>
          <h1 style={{ fontFamily: 'Playfair Display, serif', fontSize: '2rem', fontWeight: 700, color: '#fff' }}>Your First 30 Days in Paris</h1>
          <p style={{ color: '#8E8E93', fontSize: 14 }}>Priority steps to settle in — tick each one as you complete it</p>
        </div>
      </FadeIn>

      {/* Progress */}
      <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }}
        style={{ padding: '1.5rem', borderRadius: 16, background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.08)', marginBottom: '1.5rem' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1rem' }}>
          <div>
            <div style={{ fontWeight: 800, fontSize: '2rem', color: '#fff' }}>{pct}%</div>
            <div style={{ fontSize: 13, color: '#8E8E93' }}>{completed.size} of {totalTasks} tasks complete</div>
          </div>
          <div style={{ textAlign: 'right' }}>
            <div style={{ fontSize: 13, color: '#fbbf24', fontWeight: 700 }}>🚨 Critical: {completedCritical}/{criticalTasks}</div>
            {pct === 100 && <div style={{ fontSize: 13, color: '#34d399', marginTop: 4 }}>🎉 Félicitations — you're settled!</div>}
          </div>
        </div>
        <div style={{ height: 8, borderRadius: 4, background: 'rgba(255,255,255,0.08)', overflow: 'hidden' }}>
          <motion.div animate={{ width: `${pct}%` }} transition={{ duration: 0.5 }}
            style={{ height: '100%', borderRadius: 4, background: pct === 100 ? '#34d399' : `linear-gradient(90deg, #004082, ${GOLD})` }} />
        </div>
      </motion.div>

      {/* Groups */}
      <div style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
        {CHECKLIST.map((group, gi) => {
          const groupDone = group.tasks.filter(t => completed.has(t.id)).length;
          return (
            <motion.div key={group.day} initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: gi * 0.05 }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '0.75rem' }}>
                <div style={{ fontWeight: 800, color: GOLD, fontSize: 14 }}>{group.day}</div>
                <div style={{ fontSize: 12, color: groupDone === group.tasks.length ? '#34d399' : '#6b7280', fontWeight: 700 }}>
                  {groupDone}/{group.tasks.length}
                </div>
              </div>
              <div style={{ display: 'flex', flexDirection: 'column', gap: '0.5rem' }}>
                {group.tasks.map(task => {
                  const done = completed.has(task.id);
                  return (
                    <motion.div key={task.id} layout onClick={() => toggle(task.id)}
                      style={{ padding: '0.9rem 1.1rem', borderRadius: 14, background: done ? 'rgba(5,150,105,0.08)' : task.critical ? 'rgba(239,68,68,0.05)' : 'rgba(255,255,255,0.04)', border: `1px solid ${done ? 'rgba(5,150,105,0.3)' : task.critical ? 'rgba(239,68,68,0.2)' : 'rgba(255,255,255,0.08)'}`, cursor: 'pointer', display: 'flex', gap: '0.75rem', alignItems: 'flex-start', transition: 'all 0.2s' }}>
                      <div style={{ flexShrink: 0, marginTop: 2 }}>
                        {done
                          ? <CheckSquare style={{ width: 18, height: 18, color: '#34d399' }} />
                          : <Square style={{ width: 18, height: 18, color: task.critical ? '#ef4444' : '#6b7280' }} />
                        }
                      </div>
                      <div style={{ flex: 1 }}>
                        <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 3 }}>
                          <span style={{ fontSize: '1rem' }}>{task.emoji}</span>
                          <span style={{ fontSize: 14, fontWeight: 700, color: done ? '#6ee7b7' : '#fff', textDecoration: done ? 'line-through' : 'none' }}>{task.task}</span>
                          {task.critical && !done && <span style={{ fontSize: 10, fontWeight: 800, color: '#ef4444', background: 'rgba(239,68,68,0.15)', padding: '2px 6px', borderRadius: 4 }}>CRITICAL</span>}
                        </div>
                        <div style={{ fontSize: 12, color: done ? '#4ade80' : '#9ca3af', lineHeight: 1.5 }}>{task.detail}</div>
                        {task.url && !done && (
                          <a href={task.url} target="_blank" rel="noreferrer" onClick={e => e.stopPropagation()}
                            style={{ fontSize: 11, color: '#60a5fa', textDecoration: 'none', display: 'inline-block', marginTop: 4 }}>Open site →</a>
                        )}
                      </div>
                    </motion.div>
                  );
                })}
              </div>
            </motion.div>
          );
        })}
      </div>

      <AnimatePresence>
        {confetti && (
          <motion.div initial={{ opacity: 0, scale: 0.8 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0 }}
            style={{ position: 'fixed', bottom: 80, left: '50%', transform: 'translateX(-50%)', zIndex: 100, padding: '1.25rem 2rem', borderRadius: 20, background: 'linear-gradient(135deg,#004082,#FFD700)', border: '1px solid rgba(255,215,0,0.5)', textAlign: 'center', color: '#fff' }}>
            <Trophy style={{ width: 28, height: 28, color: GOLD, margin: '0 auto 8px' }} />
            <div style={{ fontWeight: 800, fontSize: 16 }}>Félicitations! 🇫🇷</div>
            <div style={{ fontSize: 13, opacity: 0.9 }}>You've completed all 30-day tasks. Paris is your home!</div>
            <button onClick={() => setConfetti(false)} style={{ marginTop: 10, padding: '6px 14px', borderRadius: 20, background: 'rgba(255,255,255,0.15)', border: 'none', cursor: 'pointer', color: '#fff', fontSize: 12 }}>Dismiss</button>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
