'use client';
import Link from 'next/link';
import { useState, useEffect, Suspense } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Sparkles, ArrowRight, TrendingUp, User, ChevronRight, Zap } from 'lucide-react';
import { useLanguage } from '@/lib/i18n/LanguageContext';
import PageMotion, { FadeIn } from '@/components/shared/PageMotion';
import StatCard from '@/components/shared/StatCard';
import dynamic from 'next/dynamic';
const MarcelDashboard = dynamic(() => import('@/components/shared/MarcelDashboard'), { ssr: false });

const GOLD = '#FFD700';
const NAVY = '#002654';
const RED  = '#ED2939';

const ALL_TOOLS = [
  { emoji: '✈️', title: 'Arrival Mode',    desc: 'CDG/Orly → your door in 90 min',           path: '/arrival',       color: '#4A90D9', new: true },
  { emoji: '🌐', title: 'AI Translation',  desc: 'Text & camera OCR — 6 languages',           path: '/translate',     color: '#30D158' },
  { emoji: '💶', title: 'Budget & Meals',  desc: 'Expense tracker + AI meal planner',          path: '/budget',        color: '#34C759' },
  { emoji: '🗺️', title: 'Itinerary AI',   desc: 'Generate full day plans in seconds',         path: '/itinerary',     color: '#FF9F0A' },
  { emoji: '🚇', title: 'Navigo Optimizer',desc: 'Stop overpaying — find your ideal pass',     path: '/navigo',        color: '#0A84FF', new: true },
  { emoji: '🚆', title: 'Commute Planner', desc: 'IDFM Métro, RER & Bus routes',              path: '/commute',       color: '#5E5CE6' },
  { emoji: '🏛️', title: 'Admin Guide',     desc: 'Préfecture, CAF, CVEC & more',              path: '/admin',         color: '#30D158', new: true },
  { emoji: '🏠', title: 'Housing Finder',  desc: 'Platforms, CAF, guarantors, scam alerts',   path: '/housing',       color: '#34C759', new: true },
  { emoji: '🏘️', title: 'Neighbourhoods', desc: 'Deep-dive guides for every arrondissement',  path: '/neighborhoods', color: '#FFD700', new: true },
  { emoji: '📍', title: 'Explore Map',     desc: '35+ Paris POIs on satellite 3D map',         path: '/explore',       color: '#64D2FF' },
  { emoji: '💬', title: 'AI Chat Guide',   desc: 'Ask anything — send photos too',             path: '/chat',          color: '#BF5AF2' },
  { emoji: '🏆', title: 'Quest & Badges',  desc: 'Earn XP exploring Paris',                    path: '/quest',         color: '#FF9F0A' },
];

const TIPS = [
  { tip: 'The Navigo Liberté+ card lets you top up trips individually — great for occasional travel.', icon: '🚇' },
  { tip: 'Most Paris museums are free on the first Sunday of each month. Plan accordingly.', icon: '🏛️' },
  { tip: 'Supermarché happy hour: Monoprix & Franprix discount fresh food after 7 pm.', icon: '🛒' },
  { tip: 'Book your préfecture appointment at 8:00 AM sharp — slots fill within minutes.', icon: '⏰' },
  { tip: 'CAF housing aid can reduce your rent by €80–250/month — apply within 3 months of moving in.', icon: '🏠' },
  { tip: 'Students under 26 save ~€57/month with ImagineR vs the standard monthly Navigo.', icon: '💡' },
];

const SECRETS = [
  { emoji: '🧀', title: 'Fromage Passport', path: '/fromage-passport', color: '#FFD700' },
  { emoji: '🌅', title: 'Window Light',     path: '/window-light',     color: '#FF9F0A' },
  { emoji: '🐦', title: 'Pigeon Translator',path: '/pigeon-translator', color: '#BF5AF2' },
  { emoji: '🌧️', title: 'Rainy Day Mode',  path: '/rainy-day',         color: '#64D2FF' },
  { emoji: '🗝️', title: 'Secret Paris',    path: '/secret-paris',      color: '#FFD700' },
  { emoji: '🪦', title: 'Famous Graves',   path: '/famous-graves',     color: '#8E8E93' },
];

function getGreeting(lang: string) {
  const h = new Date().getHours();
  const greetings: Record<string, string[]> = {
    en: ['Bonjour', 'Bon après-midi', 'Bonsoir'],
    fr: ['Bonjour', 'Bon après-midi', 'Bonsoir'],
    ar: ['صباح الخير', 'مساء النور', 'مساء الخير'],
    pt: ['Bom dia', 'Boa tarde', 'Boa noite'],
    zh: ['早上好', '下午好', '晚上好'],
    hi: ['सुप्रभात', 'नमस्कार', 'शुभ संध्या'],
  };
  const set = greetings[lang] ?? greetings['en'];
  if (h < 12) return set[0];
  if (h < 18) return set[1];
  return set[2];
}

function getCalendarAlert() {
  const m = new Date().getMonth() + 1;
  const alerts: Record<number, { msg: string; color: string; icon: string }> = {
    2:  { msg: 'Parcoursup opens this month — submit your choices before March 13', color: '#0A84FF', icon: '📚' },
    6:  { msg: 'URGENT: Book your préfecture appointment NOW before August closure', color: RED, icon: '🚨' },
    7:  { msg: 'Préfecture partially closed — emergency admin only from Aug 1', color: '#FF9F0A', icon: '⚠️' },
    8:  { msg: 'Most préfectures CLOSED. File everything online this week', color: RED, icon: '🔴' },
    9:  { msg: 'Rentrée: CVEC fee due · Register Sécurité Sociale · CAF application open', color: '#30D158', icon: '📅' },
    10: { msg: 'CVEC deadline approaching Oct 15 · CAF housing aid window open', color: '#FF9F0A', icon: '⏰' },
  };
  return alerts[m] || null;
}

/* ─── Tool Card ─────────────────────────────────────────────────────────────── */
function ToolCard({ tool, index }: { tool: typeof ALL_TOOLS[0]; index: number }) {
  const [hovered, setHovered] = useState(false);
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.04 + index * 0.045, type: 'spring', stiffness: 300, damping: 24 }}
      onHoverStart={() => setHovered(true)}
      onHoverEnd={() => setHovered(false)}
      whileHover={{ y: -3, scale: 1.02 }}
      whileTap={{ scale: 0.97 }}
    >
      <Link href={tool.path} style={{ textDecoration: 'none', display: 'block', height: '100%' }}>
        <div style={{
          padding: '1.2rem 1.25rem 1rem',
          borderRadius: 18, height: '100%',
          background: hovered
            ? `linear-gradient(135deg, rgba(21,26,35,0.9) 0%, ${tool.color}0D 100%)`
            : 'rgba(21,26,35,0.7)',
          border: `1px solid ${hovered ? tool.color + '40' : 'rgba(255,255,255,0.07)'}`,
          backdropFilter: 'blur(20px)',
          position: 'relative', overflow: 'hidden',
          cursor: 'pointer', transition: 'background 0.25s, border-color 0.25s',
          boxShadow: hovered ? `0 12px 40px rgba(0,0,0,0.35), 0 0 0 0.5px ${tool.color}25` : '0 2px 12px rgba(0,0,0,0.2)',
        }}>
          {/* Ambient glow top-right */}
          <div style={{
            position: 'absolute', top: -24, right: -24, width: 80, height: 80,
            borderRadius: '50%',
            background: `radial-gradient(circle, ${tool.color}20, transparent 70%)`,
            pointerEvents: 'none', transition: 'opacity 0.25s',
            opacity: hovered ? 1 : 0.5,
          }} />

          {tool.new && (
            <div style={{
              position: 'absolute', top: 10, right: 10,
              fontSize: 9, fontWeight: 800, color: '#0B0E14',
              background: GOLD, padding: '2px 7px', borderRadius: 20,
              letterSpacing: '0.06em', textTransform: 'uppercase',
            }}>NEW</div>
          )}

          <div style={{ fontSize: 26, marginBottom: '0.7rem', lineHeight: 1 }}>{tool.emoji}</div>
          <div style={{
            fontWeight: 700, color: '#F5F5F7', marginBottom: '0.3rem',
            fontSize: 13.5, letterSpacing: '-0.01em',
          }}>
            {tool.title}
          </div>
          <div style={{ fontSize: 11.5, color: '#8E8E93', lineHeight: 1.6, marginBottom: '0.75rem' }}>
            {tool.desc}
          </div>
          <div style={{
            display: 'flex', alignItems: 'center', gap: 4,
            fontSize: 11, fontWeight: 700,
            color: hovered ? tool.color : '#3A3A3C',
            transition: 'color 0.2s',
          }}>
            Open <ArrowRight style={{ width: 11, height: 11 }} />
          </div>
        </div>
      </Link>
    </motion.div>
  );
}

/* ─── Dashboard Page ─────────────────────────────────────────────────────────── */
export default function DashboardPage() {
  const { lang } = useLanguage();
  const tip   = TIPS[new Date().getDay() % TIPS.length];
  const alert = getCalendarAlert();
  const [hasProfile,   setHasProfile]   = useState(false);
  const [profileName,  setProfileName]  = useState('');
  const [xpEarned,     setXpEarned]     = useState(false);

  useEffect(() => {
    try {
      const p = localStorage.getItem('paris_profile');
      if (p) {
        const parsed = JSON.parse(p);
        setHasProfile(true);
        setProfileName(parsed.name || '');
      }
    } catch {}
  }, []);

  return (
    <PageMotion style={{ padding: 'clamp(1.25rem, 3vw, 2.25rem) clamp(1rem, 4vw, 2.5rem)', maxWidth: 1180, margin: '0 auto' }}>

      {/* ── Hero Greeting ──────────────────────────────────────────────── */}
      <FadeIn>
        <div style={{ marginBottom: '2rem' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 7, marginBottom: 6 }}>
            <motion.div
              animate={{ rotate: [0, 12, -8, 0], scale: [1, 1.1, 1] }}
              transition={{ duration: 2.5, repeat: Infinity, repeatDelay: 5 }}>
              <Sparkles style={{ width: 16, height: 16, color: GOLD }} />
            </motion.div>
            <span style={{
              fontSize: 11, fontWeight: 700, color: GOLD,
              textTransform: 'uppercase', letterSpacing: '0.12em',
            }}>
              Your AI Paris Companion
            </span>
          </div>

          <h1 style={{
            fontFamily: 'Playfair Display, serif',
            fontSize: 'clamp(2rem, 4vw, 3rem)',
            fontWeight: 800, lineHeight: 1.1,
            letterSpacing: '-0.025em',
            color: '#F5F5F7',
            marginBottom: '0.5rem',
          }}>
            {getGreeting(lang)}{profileName ? `, ${profileName}` : ''} 👋
          </h1>

          <p style={{ color: '#8E8E93', fontSize: '1rem', fontWeight: 400, letterSpacing: '-0.005em' }}>
            Everything you need for life in Paris & Île-de-France
          </p>
        </div>
      </FadeIn>

      {/* ── Marcel / Onboarding panel ─────────────────────────────────── */}
      {hasProfile ? (
        <MarcelDashboard />
      ) : (
        <motion.div
          initial={{ opacity: 0, y: -8 }} animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.12 }}
          style={{
            padding: '1.4rem 1.6rem', borderRadius: 20,
            background: 'linear-gradient(135deg, rgba(0,38,84,0.18) 0%, rgba(255,215,0,0.04) 100%)',
            border: '1px solid rgba(0,38,84,0.45)',
            marginBottom: '1.5rem',
            display: 'flex', alignItems: 'center', justifyContent: 'space-between',
            gap: '1rem', flexWrap: 'wrap',
            backdropFilter: 'blur(20px)',
            boxShadow: '0 4px 32px rgba(0,0,0,0.25)',
          }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '1rem' }}>
            {/* Animated Marcel avatar */}
            <motion.div
              animate={{ y: [0, -3, 0] }}
              transition={{ duration: 3, repeat: Infinity, ease: 'easeInOut' }}
              style={{
                width: 48, height: 48, borderRadius: 14,
                background: 'linear-gradient(135deg, #002654 0%, #004082 100%)',
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                fontSize: 24, flexShrink: 0,
                border: '1px solid rgba(255,215,0,0.25)',
                boxShadow: '0 4px 20px rgba(0,38,84,0.5)',
              }}>
              🧑‍🎨
            </motion.div>
            <div>
              <div style={{ fontWeight: 700, color: '#F5F5F7', fontSize: 14.5, marginBottom: 4, letterSpacing: '-0.01em' }}>
                Meet Marcel — Your Personal Paris AI
              </div>
              <p style={{ color: '#8E8E93', fontSize: 12.5, lineHeight: 1.55, maxWidth: 460 }}>
                Answer 7 quick questions and Marcel builds your personalised to-do timeline,
                settled-in score, and recommends exactly what you need first.
              </p>
            </div>
          </div>
          <Link href="/onboarding" style={{ textDecoration: 'none', flexShrink: 0 }}>
            <motion.div whileHover={{ scale: 1.04 }} whileTap={{ scale: 0.97 }} style={{
              display: 'inline-flex', alignItems: 'center', gap: 7,
              padding: '11px 22px', borderRadius: 14,
              background: 'linear-gradient(135deg, #002654 0%, #0052A5 100%)',
              color: '#F5F5F7', fontWeight: 700, fontSize: 13,
              boxShadow: '0 4px 20px rgba(0,38,84,0.45)',
              border: '1px solid rgba(255,255,255,0.08)',
            }}>
              <User style={{ width: 14, height: 14 }} /> Set up my profile
            </motion.div>
          </Link>
        </motion.div>
      )}

      {/* ── Calendar alert ────────────────────────────────────────────── */}
      <AnimatePresence>
        {alert && (
          <motion.div
            initial={{ opacity: 0, y: -6 }} animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0 }} transition={{ delay: 0.2 }}
            style={{
              padding: '12px 16px', borderRadius: 14,
              background: `${alert.color}12`,
              border: `1px solid ${alert.color}35`,
              marginBottom: '1.5rem',
              display: 'flex', alignItems: 'center', gap: 10,
            }}>
            <span style={{ fontSize: 18, flexShrink: 0 }}>{alert.icon}</span>
            <span style={{ fontSize: 13, fontWeight: 600, color: alert.color, lineHeight: 1.5 }}>
              {alert.msg}
            </span>
          </motion.div>
        )}
      </AnimatePresence>

      {/* ── Stats row ─────────────────────────────────────────────────── */}
      <div style={{
        display: 'grid',
        gridTemplateColumns: 'repeat(auto-fit, minmax(130px, 1fr))',
        gap: '0.75rem', marginBottom: '2.25rem',
      }}>
        <StatCard value={12}  label="AI Modules"    color="#4A90D9" delay={0}    />
        <StatCard value={6}   label="Languages"     color="#30D158" delay={0.07} />
        <StatCard value={35}  label="Paris POIs"    color="#FF9F0A" suffix="+"   delay={0.14} />
        <StatCard value={25}  label="Badges"        color="#ED2939" suffix="+"   delay={0.21} />
        <StatCard value={100} label="Free & Private" color={GOLD}   suffix="%"   delay={0.28} />
      </div>

      {/* ── All Tools ─────────────────────────────────────────────────── */}
      <FadeIn delay={0.18}>
        <div style={{
          display: 'flex', alignItems: 'center', justifyContent: 'space-between',
          marginBottom: '1.1rem', flexWrap: 'wrap', gap: '0.5rem',
        }}>
          <div>
            <h2 style={{
              fontWeight: 700, color: '#F5F5F7', fontSize: 17,
              letterSpacing: '-0.02em', marginBottom: 2,
            }}>
              All Tools
            </h2>
            <p style={{ fontSize: 12, color: '#8E8E93' }}>
              12 AI-powered modules for students & newcomers
            </p>
          </div>
          <motion.div whileHover={{ scale: 1.03 }} style={{
            display: 'flex', alignItems: 'center', gap: 6,
            padding: '5px 12px', borderRadius: 20,
            background: 'rgba(48,209,88,0.08)',
            border: '1px solid rgba(48,209,88,0.22)',
          }}>
            <div style={{
              width: 6, height: 6, borderRadius: '50%', background: '#30D158',
              boxShadow: '0 0 6px #30D158',
            }} className="pulse-dot" />
            <span style={{ fontSize: 11, fontWeight: 700, color: '#30D158' }}>5 NEW features</span>
          </motion.div>
        </div>
      </FadeIn>

      <div style={{
        display: 'grid',
        gridTemplateColumns: 'repeat(auto-fill, minmax(210px, 1fr))',
        gap: '0.875rem', marginBottom: '2.5rem',
      }}>
        {ALL_TOOLS.map((tool, i) => (
          <ToolCard key={tool.path} tool={tool} index={i} />
        ))}
      </div>

      {/* ── Paris+ Secrets strip ──────────────────────────────────────── */}
      <FadeIn delay={0.35}>
        <div style={{
          marginBottom: '2rem', padding: '1.4rem 1.6rem', borderRadius: 20,
          background: 'linear-gradient(135deg, rgba(191,90,242,0.08) 0%, rgba(255,215,0,0.04) 100%)',
          border: '1px solid rgba(191,90,242,0.2)',
          backdropFilter: 'blur(20px)',
        }}>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '1rem', flexWrap: 'wrap', gap: '0.5rem' }}>
            <div>
              <div style={{ display: 'flex', alignItems: 'center', gap: 7, marginBottom: 3 }}>
                <span style={{ fontSize: 16 }}>✨</span>
                <span style={{ fontSize: 11, fontWeight: 700, color: '#BF5AF2', textTransform: 'uppercase', letterSpacing: '0.1em' }}>
                  Paris+ Secrets
                </span>
              </div>
              <p style={{ fontSize: 12, color: '#8E8E93' }}>Ten quirky mini-apps, hidden Paris decoded</p>
            </div>
            <Link href="/secret-paris" style={{ textDecoration: 'none' }}>
              <motion.div whileHover={{ scale: 1.04 }} whileTap={{ scale: 0.97 }} style={{
                display: 'flex', alignItems: 'center', gap: 5, fontSize: 12, fontWeight: 700,
                color: '#BF5AF2', padding: '6px 14px', borderRadius: 20,
                border: '1px solid rgba(191,90,242,0.3)',
                background: 'rgba(191,90,242,0.08)',
              }}>
                Explore all <ChevronRight style={{ width: 13, height: 13 }} />
              </motion.div>
            </Link>
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(140px, 1fr))', gap: '0.6rem' }}>
            {SECRETS.map((s, i) => (
              <Link key={s.path} href={s.path} style={{ textDecoration: 'none' }}>
                <motion.div
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ delay: 0.4 + i * 0.06 }}
                  whileHover={{ scale: 1.05, y: -2 }}
                  whileTap={{ scale: 0.96 }}
                  style={{
                    display: 'flex', alignItems: 'center', gap: 8, padding: '10px 12px',
                    borderRadius: 12,
                    background: 'rgba(255,255,255,0.04)',
                    border: `1px solid ${s.color}25`,
                    cursor: 'pointer',
                  }}>
                  <span style={{ fontSize: 18 }}>{s.emoji}</span>
                  <span style={{ fontSize: 12, fontWeight: 600, color: '#F5F5F7' }}>{s.title}</span>
                </motion.div>
              </Link>
            ))}
          </div>
        </div>
      </FadeIn>

      {/* ── Daily tip ────────────────────────────────────────────────── */}
      <motion.div
        initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.65 }}
        style={{
          padding: '1.2rem 1.5rem', borderRadius: 18,
          background: 'linear-gradient(135deg, rgba(0,38,84,0.10) 0%, rgba(255,215,0,0.04) 100%)',
          border: '1px solid rgba(255,215,0,0.12)',
          backdropFilter: 'blur(20px)',
        }}>
        <div style={{ display: 'flex', gap: '1rem', alignItems: 'flex-start' }}>
          <div style={{
            width: 40, height: 40, borderRadius: 12, flexShrink: 0,
            background: 'rgba(255,215,0,0.10)',
            border: '1px solid rgba(255,215,0,0.18)',
            display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 20,
          }}>
            {tip.icon}
          </div>
          <div>
            <div style={{
              fontWeight: 700, color: '#F5F5F7', marginBottom: '0.35rem',
              fontSize: 13.5, display: 'flex', alignItems: 'center', gap: 6, letterSpacing: '-0.01em',
            }}>
              <TrendingUp style={{ width: 13, height: 13, color: GOLD }} />
              Marcel's Tip of the Day
            </div>
            <p style={{ fontSize: 13, color: '#8E8E93', lineHeight: 1.7 }}>{tip.tip}</p>
          </div>
        </div>
      </motion.div>

    </PageMotion>
  );
}
