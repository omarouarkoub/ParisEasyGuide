'use client';
import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Compass, Search, Heart, Layers } from 'lucide-react';
import { PARIS_POIS, POI_CATEGORIES, CATEGORY_LABELS, type PoiCategory } from '@/lib/parisPOIs';
import type { ParisPOI } from '@/types';
import ParisMap3D from '@/components/map/ParisMap3D';
import FavouritePins from '@/components/map/FavouritePins';
import { FadeIn } from '@/components/shared/PageMotion';

interface Pin { lat: number; lng: number; label: string; }

export default function ExplorePage() {
  const [selectedPOI, setSelectedPOI] = useState<ParisPOI | null>(null);
  const [category, setCategory] = useState<PoiCategory>('all');
  const [search, setSearch] = useState('');
  const [saved, setSaved] = useState<Set<string>>(new Set());
  const [pins, setPins] = useState<Pin[]>([]);
  const [mapMode, setMapMode] = useState<'satellite' | 'flat'>('satellite');

  const filtered = PARIS_POIS.filter(p =>
    (category === 'all' || p.category === category) &&
    (search === '' || p.name.toLowerCase().includes(search.toLowerCase()) || p.neighborhood.toLowerCase().includes(search.toLowerCase()))
  );

  const toggleSave = (id: string) => setSaved(prev => { const s = new Set(prev); s.has(id) ? s.delete(id) : s.add(id); return s; });

  const markers = selectedPOI ? [{ lat: selectedPOI.lat, lng: selectedPOI.lng, label: selectedPOI.name }] : [];

  return (
    <div style={{ padding: '2rem 2.5rem', maxWidth: 1200, margin: '0 auto' }}>
      <FadeIn>
        <div style={{ marginBottom: '1.5rem' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 4 }}>
            <Compass style={{ width: 16, height: 16, color: '#FFD700' }} />
            <span style={{ fontSize: 12, fontWeight: 600, color: '#FFD700', textTransform: 'uppercase', letterSpacing: '0.1em' }}>Explore</span>
          </div>
          <h1 style={{ fontFamily: 'Playfair Display, serif', fontSize: '2rem', fontWeight: 700, color: '#fff' }}>Explore Paris</h1>
          <p style={{ color: '#8E8E93', fontSize: 14 }}>35+ landmarks, culture, parks & Île-de-France day trips</p>
        </div>
      </FadeIn>

      {/* 3D Map */}
      <motion.div initial={{ opacity: 0, scale: 0.98 }} animate={{ opacity: 1, scale: 1 }} transition={{ delay: 0.1, duration: 0.5 }} style={{ marginBottom: '1.5rem' }}>
        <ParisMap3D markers={markers} pins={pins} onPinsChange={setPins} routeColor="#00bfff" height="360px" accentColor="#00bfff" />
      </motion.div>

      {/* Favourite pins */}
      {pins.length > 0 && (
        <div style={{ marginBottom: '1.5rem' }}>
          <FavouritePins pins={pins} onRemove={i => setPins(prev => prev.filter((_, idx) => idx !== i))} />
        </div>
      )}

      {/* Search + categories */}
      <FadeIn delay={0.2}>
        <div style={{ display: 'flex', gap: '1rem', marginBottom: '1.5rem', flexWrap: 'wrap', alignItems: 'center' }}>
          <div style={{ position: 'relative', flex: 1, minWidth: 200 }}>
            <Search style={{ position: 'absolute', left: 12, top: '50%', transform: 'translateY(-50%)', width: 14, height: 14, color: '#8E8E93' }} />
            <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search places, neighbourhoods…"
              style={{ width: '100%', background: 'rgba(255,255,255,0.06)', border: '1px solid rgba(255,255,255,0.1)', borderRadius: 12, padding: '10px 14px 10px 36px', color: '#fff', fontSize: 13, outline: 'none', boxSizing: 'border-box' }} />
          </div>
          <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}>
            {POI_CATEGORIES.map(c => (
              <motion.button key={c} whileTap={{ scale: 0.94 }} onClick={() => setCategory(c)}
                style={{ padding: '7px 14px', borderRadius: 20, fontSize: 12, fontWeight: 600, cursor: 'pointer', border: 'none', background: category === c ? '#00bfff' : 'rgba(255,255,255,0.06)', color: category === c ? '#000' : '#9ca3af', transition: 'all 0.2s' }}>
                {CATEGORY_LABELS[c]}
              </motion.button>
            ))}
          </div>
        </div>
      </FadeIn>

      {/* POI grid */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(220px, 1fr))', gap: '1rem' }}>
        <AnimatePresence mode="popLayout">
          {filtered.map((poi, i) => (
            <motion.div key={poi.id}
              layout
              initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0, scale: 0.85 }}
              transition={{ delay: i * 0.04, type: 'spring', stiffness: 300, damping: 24 }}
              whileHover={{ scale: 1.03, y: -3 }} whileTap={{ scale: 0.97 }}
              onClick={() => setSelectedPOI(selectedPOI?.id === poi.id ? null : poi)}
              style={{ borderRadius: 14, overflow: 'hidden', cursor: 'pointer', border: `1px solid ${selectedPOI?.id === poi.id ? poi.color + '88' : poi.color + '22'}`, background: selectedPOI?.id === poi.id ? `${poi.color}10` : 'rgba(255,255,255,0.03)', boxShadow: selectedPOI?.id === poi.id ? `0 0 20px ${poi.color}33` : 'none', transition: 'border-color 0.2s, box-shadow 0.2s' }}>
              <div style={{ position: 'relative', height: 110 }}>
                <img src={poi.photo} alt={poi.name} style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
                <div style={{ position: 'absolute', inset: 0, background: 'linear-gradient(to top, rgba(2,8,20,0.85) 0%, transparent 55%)' }} />
                <div style={{ position: 'absolute', top: 8, right: 8, display: 'flex', gap: 6 }}>
                  <motion.button whileTap={{ scale: 0.8 }} onClick={e => { e.stopPropagation(); toggleSave(poi.id); }}
                    style={{ width: 28, height: 28, borderRadius: '50%', background: 'rgba(0,0,0,0.5)', border: 'none', cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', color: saved.has(poi.id) ? '#ED2939' : '#9ca3af' }}>
                    <Heart style={{ width: 13, height: 13, fill: saved.has(poi.id) ? '#ED2939' : 'none' }} />
                  </motion.button>
                </div>
                <div style={{ position: 'absolute', bottom: 8, left: 10, fontSize: 20 }}>{poi.emoji}</div>
              </div>
              <div style={{ padding: '0.75rem' }}>
                <div style={{ fontWeight: 700, fontSize: 13, color: '#fff', marginBottom: 2 }}>{poi.name}</div>
                <div style={{ fontSize: 11, color: '#8E8E93', marginBottom: 4 }}>{poi.neighborhood}</div>
                <AnimatePresence>
                  {selectedPOI?.id === poi.id && (
                    <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: 'auto', opacity: 1 }} exit={{ height: 0, opacity: 0 }}>
                      <p style={{ fontSize: 11, color: '#8E8E93', lineHeight: 1.6, marginBottom: 8 }}>{poi.tagline}</p>
                      <a href={`https://www.google.com/maps/search/?api=1&query=${poi.lat},${poi.lng}`} target="_blank" rel="noreferrer" onClick={e => e.stopPropagation()}
                        style={{ display: 'inline-flex', alignItems: 'center', gap: 4, fontSize: 11, fontWeight: 600, color: '#60a5fa', textDecoration: 'none' }}>
                        🗺 Get directions
                      </a>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            </motion.div>
          ))}
        </AnimatePresence>
      </div>

      {filtered.length === 0 && (
        <div style={{ textAlign: 'center', padding: '4rem', color: '#4b5563' }}>
          <div style={{ fontSize: '2.5rem', marginBottom: '0.75rem' }}>🔍</div>
          <div style={{ fontSize: 14 }}>No places match your search</div>
        </div>
      )}
    </div>
  );
}
