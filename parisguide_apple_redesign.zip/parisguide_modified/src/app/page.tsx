import Link from 'next/link';
import { Sparkles, ArrowRight, Star, Shield, Zap } from 'lucide-react';

const FEATURES = [
  { emoji: '🤖', title: 'Marcel AI Profile',     desc: 'Answer 7 questions and get a personalised to-do timeline, settled-in score & recommendations',    color: '#FFD700', new: true },
  { emoji: '✈️', title: 'Arrival Mode',        desc: 'CDG/Orly → your door — step-by-step AI guide with metro tips, validation warnings & urgent admin',     color: '#002654', new: true },
  { emoji: '🚇', title: 'Navigo Optimizer',     desc: 'Stop overpaying. Find your optimal pass: Imagine\'R, Liberté+, or Mois — with zone analysis',          color: '#2563eb', new: true },
  { emoji: '🏛️', title: 'Admin Guide',          desc: 'Titre de séjour, CAF, CVEC, Sécurité Sociale — your AI bureaucracy navigator in 3 languages',          color: '#059669', new: true },
  { emoji: '🏠', title: 'Housing Finder',       desc: 'Platforms, guarantor options, CAF eligibility, scam warnings & document checklist',                     color: '#10b981', new: true },
  { emoji: '🏘️', title: 'Neighbourhoods',      desc: 'Deep-dive guides: student score, hidden gems, food guide, transport & seasonal tips',                   color: '#f59e0b', new: true },
  { emoji: '🌐', title: 'AI Translation',       desc: 'Text & camera OCR in French, English, Arabic with pronunciation for French phrases',                    color: '#7c3aed' },
  { emoji: '💶', title: 'Budget & Meals',       desc: '7-day AI meal planner + expense tracker with Parisian budget tips',                                     color: '#34d399' },
  { emoji: '🗺️', title: 'Itinerary AI',        desc: 'Generate full day Paris plans in seconds — check off steps as you go',                                  color: '#ea580c' },
  { emoji: '🚆', title: 'Commute Planner',      desc: 'Real IDFM Navitia routes with live Métro, RER & Bus journey planning',                                 color: '#3b82f6' },
  { emoji: '📍', title: 'Explore Map',          desc: '35+ POIs on satellite 3D map — pin your own locations',                                                 color: '#00bfff' },
  { emoji: '💬', title: 'AI Chat Guide',        desc: 'Send photos, share location, ask in any language — your Paris AI companion',                            color: '#db2777' },
  { emoji: '🏆', title: 'Quest & Badges',       desc: 'Earn XP and 25+ badges as you explore Paris & Île-de-France',                                          color: '#d97706' },
];

const STATS = [
  { value: '13', label: 'AI Modules',    icon: Zap },
  { value: '3',  label: 'Languages',     icon: Star },
  { value: '6',  label: 'New Features',  icon: Sparkles },
  { value: '0',  label: 'Cost',          icon: Shield, suffix: '€' },
];

export default function LandingPage() {
  return (
    <div style={{ minHeight: '100vh', background: 'hsl(210,30%,6%)', position: 'relative', overflow: 'hidden' }}>
      {/* BG blobs */}
      <div style={{ position: 'fixed', inset: 0, pointerEvents: 'none' }}>
        <div style={{ position: 'absolute', top: '-20%', left: '-10%', width: 600, height: 600, borderRadius: '50%', background: 'rgba(0,38,84,0.12)', filter: 'blur(120px)' }} />
        <div style={{ position: 'absolute', bottom: '-10%', right: '-10%', width: 500, height: 500, borderRadius: '50%', background: 'rgba(238,36,54,0.08)', filter: 'blur(100px)' }} />
        <div style={{ position: 'absolute', top: '40%', left: '50%', width: 400, height: 400, borderRadius: '50%', background: 'rgba(255,215,0,0.04)', filter: 'blur(80px)' }} />
      </div>

      <div style={{ position: 'relative', maxWidth: 1152, margin: '0 auto', padding: '2rem 1.5rem 4rem' }}>
        {/* Nav */}
        <nav style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '5rem' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
            <div style={{ width: 32, height: 32, borderRadius: 8, overflow: 'hidden', display: 'flex', border: '1px solid rgba(255,215,0,0.4)' }}>
              <div style={{ flex: 1, background: '#002395' }} /><div style={{ flex: 1, background: '#FFFFFF' }} /><div style={{ flex: 1, background: '#ED2939' }} />
            </div>
            <div>
              <div style={{ fontWeight: 700, fontSize: 14, color: '#FFD700' }}>ParisEasyGuide+</div>
              <div style={{ fontSize: 9, color: '#4b5563' }}>Powered by Claude AI</div>
            </div>
          </div>
          <Link href="/dashboard" style={{ display: 'inline-flex', alignItems: 'center', gap: 8, padding: '10px 22px', borderRadius: 12, fontSize: 14, fontWeight: 700, color: '#fff', background: 'linear-gradient(135deg,#004082,#0052A5)', textDecoration: 'none', boxShadow: '0 0 24px rgba(0,38,84,0.35)' }}>
            Open App <ArrowRight style={{ width: 14, height: 14 }} />
          </Link>
        </nav>

        {/* Hero */}
        <div style={{ textAlign: 'center', marginBottom: '4rem' }}>
          <div style={{ display: 'inline-flex', alignItems: 'center', gap: 8, padding: '7px 16px', borderRadius: 9999, marginBottom: '1.5rem', background: 'rgba(0,38,84,0.15)', border: '1px solid rgba(0,38,84,0.3)', color: '#3a7bd5', fontSize: 13, fontWeight: 600 }}>
            <Sparkles style={{ width: 14, height: 14, color: '#FFD700' }} />
            12 AI modules · 5 new features · Built for Paris students
          </div>
          <h1 style={{ fontFamily: 'Playfair Display, serif', fontSize: 'clamp(2.5rem,6vw,4.5rem)', fontWeight: 700, lineHeight: 1.12, marginBottom: '1.5rem', color: '#fff' }}>
            Navigate Paris<br /><span style={{ background: 'linear-gradient(135deg,#3a7bd5,#FFD700)', WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent', backgroundClip: 'text' }}>with AI superpowers</span>
          </h1>
          <p style={{ fontSize: '1.15rem', color: '#8E8E93', maxWidth: 580, margin: '0 auto 2.5rem', lineHeight: 1.75 }}>
            The complete app for international students & newcomers in Paris. From CDG arrival to titre de séjour — in French, English & Arabic.
          </p>
          <div style={{ display: 'flex', gap: '1rem', justifyContent: 'center', flexWrap: 'wrap' }}>
            <Link href="/arrival" style={{ display: 'inline-flex', alignItems: 'center', gap: 8, padding: '15px 32px', borderRadius: 14, fontWeight: 800, fontSize: '1rem', color: '#fff', background: 'linear-gradient(135deg,#004082,#0052A5)', boxShadow: '0 0 40px rgba(0,38,84,0.4)', textDecoration: 'none' }}>
              ✈️ Start Arrival Mode
            </Link>
            <Link href="/dashboard" style={{ display: 'inline-flex', alignItems: 'center', gap: 8, padding: '15px 32px', borderRadius: 14, fontWeight: 700, fontSize: '1rem', color: '#e5e7eb', border: '1px solid rgba(255,255,255,0.12)', textDecoration: 'none', background: 'rgba(255,255,255,0.04)' }}>
              Browse All Tools <ArrowRight style={{ width: 16, height: 16 }} />
            </Link>
          </div>
        </div>

        {/* Stats */}
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit,minmax(160px,1fr))', gap: '1rem', marginBottom: '4rem' }}>
          {STATS.map(s => (
            <div key={s.label} style={{ padding: '1.25rem', borderRadius: 16, background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.08)', textAlign: 'center', backdropFilter: 'blur(20px)' }}>
              <s.icon style={{ width: 18, height: 18, margin: '0 auto 8px', color: '#FFD700' }} />
              <div style={{ fontSize: '2rem', fontWeight: 800, color: '#FFD700' }}>{s.suffix || ''}{s.value}</div>
              <div style={{ fontSize: 12, color: '#8E8E93', marginTop: 3 }}>{s.label}</div>
            </div>
          ))}
        </div>

        {/* Feature grid */}
        <div style={{ marginBottom: '4rem' }}>
          <h2 style={{ fontFamily: 'Playfair Display, serif', fontSize: '2rem', fontWeight: 700, textAlign: 'center', color: '#fff', marginBottom: '0.5rem' }}>Everything in one app</h2>
          <p style={{ color: '#8E8E93', textAlign: 'center', marginBottom: '2.5rem', fontSize: 14 }}>Built specifically for the Île-de-France student experience</p>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill,minmax(250px,1fr))', gap: '1rem' }}>
            {FEATURES.map(f => (
              <Link key={f.title} href="/dashboard" style={{ textDecoration: 'none' }}>
                <div style={{ padding: '1.25rem', borderRadius: 14, background: 'rgba(255,255,255,0.03)', border: `1px solid ${f.color}28`, backdropFilter: 'blur(20px)', height: '100%', position: 'relative', overflow: 'hidden' }}>
                  {f.new && <div style={{ position: 'absolute', top: 8, right: 8, fontSize: 9, fontWeight: 800, color: '#fff', background: '#ef4444', padding: '2px 6px', borderRadius: 20 }}>NEW</div>}
                  <div style={{ fontSize: 22, marginBottom: '0.75rem' }}>{f.emoji}</div>
                  <div style={{ fontWeight: 700, color: '#fff', marginBottom: '0.4rem', fontSize: 14 }}>{f.title}</div>
                  <div style={{ fontSize: 12, color: '#8E8E93', lineHeight: 1.65 }}>{f.desc}</div>
                </div>
              </Link>
            ))}
          </div>
        </div>

        {/* CTA */}
        <div style={{ textAlign: 'center', padding: '3rem 2rem', borderRadius: 24, background: 'rgba(255,255,255,0.03)', border: '1px solid rgba(255,215,0,0.18)' }}>
          <div style={{ fontSize: '3rem', marginBottom: '1rem' }}>🗼</div>
          <h2 style={{ fontFamily: 'Playfair Display, serif', fontSize: '2rem', fontWeight: 700, color: '#fff', marginBottom: '0.75rem' }}>Ready to simplify Paris?</h2>
          <p style={{ color: '#8E8E93', marginBottom: '2rem', fontSize: 14 }}>Free, private, no account required to start</p>
          <Link href="/arrival" style={{ display: 'inline-flex', alignItems: 'center', gap: 8, padding: '14px 32px', borderRadius: 14, fontWeight: 800, color: '#fff', background: 'linear-gradient(135deg,#004082,#0052A5)', textDecoration: 'none', boxShadow: '0 0 32px rgba(0,38,84,0.35)' }}>
            <Sparkles style={{ width: 16, height: 16, color: '#FFD700' }} /> Start for Free
          </Link>
        </div>

        <div style={{ textAlign: 'center', color: '#3A3A3C', fontSize: 11, padding: '2rem 0 0' }}>
          © 2025 ParisEasyGuide+ · Next.js 15 · Supabase · Claude AI · IDFM · 🇫🇷
        </div>
      </div>
    </div>
  );
}
