'use client';
import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Plane, MapPin, Loader2, AlertTriangle, CheckCircle2, Phone, ShoppingCart, Building2, Wifi, ChevronRight, Volume2, Navigation } from 'lucide-react';
import { useLanguage, LANGUAGES } from '@/lib/i18n/LanguageContext';
import { toast } from 'sonner';
import { FadeIn } from '@/components/shared/PageMotion';
import ParisMap3D from '@/components/map/ParisMap3D';

const TERMINALS = ['CDG Terminal 1', 'CDG Terminal 2E', 'CDG Terminal 2F', 'CDG Terminal 3', 'Orly Terminal 1', 'Orly Terminal 2', 'Orly Terminal 3', 'Orly Terminal 4'];
const PROFILES = ['International student (first time)', 'Exchange student (Erasmus)', 'Student returning from break', 'New worker/intern', 'Tourist'];

interface ArrivalPlan {
  transport: { recommendation: string; line: string; cost: string; duration: string; departure_tip: string; navigo_advice: string; validation_warning: string; };
  steps: { step: number; icon: string; action: string; french_phrase?: string; critical?: boolean; fine?: string; }[];
  neighbourhood_intel: { nearest_supermarket: string; nearest_pharmacy: string; nearest_prefecture: string; sim_card: string; nearest_bank: string; };
  tonight: { meal: string; wifi: string; emergency_numbers: Record<string, string>; };
  urgent_admin: { task: string; deadline: string; url?: string; priority: string; }[];
  welcome_message: string;
}

function speak(text: string) {
  if (!('speechSynthesis' in window)) return;
  const u = new SpeechSynthesisUtterance(text);
  u.lang = 'fr-FR';
  speechSynthesis.speak(u);
}

function getCalendarUrgency(): { msg: string; color: string } | null {
  const m = new Date().getMonth() + 1;
  const map: Record<number, { msg: string; color: string }> = {
    6: { msg: '🚨 June: Book your préfecture appointment TODAY — August closure in 6 weeks', color: '#ef4444' },
    7: { msg: '⚠️ July: Préfecture partially closed. Book titre de séjour renewal immediately', color: '#f59e0b' },
    8: { msg: '🔴 August: Most préfectures CLOSED. File everything online now', color: '#ef4444' },
    9: { msg: '📅 September: CVEC fee due. Register for Sécurité Sociale this week', color: '#3b82f6' },
  };
  return map[m] || null;
}

export default function ArrivalPage() {
  const { lang } = useLanguage();
  const langLabel = LANGUAGES.find(l => l.code === lang)?.label ?? "English";
  const [terminal, setTerminal] = useState('CDG Terminal 2F');
  const [destination, setDestination] = useState('');
  const [profile, setProfile] = useState(PROFILES[0]);
  const [plan, setPlan] = useState<ArrivalPlan | null>(null);
  const [loading, setLoading] = useState(false);
  const [completedSteps, setCompletedSteps] = useState<Set<number>>(new Set());
  const [detecting, setDetecting] = useState(false);

  const urgency = getCalendarUrgency();

  const detectAirport = () => {
    setDetecting(true);
    navigator.geolocation?.getCurrentPosition(pos => {
      const { latitude: lat, longitude: lng } = pos.coords;
      // CDG bounding box
      if (lat > 48.99 && lat < 49.03 && lng > 2.52 && lng < 2.58) setTerminal('CDG Terminal 2F');
      // Orly bounding box
      else if (lat > 48.71 && lat < 48.74 && lng > 2.35 && lng < 2.40) setTerminal('Orly Terminal 2');
      else toast.info('Could not detect airport — please select manually');
      setDetecting(false);
    }, () => { setDetecting(false); toast.error('Location access denied'); }, { timeout: 8000 });
  };

  const generate = async () => {
    if (!destination.trim()) { toast.error('Please enter your destination address'); return; }
    setLoading(true); setPlan(null); setCompletedSteps(new Set());
    try {
      const res = await fetch('/api/arrival', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ destination, terminal, arrivalTime: new Date().toLocaleTimeString(), profile }),
      });
      const data = await res.json();
      if (data.plan) { setPlan(data.plan); toast.success('Your Paris arrival plan is ready!'); }
      else toast.error('Could not generate plan. Please try again.');
    } catch { toast.error('Failed to connect. Check your connection.'); }
    finally { setLoading(false); }
  };

  const toggleStep = (i: number) => setCompletedSteps(prev => { const s = new Set(prev); s.has(i) ? s.delete(i) : s.add(i); return s; });

  const mapMarkers = destination ? [{ lat: 48.8566, lng: 2.3522, label: destination }] : [];

  return (
    <div style={{ padding: '2rem 2.5rem', maxWidth: 1100, margin: '0 auto' }}>
      <FadeIn>
        <div style={{ marginBottom: '2rem' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 4 }}>
            <Plane style={{ width: 16, height: 16, color: '#FFD700' }} />
            <span style={{ fontSize: 12, fontWeight: 600, color: '#FFD700', textTransform: 'uppercase', letterSpacing: '0.1em' }}>Arrival Mode</span>
          </div>
          <h1 style={{ fontFamily: 'Playfair Display, serif', fontSize: '2rem', fontWeight: 700, color: '#fff' }}>First Hour in Paris</h1>
          <p style={{ color: '#8E8E93', fontSize: 14 }}>AI-powered arrival guide from CDG/Orly to your door</p>
        </div>
      </FadeIn>

      {/* Calendar urgency banner */}
      {urgency && (
        <motion.div initial={{ opacity: 0, y: -8 }} animate={{ opacity: 1, y: 0 }}
          style={{ padding: '12px 16px', borderRadius: 12, background: `${urgency.color}18`, border: `1px solid ${urgency.color}55`, marginBottom: '1.5rem', fontSize: 13, color: urgency.color, fontWeight: 600 }}>
          {urgency.msg}
        </motion.div>
      )}

      <div style={{ display: 'grid', gridTemplateColumns: plan ? '1fr 1fr' : '1fr', gap: '2rem' }}>
        {/* Left: Input */}
        <div>
          <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }}
            style={{ padding: '1.5rem', borderRadius: 16, background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.08)', marginBottom: '1.5rem' }}>
            <h2 style={{ fontWeight: 700, color: '#fff', marginBottom: '1.25rem', fontSize: 15 }}>Where are you right now?</h2>

            {/* Terminal */}
            <div style={{ marginBottom: '1.25rem' }}>
              <label style={{ fontSize: 11, fontWeight: 700, color: '#8E8E93', textTransform: 'uppercase', letterSpacing: '0.06em', display: 'block', marginBottom: 8 }}>Airport & Terminal</label>
              <div style={{ display: 'flex', gap: 8 }}>
                <select value={terminal} onChange={e => setTerminal(e.target.value)}
                  style={{ flex: 1, background: 'rgba(255,255,255,0.06)', border: '1px solid rgba(255,255,255,0.12)', borderRadius: 10, padding: '10px 14px', color: '#fff', fontSize: 14, outline: 'none', cursor: 'pointer' }}>
                  {TERMINALS.map(t => <option key={t} value={t} style={{ background: '#0d1117' }}>{t}</option>)}
                </select>
                <motion.button whileTap={{ scale: 0.95 }} onClick={detectAirport} disabled={detecting}
                  style={{ padding: '10px 14px', borderRadius: 10, background: 'rgba(0,38,84,0.2)', border: '1px solid rgba(0,38,84,0.4)', cursor: 'pointer', color: '#60a5fa', display: 'flex', alignItems: 'center', gap: 6, fontSize: 13, fontWeight: 600, flexShrink: 0 }}>
                  {detecting ? <Loader2 style={{ width: 14, height: 14, animation: 'spin 1s linear infinite' }} /> : <Navigation style={{ width: 14, height: 14 }} />}
                  Detect
                </motion.button>
              </div>
            </div>

            {/* Destination */}
            <div style={{ marginBottom: '1.25rem' }}>
              <label style={{ fontSize: 11, fontWeight: 700, color: '#8E8E93', textTransform: 'uppercase', letterSpacing: '0.06em', display: 'block', marginBottom: 8 }}>Your Destination</label>
              <div style={{ position: 'relative' }}>
                <MapPin style={{ position: 'absolute', left: 12, top: '50%', transform: 'translateY(-50%)', width: 14, height: 14, color: '#ED2939' }} />
                <input value={destination} onChange={e => setDestination(e.target.value)} onKeyDown={e => e.key === 'Enter' && generate()}
                  placeholder="e.g. 24 rue Lecourbe, 75015 Paris"
                  style={{ width: '100%', background: 'rgba(255,255,255,0.06)', border: '1px solid rgba(255,255,255,0.12)', borderRadius: 10, padding: '10px 14px 10px 34px', color: '#fff', fontSize: 14, outline: 'none', boxSizing: 'border-box' }} />
              </div>
            </div>

            {/* Profile */}
            <div style={{ marginBottom: '1.5rem' }}>
              <label style={{ fontSize: 11, fontWeight: 700, color: '#8E8E93', textTransform: 'uppercase', letterSpacing: '0.06em', display: 'block', marginBottom: 8 }}>Your Profile</label>
              <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}>
                {PROFILES.map(p => (
                  <motion.button key={p} whileTap={{ scale: 0.95 }} onClick={() => setProfile(p)}
                    style={{ padding: '6px 12px', borderRadius: 20, fontSize: 12, fontWeight: 600, cursor: 'pointer', border: 'none', background: profile === p ? '#002654' : 'rgba(255,255,255,0.06)', color: profile === p ? '#fff' : '#9ca3af', transition: 'all 0.2s' }}>
                    {p}
                  </motion.button>
                ))}
              </div>
            </div>

            <motion.button whileTap={{ scale: 0.97 }} onClick={generate} disabled={loading}
              style={{ width: '100%', padding: '14px', borderRadius: 12, background: loading ? 'rgba(0,38,84,0.3)' : 'linear-gradient(135deg,#004082,#0052A5)', border: 'none', cursor: 'pointer', color: '#fff', fontWeight: 800, fontSize: 15, display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 10 }}>
              {loading
                ? <><Loader2 style={{ width: 18, height: 18, animation: 'spin 1s linear infinite' }} />Generating your arrival plan…</>
                : <><Plane style={{ width: 18, height: 18 }} />Generate My Paris Arrival Plan</>}
            </motion.button>
          </motion.div>

          {/* 3D Map */}
          <ParisMap3D markers={mapMarkers} pins={[]} routeColor="#004082" height="280px" accentColor="#004082" />
        </div>

        {/* Right: Results */}
        <AnimatePresence>
          {plan && (
            <motion.div key="plan" initial={{ opacity: 0, x: 24 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0 }} style={{ display: 'flex', flexDirection: 'column', gap: '1.25rem' }}>

              {/* Welcome */}
              <motion.div initial={{ scale: 0.95 }} animate={{ scale: 1 }}
                style={{ padding: '1.25rem', borderRadius: 16, background: 'linear-gradient(135deg,rgba(0,38,84,0.15),rgba(255,215,0,0.05))', border: '1px solid rgba(0,38,84,0.3)', textAlign: 'center' }}>
                <div style={{ fontSize: '2rem', marginBottom: 8 }}>🗼</div>
                <p style={{ fontSize: 14, color: '#e5e7eb', fontStyle: 'italic', lineHeight: 1.7 }}>{plan.welcome_message}</p>
              </motion.div>

              {/* Transport */}
              <div style={{ padding: '1.25rem', borderRadius: 16, background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(37,99,235,0.3)' }}>
                <div style={{ fontWeight: 700, color: '#fff', marginBottom: '0.75rem', display: 'flex', alignItems: 'center', gap: 8 }}>
                  🚇 Your Route Home
                </div>
                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '0.75rem', marginBottom: '0.75rem' }}>
                  {[
                    { label: 'Route', value: plan.transport.recommendation, color: '#60a5fa' },
                    { label: 'Duration', value: plan.transport.duration, color: '#34d399' },
                    { label: 'Cost', value: plan.transport.cost, color: '#fbbf24' },
                    { label: 'Line', value: plan.transport.line, color: '#a78bfa' },
                  ].map(item => (
                    <div key={item.label} style={{ padding: '8px 12px', borderRadius: 10, background: 'rgba(255,255,255,0.03)', border: '1px solid rgba(255,255,255,0.06)' }}>
                      <div style={{ fontSize: 10, color: '#8E8E93', marginBottom: 2 }}>{item.label}</div>
                      <div style={{ fontSize: 13, fontWeight: 700, color: item.color }}>{item.value}</div>
                    </div>
                  ))}
                </div>
                <div style={{ padding: '10px 12px', borderRadius: 10, background: 'rgba(239,68,68,0.08)', border: '1px solid rgba(239,68,68,0.2)', fontSize: 12, color: '#fca5a5', marginBottom: 8 }}>
                  ⚠️ {plan.transport.validation_warning}
                </div>
                <div style={{ fontSize: 12, color: '#8E8E93', lineHeight: 1.6 }}>💡 {plan.transport.navigo_advice}</div>
              </div>

              {/* Step-by-step */}
              <div style={{ padding: '1.25rem', borderRadius: 16, background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.08)' }}>
                <div style={{ fontWeight: 700, color: '#fff', marginBottom: '1rem' }}>📋 Step-by-Step Guide</div>
                <div style={{ display: 'flex', flexDirection: 'column', gap: '0.6rem' }}>
                  {plan.steps.map((step, i) => (
                    <motion.div key={i} initial={{ opacity: 0, x: -12 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: i * 0.07 }}
                      onClick={() => toggleStep(i)} style={{ display: 'flex', gap: '0.75rem', padding: '10px 12px', borderRadius: 12, background: completedSteps.has(i) ? 'rgba(5,150,105,0.08)' : step.critical ? 'rgba(239,68,68,0.06)' : 'rgba(255,255,255,0.03)', border: `1px solid ${completedSteps.has(i) ? 'rgba(5,150,105,0.3)' : step.critical ? 'rgba(239,68,68,0.25)' : 'rgba(255,255,255,0.06)'}`, cursor: 'pointer' }}>
                      <div style={{ width: 28, height: 28, borderRadius: '50%', background: completedSteps.has(i) ? '#059669' : 'rgba(255,255,255,0.08)', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0, fontSize: completedSteps.has(i) ? 14 : 16 }}>
                        {completedSteps.has(i) ? <CheckCircle2 style={{ width: 16, height: 16, color: '#fff' }} /> : step.icon}
                      </div>
                      <div style={{ flex: 1 }}>
                        <div style={{ fontSize: 13, fontWeight: 600, color: completedSteps.has(i) ? '#6ee7b7' : '#fff', textDecoration: completedSteps.has(i) ? 'line-through' : 'none' }}>{step.action}</div>
                        {step.french_phrase && (
                          <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginTop: 4 }}>
                            <span style={{ fontSize: 11, color: '#3b82f6', fontStyle: 'italic' }}>🇫🇷 "{step.french_phrase}"</span>
                            <button onClick={e => { e.stopPropagation(); speak(step.french_phrase!); }}
                              style={{ background: 'none', border: 'none', cursor: 'pointer', color: '#8E8E93', padding: 2 }}>
                              <Volume2 style={{ width: 12, height: 12 }} />
                            </button>
                          </div>
                        )}
                        {step.fine && <div style={{ fontSize: 11, color: '#fca5a5', marginTop: 2 }}>Fine: {step.fine}</div>}
                      </div>
                      {step.critical && <div style={{ fontSize: 10, fontWeight: 700, color: '#ef4444', flexShrink: 0, alignSelf: 'center' }}>CRITICAL</div>}
                    </motion.div>
                  ))}
                </div>
              </div>

              {/* Tonight + Neighbourhood */}
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem' }}>
                <div style={{ padding: '1.1rem', borderRadius: 14, background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.08)' }}>
                  <div style={{ fontWeight: 700, color: '#fff', marginBottom: '0.75rem', fontSize: 13 }}>🌙 Tonight</div>
                  <div style={{ fontSize: 12, color: '#8E8E93', lineHeight: 1.7 }}>
                    <div>🍽 {plan.tonight.meal}</div>
                    <div style={{ marginTop: 6 }}>📶 {plan.tonight.wifi}</div>
                    <div style={{ marginTop: 8, padding: '8px', borderRadius: 8, background: 'rgba(239,68,68,0.08)', border: '1px solid rgba(239,68,68,0.15)' }}>
                      <div style={{ fontSize: 11, fontWeight: 700, color: '#fca5a5', marginBottom: 4 }}>Emergency Numbers</div>
                      {Object.entries(plan.tonight.emergency_numbers).map(([k, v]) => (
                        <div key={k} style={{ fontSize: 11, color: '#d1d5db' }}>{k.toUpperCase()}: <strong style={{ color: '#fff' }}>{v}</strong></div>
                      ))}
                    </div>
                  </div>
                </div>
                <div style={{ padding: '1.1rem', borderRadius: 14, background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.08)' }}>
                  <div style={{ fontWeight: 700, color: '#fff', marginBottom: '0.75rem', fontSize: 13 }}>📍 Near You</div>
                  <div style={{ fontSize: 12, color: '#8E8E93', lineHeight: 1.8 }}>
                    <div>🛒 {plan.neighbourhood_intel.nearest_supermarket}</div>
                    <div>💊 {plan.neighbourhood_intel.nearest_pharmacy}</div>
                    <div>📱 {plan.neighbourhood_intel.sim_card}</div>
                    <div>🏛 {plan.neighbourhood_intel.nearest_prefecture}</div>
                  </div>
                </div>
              </div>

              {/* Urgent Admin */}
              {plan.urgent_admin?.length > 0 && (
                <div style={{ padding: '1.25rem', borderRadius: 14, background: 'rgba(251,191,36,0.05)', border: '1px solid rgba(251,191,36,0.2)' }}>
                  <div style={{ fontWeight: 700, color: '#fbbf24', marginBottom: '0.75rem', display: 'flex', alignItems: 'center', gap: 6, fontSize: 13 }}>
                    <AlertTriangle style={{ width: 14, height: 14 }} /> Urgent Admin Tasks
                  </div>
                  <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
                    {plan.urgent_admin.map((task, i) => (
                      <div key={i} style={{ display: 'flex', alignItems: 'flex-start', gap: 10, padding: '8px 10px', borderRadius: 10, background: 'rgba(255,255,255,0.03)', border: '1px solid rgba(255,255,255,0.06)' }}>
                        <div style={{ width: 6, height: 6, borderRadius: '50%', background: task.priority === 'high' ? '#ef4444' : '#f59e0b', flexShrink: 0, marginTop: 5 }} />
                        <div style={{ flex: 1 }}>
                          <div style={{ fontSize: 13, fontWeight: 600, color: '#fff' }}>{task.task}</div>
                          <div style={{ fontSize: 11, color: '#8E8E93' }}>Deadline: {task.deadline}</div>
                        </div>
                        {task.url && (
                          <a href={task.url} target="_blank" rel="noreferrer" style={{ fontSize: 11, color: '#60a5fa', textDecoration: 'none', flexShrink: 0 }}>
                            Open →
                          </a>
                        )}
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </motion.div>
          )}
        </AnimatePresence>
      </div>
      <style>{`@keyframes spin { from { transform:rotate(0deg) } to { transform:rotate(360deg) } }`}</style>
    </div>
  );
}
