'use client';
import { useState, useRef, useEffect } from 'react';
import { Send, Sparkles, Image as ImageIcon, X, MapPin, Loader2 } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { useLanguage, LANGUAGES } from '@/lib/i18n/LanguageContext';

const GOLD = '#FFD700';
const NAVY = '#002654';

interface Message { id: string; role: 'user' | 'assistant'; content: string; time: string; }

const SUGGESTIONS: { [key: string]: string[] } = {
  en: ['How do I use a Navigo card?', 'Cheapest way from CDG to city center?', 'Best boulangerie near the Marais?', 'Documents needed for a French bank account?', 'Free things to do in Paris this weekend'],
  fr: ["Comment utiliser un Navigo ?", "Le moins cher de CDG au centre-ville ?", "Meilleure boulangerie près du Marais ?", "Documents pour un compte bancaire français ?", "Activités gratuites à Paris ce week-end"],
  ar: ['كيف أستخدم بطاقة نافيغو؟', 'أرخص طريقة من CDG إلى وسط المدينة؟', 'أفضل مخبز قرب مارييه؟', 'وثائق لفتح حساب بنكي فرنسي؟', 'أنشطة مجانية في باريس هذا الأسبوع'],
  pt: ['Como usar o cartão Navigo?', 'Mais barato de CDG ao centro?', 'Melhor padaria perto do Marais?', 'Documentos para conta bancária francesa?', 'Coisas gratuitas em Paris esse fim de semana'],
  zh: ['如何使用Navigo卡？', '从CDG到市中心最便宜的方式？', '马莱区附近最好的面包店？', '法国银行账户所需文件？', '本周末巴黎免费活动'],
  hi: ['Navigo कार्ड कैसे उपयोग करें?', 'CDG से शहर तक सबसे सस्ता रास्ता?', 'Marais के पास सबसे अच्छी बेकरी?', 'फ्रेंच बैंक खाते के लिए दस्तावेज़?', 'इस सप्ताहांत पेरिस में मुफ्त गतिविधियाँ'],
};

const GREETINGS: { [key: string]: string } = {
  en: "Bonjour! 👋 I'm Marcel, your Paris AI guide. Ask me anything about Paris — transport, culture, budget tips, admin paperwork, or send a photo of a sign and I'll help translate it!",
  fr: "Bonjour! 👋 Je suis Marcel, votre guide IA pour Paris. Posez-moi n'importe quelle question sur Paris — transport, culture, conseils budget, démarches administratives, ou envoyez une photo d'un panneau!",
  ar: "مرحباً! 👋 أنا مارسيل، دليلك الذكي في باريس. اسألني أي شيء عن باريس — المواصلات، الثقافة، الميزانية، الإجراءات الإدارية، أو أرسل صورة لافتة وسأساعدك!",
  pt: "Bonjour! 👋 Sou Marcel, seu guia de IA para Paris. Pergunte-me qualquer coisa sobre Paris — transporte, cultura, dicas de orçamento, questões administrativas, ou envie uma foto de um sinal!",
  zh: "Bonjour! 👋 我是Marcel，您的巴黎AI向导。向我询问任何关于巴黎的问题——交通、文化、预算技巧、行政事务，或者发送一张标志的照片，我会帮助您！",
  hi: "Bonjour! 👋 मैं Marcel हूं, आपका पेरिस AI गाइड। पेरिस के बारे में कुछ भी पूछें — परिवहन, संस्कृति, बजट टिप्स, प्रशासनिक प्रश्न, या किसी साइन की फोटो भेजें!",
};

const CHAT_LABEL: Record<string, string> = {
  en: 'Chat with Marcel', fr: "Chat avec Marcel", ar: 'دردشة مع مارسيل',
  pt: 'Chat com Marcel', zh: '与Marcel对话', hi: 'Marcel से चैट',
};

const PLACEHOLDER: Record<string, string> = {
  en: 'Ask anything about Paris…', fr: 'Posez n\'importe quelle question…',
  ar: 'اسأل أي شيء عن باريس…', pt: 'Pergunte qualquer coisa sobre Paris…',
  zh: '询问任何关于巴黎的问题…', hi: 'पेरिस के बारे में कुछ भी पूछें…',
};

/* ─── Typing indicator dots ─────────────────────────────────────────────────── */
function MarcelThinking() {
  return (
    <div style={{ display: 'flex', alignItems: 'flex-end', gap: 8 }}>
      {/* Avatar */}
      <div style={{
        width: 34, height: 34, borderRadius: '50%', flexShrink: 0,
        background: 'linear-gradient(135deg, #002654, #004082)',
        border: '1px solid rgba(255,215,0,0.2)',
        display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 16,
      }}>🧑‍🎨</div>
      <div style={{
        padding: '12px 18px', borderRadius: '18px 18px 18px 4px',
        background: 'rgba(21,26,35,0.8)',
        border: '1px solid rgba(255,255,255,0.09)',
        display: 'flex', gap: 5, alignItems: 'center',
      }}>
        <div className="marcel-dot-1" style={{ width: 6, height: 6, borderRadius: '50%', background: GOLD }} />
        <div className="marcel-dot-2" style={{ width: 6, height: 6, borderRadius: '50%', background: GOLD }} />
        <div className="marcel-dot-3" style={{ width: 6, height: 6, borderRadius: '50%', background: GOLD }} />
      </div>
    </div>
  );
}

export default function ChatPage() {
  const { lang } = useLanguage();
  const [messages, setMessages] = useState<Message[]>([{
    id: '1', role: 'assistant',
    time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    content: GREETINGS[lang] ?? GREETINGS['en'],
  }]);
  const [input, setInput]       = useState('');
  const [loading, setLoading]   = useState(false);
  const [imageFile, setImageFile] = useState<string | null>(null);
  const [locating, setLocating]   = useState(false);
  const [focused, setFocused]     = useState(false);
  const endRef  = useRef<HTMLDivElement>(null);
  const fileRef = useRef<HTMLInputElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    endRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, loading]);

  const suggestions = SUGGESTIONS[lang] ?? SUGGESTIONS['en'];
  const currentLang = LANGUAGES.find(l => l.code === lang);

  const shareLocation = () => {
    if (!navigator.geolocation) return;
    setLocating(true);
    navigator.geolocation.getCurrentPosition(async (pos) => {
      const { latitude: lat, longitude: lng } = pos.coords;
      try {
        const res = await fetch(`https://nominatim.openstreetmap.org/reverse?lat=${lat}&lon=${lng}&format=json`);
        const data = await res.json();
        const addr = data.display_name || `${lat.toFixed(5)}, ${lng.toFixed(5)}`;
        sendMessage(`📍 My location: ${addr}. Give me tips and things to do nearby!`);
      } catch {
        sendMessage(`📍 Location: ${lat.toFixed(5)}, ${lng.toFixed(5)}`);
      } finally { setLocating(false); }
    }, () => setLocating(false), { enableHighAccuracy: true, timeout: 10000 });
  };

  const handleImage = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => setImageFile((reader.result as string).split(',')[1]);
    reader.readAsDataURL(file);
  };

  const sendMessage = async (text?: string) => {
    const msgText = text || input;
    if (!msgText.trim() && !imageFile) return;
    const userMsg: Message = {
      id: Date.now().toString(), role: 'user', content: msgText,
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };
    const newMessages = [...messages, userMsg];
    setMessages(newMessages);
    setInput('');
    setLoading(true);

    try {
      const res = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          messages: newMessages.map(m => ({ role: m.role, content: m.content })),
          language: lang,
          imageBase64: imageFile,
        }),
      });
      const data = await res.json();
      if (data.error) throw new Error(data.error);
      setMessages(prev => [...prev, {
        id: Date.now().toString(), role: 'assistant', content: data.content,
        time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      }]);
    } catch {
      setMessages(prev => [...prev, {
        id: Date.now().toString(), role: 'assistant',
        content: { en: "Oh là là — Marcel spilled his café crème. Please retry! ☕", fr: "Oh là là — Marcel a renversé son café crème. Veuillez réessayer !", ar: "أوه لا لا — مارسيل سكب قهوته. يرجى المحاولة مرة أخرى!", pt: "Oh là là — Marcel derramou seu café! Tente novamente.", zh: "哎呀——Marcel打翻咖啡了，请重试！", hi: "Oh là là — Marcel ने अपनी कॉफी गिरा दी। कृपया पुनः प्रयास करें!" }[lang] ?? "Marcel spilled his café crème. Please retry! ☕",
        time: '',
      }]);
    } finally {
      setLoading(false);
      setImageFile(null);
    }
  };

  const renderContent = (text: string) =>
    text.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>').replace(/\n/g, '<br/>');

  const canSend = (input.trim() || imageFile) && !loading;

  return (
    <div style={{
      display: 'flex', flexDirection: 'column', height: '100vh',
      maxWidth: 780, margin: '0 auto',
      padding: '0 0 0',
    }}>

      {/* ── Header ─────────────────────────────────────────────────────── */}
      <div style={{
        padding: '1.5rem 1.5rem 1rem',
        borderBottom: '1px solid rgba(255,255,255,0.06)',
        display: 'flex', alignItems: 'center', justifyContent: 'space-between',
        background: 'rgba(11,14,20,0.6)', backdropFilter: 'blur(20px)',
        position: 'sticky', top: 0, zIndex: 10,
      }}>
        <div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 7, marginBottom: 4 }}>
            <Sparkles style={{ width: 14, height: 14, color: GOLD }} />
            <span style={{ fontSize: 10.5, fontWeight: 700, color: GOLD, textTransform: 'uppercase', letterSpacing: '0.12em' }}>
              {currentLang?.flag} AI Paris Guide
            </span>
          </div>
          <h1 style={{
            fontFamily: 'Playfair Display, serif',
            fontSize: 'clamp(1.3rem, 3vw, 1.75rem)',
            fontWeight: 700, color: '#F5F5F7', letterSpacing: '-0.02em',
          }}>
            {CHAT_LABEL[lang] ?? CHAT_LABEL['en']}
          </h1>
        </div>
        {/* Language flags row */}
        <div style={{ display: 'flex', gap: 4, flexWrap: 'wrap', justifyContent: 'flex-end', maxWidth: 160 }}>
          {LANGUAGES.map(l => (
            <span key={l.code} title={l.native} style={{
              fontSize: 18, cursor: 'default',
              opacity: lang === l.code ? 1 : 0.25, transition: 'opacity 0.2s',
            }}>{l.flag}</span>
          ))}
        </div>
      </div>

      {/* ── Messages ───────────────────────────────────────────────────── */}
      <div style={{
        flex: 1, overflowY: 'auto', display: 'flex', flexDirection: 'column',
        gap: '1rem', padding: '1.25rem 1.5rem 1rem',
      }}>
        <AnimatePresence initial={false}>
          {messages.map(msg => (
            <motion.div
              key={msg.id}
              initial={{ opacity: 0, y: 12, scale: 0.97 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              transition={{ type: 'spring', stiffness: 340, damping: 28 }}
              style={{
                display: 'flex',
                justifyContent: msg.role === 'user' ? 'flex-end' : 'flex-start',
                alignItems: 'flex-end', gap: 8,
              }}>
              {/* Marcel avatar */}
              {msg.role === 'assistant' && (
                <div style={{
                  width: 34, height: 34, borderRadius: '50%', flexShrink: 0,
                  background: 'linear-gradient(135deg, #002654, #004082)',
                  border: '1px solid rgba(255,215,0,0.2)',
                  display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 16,
                  boxShadow: '0 2px 12px rgba(0,38,84,0.4)',
                }}>🧑‍🎨</div>
              )}

              <div style={{ maxWidth: '76%' }}>
                <div
                  style={{
                    padding: '12px 16px',
                    borderRadius: msg.role === 'user'
                      ? '20px 20px 5px 20px'
                      : '5px 20px 20px 20px',
                    background: msg.role === 'user'
                      ? 'linear-gradient(135deg, #002654 0%, #004082 100%)'
                      : 'rgba(21,26,35,0.85)',
                    border: msg.role === 'user'
                      ? '1px solid rgba(255,215,0,0.12)'
                      : '1px solid rgba(255,255,255,0.09)',
                    color: '#F5F5F7', fontSize: 14, lineHeight: 1.75,
                    backdropFilter: 'blur(20px)',
                    boxShadow: msg.role === 'user'
                      ? '0 4px 20px rgba(0,38,84,0.4)'
                      : '0 2px 12px rgba(0,0,0,0.2)',
                  }}
                  dangerouslySetInnerHTML={{ __html: renderContent(msg.content) }}
                />
                {msg.time && (
                  <div style={{
                    fontSize: 10.5, color: '#3A3A3C', marginTop: 5,
                    textAlign: msg.role === 'user' ? 'right' : 'left',
                  }}>
                    {msg.time}
                  </div>
                )}
              </div>
            </motion.div>
          ))}
        </AnimatePresence>

        {/* Typing indicator */}
        {loading && (
          <motion.div
            initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0 }}>
            <MarcelThinking />
          </motion.div>
        )}
        <div ref={endRef} />
      </div>

      {/* ── Quick suggestions ─────────────────────────────────────────── */}
      <AnimatePresence>
        {messages.length <= 1 && (
          <motion.div
            initial={{ opacity: 0, y: 6 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}
            style={{
              display: 'flex', gap: 7, flexWrap: 'wrap', padding: '0 1.5rem 0.75rem',
            }}>
            {suggestions.slice(0, 3).map((s, i) => (
              <motion.button
                key={s} initial={{ opacity: 0, scale: 0.94 }}
                animate={{ opacity: 1, scale: 1 }} transition={{ delay: i * 0.06 }}
                whileHover={{ scale: 1.03 }} whileTap={{ scale: 0.97 }}
                onClick={() => sendMessage(s)}
                style={{
                  padding: '7px 14px', borderRadius: 20, fontSize: 12,
                  cursor: 'pointer',
                  border: '1px solid rgba(0,38,84,0.4)',
                  background: 'rgba(0,38,84,0.10)',
                  color: '#8E8E93', whiteSpace: 'nowrap',
                  maxWidth: 230, overflow: 'hidden', textOverflow: 'ellipsis',
                  fontWeight: 500, transition: 'all 0.15s',
                }}>
                {s}
              </motion.button>
            ))}
          </motion.div>
        )}
      </AnimatePresence>

      {/* ── Image preview ─────────────────────────────────────────────── */}
      <AnimatePresence>
        {imageFile && (
          <motion.div
            initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            style={{
              display: 'flex', alignItems: 'center', gap: 8,
              padding: '8px 14px', margin: '0 1.5rem 8px',
              borderRadius: 12, background: 'rgba(10,132,255,0.10)',
              border: '1px solid rgba(10,132,255,0.25)',
            }}>
            <ImageIcon style={{ width: 14, height: 14, color: '#0A84FF' }} />
            <span style={{ fontSize: 12, color: '#0A84FF', flex: 1, fontWeight: 500 }}>
              Image ready to send
            </span>
            <button onClick={() => setImageFile(null)}
              style={{ background: 'none', border: 'none', cursor: 'pointer', color: '#8E8E93' }}>
              <X style={{ width: 14, height: 14 }} />
            </button>
          </motion.div>
        )}
      </AnimatePresence>

      {/* ── Input bar ─────────────────────────────────────────────────── */}
      <div style={{ padding: '0.75rem 1.5rem 1rem' }}>
        <motion.div
          animate={{
            border: focused
              ? '1px solid rgba(255,215,0,0.35)'
              : '1px solid rgba(255,255,255,0.09)',
            boxShadow: focused
              ? '0 0 0 3px rgba(255,215,0,0.07)'
              : '0 2px 12px rgba(0,0,0,0.2)',
          }}
          transition={{ duration: 0.2 }}
          style={{
            display: 'flex', gap: 8, padding: '10px 10px 10px 14px',
            borderRadius: 18, background: 'rgba(21,26,35,0.85)',
            backdropFilter: 'blur(24px)',
          }}>
          {/* Attach image */}
          <motion.button whileHover={{ scale: 1.08 }} whileTap={{ scale: 0.92 }}
            onClick={() => fileRef.current?.click()}
            style={{
              padding: 8, borderRadius: 10,
              background: 'rgba(10,132,255,0.10)',
              border: '1px solid rgba(10,132,255,0.2)',
              cursor: 'pointer', color: '#0A84FF', flexShrink: 0,
            }}>
            <ImageIcon style={{ width: 16, height: 16 }} />
          </motion.button>

          {/* Location */}
          <motion.button whileHover={{ scale: 1.08 }} whileTap={{ scale: 0.92 }}
            onClick={shareLocation} disabled={locating}
            style={{
              padding: 8, borderRadius: 10,
              background: 'rgba(237,41,57,0.08)',
              border: '1px solid rgba(237,41,57,0.2)',
              cursor: 'pointer', color: '#ED2939', flexShrink: 0,
            }}>
            {locating
              ? <Loader2 style={{ width: 16, height: 16, animation: 'spin 1s linear infinite' }} />
              : <MapPin style={{ width: 16, height: 16 }} />}
          </motion.button>

          <input ref={fileRef} type="file" accept="image/*" onChange={handleImage} style={{ display: 'none' }} />

          <input
            ref={inputRef}
            value={input}
            onChange={e => setInput(e.target.value)}
            onKeyDown={e => e.key === 'Enter' && !e.shiftKey && sendMessage()}
            onFocus={() => setFocused(true)}
            onBlur={() => setFocused(false)}
            placeholder={PLACEHOLDER[lang] ?? PLACEHOLDER['en']}
            style={{
              flex: 1, background: 'none', border: 'none', outline: 'none',
              color: '#F5F5F7', fontSize: 14, fontWeight: 400,
            }}
          />

          <motion.button
            whileHover={canSend ? { scale: 1.06 } : {}}
            whileTap={canSend ? { scale: 0.92 } : {}}
            onClick={() => sendMessage()}
            disabled={!canSend}
            style={{
              padding: '9px 14px', borderRadius: 12, border: 'none',
              cursor: canSend ? 'pointer' : 'default', flexShrink: 0,
              background: canSend
                ? 'linear-gradient(135deg, #002654 0%, #004082 100%)'
                : 'rgba(255,255,255,0.06)',
              color: canSend ? '#F5F5F7' : '#3A3A3C',
              transition: 'all 0.2s',
              boxShadow: canSend ? '0 4px 14px rgba(0,38,84,0.5)' : 'none',
            }}>
            <Send style={{ width: 16, height: 16 }} />
          </motion.button>
        </motion.div>
      </div>

      <style>{`
        @keyframes spin { from { transform: rotate(0deg) } to { transform: rotate(360deg) } }
      `}</style>
    </div>
  );
}
