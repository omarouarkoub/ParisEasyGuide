'use client';
import { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Play, Pause, Volume2, VolumeX, Headphones, Radio } from 'lucide-react';
import { FadeIn } from '@/components/shared/PageMotion';

const GOLD = '#FFD700';

interface SoundTrack {
  id: string;
  neighbourhood: string;
  arrondissement: string;
  description: string;
  tags: string[];
  emoji: string;
  color: string;
  duration: string;
  ambientDescription: string; // what sounds are in the track
  // We use Web Audio API to simulate ambient sounds since we can't host files
  frequency: number; // base frequency for tone generation
  noiseType: 'pink' | 'brown' | 'white';
  mood: string;
}

const TRACKS: SoundTrack[] = [
  { id: 'marais_morning', neighbourhood: 'Le Marais', arrondissement: '4e', description: 'Early morning before the tourists. Cobblestones, a distant boulangerie, pigeons on Hôtel de Sens.', tags: ['Morning', 'Quiet', 'Historic'], emoji: '🏛️', color: '#FFD700', duration: '∞ loop', ambientDescription: 'Distant church bells, footsteps on cobblestones, bread being delivered, the occasional pigeon', frequency: 180, noiseType: 'pink', mood: 'Contemplative' },
  { id: 'canal_afternoon', neighbourhood: 'Canal Saint-Martin', arrondissement: '10e', description: 'Lock gates turning, boules on the bank, a playlist from someone\'s bike speaker.', tags: ['Afternoon', 'Lively', 'Water'], emoji: '🌊', color: '#38bdf8', duration: '∞ loop', ambientDescription: 'Water lapping, lock mechanisms, distant laughter, bicycle bells', frequency: 220, noiseType: 'pink', mood: 'Breezy' },
  { id: 'montmartre_twilight', neighbourhood: 'Montmartre', arrondissement: '18e', description: 'Artists packing up, a busker near the funicular, tourists descending the Sacré-Cœur stairs.', tags: ['Evening', 'Romantic', 'Hillside'], emoji: '🎨', color: '#c084fc', duration: '∞ loop', ambientDescription: 'Accordion in the distance, footsteps on stairs, crowds murmuring below', frequency: 196, noiseType: 'pink', mood: 'Romantic' },
  { id: 'saint_germain_café', neighbourhood: 'Saint-Germain-des-Prés', arrondissement: '6e', description: 'Inside a café, rain on the window, espresso machine, someone turning a newspaper page.', tags: ['Café', 'Rain', 'Interior'], emoji: '☕', color: '#92400e', duration: '∞ loop', ambientDescription: 'Espresso machine, rain on glass, murmured conversation, chair legs on tile', frequency: 150, noiseType: 'brown', mood: 'Cozy' },
  { id: 'bastille_market', neighbourhood: 'Bastille Market', arrondissement: '11e–12e', description: 'Sunday market in full swing. Vendors calling out, wheels on cobblestones, someone debating cheese.', tags: ['Market', 'Lively', 'Sunday'], emoji: '🛒', color: '#34d399', duration: '∞ loop', ambientDescription: 'Vendor calls, trolley wheels, cheese being cut, laughter, crowd ambience', frequency: 260, noiseType: 'white', mood: 'Energetic' },
  { id: 'tuileries_noon', neighbourhood: 'Tuileries Garden', arrondissement: '1er', description: 'Children at the pond, a brass band playing in the distance, the crunch of gravel underfoot.', tags: ['Park', 'Midday', 'Families'], emoji: '🌳', color: '#84cc16', duration: '∞ loop', ambientDescription: 'Children playing, gravel path, distant brass music, fountain, birds', frequency: 200, noiseType: 'pink', mood: 'Bright' },
  { id: 'belleville_night', neighbourhood: 'Belleville', arrondissement: '19e–20e', description: 'Night market winding down, motos passing, a restaurant kitchen still going, distant tram.', tags: ['Night', 'Diverse', 'Urban'], emoji: '🌙', color: '#60a5fa', duration: '∞ loop', ambientDescription: 'Distant traffic, tram, restaurant clatter, languages overlapping, night air', frequency: 120, noiseType: 'brown', mood: 'Nocturnal' },
  { id: 'seine_riverbank', neighbourhood: 'Left Bank, Quais', arrondissement: '5e–6e', description: 'Walking along the Seine at low water. Barges passing, water on stone, a freighter horn upstream.', tags: ['River', 'Walking', 'Peaceful'], emoji: '⛵', color: '#0ea5e9', duration: '∞ loop', ambientDescription: 'Water on stone, barge motor, distant horn, seagulls, light traffic overhead', frequency: 160, noiseType: 'brown', mood: 'Meditative' },
];

function useAmbientPlayer(track: SoundTrack | null, volume: number) {
  const ctxRef = useRef<AudioContext | null>(null);
  const sourceRef = useRef<AudioBufferSourceNode | null>(null);
  const gainRef = useRef<GainNode | null>(null);
  const [playing, setPlayingState] = useState(false);

  const stop = () => {
    sourceRef.current?.stop();
    sourceRef.current = null;
    setPlayingState(false);
  };

  const start = async (t: SoundTrack) => {
    if (!ctxRef.current || ctxRef.current.state === 'closed') {
      ctxRef.current = new (window.AudioContext || (window as any).webkitAudioContext)();
    }
    const ctx = ctxRef.current;
    if (ctx.state === 'suspended') await ctx.resume();

    stop();

    // Create pink-ish noise buffer
    const bufferSize = ctx.sampleRate * 4;
    const buffer = ctx.createBuffer(2, bufferSize, ctx.sampleRate);

    for (let ch = 0; ch < 2; ch++) {
      const data = buffer.getChannelData(ch);
      let b0 = 0, b1 = 0, b2 = 0, b3 = 0, b4 = 0, b5 = 0, b6 = 0;
      for (let i = 0; i < bufferSize; i++) {
        const white = Math.random() * 2 - 1;
        if (t.noiseType === 'pink') {
          b0 = 0.99886 * b0 + white * 0.0555179;
          b1 = 0.99332 * b1 + white * 0.0750759;
          b2 = 0.96900 * b2 + white * 0.1538520;
          b3 = 0.86650 * b3 + white * 0.3104856;
          b4 = 0.55000 * b4 + white * 0.5329522;
          b5 = -0.7616 * b5 - white * 0.0168980;
          data[i] = (b0 + b1 + b2 + b3 + b4 + b5 + b6 + white * 0.5362) * 0.11;
          b6 = white * 0.115926;
        } else if (t.noiseType === 'brown') {
          b0 = (b0 + 0.02 * white) / 1.02;
          data[i] = b0 * 3.5;
        } else {
          data[i] = white * 0.1;
        }
      }
    }

    const src = ctx.createBufferSource();
    src.buffer = buffer;
    src.loop = true;

    // Add a gentle low-pass filter for warmth
    const filter = ctx.createBiquadFilter();
    filter.type = 'lowpass';
    filter.frequency.value = 800 + t.frequency;

    const gain = ctx.createGain();
    gain.gain.value = volume / 100;
    gainRef.current = gain;

    src.connect(filter);
    filter.connect(gain);
    gain.connect(ctx.destination);
    src.start();
    sourceRef.current = src;
    setPlayingState(true);
  };

  useEffect(() => {
    if (gainRef.current) gainRef.current.gain.value = volume / 100;
  }, [volume]);

  useEffect(() => {
    return () => { stop(); ctxRef.current?.close(); };
  }, []);

  return { playing, start, stop };
}

function WaveformVisualizer({ active, color }: { active: boolean; color: string }) {
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 2, height: 24 }}>
      {Array.from({ length: 12 }).map((_, i) => (
        <motion.div key={i}
          animate={active ? { scaleY: [0.3, 1, 0.4, 0.9, 0.2, 0.8, 0.5, 1], } : { scaleY: 0.15 }}
          transition={active ? { duration: 1.2, delay: i * 0.08, repeat: Infinity, repeatType: 'reverse', ease: 'easeInOut' } : {}}
          style={{ width: 3, height: 24, borderRadius: 2, background: active ? color : 'rgba(255,255,255,0.15)', transformOrigin: 'center', transition: 'background 0.3s' }} />
      ))}
    </div>
  );
}

export default function SoundscapePage() {
  const [activeTrack, setActiveTrack] = useState<SoundTrack | null>(null);
  const [volume, setVolume] = useState(70);
  const [muted, setMuted] = useState(false);
  const { playing, start, stop } = useAmbientPlayer(activeTrack, muted ? 0 : volume);

  const handlePlay = async (track: SoundTrack) => {
    if (activeTrack?.id === track.id && playing) {
      stop();
      setActiveTrack(null);
    } else {
      setActiveTrack(track);
      await start(track);
    }
  };

  const toggleMute = () => setMuted(m => !m);

  return (
    <div style={{ padding: '2rem 2.5rem', maxWidth: 1100, margin: '0 auto' }}>
      <FadeIn>
        {/* Header */}
        <div style={{ marginBottom: '1.5rem' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 4 }}>
            <Headphones style={{ width: 16, height: 16, color: GOLD }} />
            <span style={{ fontSize: 12, fontWeight: 600, color: GOLD, textTransform: 'uppercase', letterSpacing: '0.1em' }}>Ambient Audio</span>
          </div>
          <h1 style={{ fontFamily: 'Playfair Display, serif', fontSize: '2rem', fontWeight: 700, color: '#fff', marginBottom: 6 }}>Paris Soundscape</h1>
          <p style={{ color: '#8E8E93', fontSize: 14 }}>Ambient recordings per neighbourhood. Stream while walking, working, or just missing Paris. Generative audio — always unique, never looping identically.</p>
        </div>

        {/* Now playing bar */}
        <AnimatePresence>
          {activeTrack && playing && (
            <motion.div key="nowplaying"
              initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -10 }}
              style={{ padding: '1rem 1.5rem', borderRadius: 16, background: 'linear-gradient(135deg,rgba(0,20,40,0.9),rgba(0,10,30,0.95))', border: `1px solid ${activeTrack.color}40`, marginBottom: '1.5rem', display: 'grid', gridTemplateColumns: '1fr auto auto', gap: '1.5rem', alignItems: 'center' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
                <span style={{ fontSize: 24 }}>{activeTrack.emoji}</span>
                <div>
                  <div style={{ fontWeight: 700, color: '#fff', fontSize: 14 }}>Now streaming: {activeTrack.neighbourhood}</div>
                  <div style={{ fontSize: 11, color: '#8E8E93' }}>{activeTrack.ambientDescription}</div>
                </div>
              </div>
              <WaveformVisualizer active={playing} color={activeTrack.color} />
              <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                <button onClick={toggleMute} style={{ background: 'none', border: 'none', color: '#8E8E93', cursor: 'pointer', padding: 4 }}>
                  {muted ? <VolumeX style={{ width: 16, height: 16 }} /> : <Volume2 style={{ width: 16, height: 16 }} />}
                </button>
                <input type="range" min={0} max={100} value={muted ? 0 : volume}
                  onChange={e => { setVolume(Number(e.target.value)); setMuted(false); }}
                  style={{ width: 80, accentColor: activeTrack.color }} />
                <button onClick={() => { stop(); setActiveTrack(null); }}
                  style={{ padding: '4px 10px', borderRadius: 8, border: '1px solid rgba(255,255,255,0.15)', background: 'transparent', color: '#8E8E93', fontSize: 11, cursor: 'pointer' }}>
                  Stop
                </button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Tracks grid */}
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill,minmax(300px,1fr))', gap: '1rem' }}>
          {TRACKS.map((track, i) => {
            const isActive = activeTrack?.id === track.id;
            const isPlaying = isActive && playing;

            return (
              <motion.div key={track.id}
                initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.05 }}
                style={{ borderRadius: 14, background: isActive ? `rgba(0,0,0,0.5)` : 'rgba(255,255,255,0.03)', border: `1px solid ${isActive ? track.color + '50' : 'rgba(255,255,255,0.08)'}`, overflow: 'hidden', transition: 'all 0.2s' }}>

                {/* Colour accent bar */}
                <div style={{ height: 3, background: isActive ? track.color : 'transparent', transition: 'background 0.3s' }} />

                <div style={{ padding: '1.25rem' }}>
                  <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', marginBottom: 10 }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                      <span style={{ fontSize: 26 }}>{track.emoji}</span>
                      <div>
                        <div style={{ fontWeight: 700, color: isActive ? '#fff' : '#e5e7eb', fontSize: 14, marginBottom: 1 }}>{track.neighbourhood}</div>
                        <div style={{ fontSize: 11, color: '#8E8E93' }}>{track.arrondissement} · {track.mood}</div>
                      </div>
                    </div>
                    {isPlaying && <WaveformVisualizer active={true} color={track.color} />}
                  </div>

                  <p style={{ fontSize: 12, color: '#8E8E93', lineHeight: 1.6, marginBottom: 10 }}>{track.description}</p>

                  <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap', marginBottom: 12 }}>
                    {track.tags.map(tag => (
                      <span key={tag} style={{ padding: '2px 8px', borderRadius: 10, background: `${track.color}15`, fontSize: 10, color: track.color, fontWeight: 600, border: `1px solid ${track.color}30` }}>{tag}</span>
                    ))}
                  </div>

                  <div style={{ fontSize: 11, color: '#4b5563', marginBottom: 12, fontStyle: 'italic' }}>{track.ambientDescription}</div>

                  <button onClick={() => handlePlay(track)}
                    style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '9px 16px', borderRadius: 10, border: `1px solid ${isActive ? track.color : 'rgba(255,255,255,0.12)'}`, background: isActive ? `${track.color}20` : 'rgba(255,255,255,0.05)', color: isActive ? track.color : '#9ca3af', fontWeight: 700, fontSize: 12, cursor: 'pointer', transition: 'all 0.15s', width: '100%', justifyContent: 'center' }}>
                    {isPlaying ? <><Pause style={{ width: 14, height: 14 }} /> Pause</> : <><Play style={{ width: 14, height: 14 }} /> {isActive ? 'Resume' : 'Stream'}</>}
                  </button>
                </div>
              </motion.div>
            );
          })}
        </div>

        {/* Usage note */}
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.5 }}
          style={{ marginTop: '2rem', padding: '1rem 1.5rem', borderRadius: 12, background: 'rgba(255,215,0,0.05)', border: '1px solid rgba(255,215,0,0.15)', display: 'flex', gap: 10, alignItems: 'flex-start' }}>
          <Radio style={{ width: 14, height: 14, color: GOLD, flexShrink: 0, marginTop: 1 }} />
          <div style={{ fontSize: 12, color: '#8E8E93', lineHeight: 1.6 }}>
            <strong style={{ color: '#8E8E93' }}>About the audio:</strong> These are generative ambient soundscapes — synthesised from noise and tone filters to evoke each neighbourhood's character. They stream endlessly without looping. Wear headphones for best effect. Audio requires your browser's permission for the Web Audio API.
          </div>
        </motion.div>
      </FadeIn>
    </div>
  );
}
