'use client';
import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { MapPin, Sparkles, Loader2, Star, Coffee, ShoppingBag, Train, Shield, Home } from 'lucide-react';
import { useLanguage, LANGUAGES } from '@/lib/i18n/LanguageContext';
import { toast } from 'sonner';
import { FadeIn, StaggerList } from '@/components/shared/PageMotion';

const POPULAR_HOODS = [
  { name: 'Le Marais', arr: '3ème & 4ème', emoji: '🏘️', color: '#7c3aed' },
  { name: 'Montmartre', arr: '18ème', emoji: '🎨', color: '#db2777' },
  { name: 'Saint-Germain-des-Prés', arr: '6ème', emoji: '☕', color: '#002654' },
  { name: 'Canal Saint-Martin', arr: '10ème', emoji: '🛶', color: '#059669' },
  { name: 'Belleville', arr: '20ème', emoji: '🌍', color: '#ea580c' },
  { name: 'Châtelet-Les Halles', arr: '1er', emoji: '🚇', color: '#8E8E93' },
  { name: 'Pigalle', arr: '9ème', emoji: '🎭', color: '#d97706' },
  { name: 'Nation', arr: '12ème', emoji: '🌳', color: '#059669' },
  { name: 'Oberkampf', arr: '11ème', emoji: '🎸', color: '#7c3aed' },
  { name: 'Denfert-Rochereau', arr: '14ème', emoji: '🎓', color: '#2563eb' },
  { name: 'Javel', arr: '15ème', emoji: '🏫', color: '#002654' },
  { name: 'Père Lachaise', arr: '20ème', emoji: '🕊️', color: '#8E8E93' },
];

interface Guide {
  name: string; arrondissement: string; tagline: string; vibe: string;
  student_score: number; safety_score: number; affordability_score: number; transport_score: number;
  metro_lines: string[]; rer_lines: string[]; avg_studio_rent: string; avg_meal_cost: string;
  must_know: { emoji: string; title: string; detail: string }[];
  hidden_gems: { name: string; type: string; why: string; address: string }[];
  student_life: { universities_nearby: string[]; coworking_spaces: string[]; best_study_cafes: string[] };
  food_guide: { cheapest_meal: { place: string; dish: string; price: string }; best_bakery: { name: string; specialty: string; address: string }; halal_options: string; vegetarian_options: string; supermarkets: string[] };
  admin_offices: { type: string; address: string; note: string }[];
  seasonal_tips: { summer: string; winter: string; avoid: string };
}

function ScoreBar({ label, value, color }: { label: string; value: number; color: string }) {
  return (
    <div style={{ marginBottom: 10 }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 4 }}>
        <span style={{ fontSize: 12, color: '#8E8E93' }}>{label}</span>
        <span style={{ fontSize: 12, fontWeight: 700, color }}>{value}/10</span>
      </div>
      <div style={{ height: 5, borderRadius: 3, background: 'rgba(255,255,255,0.08)', overflow: 'hidden' }}>
        <motion.div initial={{ width: 0 }} animate={{ width: `${value * 10}%` }} transition={{ duration: 0.8, ease: 'easeOut' }}
          style={{ height: '100%', borderRadius: 3, background: color }} />
      </div>
    </div>
  );
}

export default function NeighbourhoodsPage() {
  const { lang } = useLanguage();
  const langLabel = LANGUAGES.find(l => l.code === lang)?.label ?? "English";
  const [search, setSearch] = useState('');
  const [guide, setGuide] = useState<Guide | null>(null);
  const [loading, setLoading] = useState(false);
  const [selected, setSelected] = useState('');

  const fetch_guide = async (name: string) => {
    setSelected(name); setLoading(true); setGuide(null);
    try {
      const res = await fetch('/api/neighbourhood', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ neighbourhood: name }),
      });
      const data = await res.json();
      if (data.guide) setGuide(data.guide);
      else toast.error('Could not load guide.');
    } catch { toast.error('Failed to load neighbourhood guide.'); }
    finally { setLoading(false); }
  };

  const handleSearch = () => { if (search.trim()) fetch_guide(search.trim()); };

  return (
    <div style={{ padding: '2rem 2.5rem', maxWidth: 1100, margin: '0 auto' }}>
      <FadeIn>
        <div style={{ marginBottom: '2rem' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 4 }}>
            <MapPin style={{ width: 16, height: 16, color: '#FFD700' }} />
            <span style={{ fontSize: 12, fontWeight: 600, color: '#FFD700', textTransform: 'uppercase', letterSpacing: '0.1em' }}>Neighbourhood Guide</span>
          </div>
          <h1 style={{ fontFamily: 'Playfair Display, serif', fontSize: '2rem', fontWeight: 700, color: '#fff' }}>Explore Neighbourhoods</h1>
          <p style={{ color: '#8E8E93', fontSize: 14 }}>Deep-dive guides for every Paris arrondissement</p>
        </div>
      </FadeIn>

      {/* Search */}
      <div style={{ display: 'flex', gap: 10, marginBottom: '1.5rem' }}>
        <input value={search} onChange={e => setSearch(e.target.value)} onKeyDown={e => e.key === 'Enter' && handleSearch()}
          placeholder="Type any Paris neighbourhood, arrondissement, or suburb…"
          style={{ flex: 1, background: 'rgba(255,255,255,0.06)', border: '1px solid rgba(255,255,255,0.1)', borderRadius: 12, padding: '12px 16px', color: '#fff', fontSize: 14, outline: 'none' }} />
        <motion.button whileTap={{ scale: 0.95 }} onClick={handleSearch}
          style={{ padding: '12px 20px', borderRadius: 12, background: 'linear-gradient(135deg,#004082,#0052A5)', border: 'none', cursor: 'pointer', color: '#fff', fontWeight: 700, display: 'flex', alignItems: 'center', gap: 8 }}>
          <Sparkles style={{ width: 16, height: 16 }} />Explore
        </motion.button>
      </div>

      {/* Popular chips */}
      <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap', marginBottom: '2rem' }}>
        {POPULAR_HOODS.map(h => (
          <motion.button key={h.name} whileTap={{ scale: 0.93 }} onClick={() => fetch_guide(h.name)}
            style={{ padding: '7px 14px', borderRadius: 20, fontSize: 13, fontWeight: 600, cursor: 'pointer', border: `1px solid ${selected === h.name ? h.color : h.color + '33'}`, background: selected === h.name ? `${h.color}22` : 'rgba(255,255,255,0.03)', color: selected === h.name ? '#fff' : '#9ca3af', transition: 'all 0.2s' }}>
            {h.emoji} {h.name}
          </motion.button>
        ))}
      </div>

      {/* Loading */}
      {loading && (
        <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '1rem', padding: '3rem' }}>
          <motion.div animate={{ rotate: 360 }} transition={{ repeat: Infinity, duration: 2, ease: 'linear' }}>
            <MapPin style={{ width: 28, height: 28, color: '#FFD700' }} />
          </motion.div>
          <div style={{ color: '#8E8E93', fontSize: 14 }}>Researching {selected}…</div>
        </div>
      )}

      {/* Guide result */}
      <AnimatePresence>
        {guide && !loading && (
          <motion.div key={guide.name} initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}>
            {/* Hero */}
            <div style={{ padding: '1.75rem', borderRadius: 20, background: 'linear-gradient(135deg,rgba(0,38,84,0.12),rgba(255,215,0,0.05))', border: '1px solid rgba(0,38,84,0.25)', marginBottom: '1.5rem' }}>
              <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', flexWrap: 'wrap', gap: '1rem' }}>
                <div>
                  <h2 style={{ fontFamily: 'Playfair Display, serif', fontSize: '1.75rem', fontWeight: 700, color: '#fff', marginBottom: 4 }}>{guide.name}</h2>
                  <div style={{ fontSize: 13, color: '#FFD700', fontWeight: 600, marginBottom: 8 }}>{guide.arrondissement}</div>
                  <p style={{ fontSize: 14, color: '#d1d5db', fontStyle: 'italic', lineHeight: 1.7, maxWidth: 500 }}>{guide.tagline}</p>
                </div>
                <div style={{ display: 'flex', gap: '1rem', flexWrap: 'wrap' }}>
                  {[
                    { label: '🏠 Rent', value: guide.avg_studio_rent },
                    { label: '🍽 Meal', value: guide.avg_meal_cost },
                  ].map(s => (
                    <div key={s.label} style={{ textAlign: 'center', padding: '10px 16px', borderRadius: 12, background: 'rgba(255,255,255,0.06)', border: '1px solid rgba(255,255,255,0.1)' }}>
                      <div style={{ fontSize: 11, color: '#8E8E93' }}>{s.label}</div>
                      <div style={{ fontSize: 14, fontWeight: 700, color: '#fff', marginTop: 2 }}>{s.value}</div>
                    </div>
                  ))}
                </div>
              </div>
              <p style={{ fontSize: 13, color: '#8E8E93', lineHeight: 1.75, marginTop: '1rem' }}>{guide.vibe}</p>

              {/* Scores */}
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(180px, 1fr))', gap: '1rem', marginTop: '1.25rem' }}>
                <div style={{ padding: '1rem', borderRadius: 12, background: 'rgba(255,255,255,0.04)' }}>
                  <ScoreBar label="👨‍🎓 Student Life" value={guide.student_score} color="#3b82f6" />
                  <ScoreBar label="🛡 Safety" value={guide.safety_score} color="#10b981" />
                  <ScoreBar label="💶 Affordability" value={guide.affordability_score} color="#f59e0b" />
                  <ScoreBar label="🚇 Transport" value={guide.transport_score} color="#8b5cf6" />
                </div>
                <div style={{ padding: '1rem', borderRadius: 12, background: 'rgba(255,255,255,0.04)' }}>
                  <div style={{ fontSize: 11, fontWeight: 700, color: '#8E8E93', marginBottom: 8 }}>METRO & RER</div>
                  <div style={{ display: 'flex', flexWrap: 'wrap', gap: 5 }}>
                    {guide.metro_lines?.map(l => <span key={l} style={{ padding: '3px 9px', borderRadius: 20, fontSize: 12, fontWeight: 700, background: 'rgba(59,130,246,0.15)', border: '1px solid rgba(59,130,246,0.3)', color: '#93c5fd' }}>M{l}</span>)}
                    {guide.rer_lines?.map(l => <span key={l} style={{ padding: '3px 9px', borderRadius: 20, fontSize: 12, fontWeight: 700, background: 'rgba(139,92,246,0.15)', border: '1px solid rgba(139,92,246,0.3)', color: '#c4b5fd' }}>{l}</span>)}
                  </div>
                </div>
              </div>
            </div>

            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))', gap: '1.25rem' }}>
              {/* Must Know */}
              {guide.must_know?.length > 0 && (
                <div style={{ padding: '1.25rem', borderRadius: 16, background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.08)' }}>
                  <h3 style={{ fontWeight: 700, color: '#fff', marginBottom: '1rem', fontSize: 14 }}>💡 Must Know</h3>
                  <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
                    {guide.must_know.map((item, i) => (
                      <motion.div key={i} initial={{ opacity: 0, x: -8 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: i * 0.07 }}
                        style={{ display: 'flex', gap: 10 }}>
                        <span style={{ fontSize: 18, flexShrink: 0 }}>{item.emoji}</span>
                        <div><div style={{ fontSize: 13, fontWeight: 600, color: '#fff', marginBottom: 2 }}>{item.title}</div><div style={{ fontSize: 12, color: '#8E8E93', lineHeight: 1.6 }}>{item.detail}</div></div>
                      </motion.div>
                    ))}
                  </div>
                </div>
              )}

              {/* Hidden Gems */}
              {guide.hidden_gems?.length > 0 && (
                <div style={{ padding: '1.25rem', borderRadius: 16, background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.08)' }}>
                  <h3 style={{ fontWeight: 700, color: '#fff', marginBottom: '1rem', fontSize: 14 }}>💎 Hidden Gems</h3>
                  <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
                    {guide.hidden_gems.map((gem, i) => (
                      <div key={i} style={{ padding: '10px 12px', borderRadius: 10, background: 'rgba(255,255,255,0.03)', border: '1px solid rgba(255,255,255,0.07)' }}>
                        <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 2 }}>
                          <span style={{ fontWeight: 600, fontSize: 13, color: '#fff' }}>{gem.name}</span>
                          <span style={{ fontSize: 10, color: '#8E8E93', background: 'rgba(255,255,255,0.06)', padding: '2px 8px', borderRadius: 20 }}>{gem.type}</span>
                        </div>
                        <div style={{ fontSize: 12, color: '#8E8E93', marginBottom: 2 }}>{gem.why}</div>
                        <div style={{ fontSize: 11, color: '#8E8E93' }}>📍 {gem.address}</div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Food guide */}
              {guide.food_guide && (
                <div style={{ padding: '1.25rem', borderRadius: 16, background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.08)' }}>
                  <h3 style={{ fontWeight: 700, color: '#fff', marginBottom: '1rem', fontSize: 14 }}>🍽 Food Guide</h3>
                  <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
                    <div style={{ padding: '10px 12px', borderRadius: 10, background: 'rgba(5,150,105,0.08)', border: '1px solid rgba(5,150,105,0.2)' }}>
                      <div style={{ fontSize: 11, fontWeight: 700, color: '#34d399', marginBottom: 3 }}>🤑 CHEAPEST MEAL</div>
                      <div style={{ fontSize: 13, color: '#fff', fontWeight: 600 }}>{guide.food_guide.cheapest_meal?.place}</div>
                      <div style={{ fontSize: 12, color: '#8E8E93' }}>{guide.food_guide.cheapest_meal?.dish} — {guide.food_guide.cheapest_meal?.price}</div>
                    </div>
                    <div style={{ padding: '10px 12px', borderRadius: 10, background: 'rgba(251,191,36,0.06)', border: '1px solid rgba(251,191,36,0.15)' }}>
                      <div style={{ fontSize: 11, fontWeight: 700, color: '#fbbf24', marginBottom: 3 }}>🥐 BEST BAKERY</div>
                      <div style={{ fontSize: 13, color: '#fff', fontWeight: 600 }}>{guide.food_guide.best_bakery?.name}</div>
                      <div style={{ fontSize: 12, color: '#8E8E93' }}>{guide.food_guide.best_bakery?.specialty} · {guide.food_guide.best_bakery?.address}</div>
                    </div>
                    {guide.food_guide.halal_options && <div style={{ fontSize: 12, color: '#8E8E93' }}>🕌 Halal: {guide.food_guide.halal_options}</div>}
                    {guide.food_guide.vegetarian_options && <div style={{ fontSize: 12, color: '#8E8E93' }}>🌱 Veg: {guide.food_guide.vegetarian_options}</div>}
                    {guide.food_guide.supermarkets?.map((s, i) => <div key={i} style={{ fontSize: 12, color: '#8E8E93' }}>🛒 {s}</div>)}
                  </div>
                </div>
              )}

              {/* Seasonal tips */}
              {guide.seasonal_tips && (
                <div style={{ padding: '1.25rem', borderRadius: 16, background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.08)' }}>
                  <h3 style={{ fontWeight: 700, color: '#fff', marginBottom: '1rem', fontSize: 14 }}>🌤 Seasonal Tips</h3>
                  <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
                    <div style={{ fontSize: 13, color: '#fbbf24' }}>☀️ Summer: <span style={{ color: '#8E8E93', fontWeight: 400 }}>{guide.seasonal_tips.summer}</span></div>
                    <div style={{ fontSize: 13, color: '#93c5fd' }}>❄️ Winter: <span style={{ color: '#8E8E93', fontWeight: 400 }}>{guide.seasonal_tips.winter}</span></div>
                    <div style={{ fontSize: 13, color: '#fca5a5' }}>⚠️ Avoid: <span style={{ color: '#8E8E93', fontWeight: 400 }}>{guide.seasonal_tips.avoid}</span></div>
                  </div>
                </div>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
