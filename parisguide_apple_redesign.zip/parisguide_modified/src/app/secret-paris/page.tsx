'use client';
import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { MapPin, Plus, Compass, Eye, EyeOff, Lock, Unlock, X } from 'lucide-react';
import { FadeIn } from '@/components/shared/PageMotion';
import { fireBadgeToast } from '@/components/quest/BadgeUnlockToast';

const GOLD = '#FFD700';
const RED = '#ED2939';

type SecretType = 'courtyard' | 'fountain' | 'rooftop' | 'passage' | 'garden' | 'artwork' | 'view' | 'other';

interface SecretGem {
  id: string;
  name: string;
  type: SecretType;
  arrondissement: string;
  hint: string; // directions without giving it away fully
  fullAddress?: string; // revealed after unlock
  description: string;
  discovered: boolean;
  emoji: string;
  rarity: 'known' | 'hidden' | 'ultra-secret';
  addedBy: string; // anonymous contributor name
  confirmedCount: number;
  lat?: number;
  lng?: number;
}

const GEMS: SecretGem[] = [
  { id: 'sq_brasserie', name: 'Square of the Secret Brasserie', type: 'courtyard', arrondissement: '3e', hint: 'Enter through an unmarked wooden door on a street named after a medieval craft. The courtyard has a 17th-century well.', fullAddress: '4 Rue de Venise, 3e — push the green door', description: 'A hidden courtyard behind a medieval street. Still has the original well and old cobblestones. No tourists have found this.', discovered: false, emoji: '🏚️', rarity: 'ultra-secret', addedBy: 'Claude V.', confirmedCount: 3, lat: 48.859, lng: 2.351 },
  { id: 'fontaine_innocents', name: 'Fontaine des Innocents hidden angle', type: 'fountain', arrondissement: '1er', hint: 'The famous Fontaine des Innocents has a 5th face. Approach from the north-east diagonal and look at the lower tier.', fullAddress: 'Place Joachim-du-Bellay, 1er — approach from NE corner', description: 'The Renaissance fountain has a rarely-noticed fifth sculptural face on the inner lower column, visible only from one angle at low tide of tourists.', discovered: false, emoji: '⛲', rarity: 'hidden', addedBy: 'Margaux H.', confirmedCount: 14, lat: 48.8604, lng: 2.3479 },
  { id: 'rooftop_beaubourg', name: 'Beaubourg Pipe Terrace', type: 'rooftop', arrondissement: '4e', hint: 'You must visit the Centre Pompidou library (free, bring ID). Take the escalator to floor 3 and find the terrace through the reading room exit.', fullAddress: 'BPI Library, Centre Pompidou, 4e — 3rd floor reading room exit', description: 'The Pompidou\'s public library has a free terrace overlooking the rooftop pipes and all of Paris. No one goes here because no one knows it\'s public.', discovered: false, emoji: '🔭', rarity: 'hidden', addedBy: 'Pierre M.', confirmedCount: 31, lat: 48.8607, lng: 2.3521 },
  { id: 'passage_du_caire', name: 'Passage du Caire Egyptian Door', type: 'passage', arrondissement: '2e', hint: 'On the Passage du Caire, the oldest covered passage in Paris, look for the building façade with three Egyptian faces at the entrance — it dates from 1799.', fullAddress: '2 Passage du Caire, 2e', description: 'Built after Napoleon\'s Egyptian campaign, the passage entrance has three extraordinary Egyptian pharaoh heads from 1799. Nobody looks up.', discovered: false, emoji: '🏺', rarity: 'known', addedBy: 'Nadia F.', confirmedCount: 88, lat: 48.8660, lng: 2.3517 },
  { id: 'jardin_anne_frank', name: 'Square du Temple Mémorial Garden', type: 'garden', arrondissement: '3e', hint: 'Behind the Marais\'s main square (not the Place des Vosges, the other one). Look for a memorial plaque near a small sunken garden.', fullAddress: 'Square du Temple, near Rue Eugène-Spuller, 3e', description: 'A quiet sunken garden with a memorial to Temple prison victims (Marie Antoinette was held here). Almost always empty at 9am.', discovered: false, emoji: '🌿', rarity: 'hidden', addedBy: 'Isabelle R.', confirmedCount: 12, lat: 48.8635, lng: 2.3606 },
  { id: 'mur_je_taime', name: 'Hidden "Je T\'Aime" Wall Room', type: 'artwork', arrondissement: '18e', hint: 'The famous wall is in Montmartre — but there\'s a smaller, unofficial version inside an arcade 2 streets north. Look for a tiny doorway with no sign.', fullAddress: 'Square Jehan-Rictus, Place des Abbesses, 18e (the official one is public)', description: 'The official "Je T\'Aime" wall — 612 "I love yous" in 250 languages on 429 tiles. Deeply hidden in a small garden that locals use as a shortcut.', discovered: false, emoji: '💙', rarity: 'known', addedBy: 'Amira C.', confirmedCount: 167, lat: 48.8842, lng: 2.3385 },
  { id: 'pont_bir_hakeim', name: 'Pont Bir-Hakeim Iron Cathedral', type: 'view', arrondissement: '16e', hint: 'Go under the bridge, not over it. Descend to the riverbank on the 16e side and walk under the arches at midday. Bring a wide-angle lens.', fullAddress: 'Pont de Bir-Hakeim, from the Passy riverbank, 16e', description: 'The underside of this double-decker bridge creates a cathedral of riveted iron arches. Inception was filmed here. Photographers call it "the infinite corridor".', discovered: false, emoji: '⚙️', rarity: 'hidden', addedBy: 'Thomas K.', confirmedCount: 45, lat: 48.8537, lng: 2.2892 },
  { id: 'crypte_notre_dame', name: 'Crypte Archéologique de Notre-Dame', type: 'other', arrondissement: '4e', hint: 'Under the parvis of Notre-Dame. The entrance is a small staircase in the square. Most tourists photograph the cathedral and never go down.', fullAddress: 'Crypte Archéologique du Parvis de Notre-Dame, Place du Parvis Notre-Dame', description: 'Beneath the cathedral forecourt, Paris from 52 BC to the Middle Ages is excavated and visible. Roman walls, medieval foundations, heating systems — all underground.', discovered: false, emoji: '🏛️', rarity: 'known', addedBy: 'Élodie N.', confirmedCount: 203, lat: 48.8531, lng: 2.3499 },
  { id: 'rue_cremieux', name: 'Rue Crémieux Colour Secret', type: 'other', arrondissement: '12e', hint: 'A one-block street east of the Gare de Lyon, painted in every colour. It\'s not secret — but 99% of tourists walk past the unremarkable entrance without noticing.', fullAddress: 'Rue Crémieux, 12e — entrance from Rue de Bercy or Rue de Lyon', description: 'The most colourful street in Paris — 42 houses painted in Caribbean colours. Now technically private and locals are asking visitors to stop, so be respectful.', discovered: false, emoji: '🌈', rarity: 'known', addedBy: 'Valentina S.', confirmedCount: 412, lat: 48.8476, lng: 2.3666 },
];

const TYPE_CONFIG: Record<SecretType, { color: string; label: string }> = {
  courtyard: { color: '#84cc16', label: 'Courtyard' },
  fountain:  { color: '#38bdf8', label: 'Fountain' },
  rooftop:   { color: '#c084fc', label: 'Rooftop' },
  passage:   { color: GOLD, label: 'Passage' },
  garden:    { color: '#34d399', label: 'Garden' },
  artwork:   { color: RED, label: 'Artwork' },
  view:      { color: '#60a5fa', label: 'Viewpoint' },
  other:     { color: '#8E8E93', label: 'Other' },
};

const RARITY_CONFIG = {
  'known':        { color: '#8E8E93', label: 'Well-known secret' },
  'hidden':       { color: '#60a5fa', label: 'Hidden gem' },
  'ultra-secret': { color: GOLD, label: 'Ultra-secret' },
};

export default function SecretParisPage() {
  const [discovered, setDiscovered] = useState<string[]>([]);
  const [revealing, setRevealing] = useState<string | null>(null);
  const [filter, setFilter] = useState<SecretType | 'all'>('all');
  const [showAddForm, setShowAddForm] = useState(false);

  useEffect(() => {
    const d = localStorage.getItem('secret_paris_discovered');
    if (d) setDiscovered(JSON.parse(d));
  }, []);

  const revealGem = (id: string) => {
    const next = [...discovered, id];
    setDiscovered(next);
    localStorage.setItem('secret_paris_discovered', JSON.stringify(next));
    setRevealing(null);

    if (next.length === 1) {
      fireBadgeToast({ id: 'secret_1', emoji: '🔍', name: 'Secret Seeker', description: 'You unlocked your first hidden gem!', rarity: 'common', xp: 50 });
    } else if (next.length >= 5) {
      fireBadgeToast({ id: 'secret_5', emoji: '🗝️', name: 'Vieux Parisien', description: '5 hidden gems unlocked — you know Paris.', rarity: 'legendary', xp: 400 });
    }
  };

  const filtered = GEMS.filter(g => filter === 'all' || g.type === filter);
  const isDiscovered = (id: string) => discovered.includes(id);

  return (
    <div style={{ padding: '2rem 2.5rem', maxWidth: 1100, margin: '0 auto' }}>
      <FadeIn>
        {/* Header */}
        <div style={{ marginBottom: '1.5rem' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 4 }}>
            <Compass style={{ width: 16, height: 16, color: GOLD }} />
            <span style={{ fontSize: 12, fontWeight: 600, color: GOLD, textTransform: 'uppercase', letterSpacing: '0.1em' }}>Crowd-Sourced Secrets</span>
          </div>
          <h1 style={{ fontFamily: 'Playfair Display, serif', fontSize: '2rem', fontWeight: 700, color: '#fff', marginBottom: 6 }}>Secret Paris Layer</h1>
          <p style={{ color: '#8E8E93', fontSize: 14 }}>Unmarked courtyards, forgotten fountains, rooftop terraces, and places that locals have quietly kept to themselves. Unlock each one to reveal its location.</p>
        </div>

        {/* Progress */}
        <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }}
          style={{ padding: '1.25rem 1.5rem', borderRadius: 16, background: 'linear-gradient(135deg,rgba(255,215,0,0.08),rgba(0,38,84,0.08))', border: '1px solid rgba(255,215,0,0.2)', marginBottom: '1.5rem', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
          <div>
            <div style={{ fontSize: 22, fontWeight: 800, color: GOLD, fontFamily: 'Playfair Display, serif' }}>{discovered.length} <span style={{ fontSize: 14, color: '#8E8E93', fontFamily: 'sans-serif' }}>/ {GEMS.length} secrets unlocked</span></div>
            <div style={{ height: 6, borderRadius: 3, background: 'rgba(255,255,255,0.08)', overflow: 'hidden', marginTop: 8, width: 200 }}>
              <motion.div initial={{ width: 0 }} animate={{ width: `${(discovered.length/GEMS.length)*100}%` }} transition={{ duration: 1, ease: 'easeOut' }}
                style={{ height: '100%', borderRadius: 3, background: 'linear-gradient(90deg,#FFD700,#ED2939)' }} />
            </div>
          </div>
          <button onClick={() => setShowAddForm(true)}
            style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '8px 16px', borderRadius: 10, background: 'rgba(255,215,0,0.15)', border: '1px solid rgba(255,215,0,0.35)', color: GOLD, fontWeight: 700, fontSize: 12, cursor: 'pointer' }}>
            <Plus style={{ width: 14, height: 14 }} /> Share a Secret
          </button>
        </motion.div>

        {/* Type filter */}
        <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap', marginBottom: '1.5rem' }}>
          <button onClick={() => setFilter('all')} style={{ padding: '5px 12px', borderRadius: 20, border: `1px solid ${filter==='all' ? GOLD : 'rgba(255,255,255,0.1)'}`, background: filter==='all' ? 'rgba(255,215,0,0.12)' : 'rgba(255,255,255,0.03)', color: filter==='all' ? GOLD : '#9ca3af', fontSize: 11, fontWeight: 600, cursor: 'pointer' }}>All</button>
          {Object.entries(TYPE_CONFIG).map(([key, cfg]) => (
            <button key={key} onClick={() => setFilter(key as SecretType)}
              style={{ padding: '5px 12px', borderRadius: 20, border: `1px solid ${filter===key ? cfg.color : 'rgba(255,255,255,0.1)'}`, background: filter===key ? `${cfg.color}20` : 'rgba(255,255,255,0.03)', color: filter===key ? cfg.color : '#9ca3af', fontSize: 11, fontWeight: 600, cursor: 'pointer' }}>
              {cfg.label}
            </button>
          ))}
        </div>

        {/* Gems grid */}
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill,minmax(320px,1fr))', gap: '1rem' }}>
          {filtered.map((gem, i) => {
            const disc = isDiscovered(gem.id);
            const typeCfg = TYPE_CONFIG[gem.type];
            const rarityCfg = RARITY_CONFIG[gem.rarity];
            const isRevealing = revealing === gem.id;

            return (
              <motion.div key={gem.id}
                initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.05 }}
                style={{ borderRadius: 14, background: disc ? 'rgba(255,215,0,0.06)' : 'rgba(255,255,255,0.03)', border: `1px solid ${disc ? 'rgba(255,215,0,0.3)' : 'rgba(255,255,255,0.08)'}`, overflow: 'hidden' }}>
                <div style={{ padding: '1.25rem' }}>
                  {/* Header */}
                  <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', marginBottom: 8 }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                      <div style={{ fontSize: 24, filter: disc ? 'none' : 'grayscale(0.7)' }}>{gem.emoji}</div>
                      <div>
                        <div style={{ fontWeight: 700, color: disc ? '#fff' : '#9ca3af', fontSize: 14, marginBottom: 2 }}>
                          {disc ? gem.name : '████ ██████'}
                        </div>
                        <div style={{ fontSize: 11, color: '#8E8E93' }}>{gem.arrondissement}</div>
                      </div>
                    </div>
                    <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'flex-end', gap: 4 }}>
                      <span style={{ padding: '2px 7px', borderRadius: 10, fontSize: 10, fontWeight: 700, color: typeCfg.color, background: `${typeCfg.color}15` }}>{typeCfg.label}</span>
                      <span style={{ fontSize: 9, color: rarityCfg.color, fontWeight: 700 }}>{rarityCfg.label}</span>
                    </div>
                  </div>

                  {/* Hint */}
                  <div style={{ padding: '10px 12px', borderRadius: 10, background: 'rgba(0,0,0,0.2)', border: '1px solid rgba(255,255,255,0.06)', marginBottom: 10 }}>
                    <div style={{ fontSize: 10, fontWeight: 700, color: '#8E8E93', marginBottom: 4 }}>HINT</div>
                    <div style={{ fontSize: 12, color: '#8E8E93', lineHeight: 1.5, fontStyle: 'italic' }}>{gem.hint}</div>
                  </div>

                  {disc ? (
                    <div>
                      <div style={{ padding: '10px 12px', borderRadius: 10, background: 'rgba(255,215,0,0.08)', border: '1px solid rgba(255,215,0,0.2)', marginBottom: 10 }}>
                        <div style={{ fontSize: 10, fontWeight: 700, color: GOLD, marginBottom: 4, display: 'flex', alignItems: 'center', gap: 4 }}><MapPin style={{ width: 10, height: 10 }} /> EXACT LOCATION</div>
                        <div style={{ fontSize: 12, color: '#fde68a', fontWeight: 600 }}>{gem.fullAddress}</div>
                      </div>
                      <p style={{ fontSize: 12, color: '#d1d5db', lineHeight: 1.6, marginBottom: 8 }}>{gem.description}</p>
                      <div style={{ fontSize: 10, color: '#8E8E93' }}>Added by {gem.addedBy} · {gem.confirmedCount} confirmed visits</div>
                    </div>
                  ) : (
                    <div>
                      {isRevealing ? (
                        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }}
                          style={{ padding: '12px', borderRadius: 10, background: 'rgba(255,215,0,0.1)', border: `1px solid ${GOLD}40`, textAlign: 'center' }}>
                          <div style={{ fontSize: 12, color: '#d1d5db', marginBottom: 10 }}>Revealing location for <strong style={{ color: '#fff' }}>{gem.name}</strong>…</div>
                          <div style={{ display: 'flex', gap: 8, justifyContent: 'center' }}>
                            <button onClick={() => revealGem(gem.id)}
                              style={{ padding: '8px 16px', borderRadius: 8, background: 'rgba(255,215,0,0.9)', color: '#000', fontWeight: 700, fontSize: 12, border: 'none', cursor: 'pointer' }}>
                              Unlock Secret
                            </button>
                            <button onClick={() => setRevealing(null)}
                              style={{ padding: '8px 12px', borderRadius: 8, background: 'transparent', border: '1px solid rgba(255,255,255,0.15)', color: '#8E8E93', fontSize: 12, cursor: 'pointer' }}>
                              Keep Mystery
                            </button>
                          </div>
                        </motion.div>
                      ) : (
                        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                          <div style={{ fontSize: 10, color: '#8E8E93' }}>{gem.confirmedCount} people found this</div>
                          <button onClick={() => setRevealing(gem.id)}
                            style={{ display: 'flex', alignItems: 'center', gap: 6, padding: '7px 14px', borderRadius: 10, border: `1px solid ${GOLD}50`, background: 'rgba(255,215,0,0.1)', color: GOLD, fontWeight: 700, fontSize: 12, cursor: 'pointer' }}>
                            <Unlock style={{ width: 12, height: 12 }} /> Reveal Location
                          </button>
                        </div>
                      )}
                    </div>
                  )}
                </div>
              </motion.div>
            );
          })}
        </div>

        {/* Share a Secret modal */}
        <AnimatePresence>
          {showAddForm && (
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
              onClick={() => setShowAddForm(false)}
              style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.7)', zIndex: 1000, display: 'flex', alignItems: 'center', justifyContent: 'center', padding: '2rem' }}>
              <motion.div initial={{ scale: 0.9, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} exit={{ scale: 0.9, opacity: 0 }}
                onClick={e => e.stopPropagation()}
                style={{ background: '#111827', border: `1px solid ${GOLD}40`, borderRadius: 16, padding: '2rem', maxWidth: 440, width: '100%' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1.5rem' }}>
                  <h3 style={{ fontFamily: 'Playfair Display, serif', color: '#fff', fontSize: '1.25rem', margin: 0 }}>Share a Secret</h3>
                  <button onClick={() => setShowAddForm(false)} style={{ background: 'none', border: 'none', color: '#8E8E93', cursor: 'pointer' }}><X /></button>
                </div>
                <div style={{ textAlign: 'center', padding: '2rem', color: '#8E8E93' }}>
                  <div style={{ fontSize: 32, marginBottom: 10 }}>🗝️</div>
                  <div style={{ fontSize: 13, color: '#8E8E93', marginBottom: 8 }}>Secret submissions are reviewed before going live.</div>
                  <div style={{ fontSize: 12, color: '#8E8E93', lineHeight: 1.6 }}>This feature will connect to the community API when available. For now, suggest secrets via the chat feature using the 🤖 assistant.</div>
                  <button onClick={() => setShowAddForm(false)} style={{ marginTop: 16, padding: '8px 20px', borderRadius: 10, background: 'rgba(255,215,0,0.15)', border: `1px solid ${GOLD}50`, color: GOLD, fontWeight: 700, fontSize: 13, cursor: 'pointer' }}>Got it</button>
                </div>
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>
      </FadeIn>
    </div>
  );
}
