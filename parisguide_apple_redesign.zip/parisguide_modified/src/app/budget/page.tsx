'use client';
import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Wallet, Plus, Trash2, Sparkles, Loader2, TrendingDown } from 'lucide-react';
import { useLanguage, LANGUAGES } from '@/lib/i18n/LanguageContext';
import { toast } from 'sonner';
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip } from 'recharts';
import { FadeIn, SlideIn } from '@/components/shared/PageMotion';
import MealPlanner from '@/components/budget/MealPlanner';

interface Expense { id: string; label: string; amount: number; category: string; }
const CATEGORIES = [
  { id: 'food',   label: 'Groceries', color: '#002654', emoji: '🛒' },
  { id: 'café',   label: 'Café',      color: '#f59e0b', emoji: '☕' },
  { id: 'ticket', label: 'Ticket',    color: '#8b5cf6', emoji: '🎫' },
  { id: 'other',  label: 'Other',     color: '#8E8E93', emoji: '📦' },
];
const DEFAULT_EXPENSES: Expense[] = [
  { id: '1', label: 'Baguette + sandwich', amount: 4.5,  category: 'food' },
  { id: '2', label: 'Café crème',          amount: 3.0,  category: 'café' },
  { id: '3', label: 'Supermarché',         amount: 18.5, category: 'food' },
];

export default function BudgetPage() {
  const { lang } = useLanguage();
  const langLabel = LANGUAGES.find(l => l.code === lang)?.label ?? "English";
  const [tab, setTab] = useState<'tracker' | 'meals'>('tracker');
  const [budget, setBudget] = useState(50);
  const [expenses, setExpenses] = useState<Expense[]>(DEFAULT_EXPENSES);
  const [label, setLabel] = useState('');
  const [amount, setAmount] = useState('');
  const [category, setCategory] = useState('food');
  const [aiTips, setAiTips] = useState<string[]>([]);
  const [loadingTips, setLoadingTips] = useState(false);

  const total = expenses.reduce((s, e) => s + e.amount, 0);
  const remaining = budget - total;
  const pct = Math.min((total / budget) * 100, 100);

  const addExpense = () => {
    if (!label.trim() || !amount) return;
    setExpenses(prev => [...prev, { id: Date.now().toString(), label, amount: parseFloat(amount), category }]);
    setLabel(''); setAmount('');
    toast.success('Expense added!');
  };
  const deleteExpense = (id: string) => setExpenses(prev => prev.filter(e => e.id !== id));

  const getAiTips = async () => {
    setLoadingTips(true); setAiTips([]);
    try {
      const res = await fetch('/api/budget', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ expenses, budget, total }) });
      const data = await res.json();
      setAiTips(data.tips || []);
    } catch { toast.error('Could not load AI tips.'); }
    finally { setLoadingTips(false); }
  };

  const pieData = CATEGORIES.map(c => ({ name: c.label, value: expenses.filter(e => e.category === c.id).reduce((s, e) => s + e.amount, 0), color: c.color })).filter(d => d.value > 0);

  return (
    <div style={{ padding: '2rem 2.5rem', maxWidth: 1100, margin: '0 auto' }}>
      <FadeIn>
        <div style={{ marginBottom: '2rem' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 4 }}>
            <Wallet style={{ width: 16, height: 16, color: '#FFD700' }} />
            <span style={{ fontSize: 12, fontWeight: 600, color: '#FFD700', textTransform: 'uppercase', letterSpacing: '0.1em' }}>Smart Budget</span>
          </div>
          <h1 style={{ fontFamily: 'Playfair Display, serif', fontSize: '2rem', fontWeight: 700, color: '#fff' }}>Budget & Meals</h1>
          <p style={{ color: '#8E8E93', fontSize: 14 }}>Track expenses and plan your Parisian meals</p>
        </div>
      </FadeIn>

      {/* Tab switcher */}
      <div style={{ display: 'flex', gap: 4, padding: 4, borderRadius: 14, background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.08)', marginBottom: '2rem', width: 'fit-content' }}>
        {[{ key: 'tracker', label: '💶 Expense Tracker' }, { key: 'meals', label: '🍽️ Meal Planner' }].map(t => (
          <button key={t.key} onClick={() => setTab(t.key as any)}
            style={{ padding: '9px 20px', borderRadius: 10, fontSize: 13, fontWeight: 700, cursor: 'pointer', border: 'none', background: tab === t.key ? '#059669' : 'transparent', color: tab === t.key ? '#fff' : '#9ca3af', transition: 'all 0.2s' }}>
            {t.label}
          </button>
        ))}
      </div>

      <AnimatePresence mode="wait">
        {tab === 'tracker' && (
          <motion.div key="tracker" initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -8 }}>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 300px', gap: '1.5rem' }}>
              <div style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
                {/* Budget bar */}
                <SlideIn from="left">
                  <div style={{ padding: '1.5rem', borderRadius: 16, background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.08)' }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '0.75rem' }}>
                      <div><div style={{ fontSize: 12, color: '#8E8E93' }}>Daily budget</div><div style={{ fontSize: '1.5rem', fontWeight: 700, color: '#fff' }}>€{budget}</div></div>
                      <div style={{ textAlign: 'right' }}><div style={{ fontSize: 12, color: '#8E8E93' }}>Remaining</div>
                        <motion.div key={remaining} initial={{ scale: 1.2 }} animate={{ scale: 1 }} style={{ fontSize: '1.5rem', fontWeight: 700, color: remaining >= 0 ? '#059669' : '#ef4444' }}>€{remaining.toFixed(2)}</motion.div>
                      </div>
                    </div>
                    <div style={{ height: 8, borderRadius: 4, background: 'rgba(255,255,255,0.08)', overflow: 'hidden' }}>
                      <motion.div initial={{ width: 0 }} animate={{ width: `${pct}%` }} transition={{ duration: 0.8, ease: 'easeOut' }}
                        style={{ height: '100%', borderRadius: 4, background: pct > 90 ? '#ef4444' : pct > 70 ? '#f59e0b' : '#059669' }} />
                    </div>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginTop: '0.75rem' }}>
                      <span style={{ fontSize: 12, color: '#8E8E93' }}>Budget: €</span>
                      <input type="number" value={budget} onChange={e => setBudget(Number(e.target.value))} style={{ width: 70, background: 'rgba(255,255,255,0.06)', border: '1px solid rgba(255,255,255,0.1)', borderRadius: 8, padding: '4px 8px', color: '#fff', fontSize: 13, outline: 'none' }} />
                    </div>
                  </div>
                </SlideIn>

                {/* Add expense */}
                <div style={{ padding: '1.5rem', borderRadius: 16, background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.08)' }}>
                  <h3 style={{ fontWeight: 600, color: '#fff', marginBottom: '1rem', fontSize: 14 }}>Add Expense</h3>
                  <div style={{ display: 'flex', gap: '0.75rem', flexWrap: 'wrap' }}>
                    <input value={label} onChange={e => setLabel(e.target.value)} placeholder="What did you buy?" style={{ flex: 2, minWidth: 140, background: 'rgba(255,255,255,0.06)', border: '1px solid rgba(255,255,255,0.1)', borderRadius: 10, padding: '10px 14px', color: '#fff', fontSize: 14, outline: 'none' }} />
                    <input type="number" value={amount} onChange={e => setAmount(e.target.value)} onKeyDown={e => e.key === 'Enter' && addExpense()} placeholder="€0.00" style={{ width: 90, background: 'rgba(255,255,255,0.06)', border: '1px solid rgba(255,255,255,0.1)', borderRadius: 10, padding: '10px 14px', color: '#fff', fontSize: 14, outline: 'none' }} />
                    <select value={category} onChange={e => setCategory(e.target.value)} style={{ background: 'rgba(255,255,255,0.06)', border: '1px solid rgba(255,255,255,0.1)', borderRadius: 10, padding: '10px 14px', color: '#fff', fontSize: 13, outline: 'none', cursor: 'pointer' }}>
                      {CATEGORIES.map(c => <option key={c.id} value={c.id}>{c.emoji} {c.label}</option>)}
                    </select>
                    <motion.button whileTap={{ scale: 0.95 }} onClick={addExpense} style={{ padding: '10px 16px', borderRadius: 10, background: 'linear-gradient(135deg,#059669,#047857)', border: 'none', cursor: 'pointer', color: '#fff', display: 'flex', alignItems: 'center', gap: 6, fontWeight: 600, fontSize: 14 }}>
                      <Plus style={{ width: 16, height: 16 }} /> Add
                    </motion.button>
                  </div>
                </div>

                {/* Expenses list */}
                <div style={{ padding: '1.5rem', borderRadius: 16, background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.08)' }}>
                  <h3 style={{ fontWeight: 600, color: '#fff', marginBottom: '1rem', fontSize: 14 }}>Today's Expenses</h3>
                  <div style={{ display: 'flex', flexDirection: 'column', gap: '0.5rem' }}>
                    <AnimatePresence>
                      {expenses.map(e => {
                        const cat = CATEGORIES.find(c => c.id === e.category);
                        return (
                          <motion.div key={e.id} initial={{ opacity: 0, x: -16 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: 16, height: 0, marginBottom: 0 }}
                            style={{ display: 'flex', alignItems: 'center', gap: '0.75rem', padding: '10px 12px', borderRadius: 10, background: 'rgba(255,255,255,0.03)', border: '1px solid rgba(255,255,255,0.06)' }}>
                            <span style={{ fontSize: 16 }}>{cat?.emoji}</span>
                            <span style={{ flex: 1, fontSize: 14, color: '#e5e7eb' }}>{e.label}</span>
                            <span style={{ fontWeight: 700, color: '#fff', marginRight: 8 }}>€{e.amount.toFixed(2)}</span>
                            <button onClick={() => deleteExpense(e.id)} style={{ background: 'none', border: 'none', cursor: 'pointer', color: '#4b5563', padding: 4 }}><Trash2 style={{ width: 14, height: 14 }} /></button>
                          </motion.div>
                        );
                      })}
                    </AnimatePresence>
                  </div>
                  <div style={{ marginTop: '1rem', paddingTop: '0.75rem', borderTop: '1px solid rgba(255,255,255,0.08)', display: 'flex', justifyContent: 'space-between' }}>
                    <span style={{ fontWeight: 600, color: '#8E8E93' }}>Total</span>
                    <span style={{ fontWeight: 700, fontSize: '1.1rem', color: '#fff' }}>€{total.toFixed(2)}</span>
                  </div>
                </div>
              </div>

              {/* Right column */}
              <div style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
                <div style={{ padding: '1.5rem', borderRadius: 16, background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.08)' }}>
                  <h3 style={{ fontWeight: 600, color: '#fff', marginBottom: '1rem', fontSize: 14 }}>Breakdown</h3>
                  {pieData.length > 0 ? (
                    <ResponsiveContainer width="100%" height={160}>
                      <PieChart><Pie data={pieData} cx="50%" cy="50%" outerRadius={65} dataKey="value">{pieData.map((entry, i) => <Cell key={i} fill={entry.color} />)}</Pie>
                        <Tooltip formatter={(v: any) => `€${Number(v).toFixed(2)}`} contentStyle={{ background: '#0a0c19', border: '1px solid rgba(255,255,255,0.1)', borderRadius: 8, color: '#fff' }} /></PieChart>
                    </ResponsiveContainer>
                  ) : <div style={{ height: 160, display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#4b5563', fontSize: 13 }}>No expenses yet</div>}
                  <div style={{ display: 'flex', flexDirection: 'column', gap: 6, marginTop: 8 }}>
                    {CATEGORIES.map(c => { const amt = expenses.filter(e => e.category === c.id).reduce((s, e) => s + e.amount, 0); return amt > 0 ? (<div key={c.id} style={{ display: 'flex', alignItems: 'center', gap: 8 }}><div style={{ width: 10, height: 10, borderRadius: '50%', background: c.color, flexShrink: 0 }} /><span style={{ fontSize: 12, color: '#8E8E93', flex: 1 }}>{c.label}</span><span style={{ fontSize: 12, fontWeight: 600, color: '#fff' }}>€{amt.toFixed(2)}</span></div>) : null; })}
                  </div>
                </div>

                <div style={{ padding: '1.5rem', borderRadius: 16, background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.08)' }}>
                  <h3 style={{ fontWeight: 600, color: '#fff', marginBottom: '0.75rem', display: 'flex', alignItems: 'center', gap: 8, fontSize: 14 }}>
                    <TrendingDown style={{ width: 16, height: 16, color: '#FFD700' }} /> AI Tips
                  </h3>
                  {aiTips.length > 0 && (
                    <AnimatePresence>
                      <div style={{ display: 'flex', flexDirection: 'column', gap: '0.75rem', marginBottom: '0.75rem' }}>
                        {aiTips.map((tip, i) => (
                          <motion.div key={i} initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.1 }}
                            style={{ padding: '10px 12px', borderRadius: 10, background: 'rgba(0,38,84,0.12)', border: '1px solid rgba(0,38,84,0.2)', fontSize: 12, color: '#d1d5db', lineHeight: 1.6 }}>
                            💡 {tip}
                          </motion.div>
                        ))}
                      </div>
                    </AnimatePresence>
                  )}
                  <motion.button whileTap={{ scale: 0.97 }} onClick={getAiTips} disabled={loadingTips || expenses.length === 0}
                    style={{ width: '100%', padding: '10px', borderRadius: 10, background: 'linear-gradient(135deg,#004082,#0052A5)', border: 'none', cursor: 'pointer', color: '#fff', fontWeight: 600, fontSize: 13, display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8 }}>
                    {loadingTips ? <><Loader2 style={{ width: 14, height: 14, animation: 'spin 1s linear infinite' }} />Getting tips…</> : <><Sparkles style={{ width: 14, height: 14 }} />Get AI Tips</>}
                  </motion.button>
                </div>
              </div>
            </div>
          </motion.div>
        )}

        {tab === 'meals' && (
          <motion.div key="meals" initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -8 }}>
            <MealPlanner />
          </motion.div>
        )}
      </AnimatePresence>
      <style>{`@keyframes spin { from { transform:rotate(0deg) } to { transform:rotate(360deg) } }`}</style>
    </div>
  );
}
