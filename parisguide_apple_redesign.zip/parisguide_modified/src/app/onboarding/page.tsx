'use client';
import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useRouter } from 'next/navigation';
import { Sparkles, ArrowRight, ArrowLeft, CheckCircle2, Loader2, User, MapPin, Globe, Briefcase, Home, Heart, GraduationCap, Calendar } from 'lucide-react';
import { useLanguage, LANGUAGES, translations } from '@/lib/i18n/LanguageContext';

const GOLD = '#FFD700';
const BLUE = '#002654';
const tr = translations.onboarding;

// ─── Profile schema ────────────────────────────────────────────────
interface Profile {
  name: string;
  profile_type: string;
  arrival_date: string;
  arrondissement: string;
  visa_type: string;
  french_level: string;
  housing_status: string;
  has_children: boolean;
  has_pets: boolean;
  goals: string[];
  nationality: string;
}

const PROFILE_TYPES = [
  { id: 'student',      emoji: '🎓', label: 'Student',       desc: 'University or language school' },
  { id: 'professional', emoji: '💼', label: 'Professional',  desc: 'Work visa or posted employee' },
  { id: 'family',       emoji: '👨‍👩‍👧', label: 'Family',        desc: 'Relocating with partner/kids' },
  { id: 'freelancer',   emoji: '💻', label: 'Freelancer',    desc: 'Remote worker or entrepreneur' },
  { id: 'retiree',      emoji: '🌸', label: 'Retiree',       desc: 'Long-stay or retirement visa' },
  { id: 'explorer',     emoji: '🌍', label: 'Explorer',      desc: 'Digital nomad or tourist extended stay' },
];

const VISA_TYPES = [
  { id: 'student',     label: 'Student VLS-TS',       desc: 'Visa long séjour étudiant' },
  { id: 'work',        label: 'Work Visa',             desc: 'Salarié or talent passport' },
  { id: 'eu',          label: 'EU/EEA Citizen',        desc: 'Freedom of movement, no titre de séjour' },
  { id: 'passeport_talent', label: 'Talent Passport',  desc: 'Highly skilled professionals' },
  { id: 'entrepreneur', label: 'Entrepreneur Visa',    desc: 'Auto-entrepreneur or business creation' },
  { id: 'family',      label: 'Family Reunification',  desc: 'Regroupement familial' },
  { id: 'tourist',     label: 'Tourist / Short Stay',  desc: '< 90 days, Schengen visa' },
  { id: 'other',       label: 'Other / Not sure',      desc: "I'll figure it out" },
];

const FRENCH_LEVELS = [
  { id: 'none',         emoji: '😅', label: 'Zero French',   desc: 'I only know "bonjour" and "merci"' },
  { id: 'basic',        emoji: '🙂', label: 'Basic',          desc: 'A few phrases, survival mode' },
  { id: 'intermediate', emoji: '😊', label: 'Intermediate',   desc: 'Can have a simple conversation' },
  { id: 'advanced',     emoji: '🥐', label: 'Advanced',       desc: 'Comfortable in most situations' },
  { id: 'fluent',       emoji: '🇫🇷', label: 'Fluent',        desc: 'Nearly native level' },
];

const HOUSING_STATUS = [
  { id: 'searching',  emoji: '🔍', label: 'Still searching',  desc: "Haven't found a place yet" },
  { id: 'temporary',  emoji: '🏨', label: 'Temporary lodging', desc: "Hotel, Airbnb, friend's place" },
  { id: 'settled',    emoji: '🏠', label: 'Settled in',        desc: 'Have my own apartment' },
  { id: 'crous',      emoji: '🏫', label: 'CROUS residence',   desc: 'Student accommodation' },
];

const GOALS = [
  { id: 'admin',      emoji: '🏛️', label: 'Navigate paperwork', desc: 'CAF, Préfecture, AMELI...' },
  { id: 'housing',    emoji: '🏠', label: 'Find housing',        desc: 'Apartment & settling in' },
  { id: 'healthcare', emoji: '❤️‍🩹', label: 'Access healthcare',  desc: 'Doctor, Carte Vitale...' },
  { id: 'work',       emoji: '💼', label: 'Find work',           desc: 'Jobs, freelancing, contracts' },
  { id: 'language',   emoji: '🌐', label: 'Learn French',        desc: 'Classes, language exchange' },
  { id: 'community',  emoji: '🤝', label: 'Meet people',         desc: 'Expat groups, social life' },
  { id: 'culture',    emoji: '🎭', label: 'Explore Paris',       desc: 'Museums, food, experiences' },
  { id: 'banking',    emoji: '🏦', label: 'Set up banking',      desc: 'Bank account, savings' },
];

const ARRONDISSEMENTS = [
  '1er', '2ème', '3ème', '4ème', '5ème', '6ème', '7ème', '8ème', '9ème', '10ème',
  '11ème', '12ème', '13ème', '14ème', '15ème', '16ème', '17ème', '18ème', '19ème', '20ème',
  'Banlieue / Suburbs', 'Not sure yet',
];

// ─── Step Components ────────────────────────────────────────────────
function StepCard({ children, title, subtitle }: { children: React.ReactNode; title: string; subtitle?: string }) {
  return (
    <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -20 }}
      transition={{ duration: 0.35, ease: 'easeOut' }}
      style={{ maxWidth: 640, margin: '0 auto' }}>
      <div style={{ marginBottom: '2rem', textAlign: 'center' }}>
        <h2 style={{ fontFamily: 'Playfair Display, serif', fontSize: 'clamp(1.5rem,3vw,2rem)', fontWeight: 700, color: '#fff', marginBottom: '0.5rem' }}>{title}</h2>
        {subtitle && <p style={{ color: '#8E8E93', fontSize: '0.95rem' }}>{subtitle}</p>}
      </div>
      {children}
    </motion.div>
  );
}

function OptionGrid({ options, value, onSelect, multi = false }: {
  options: { id: string; emoji: string; label: string; desc?: string }[];
  value: string | string[];
  onSelect: (id: string) => void;
  multi?: boolean;
}) {
  const isSelected = (id: string) => multi ? (value as string[]).includes(id) : value === id;
  return (
    <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(180px, 1fr))', gap: '0.75rem' }}>
      {options.map(opt => (
        <motion.button key={opt.id} whileHover={{ scale: 1.03 }} whileTap={{ scale: 0.97 }}
          onClick={() => onSelect(opt.id)}
          style={{
            padding: '1rem 1.1rem', borderRadius: 14, textAlign: 'left', cursor: 'pointer',
            background: isSelected(opt.id) ? `rgba(0,38,84,0.25)` : 'rgba(255,255,255,0.04)',
            border: `1.5px solid ${isSelected(opt.id) ? '#3a7bd5' : 'rgba(255,255,255,0.08)'}`,
            boxShadow: isSelected(opt.id) ? '0 0 20px rgba(0,38,84,0.2)' : 'none',
            transition: 'all 0.15s',
          }}>
          <div style={{ fontSize: 22, marginBottom: '0.5rem' }}>{opt.emoji}</div>
          <div style={{ fontWeight: 700, color: isSelected(opt.id) ? '#fff' : '#e5e7eb', fontSize: 13, marginBottom: '0.25rem' }}>{opt.label}</div>
          {opt.desc && <div style={{ fontSize: 11, color: '#8E8E93', lineHeight: 1.5 }}>{opt.desc}</div>}
          {isSelected(opt.id) && (
            <CheckCircle2 style={{ width: 14, height: 14, color: '#3a7bd5', marginTop: 6 }} />
          )}
        </motion.button>
      ))}
    </div>
  );
}

// ─── Main Onboarding Component ────────────────────────────────────
export default function OnboardingPage() {
  const router = useRouter();
  const { lang, setLang, t } = useLanguage();
  const [step, setStep] = useState(0);
  const [generating, setGenerating] = useState(false);
  const [profile, setProfile] = useState<Profile>({
    name: '',
    profile_type: '',
    arrival_date: '',
    arrondissement: '',
    visa_type: '',
    french_level: '',
    housing_status: '',
    has_children: false,
    has_pets: false,
    goals: [],
    nationality: '',
  });

  const update = (key: keyof Profile, val: string | boolean | string[]) =>
    setProfile(p => ({ ...p, [key]: val }));

  const toggleGoal = (id: string) => {
    const goals = profile.goals.includes(id)
      ? profile.goals.filter(g => g !== id)
      : [...profile.goals, id];
    update('goals', goals);
  };

  // Step 0 = language picker; steps 1-7 = profile setup
  const TOTAL_STEPS = 8;
  const progress = ((step + 1) / TOTAL_STEPS) * 100;

  const canProceed = () => {
    switch (step) {
      case 0: return true; // language always valid
      case 1: return profile.name.trim().length > 0;
      case 2: return !!profile.profile_type;
      case 3: return !!profile.visa_type;
      case 4: return !!profile.french_level && !!profile.housing_status;
      case 5: return profile.goals.length > 0;
      case 6: return !!profile.arrondissement;
      case 7: return true;
      default: return true;
    }
  };

  const handleFinish = async () => {
    setGenerating(true);
    try {
      const res = await fetch('/api/onboarding', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ profile }),
      });
      const data = await res.json();
      localStorage.setItem('paris_profile', JSON.stringify(profile));
      if (data.timeline) {
        localStorage.setItem('paris_timeline', JSON.stringify(data.timeline));
      }
      router.push('/dashboard?welcome=1');
    } catch {
      localStorage.setItem('paris_profile', JSON.stringify(profile));
      router.push('/dashboard?welcome=1');
    }
  };

  const steps = [
    // Step 0 — Language picker (NEW)
    <StepCard key={0} title={t(tr.langStep.title)} subtitle={t(tr.langStep.subtitle)}>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(180px, 1fr))', gap: '0.75rem' }}>
        {LANGUAGES.map(l => (
          <motion.button
            key={l.code}
            whileHover={{ scale: 1.03 }} whileTap={{ scale: 0.97 }}
            onClick={() => setLang(l.code)}
            style={{
              padding: '1.2rem 1.1rem', borderRadius: 14, textAlign: 'center', cursor: 'pointer',
              background: lang === l.code ? 'rgba(0,38,84,0.25)' : 'rgba(255,255,255,0.04)',
              border: `1.5px solid ${lang === l.code ? '#3a7bd5' : 'rgba(255,255,255,0.08)'}`,
              boxShadow: lang === l.code ? '0 0 20px rgba(0,38,84,0.2)' : 'none',
              transition: 'all 0.15s',
            }}>
            <div style={{ fontSize: 32, marginBottom: '0.5rem' }}>{l.flag}</div>
            <div style={{ fontWeight: 700, color: lang === l.code ? '#fff' : '#e5e7eb', fontSize: 14, marginBottom: '0.25rem' }}>{l.native}</div>
            <div style={{ fontSize: 11, color: '#8E8E93' }}>{l.label}</div>
            {lang === l.code && <CheckCircle2 style={{ width: 14, height: 14, color: '#3a7bd5', marginTop: 8, margin: '8px auto 0' }} />}
          </motion.button>
        ))}
      </div>
    </StepCard>,

    // Step 1 — Name
    <StepCard key={1} title="Bienvenue à Paris 🗼" subtitle={t(tr.nameStep.subtitle)}>
      <div style={{ position: 'relative', maxWidth: 320, margin: '0 auto' }}>
        <User style={{ position: 'absolute', left: 14, top: '50%', transform: 'translateY(-50%)', width: 16, height: 16, color: '#4b5563' }} />
        <input
          autoFocus
          placeholder={t(tr.nameStep.placeholder)}
          value={profile.name}
          onChange={e => update('name', e.target.value)}
          onKeyDown={e => e.key === 'Enter' && canProceed() && setStep(2)}
          style={{
            width: '100%', paddingLeft: 42, paddingRight: 16, paddingTop: 14, paddingBottom: 14,
            borderRadius: 14, background: 'rgba(255,255,255,0.06)', border: '1.5px solid rgba(255,255,255,0.12)',
            color: '#fff', fontSize: 16, outline: 'none', boxSizing: 'border-box',
          }}
        />
      </div>
    </StepCard>,

    // Step 2 — Profile type
    <StepCard key={2} title={t(tr.profileStep.title)} subtitle={t(tr.profileStep.subtitle)}>
      <OptionGrid options={PROFILE_TYPES} value={profile.profile_type} onSelect={v => update('profile_type', v)} />
    </StepCard>,

    // Step 3 — Visa
    <StepCard key={3} title={t(tr.visaStep.title)} subtitle={t(tr.visaStep.subtitle)}>
      <div style={{ display: 'flex', flexDirection: 'column', gap: '0.6rem' }}>
        {VISA_TYPES.map(opt => (
          <motion.button key={opt.id} whileTap={{ scale: 0.98 }} onClick={() => update('visa_type', opt.id)}
            style={{ padding: '0.875rem 1rem', borderRadius: 12, cursor: 'pointer', textAlign: 'left',
              background: profile.visa_type === opt.id ? 'rgba(0,38,84,0.25)' : 'rgba(255,255,255,0.04)',
              border: `1.5px solid ${profile.visa_type === opt.id ? '#3a7bd5' : 'rgba(255,255,255,0.08)'}`,
              transition: 'all 0.15s' }}>
            <div style={{ fontWeight: 700, color: profile.visa_type === opt.id ? '#fff' : '#e5e7eb', fontSize: 13 }}>{opt.label}</div>
            <div style={{ fontSize: 11, color: '#8E8E93', marginTop: 3 }}>{opt.desc}</div>
          </motion.button>
        ))}
      </div>
    </StepCard>,

    // Step 4 — French level + housing
    <StepCard key={4} title={t(tr.situationStep.title)} subtitle={t(tr.situationStep.subtitle)}>
      <div style={{ marginBottom: '1.75rem' }}>
        <div style={{ fontWeight: 700, color: '#fff', marginBottom: '0.875rem', fontSize: 14, display: 'flex', alignItems: 'center', gap: 6 }}>
          <Globe style={{ width: 15, height: 15, color: GOLD }} /> {t(tr.situationStep.frenchLabel)}
        </div>
        <div style={{ display: 'flex', flexDirection: 'column', gap: '0.5rem' }}>
          {FRENCH_LEVELS.map(opt => (
            <motion.button key={opt.id} whileTap={{ scale: 0.98 }} onClick={() => update('french_level', opt.id)}
              style={{ padding: '0.875rem 1rem', borderRadius: 12, cursor: 'pointer', textAlign: 'left',
                background: profile.french_level === opt.id ? 'rgba(0,38,84,0.25)' : 'rgba(255,255,255,0.04)',
                border: `1.5px solid ${profile.french_level === opt.id ? '#3a7bd5' : 'rgba(255,255,255,0.08)'}`,
                transition: 'all 0.15s', display: 'flex', alignItems: 'center', gap: 10 }}>
              <span style={{ fontSize: 20 }}>{opt.emoji}</span>
              <div>
                <div style={{ fontWeight: 700, color: profile.french_level === opt.id ? '#fff' : '#e5e7eb', fontSize: 13 }}>{opt.label}</div>
                <div style={{ fontSize: 11, color: '#8E8E93' }}>{opt.desc}</div>
              </div>
            </motion.button>
          ))}
        </div>
      </div>
      <div>
        <div style={{ fontWeight: 700, color: '#fff', marginBottom: '0.875rem', fontSize: 14, display: 'flex', alignItems: 'center', gap: 6 }}>
          <Home style={{ width: 15, height: 15, color: GOLD }} /> {t(tr.situationStep.housingLabel)}
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '0.5rem' }}>
          {HOUSING_STATUS.map(opt => (
            <motion.button key={opt.id} whileTap={{ scale: 0.96 }} onClick={() => update('housing_status', opt.id)}
              style={{ padding: '0.875rem 1rem', borderRadius: 12, cursor: 'pointer', textAlign: 'left',
                background: profile.housing_status === opt.id ? 'rgba(0,38,84,0.25)' : 'rgba(255,255,255,0.04)',
                border: `1.5px solid ${profile.housing_status === opt.id ? '#3a7bd5' : 'rgba(255,255,255,0.08)'}`,
                transition: 'all 0.15s' }}>
              <div style={{ fontSize: 20, marginBottom: 4 }}>{opt.emoji}</div>
              <div style={{ fontSize: 12, fontWeight: 700, color: profile.housing_status === opt.id ? '#fff' : '#d1d5db' }}>{opt.label}</div>
              <div style={{ fontSize: 10, color: '#8E8E93', marginTop: 2 }}>{opt.desc}</div>
            </motion.button>
          ))}
        </div>
      </div>
    </StepCard>,

    // Step 5 — Goals
    <StepCard key={5} title={t(tr.goalsStep.title)} subtitle={t(tr.goalsStep.subtitle)}>
      <OptionGrid options={GOALS} value={profile.goals} onSelect={toggleGoal} multi />
      {profile.goals.length > 0 && (
        <motion.p initial={{ opacity: 0 }} animate={{ opacity: 1 }}
          style={{ textAlign: 'center', marginTop: '1rem', color: GOLD, fontSize: 13, fontWeight: 600 }}>
          {profile.goals.length} {t(tr.goalsStep.selected)}
        </motion.p>
      )}
    </StepCard>,

    // Step 6 — Location
    <StepCard key={6} title={t(tr.locationStep.title)} subtitle={t(tr.locationStep.subtitle)}>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(100px, 1fr))', gap: '0.5rem' }}>
        {ARRONDISSEMENTS.map(arr => (
          <motion.button key={arr} whileTap={{ scale: 0.95 }} onClick={() => update('arrondissement', arr)}
            style={{ padding: '0.6rem 0.5rem', borderRadius: 10, cursor: 'pointer', textAlign: 'center',
              background: profile.arrondissement === arr ? 'rgba(0,38,84,0.25)' : 'rgba(255,255,255,0.04)',
              border: `1.5px solid ${profile.arrondissement === arr ? '#3a7bd5' : 'rgba(255,255,255,0.08)'}`,
              fontSize: 12, fontWeight: 600, color: profile.arrondissement === arr ? '#fff' : '#9ca3af',
              transition: 'all 0.15s' }}>
            <MapPin style={{ width: 12, height: 12, margin: '0 auto 3px', color: profile.arrondissement === arr ? '#3a7bd5' : '#4b5563', display: 'block' }} />
            {arr}
          </motion.button>
        ))}
      </div>
    </StepCard>,

    // Step 7 — Family & arrival date
    <StepCard key={7} title={t(tr.finalStep.title)} subtitle={t(tr.finalStep.subtitle)}>
      <div style={{ marginBottom: '2rem' }}>
        <div style={{ fontWeight: 700, color: '#fff', marginBottom: '0.875rem', fontSize: 14, display: 'flex', alignItems: 'center', gap: 6 }}>
          <Calendar style={{ width: 15, height: 15, color: GOLD }} /> {t(tr.finalStep.arrivalQ)}
        </div>
        <input
          type="date"
          value={profile.arrival_date}
          onChange={e => update('arrival_date', e.target.value)}
          style={{
            padding: '12px 14px', borderRadius: 12, background: 'rgba(255,255,255,0.06)',
            border: '1.5px solid rgba(255,255,255,0.12)', color: '#fff', fontSize: 14, width: '100%',
            colorScheme: 'dark',
          }}
        />
      </div>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '0.875rem' }}>
        <div>
          <div style={{ fontWeight: 700, color: '#fff', marginBottom: '0.75rem', fontSize: 14, display: 'flex', alignItems: 'center', gap: 6 }}>
            <Heart style={{ width: 15, height: 15, color: GOLD }} /> {t(tr.finalStep.children)}
          </div>
          <div style={{ display: 'flex', gap: '0.5rem' }}>
            {[{ label: t(tr.finalStep.yes) + ' 👶', val: true }, { label: t(tr.finalStep.no), val: false }].map(v => (
              <motion.button key={String(v.val)} whileTap={{ scale: 0.95 }} onClick={() => update('has_children', v.val)}
                style={{ flex: 1, padding: '0.75rem', borderRadius: 10, cursor: 'pointer',
                  background: profile.has_children === v.val ? 'rgba(0,38,84,0.25)' : 'rgba(255,255,255,0.04)',
                  border: `1.5px solid ${profile.has_children === v.val ? '#3a7bd5' : 'rgba(255,255,255,0.08)'}`,
                  color: '#e5e7eb', fontSize: 13, fontWeight: 600, transition: 'all 0.15s' }}>
                {v.label}
              </motion.button>
            ))}
          </div>
        </div>
        <div>
          <div style={{ fontWeight: 700, color: '#fff', marginBottom: '0.75rem', fontSize: 14 }}>
            🐾 {t(tr.finalStep.pets)}
          </div>
          <div style={{ display: 'flex', gap: '0.5rem' }}>
            {[{ label: t(tr.finalStep.yes) + ' 🐶', val: true }, { label: t(tr.finalStep.no), val: false }].map(v => (
              <motion.button key={String(v.val)} whileTap={{ scale: 0.95 }} onClick={() => update('has_pets', v.val)}
                style={{ flex: 1, padding: '0.75rem', borderRadius: 10, cursor: 'pointer',
                  background: profile.has_pets === v.val ? 'rgba(0,38,84,0.25)' : 'rgba(255,255,255,0.04)',
                  border: `1.5px solid ${profile.has_pets === v.val ? '#3a7bd5' : 'rgba(255,255,255,0.08)'}`,
                  color: '#e5e7eb', fontSize: 13, fontWeight: 600, transition: 'all 0.15s' }}>
                {v.label}
              </motion.button>
            ))}
          </div>
        </div>
      </div>
    </StepCard>,
  ];

  if (generating) {
    return (
      <div style={{ minHeight: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center', flexDirection: 'column', gap: '1.5rem', padding: '2rem', background: 'hsl(210,30%,6%)' }}>
        <motion.div animate={{ rotate: 360 }} transition={{ duration: 2, repeat: Infinity, ease: 'linear' }}>
          <div style={{ width: 56, height: 56, borderRadius: '50%', border: `3px solid rgba(0,38,84,0.2)`, borderTop: `3px solid ${GOLD}` }} />
        </motion.div>
        <div style={{ textAlign: 'center' }}>
          <div style={{ fontFamily: 'Playfair Display, serif', fontSize: '1.5rem', color: '#fff', marginBottom: '0.5rem' }}>{t(tr.loading.title)}</div>
          <motion.p
            animate={{ opacity: [0.5, 1, 0.5] }} transition={{ duration: 2, repeat: Infinity }}
            style={{ color: '#8E8E93', fontSize: 14 }}>
            {t(tr.loading.subtitle)}
          </motion.p>
        </div>
      </div>
    );
  }

  return (
    <div style={{ minHeight: '100vh', background: 'hsl(210,30%,6%)', position: 'relative', overflow: 'hidden' }}>
      <div style={{ position: 'fixed', inset: 0, pointerEvents: 'none' }}>
        <div style={{ position: 'absolute', top: '-20%', left: '-10%', width: 600, height: 600, borderRadius: '50%', background: 'rgba(0,38,84,0.1)', filter: 'blur(120px)' }} />
        <div style={{ position: 'absolute', bottom: '-10%', right: '-5%', width: 400, height: 400, borderRadius: '50%', background: 'rgba(255,215,0,0.06)', filter: 'blur(100px)' }} />
      </div>

      <div style={{ maxWidth: 720, margin: '0 auto', padding: '2rem 1.5rem 6rem', position: 'relative' }}>
        {/* Header */}
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '2.5rem' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
            <Sparkles style={{ width: 18, height: 18, color: GOLD }} />
            <span style={{ fontSize: 13, fontWeight: 700, color: GOLD }}>Marcel · Your Paris AI</span>
          </div>
          <div style={{ fontSize: 12, color: '#8E8E93' }}>{t(tr.nav.step)} {step + 1} {t(tr.nav.of)} {TOTAL_STEPS}</div>
        </div>

        {/* Progress bar */}
        <div style={{ height: 3, borderRadius: 3, background: 'rgba(255,255,255,0.06)', marginBottom: '3rem', overflow: 'hidden' }}>
          <motion.div
            animate={{ width: `${progress}%` }}
            transition={{ duration: 0.5, ease: 'easeOut' }}
            style={{ height: '100%', borderRadius: 3, background: `linear-gradient(90deg, ${BLUE}, ${GOLD})` }}
          />
        </div>

        {/* Step content */}
        <AnimatePresence mode="wait">
          {steps[step]}
        </AnimatePresence>

        {/* Navigation buttons */}
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginTop: '2.5rem', maxWidth: 640, margin: '2.5rem auto 0' }}>
          {step > 0 ? (
            <motion.button whileHover={{ scale: 1.03 }} whileTap={{ scale: 0.97 }} onClick={() => setStep(s => s - 1)}
              style={{ display: 'flex', alignItems: 'center', gap: 6, padding: '10px 18px', borderRadius: 10, background: 'rgba(255,255,255,0.06)', border: '1px solid rgba(255,255,255,0.1)', cursor: 'pointer', color: '#8E8E93', fontSize: 13, fontWeight: 600 }}>
              <ArrowLeft style={{ width: 14, height: 14 }} /> {t(tr.nav.back)}
            </motion.button>
          ) : (
            <div />
          )}

          {step < TOTAL_STEPS - 1 ? (
            <motion.button whileHover={{ scale: canProceed() ? 1.04 : 1 }} whileTap={{ scale: canProceed() ? 0.97 : 1 }}
              onClick={() => canProceed() && setStep(s => s + 1)}
              style={{
                display: 'flex', alignItems: 'center', gap: 8, padding: '12px 28px', borderRadius: 12,
                background: canProceed() ? `linear-gradient(135deg, ${BLUE}, #0052A5)` : 'rgba(255,255,255,0.06)',
                border: 'none', cursor: canProceed() ? 'pointer' : 'not-allowed', color: canProceed() ? '#fff' : '#4b5563',
                fontSize: 14, fontWeight: 700, boxShadow: canProceed() ? '0 0 24px rgba(0,38,84,0.3)' : 'none',
                transition: 'all 0.2s',
              }}>
              {t(tr.nav.continue)} <ArrowRight style={{ width: 14, height: 14 }} />
            </motion.button>
          ) : (
            <motion.button whileHover={{ scale: 1.04 }} whileTap={{ scale: 0.97 }}
              onClick={handleFinish}
              style={{
                display: 'flex', alignItems: 'center', gap: 8, padding: '14px 32px', borderRadius: 14,
                background: `linear-gradient(135deg, ${BLUE}, ${GOLD})`, border: 'none', cursor: 'pointer',
                color: '#fff', fontSize: 15, fontWeight: 800, boxShadow: '0 0 32px rgba(0,38,84,0.4)',
              }}>
              <Sparkles style={{ width: 16, height: 16 }} /> {t(tr.nav.finish)}
            </motion.button>
          )}
        </div>

        {/* Marcel intro card (language step only) */}
        {step === 0 && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.5 }}
            style={{ maxWidth: 640, margin: '2rem auto 0', padding: '1rem 1.25rem', borderRadius: 14, background: 'rgba(255,215,0,0.06)', border: '1px solid rgba(255,215,0,0.18)', display: 'flex', gap: '0.875rem' }}>
            <div style={{ width: 36, height: 36, borderRadius: 10, background: `linear-gradient(135deg, ${BLUE}, #0052A5)`, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 18, flexShrink: 0 }}>
              🤖
            </div>
            <div>
              <div style={{ fontWeight: 700, color: GOLD, fontSize: 12, marginBottom: 4 }}>Marcel · AI Paris Companion</div>
              <p style={{ color: '#8E8E93', fontSize: 13, lineHeight: 1.6 }}>
                {t(tr.marcelIntro)}
              </p>
            </div>
          </motion.div>
        )}
      </div>
    </div>
  );
}
