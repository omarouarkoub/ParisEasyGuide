'use client';
import { motion, AnimatePresence } from 'framer-motion';
import { FadeIn } from '@/components/shared/PageMotion';
import ParisMap3D from '@/components/map/ParisMap3D';
import { useState } from 'react';
import { Map, Sparkles, Clock, Euro, Star, CheckCircle2, MapPin, Loader2 } from 'lucide-react';
import { useLanguage, LANGUAGES } from '@/lib/i18n/LanguageContext';
import { toast } from 'sonner';

const DURATIONS = ['2 hours', 'Half day', 'Full day'];
const BUDGETS = ['€10–20', '€20–50', '€50–100', '€100+'];
const INTERESTS = ['Museums', 'Food & Cafés', 'Parks', 'History', 'Shopping', 'Hidden gems', 'Free only'];

interface ItineraryStep {
  time: string; place: string; address: string; description: string;
  duration: string; cost: string; tip: string; lat?: number; lng?: number;
}
interface Itinerary {
  title: string; summary: string; steps: ItineraryStep[];
  transport_tip: string; total_cost: string;
}

export default function ItineraryPage() {
  const { lang } = useLanguage();
  const langLabel = LANGUAGES.find(l => l.code === lang)?.label ?? "English";
  const [location, setLocation] = useState('');
  const [duration, setDuration] = useState('Half day');
  const [budget, setBudget] = useState('€20–50');
  const [interests, setInterests] = useState(['Museums', 'Food & Cafés']);
  const [result, setResult] = useState<Itinerary | null>(null);
  const [loading, setLoading] = useState(false);
  const [locating, setLocating] = useState(false);
  const [checked, setChecked] = useState<Set<number>>(new Set());

  const toggleInterest = (item: string) =>
    setInterests(prev => prev.includes(item) ? prev.filter(x => x !== item) : [...prev, item]);

  const toggleCheck = (i: number) =>
    setChecked(prev => { const s = new Set(prev); s.has(i) ? s.delete(i) : s.add(i); return s; });

  const useMyLocation = () => {
    if (!navigator.geolocation) return;
    setLocating(true);
    navigator.geolocation.getCurrentPosition(async (pos) => {
      const { latitude: lat, longitude: lng } = pos.coords;
      const res = await fetch(`https://nominatim.openstreetmap.org/reverse?lat=${lat}&lon=${lng}&format=json`);
      const data = await res.json();
      const name = data.address?.road
        ? `${data.address.road}${data.address.suburb ? ', ' + data.address.suburb : ''}`
        : data.display_name?.split(',')[0] || `${lat.toFixed(4)}, ${lng.toFixed(4)}`;
      setLocation(name);
      setLocating(false);
    }, () => setLocating(false), { enableHighAccuracy: true, timeout: 10000 });
  };

  const generate = async () => {
    if (interests.length === 0) { toast.error('Please select at least one interest.'); return; }
    setLoading(true);
    setResult(null);
    setChecked(new Set());
    try {
      const res = await fetch('/api/itinerary', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ location, duration, budget, interests }),
      });
      const data = await res.json();
      if (data.itinerary) { setResult(data.itinerary); toast.success('Itinerary generated!'); }
      else toast.error('Could not generate itinerary.');
    } catch { toast.error('Failed to generate itinerary.'); }
    finally { setLoading(false); }
  };

  return (
    <div style={{ padding: '2rem 2.5rem', maxWidth: 900, margin: '0 auto' }}>
      <div style={{ marginBottom: '2rem' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 4 }}>
          <Map style={{ width: 16, height: 16, color: '#FFD700' }} />
          <span style={{ fontSize: 12, fontWeight: 600, color: '#FFD700', textTransform: 'uppercase', letterSpacing: '0.1em' }}>Itinerary AI</span>
        </div>
        <h1 style={{ fontFamily: 'Playfair Display, serif', fontSize: '2rem', fontWeight: 700, color: '#fff' }}>Plan Your Day</h1>
        <p style={{ color: '#8E8E93', fontSize: 14 }}>Generate a personalised Paris itinerary in seconds</p>
      </div>

      {/* Builder */}
      <div style={{ padding: '1.5rem', borderRadius: 16, background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.08)', marginBottom: '1.5rem' }}>
        {/* Location */}
        <div style={{ marginBottom: '1.25rem' }}>
          <label style={{ fontSize: 12, fontWeight: 600, color: '#8E8E93', textTransform: 'uppercase', letterSpacing: '0.05em', display: 'block', marginBottom: 8 }}>Starting Location</label>
          <div style={{ display: 'flex', gap: 8 }}>
            <input value={location} onChange={e => setLocation(e.target.value)} placeholder="e.g. Le Marais, Eiffel Tower, Gare du Nord…"
              style={{ flex: 1, background: 'rgba(255,255,255,0.06)', border: '1px solid rgba(255,255,255,0.1)', borderRadius: 10, padding: '10px 14px', color: '#fff', fontSize: 14, outline: 'none' }} />
            <button onClick={useMyLocation} disabled={locating}
              style={{ padding: '10px 14px', borderRadius: 10, background: 'rgba(234,88,12,0.2)', border: '1px solid rgba(234,88,12,0.3)', cursor: 'pointer', color: '#fb923c', display: 'flex', alignItems: 'center', gap: 6, fontSize: 13, fontWeight: 600 }}>
              {locating ? <Loader2 style={{ width: 14, height: 14, animation: 'spin 1s linear infinite' }} /> : <MapPin style={{ width: 14, height: 14 }} />}
              {locating ? 'Locating…' : 'My Location'}
            </button>
          </div>
        </div>

        {/* Duration & Budget */}
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1.25rem', marginBottom: '1.25rem' }}>
          <div>
            <label style={{ fontSize: 12, fontWeight: 600, color: '#8E8E93', textTransform: 'uppercase', letterSpacing: '0.05em', display: 'block', marginBottom: 8 }}>Duration</label>
            <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}>
              {DURATIONS.map(d => (
                <button key={d} onClick={() => setDuration(d)} style={{ padding: '7px 14px', borderRadius: 20, fontSize: 13, fontWeight: 600, cursor: 'pointer', border: 'none', background: duration === d ? '#ea580c' : 'rgba(255,255,255,0.06)', color: duration === d ? '#fff' : '#9ca3af' }}>
                  {d}
                </button>
              ))}
            </div>
          </div>
          <div>
            <label style={{ fontSize: 12, fontWeight: 600, color: '#8E8E93', textTransform: 'uppercase', letterSpacing: '0.05em', display: 'block', marginBottom: 8 }}>Budget</label>
            <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}>
              {BUDGETS.map(b => (
                <button key={b} onClick={() => setBudget(b)} style={{ padding: '7px 14px', borderRadius: 20, fontSize: 13, fontWeight: 600, cursor: 'pointer', border: 'none', background: budget === b ? '#ea580c' : 'rgba(255,255,255,0.06)', color: budget === b ? '#fff' : '#9ca3af' }}>
                  {b}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Interests */}
        <div style={{ marginBottom: '1.5rem' }}>
          <label style={{ fontSize: 12, fontWeight: 600, color: '#8E8E93', textTransform: 'uppercase', letterSpacing: '0.05em', display: 'block', marginBottom: 8 }}>Interests</label>
          <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}>
            {INTERESTS.map(i => (
              <button key={i} onClick={() => toggleInterest(i)} style={{ padding: '7px 14px', borderRadius: 20, fontSize: 13, fontWeight: 600, cursor: 'pointer', border: interests.includes(i) ? '1px solid rgba(234,88,12,0.6)' : '1px solid rgba(255,255,255,0.1)', background: interests.includes(i) ? 'rgba(234,88,12,0.2)' : 'rgba(255,255,255,0.04)', color: interests.includes(i) ? '#fb923c' : '#9ca3af' }}>
                {i}
              </button>
            ))}
          </div>
        </div>

        <button onClick={generate} disabled={loading}
          style={{ width: '100%', padding: '14px', borderRadius: 12, background: loading ? 'rgba(234,88,12,0.3)' : 'linear-gradient(135deg, #ea580c, #c2410c)', border: 'none', cursor: 'pointer', color: '#fff', fontWeight: 700, fontSize: 15, display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8 }}>
          {loading ? <><Loader2 style={{ width: 18, height: 18, animation: 'spin 1s linear infinite' }} /> Generating your itinerary…</> : <><Sparkles style={{ width: 18, height: 18 }} /> Generate Itinerary</>}
        </button>
      </div>

      {/* Result */}
      {result && (
        <div style={{ borderRadius: 16, background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(234,88,12,0.2)', overflow: 'hidden' }}>
          <div style={{ padding: '1.5rem', background: 'linear-gradient(135deg, rgba(234,88,12,0.1), rgba(194,65,12,0.05))', borderBottom: '1px solid rgba(255,255,255,0.08)' }}>
            <h2 style={{ fontFamily: 'Playfair Display, serif', fontSize: '1.4rem', fontWeight: 700, color: '#fff', marginBottom: 4 }}>{result.title}</h2>
            <p style={{ fontSize: 14, color: '#8E8E93', marginBottom: '0.75rem' }}>{result.summary}</p>
            <div style={{ display: 'flex', gap: '1rem', flexWrap: 'wrap' }}>
              <span style={{ fontSize: 12, color: '#fb923c', display: 'flex', alignItems: 'center', gap: 4 }}><Euro style={{ width: 12, height: 12 }} /> {result.total_cost}</span>
              <span style={{ fontSize: 12, color: '#60a5fa', display: 'flex', alignItems: 'center', gap: 4 }}>🚇 {result.transport_tip}</span>
            </div>
          </div>
          {/* 3D Route Map */}
          {result.steps.some(s => s.lat && s.lng) && (
            <div style={{ padding: '0 1.5rem 1.5rem' }}>
              <ParisMap3D
                markers={result.steps.filter(s => s.lat && s.lng).map(s => ({ lat: s.lat!, lng: s.lng!, label: s.place }))}
                pins={[]} routeColor="#ea580c" height="280px" accentColor="#ea580c" />
            </div>
          )}
          <div style={{ padding: '1.5rem', display: 'flex', flexDirection: 'column', gap: '1rem' }}>
            {result.steps.map((step, i) => (
              <div key={i} style={{ display: 'flex', gap: '1rem', padding: '1rem', borderRadius: 12, background: checked.has(i) ? 'rgba(5,150,105,0.08)' : 'rgba(255,255,255,0.03)', border: `1px solid ${checked.has(i) ? 'rgba(5,150,105,0.3)' : 'rgba(255,255,255,0.06)'}`, cursor: 'pointer', transition: 'all 0.2s' }}
                onClick={() => toggleCheck(i)}>
                <div style={{ flexShrink: 0, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 4 }}>
                  <div style={{ width: 36, height: 36, borderRadius: '50%', background: checked.has(i) ? '#059669' : 'rgba(234,88,12,0.2)', border: `2px solid ${checked.has(i) ? '#059669' : 'rgba(234,88,12,0.4)'}`, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 13, fontWeight: 700, color: '#fff' }}>
                    {checked.has(i) ? <CheckCircle2 style={{ width: 18, height: 18 }} /> : i + 1}
                  </div>
                  <span style={{ fontSize: 10, color: '#fb923c', fontWeight: 600 }}>{step.time}</span>
                </div>
                <div style={{ flex: 1 }}>
                  <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', marginBottom: 4 }}>
                    <div>
                      <span style={{ fontWeight: 700, color: checked.has(i) ? '#6ee7b7' : '#fff', fontSize: 15, textDecoration: checked.has(i) ? 'line-through' : 'none' }}>{step.place}</span>
                      <span style={{ fontSize: 12, color: '#8E8E93', marginLeft: 8 }}>{step.address}</span>
                    </div>
                    <div style={{ display: 'flex', gap: 6, flexShrink: 0, marginLeft: 8 }}>
                      <span style={{ fontSize: 11, padding: '2px 8px', borderRadius: 20, background: 'rgba(234,88,12,0.15)', color: '#fb923c', display: 'flex', alignItems: 'center', gap: 3 }}>
                        <Clock style={{ width: 10, height: 10 }} />{step.duration}
                      </span>
                      <span style={{ fontSize: 11, padding: '2px 8px', borderRadius: 20, background: 'rgba(5,150,105,0.15)', color: '#34d399', display: 'flex', alignItems: 'center', gap: 3 }}>
                        <Euro style={{ width: 10, height: 10 }} />{step.cost}
                      </span>
                    </div>
                  </div>
                  <p style={{ fontSize: 13, color: '#8E8E93', lineHeight: 1.6, marginBottom: step.tip ? 6 : 0 }}>{step.description}</p>
                  {step.tip && <p style={{ fontSize: 12, color: '#fbbf24', display: 'flex', alignItems: 'flex-start', gap: 4 }}><Star style={{ width: 11, height: 11, marginTop: 2, flexShrink: 0 }} />{step.tip}</p>}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
      <style>{`@keyframes spin { from { transform: rotate(0deg); } to { transform: rotate(360deg); } }`}</style>
    </div>
  );
}
