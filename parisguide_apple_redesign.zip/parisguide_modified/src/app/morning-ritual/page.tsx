'use client';
import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Loader2, Sunrise, MapPin, Coffee, Navigation } from 'lucide-react';
import { FadeIn } from '@/components/shared/PageMotion';

const GOLD = '#FFD700';

interface QuizOption { label: string; value: string; emoji: string; }
interface QuizQuestion { id: string; question: string; options: QuizOption[]; }

const QUIZ: QuizQuestion[] = [
  {
    id: 'energy',
    question: 'Your ideal morning energy level is…',
    options: [
      { label: 'Very slow, barely conscious', value: 'slow', emoji: '🐌' },
      { label: 'Gentle and contemplative', value: 'gentle', emoji: '🍃' },
      { label: 'Awake and curious', value: 'curious', emoji: '👀' },
      { label: 'Ready to conquer the world', value: 'energized', emoji: '⚡' },
    ],
  },
  {
    id: 'coffee',
    question: 'Your coffee order says a lot. You choose…',
    options: [
      { label: 'Espresso, straight, no ceremony', value: 'espresso', emoji: '☕' },
      { label: 'Long black at a terrace', value: 'longblack', emoji: '🪑' },
      { label: 'Café crème with a croissant', value: 'classic', emoji: '🥐' },
      { label: 'Matcha / herbal tea, honestly', value: 'tea', emoji: '🍵' },
    ],
  },
  {
    id: 'solitude',
    question: 'Morning time is best…',
    options: [
      { label: 'Completely alone, silence', value: 'alone', emoji: '🌌' },
      { label: 'With people around but no conversation', value: 'ambient', emoji: '📰' },
      { label: 'Light conversation with a stranger', value: 'social', emoji: '💬' },
      { label: 'Moving through the city, no fixed spot', value: 'moving', emoji: '🚶' },
    ],
  },
  {
    id: 'scenery',
    question: 'Your ideal morning backdrop is…',
    options: [
      { label: 'Water — river, canal, fountain', value: 'water', emoji: '🌊' },
      { label: 'A market with noise and colour', value: 'market', emoji: '🛒' },
      { label: 'A garden or park, birds only', value: 'garden', emoji: '🌳' },
      { label: 'An interesting street, watching the city wake', value: 'street', emoji: '🏙️' },
    ],
  },
  {
    id: 'time',
    question: 'You actually wake up at…',
    options: [
      { label: 'Before 7h — I\'m absurdly early', value: 'dawn', emoji: '🌅' },
      { label: '7h–8h30 — a normal early', value: 'early', emoji: '🌤️' },
      { label: '8h30–10h — civilized', value: 'mid', emoji: '☀️' },
      { label: 'After 10h — morning is a loose concept', value: 'late', emoji: '🌙' },
    ],
  },
];

interface MorningRitual {
  title: string;
  tagline: string;
  emoji: string;
  sequence: Array<{ time: string; activity: string; location: string; why: string; }>;
  radius: string;
  vibe: string;
}

export default function MorningRitualPage() {
  const [answers, setAnswers] = useState<Record<string, string>>({});
  const [currentQ, setCurrentQ] = useState(0);
  const [ritual, setRitual] = useState<MorningRitual | null>(null);
  const [loading, setLoading] = useState(false);
  const [location, setLocation] = useState('');
  const [locationAsked, setLocationAsked] = useState(false);

  const handleAnswer = (qId: string, value: string) => {
    const next = { ...answers, [qId]: value };
    setAnswers(next);
    if (currentQ < QUIZ.length - 1) {
      setCurrentQ(currentQ + 1);
    } else {
      setLocationAsked(true);
    }
  };

  const generateRitual = async () => {
    setLoading(true);
    try {
      const answerSummary = Object.entries(answers)
        .map(([qId, val]) => {
          const q = QUIZ.find(q => q.id === qId);
          const opt = q?.options.find(o => o.value === val);
          return `${q?.question}: ${opt?.label}`;
        }).join('\n');

      const res = await fetch('https://api.anthropic.com/v1/messages', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          model: 'claude-sonnet-4-6',
          max_tokens: 1000,
          messages: [{
            role: 'user',
            content: `You are a Paris morning ritual curator — deeply knowledgeable about the city's rhythms, cafés, markets, parks, and streets. Based on this person's personality profile, design their ideal Paris morning ritual.

Personality profile:
${answerSummary}

Their location/neighbourhood: ${location || 'Central Paris (between the 1st and 6th arrondissements)'}

Create a ritual with 3–4 steps, all achievable within approximately 500m of their stated location or a typical Paris neighbourhood. Make it feel personal, specific to Paris, and joyful.

Respond ONLY with valid JSON:
{
  "title": "Short poetic name for this ritual (max 6 words)",
  "tagline": "One sentence that captures the spirit (max 20 words)",
  "emoji": "One emoji that represents this ritual",
  "vibe": "Three adjectives that describe this morning (comma-separated)",
  "radius": "Approximate area covered (e.g. '400m around Saint-Germain')",
  "sequence": [
    {
      "time": "e.g. 7h00",
      "activity": "What they do (max 12 words)",
      "location": "Specific Paris place name and arrondissement",
      "why": "Why this works for their personality (max 25 words)"
    }
  ]
}`
          }]
        })
      });
      const data = await res.json();
      const text = data.content?.map((b: { type: string; text?: string }) => b.type === 'text' ? b.text : '').join('') || '{}';
      const clean = text.replace(/```json|```/g, '').trim();
      setRitual(JSON.parse(clean));
    } catch {
      setRitual({
        title: 'The Classic Slow Morning',
        tagline: 'Coffee, croissant, and watching Paris wake up without hurry.',
        emoji: '🥐',
        vibe: 'unhurried, golden, Parisian',
        radius: 'Within 400m of wherever you are',
        sequence: [
          { time: '8h00', activity: 'Walk to your nearest boulangerie, order fresh croissant', location: 'Your local boulangerie', why: 'Smell of fresh bread anchors every Paris morning. This is non-negotiable.' },
          { time: '8h20', activity: 'Find a café with terrace, order café crème, read nothing', location: 'Any terrace facing a street', why: 'Watching the city wake up is a sport in Paris. Sit outside regardless of season.' },
          { time: '9h15', activity: 'Slow walk to a nearby garden or fountain', location: 'Nearest square or jardin', why: 'Even 10 minutes of green resets the whole day. Paris has gardens hiding everywhere.' },
        ],
      });
    }
    setLoading(false);
  };

  const reset = () => {
    setAnswers({});
    setCurrentQ(0);
    setRitual(null);
    setLocationAsked(false);
    setLocation('');
  };

  const progress = (Object.keys(answers).length / QUIZ.length) * 100;

  return (
    <div style={{ padding: '2rem 2.5rem', maxWidth: 800, margin: '0 auto' }}>
      <FadeIn>
        {/* Header */}
        <div style={{ marginBottom: '1.5rem' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 4 }}>
            <Sunrise style={{ width: 16, height: 16, color: GOLD }} />
            <span style={{ fontSize: 12, fontWeight: 600, color: GOLD, textTransform: 'uppercase', letterSpacing: '0.1em' }}>Personalised Morning</span>
          </div>
          <h1 style={{ fontFamily: 'Playfair Display, serif', fontSize: '2rem', fontWeight: 700, color: '#fff', marginBottom: 6 }}>Morning Ritual Finder</h1>
          <p style={{ color: '#8E8E93', fontSize: 14 }}>Answer 5 questions. Get a personalised Paris morning ritual — all within 500m of where you're staying.</p>
        </div>

        {/* Result */}
        {ritual && (
          <motion.div key="result" initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}
            style={{ padding: '2rem', borderRadius: 20, background: 'linear-gradient(135deg,rgba(255,215,0,0.08),rgba(0,38,84,0.06))', border: '1px solid rgba(255,215,0,0.3)' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: '1.5rem' }}>
              <span style={{ fontSize: 40 }}>{ritual.emoji}</span>
              <div>
                <h2 style={{ fontFamily: 'Playfair Display, serif', fontSize: '1.5rem', color: '#fff', margin: 0, marginBottom: 4 }}>{ritual.title}</h2>
                <p style={{ color: '#8E8E93', fontSize: 13, margin: 0, fontStyle: 'italic' }}>{ritual.tagline}</p>
              </div>
            </div>

            <div style={{ display: 'flex', gap: 10, marginBottom: '1.5rem', flexWrap: 'wrap' }}>
              {ritual.vibe.split(',').map(v => (
                <span key={v} style={{ padding: '4px 12px', borderRadius: 20, background: 'rgba(255,215,0,0.12)', border: '1px solid rgba(255,215,0,0.25)', fontSize: 12, color: GOLD, fontWeight: 600 }}>{v.trim()}</span>
              ))}
              <span style={{ display: 'flex', alignItems: 'center', gap: 4, padding: '4px 12px', borderRadius: 20, background: 'rgba(0,38,84,0.15)', border: '1px solid rgba(0,38,84,0.3)', fontSize: 12, color: '#93c5fd', fontWeight: 600 }}>
                <Navigation style={{ width: 10, height: 10 }} />{ritual.radius}
              </span>
            </div>

            <div style={{ display: 'flex', flexDirection: 'column', gap: 0, position: 'relative' }}>
              {ritual.sequence.map((step, i) => (
                <motion.div key={i} initial={{ opacity: 0, x: -16 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.1 + i * 0.12 }}
                  style={{ display: 'grid', gridTemplateColumns: '80px 1fr', gap: '1rem', paddingBottom: i < ritual.sequence.length - 1 ? '1.5rem' : 0 }}>
                  {/* Timeline */}
                  <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 0 }}>
                    <div style={{ padding: '4px 8px', borderRadius: 8, background: 'rgba(255,215,0,0.15)', border: '1px solid rgba(255,215,0,0.3)', fontSize: 11, fontWeight: 800, color: GOLD, whiteSpace: 'nowrap' }}>{step.time}</div>
                    {i < ritual.sequence.length - 1 && <div style={{ width: 1, flex: 1, minHeight: 24, background: 'rgba(255,215,0,0.2)', marginTop: 6 }} />}
                  </div>
                  {/* Content */}
                  <div style={{ padding: '0 0 0 0.5rem' }}>
                    <div style={{ fontWeight: 700, color: '#fff', fontSize: 14, marginBottom: 3 }}>{step.activity}</div>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 4, marginBottom: 6 }}>
                      <MapPin style={{ width: 11, height: 11, color: '#8E8E93' }} />
                      <span style={{ fontSize: 11, color: '#8E8E93' }}>{step.location}</span>
                    </div>
                    <div style={{ fontSize: 12, color: '#8E8E93', fontStyle: 'italic', lineHeight: 1.5 }}>{step.why}</div>
                  </div>
                </motion.div>
              ))}
            </div>

            <div style={{ marginTop: '1.5rem', paddingTop: '1.5rem', borderTop: '1px solid rgba(255,255,255,0.08)', display: 'flex', gap: 10 }}>
              <button onClick={reset}
                style={{ padding: '10px 20px', borderRadius: 10, border: '1px solid rgba(255,255,255,0.15)', background: 'transparent', color: '#8E8E93', fontWeight: 700, fontSize: 13, cursor: 'pointer' }}>
                ↩ Try Again
              </button>
              <button onClick={() => { reset(); }}
                style={{ padding: '10px 20px', borderRadius: 10, border: `1px solid ${GOLD}50`, background: 'rgba(255,215,0,0.12)', color: GOLD, fontWeight: 700, fontSize: 13, cursor: 'pointer' }}>
                ✨ New Ritual
              </button>
            </div>
          </motion.div>
        )}

        {/* Location step */}
        {!ritual && !loading && locationAsked && (
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}
            style={{ padding: '2rem', borderRadius: 16, background: 'rgba(255,255,255,0.03)', border: '1px solid rgba(255,255,255,0.1)' }}>
            <div style={{ fontSize: 32, textAlign: 'center', marginBottom: 12 }}>📍</div>
            <h3 style={{ fontFamily: 'Playfair Display, serif', color: '#fff', textAlign: 'center', marginBottom: 8 }}>Where are you staying?</h3>
            <p style={{ color: '#8E8E93', fontSize: 13, textAlign: 'center', marginBottom: '1.5rem' }}>We'll keep your ritual within 500m. Give a neighbourhood, arrondissement, or landmark.</p>
            <input value={location} onChange={e => setLocation(e.target.value)}
              onKeyDown={e => e.key === 'Enter' && generateRitual()}
              placeholder='e.g. "Near the Marais, 3e" or "Saint-Germain-des-Prés"'
              style={{ width: '100%', padding: '12px 16px', borderRadius: 10, border: '1px solid rgba(255,255,255,0.15)', background: 'rgba(255,255,255,0.06)', color: '#fff', fontSize: 14, outline: 'none', boxSizing: 'border-box', marginBottom: '1rem' }} />
            <div style={{ display: 'flex', gap: 10 }}>
              <button onClick={generateRitual}
                style={{ flex: 1, padding: '12px', borderRadius: 10, background: 'rgba(255,215,0,0.9)', color: '#000', fontWeight: 700, fontSize: 14, border: 'none', cursor: 'pointer' }}>
                ✨ Build My Ritual
              </button>
              <button onClick={generateRitual}
                style={{ padding: '12px 16px', borderRadius: 10, background: 'transparent', border: '1px solid rgba(255,255,255,0.12)', color: '#8E8E93', fontSize: 13, cursor: 'pointer' }}>
                Skip
              </button>
            </div>
          </motion.div>
        )}

        {/* Loading */}
        {loading && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }}
            style={{ padding: '3rem', textAlign: 'center', color: '#8E8E93' }}>
            <Loader2 style={{ width: 32, height: 32, animation: 'spin 1s linear infinite', color: GOLD, margin: '0 auto 12px' }} />
            <div style={{ fontSize: 14, fontWeight: 600 }}>Designing your perfect Paris morning…</div>
            <div style={{ fontSize: 12, color: '#8E8E93', marginTop: 6 }}>Finding the best boulangerie, terrace, and garden for your style</div>
          </motion.div>
        )}

        {/* Quiz */}
        {!ritual && !loading && !locationAsked && (
          <div>
            {/* Progress bar */}
            <div style={{ marginBottom: '2rem' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 8 }}>
                <span style={{ fontSize: 11, color: '#8E8E93' }}>Question {currentQ + 1} of {QUIZ.length}</span>
                <span style={{ fontSize: 11, color: GOLD, fontWeight: 700 }}>{Math.round(progress)}%</span>
              </div>
              <div style={{ height: 4, borderRadius: 2, background: 'rgba(255,255,255,0.08)', overflow: 'hidden' }}>
                <motion.div animate={{ width: `${progress}%` }} transition={{ duration: 0.4, ease: 'easeOut' }}
                  style={{ height: '100%', borderRadius: 2, background: 'linear-gradient(90deg,#FFD700,#ED2939)' }} />
              </div>
            </div>

            <AnimatePresence mode="wait">
              {QUIZ.map((q, qi) => qi === currentQ && (
                <motion.div key={q.id}
                  initial={{ opacity: 0, x: 30 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -30 }}
                  transition={{ duration: 0.25 }}>
                  <h2 style={{ fontFamily: 'Playfair Display, serif', fontSize: '1.4rem', color: '#fff', marginBottom: '1.5rem', lineHeight: 1.4 }}>{q.question}</h2>
                  <div style={{ display: 'flex', flexDirection: 'column', gap: '0.75rem' }}>
                    {q.options.map(opt => (
                      <motion.button key={opt.value}
                        whileHover={{ x: 4 }}
                        whileTap={{ scale: 0.98 }}
                        onClick={() => handleAnswer(q.id, opt.value)}
                        style={{ display: 'flex', alignItems: 'center', gap: 14, padding: '1rem 1.25rem', borderRadius: 12, border: `1px solid ${answers[q.id] === opt.value ? GOLD : 'rgba(255,255,255,0.1)'}`, background: answers[q.id] === opt.value ? 'rgba(255,215,0,0.1)' : 'rgba(255,255,255,0.03)', cursor: 'pointer', textAlign: 'left', transition: 'all 0.15s' }}>
                        <span style={{ fontSize: 24, flexShrink: 0 }}>{opt.emoji}</span>
                        <span style={{ fontSize: 14, color: '#fff', fontWeight: 500, lineHeight: 1.4 }}>{opt.label}</span>
                      </motion.button>
                    ))}
                  </div>
                </motion.div>
              ))}
            </AnimatePresence>

            {currentQ > 0 && (
              <button onClick={() => setCurrentQ(currentQ - 1)} style={{ marginTop: '1.5rem', padding: '8px 16px', borderRadius: 8, border: '1px solid rgba(255,255,255,0.1)', background: 'transparent', color: '#8E8E93', fontSize: 12, cursor: 'pointer' }}>
                ← Back
              </button>
            )}
          </div>
        )}
      </FadeIn>
      <style>{`@keyframes spin { from{transform:rotate(0deg)} to{transform:rotate(360deg)} }`}</style>
    </div>
  );
}
