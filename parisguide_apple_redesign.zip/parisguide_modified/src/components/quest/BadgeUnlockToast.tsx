'use client';
import { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Zap, Sparkles } from 'lucide-react';

interface BadgeToastData {
  id: string; emoji: string; name: string;
  description: string; rarity: 'common' | 'rare' | 'legendary'; xp: number;
}

const RARITY_CONFIG = {
  common:    {
    border: 'rgba(142,142,147,0.4)', glow: 'rgba(142,142,147,0.2)',
    bg: 'rgba(21,26,35,0.97)', label: '🔹 Common', accent: '#8E8E93',
    shimmer: 'rgba(142,142,147,0.08)',
  },
  rare: {
    border: 'rgba(100,210,255,0.5)', glow: 'rgba(100,210,255,0.25)',
    bg: 'rgba(11,20,35,0.98)', label: '💎 Rare', accent: '#64D2FF',
    shimmer: 'rgba(100,210,255,0.10)',
  },
  legendary: {
    border: 'rgba(255,215,0,0.6)', glow: 'rgba(255,215,0,0.35)',
    bg: 'rgba(20,15,5,0.98)', label: '⭐ Legendary', accent: '#FFD700',
    shimmer: 'rgba(255,215,0,0.12)',
  },
};

let listeners: ((badge: BadgeToastData) => void)[] = [];
export function fireBadgeToast(badge: BadgeToastData) {
  listeners.forEach(fn => fn(badge));
}

export default function BadgeUnlockToastProvider() {
  const [queue, setQueue] = useState<BadgeToastData[]>([]);

  useEffect(() => {
    const handler = (badge: BadgeToastData) =>
      setQueue(prev => prev.find(b => b.id === badge.id) ? prev : [...prev, badge]);
    listeners.push(handler);
    return () => { listeners = listeners.filter(fn => fn !== handler); };
  }, []);

  const dismiss = (id: string) => setQueue(prev => prev.filter(b => b.id !== id));

  useEffect(() => {
    if (!queue.length) return;
    const timer = setTimeout(() => dismiss(queue[0].id), 5200);
    return () => clearTimeout(timer);
  }, [queue]);

  const current = queue[0];
  if (!current) return null;
  const cfg = RARITY_CONFIG[current.rarity];

  return (
    <div style={{ position: 'fixed', top: 20, right: 20, zIndex: 9999, pointerEvents: 'none' }}>
      <AnimatePresence mode="wait">
        <motion.div
          key={current.id}
          initial={{ opacity: 0, x: 90, scale: 0.85, y: -10 }}
          animate={{ opacity: 1, x: 0, scale: 1, y: 0 }}
          exit={{ opacity: 0, x: 90, scale: 0.9 }}
          transition={{ type: 'spring', stiffness: 400, damping: 26 }}
          style={{
            pointerEvents: 'all', width: 320, borderRadius: 22,
            background: cfg.bg,
            backdropFilter: 'blur(32px)',
            border: `1.5px solid ${cfg.border}`,
            boxShadow: `0 0 0 1px ${cfg.border}33, 0 16px 60px rgba(0,0,0,0.8), 0 0 80px ${cfg.glow}`,
            overflow: 'hidden',
          }}>

          {/* Shimmer header bar */}
          <div style={{
            height: 3, width: '100%',
            background: `linear-gradient(90deg, transparent, ${cfg.accent}, transparent)`,
            opacity: 0.7,
          }} />

          {/* Content */}
          <div style={{ padding: '16px 16px 12px' }}>
            <div style={{ display: 'flex', alignItems: 'flex-start', gap: 12 }}>

              {/* Badge emoji with glow */}
              <motion.div
                animate={current.rarity === 'legendary'
                  ? { rotate: [0, -5, 5, -3, 3, 0], scale: [1, 1.15, 1] }
                  : { scale: [1, 1.08, 1] }}
                transition={{ duration: 0.6, delay: 0.2 }}
                style={{
                  width: 56, height: 56, borderRadius: 16, flexShrink: 0,
                  display: 'flex', alignItems: 'center', justifyContent: 'center',
                  fontSize: 28,
                  background: `${cfg.shimmer}`,
                  border: `1px solid ${cfg.border}`,
                  boxShadow: `0 4px 20px ${cfg.glow}`,
                }}>
                {current.emoji}
              </motion.div>

              <div style={{ flex: 1, minWidth: 0 }}>
                {/* Unlock label */}
                <div style={{
                  display: 'flex', alignItems: 'center', gap: 5, marginBottom: 4,
                }}>
                  <Sparkles style={{ width: 11, height: 11, color: cfg.accent }} />
                  <span style={{
                    fontSize: 9.5, fontWeight: 800, color: cfg.accent,
                    textTransform: 'uppercase', letterSpacing: '0.12em',
                  }}>
                    Badge Unlocked!
                  </span>
                </div>

                {/* Name */}
                <div style={{
                  fontWeight: 800, color: '#F5F5F7', fontSize: 14.5,
                  letterSpacing: '-0.01em', marginBottom: 2, lineHeight: 1.2,
                }}>
                  {current.name}
                </div>

                {/* Description */}
                <p style={{ fontSize: 11.5, color: '#8E8E93', lineHeight: 1.5, margin: 0 }}>
                  {current.description}
                </p>
              </div>

              {/* Dismiss */}
              <button onClick={() => dismiss(current.id)}
                style={{
                  background: 'rgba(255,255,255,0.06)', border: '1px solid rgba(255,255,255,0.08)',
                  borderRadius: 8, cursor: 'pointer', color: '#8E8E93',
                  width: 26, height: 26, display: 'flex', alignItems: 'center', justifyContent: 'center',
                  flexShrink: 0,
                }}>
                <X style={{ width: 12, height: 12 }} />
              </button>
            </div>

            {/* Footer: rarity + XP */}
            <div style={{
              display: 'flex', alignItems: 'center', justifyContent: 'space-between',
              marginTop: 12, paddingTop: 10,
              borderTop: '1px solid rgba(255,255,255,0.06)',
            }}>
              <span style={{
                fontSize: 10.5, fontWeight: 700,
                color: cfg.accent,
                textShadow: `0 0 10px ${cfg.glow}`,
              }}>
                {cfg.label}
              </span>
              <motion.div
                initial={{ opacity: 0, y: 6 }} animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.35 }}
                style={{
                  display: 'flex', alignItems: 'center', gap: 4,
                  padding: '3px 10px', borderRadius: 20,
                  background: 'rgba(255,215,0,0.10)',
                  border: '1px solid rgba(255,215,0,0.2)',
                  fontSize: 11, fontWeight: 800, color: '#FFD700',
                }}>
                <Zap style={{ width: 10, height: 10 }} />
                +{current.xp} XP earned
              </motion.div>
            </div>
          </div>

          {/* Auto-dismiss progress bar */}
          <motion.div
            initial={{ scaleX: 1 }} animate={{ scaleX: 0 }}
            transition={{ duration: 5.2, ease: 'linear' }}
            style={{
              height: 2, background: cfg.accent, transformOrigin: 'left',
              opacity: 0.4,
            }}
          />
        </motion.div>
      </AnimatePresence>
    </div>
  );
}
