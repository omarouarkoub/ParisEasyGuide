'use client';
import { useEffect, useRef, useState } from 'react';
import { MapPin, X, Star, Layers } from 'lucide-react';

interface Marker { lat: number; lng: number; label?: string; popup?: string; }
interface Pin { lat: number; lng: number; label: string; }

interface ParisMap3DProps {
  markers?: Marker[];
  pins?: Pin[];
  onPinsChange?: (pins: Pin[]) => void;
  routeColor?: string;
  height?: string;
  accentColor?: string;
}

function makeNeonIcon(L: any, color: string, label: string) {
  return L.divIcon({
    className: '',
    html: `<div style="position:relative;width:36px;height:36px;">
      <div style="position:absolute;inset:-6px;border-radius:50%;background:radial-gradient(circle,${color}44 0%,transparent 70%);animation:paris3d-pulse 2s ease-in-out infinite;"></div>
      <div style="position:absolute;inset:0;background:${color};border-radius:50% 50% 50% 0;transform:rotate(-45deg);border:2.5px solid #fff;box-shadow:0 4px 16px rgba(0,0,0,0.7),0 0 0 2px rgba(0,0,0,0.3);display:flex;align-items:center;justify-content:center;">
        <span style="transform:rotate(45deg);font-size:12px;font-weight:900;color:#fff;text-shadow:0 1px 3px rgba(0,0,0,0.9);display:block;text-align:center;line-height:28px;">${label}</span>
      </div></div>`,
    iconSize: [36, 36], iconAnchor: [18, 36], popupAnchor: [0, -40],
  });
}

function makeStarIcon(L: any) {
  return L.divIcon({
    className: '',
    html: `<div style="width:28px;height:28px;border-radius:50%;background:radial-gradient(circle,#ffe000 0%,#ff9900 70%);border:2px solid #fff;box-shadow:0 0 14px #ffe000,0 0 28px #ff990088;display:flex;align-items:center;justify-content:center;font-size:14px;">⭐</div>`,
    iconSize: [28, 28], iconAnchor: [14, 14], popupAnchor: [0, -18],
  });
}

export default function ParisMap3D({
  markers = [], pins = [], onPinsChange,
  routeColor = '#b04fff', height = '380px', accentColor = '#b04fff',
}: ParisMap3DProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const mapRef = useRef<any>(null);
  const layersRef = useRef<any[]>([]);
  const pinsRef = useRef<Pin[]>(pins);
  const [pendingPin, setPendingPin] = useState<{ lat: number; lng: number } | null>(null);
  const [pinLabel, setPinLabel] = useState('');
  const [tilt, setTilt] = useState(0);

  useEffect(() => { pinsRef.current = pins; }, [pins]);

  // Entry 3-D tilt animation
  useEffect(() => {
    let frame: number;
    let start: number | null = null;
    const animate = (ts: number) => {
      if (!start) start = ts;
      const progress = Math.min((ts - start) / 1200, 1);
      setTilt(20 * Math.sin(progress * Math.PI));
      if (progress < 1) frame = requestAnimationFrame(animate);
      else setTilt(0);
    };
    frame = requestAnimationFrame(animate);
    return () => cancelAnimationFrame(frame);
  }, []);

  useEffect(() => {
    if (!document.getElementById('leaflet-css')) {
      const link = document.createElement('link');
      link.id = 'leaflet-css'; link.rel = 'stylesheet';
      link.href = 'https://unpkg.com/leaflet@1.9.4/dist/leaflet.css';
      document.head.appendChild(link);
    }

    const init = (L: any) => {
      if (mapRef.current || !containerRef.current) return;
      const map = L.map(containerRef.current, {
        center: [48.8566, 2.3522], zoom: 13, zoomControl: false, attributionControl: false,
      });
      // Satellite imagery
      L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}', { maxZoom: 19 }).addTo(map);
      // Label overlay
      L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/Reference/World_Transportation/MapServer/tile/{z}/{y}/{x}', { maxZoom: 19, opacity: 0.7 }).addTo(map);
      L.control.zoom({ position: 'bottomright' }).addTo(map);
      map.on('click', (e: any) => { setPendingPin({ lat: e.latlng.lat, lng: e.latlng.lng }); setPinLabel(''); });
      mapRef.current = map;
      redraw(L, map, markers, pins);
    };

    if ((window as any).L) { init((window as any).L); }
    else {
      const s = document.createElement('script');
      s.src = 'https://unpkg.com/leaflet@1.9.4/dist/leaflet.js';
      s.onload = () => init((window as any).L);
      document.head.appendChild(s);
    }
    return () => { if (mapRef.current) { mapRef.current.remove(); mapRef.current = null; layersRef.current = []; } };
  }, []);

  function redraw(L: any, map: any, mkrs: Marker[], pns: Pin[]) {
    layersRef.current.forEach(l => map.removeLayer(l));
    layersRef.current = [];
    const points: [number, number][] = [];

    mkrs.forEach((m, i) => {
      if (!m.lat || !m.lng) return;
      const color = i === 0 ? '#00ff94' : i === mkrs.length - 1 ? '#ff2d9b' : routeColor;
      const lbl = i === 0 ? 'A' : i === mkrs.length - 1 ? 'B' : String(i);
      const mk = L.marker([m.lat, m.lng], { icon: makeNeonIcon(L, color, lbl) })
        .bindPopup(`<b>${m.label || ''}</b>`).addTo(map);
      layersRef.current.push(mk);
      points.push([m.lat, m.lng]);
    });

    if (points.length >= 2) {
      const glow = L.polyline(points, { color: routeColor, weight: 8, opacity: 0.18 }).addTo(map);
      const core = L.polyline(points, { color: routeColor, weight: 2.5, opacity: 0.95, dashArray: '8 5' }).addTo(map);
      layersRef.current.push(glow, core);
    }

    pns.forEach(p => {
      if (!p.lat || !p.lng) return;
      const mk = L.marker([p.lat, p.lng], { icon: makeStarIcon(L) })
        .bindPopup(`<b>⭐ ${p.label}</b>`).addTo(map);
      layersRef.current.push(mk);
    });

    if (points.length >= 1) {
      map.fitBounds(
        points.length === 1
          ? [[points[0][0] - 0.01, points[0][1] - 0.01], [points[0][0] + 0.01, points[0][1] + 0.01]]
          : points,
        { padding: [48, 48] }
      );
    }
  }

  useEffect(() => {
    if (!mapRef.current || !(window as any).L) return;
    redraw((window as any).L, mapRef.current, markers, pins);
  }, [markers, pins, routeColor]);

  const savePin = () => {
    if (!pendingPin || !pinLabel.trim()) return;
    onPinsChange?.([...pinsRef.current, { lat: pendingPin.lat, lng: pendingPin.lng, label: pinLabel.trim() }]);
    setPendingPin(null); setPinLabel('');
  };

  return (
    <div style={{ position: 'relative', borderRadius: 16, overflow: 'hidden', height, border: `1px solid ${accentColor}44`, boxShadow: `0 0 0 1px ${accentColor}22, 0 0 40px ${accentColor}18`, perspective: '1200px' }}>
      <div style={{ height: '100%', width: '100%', transform: `rotateX(${tilt}deg)`, transformOrigin: 'center bottom', transition: 'transform 0.05s linear' }}>
        <div ref={containerRef} style={{ height: '100%', width: '100%', background: '#1a2a1a' }} />
      </div>

      {/* Neon corner brackets */}
      {['top-0 left-0 border-t-2 border-l-2', 'top-0 right-0 border-t-2 border-r-2', 'bottom-0 left-0 border-b-2 border-l-2', 'bottom-0 right-0 border-b-2 border-r-2'].map((cls, i) => (
        <div key={i} style={{ position: 'absolute', width: 20, height: 20, top: cls.includes('top-0') ? 0 : 'auto', bottom: cls.includes('bottom-0') ? 0 : 'auto', left: cls.includes('left-0') ? 0 : 'auto', right: cls.includes('right-0') ? 0 : 'auto', borderTop: cls.includes('border-t') ? `2px solid ${accentColor}` : 'none', borderBottom: cls.includes('border-b') ? `2px solid ${accentColor}` : 'none', borderLeft: cls.includes('border-l') ? `2px solid ${accentColor}` : 'none', borderRight: cls.includes('border-r') ? `2px solid ${accentColor}` : 'none', pointerEvents: 'none' }} />
      ))}

      {/* HUD label */}
      <div style={{ position: 'absolute', top: 10, left: 28, zIndex: 500, pointerEvents: 'none' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 6, padding: '4px 10px', borderRadius: 8, background: 'rgba(6,8,16,0.75)', border: `1px solid ${accentColor}33` }}>
          <Layers style={{ width: 10, height: 10, color: accentColor }} />
          <span style={{ fontSize: 9, fontWeight: 700, letterSpacing: '0.1em', textTransform: 'uppercase', color: accentColor }}>PARIS · SATELLITE</span>
        </div>
      </div>

      {/* Pin input */}
      {pendingPin && (
        <div style={{ position: 'absolute', bottom: 16, left: '50%', transform: 'translateX(-50%)', zIndex: 1000, display: 'flex', alignItems: 'center', gap: 8, padding: '10px 16px', borderRadius: 14, background: 'rgba(6,8,16,0.95)', border: `1px solid ${accentColor}55`, boxShadow: '0 8px 32px rgba(0,0,0,0.8)' }}>
          <Star style={{ width: 16, height: 16, color: '#ffe000', flexShrink: 0 }} />
          <input autoFocus value={pinLabel} onChange={e => setPinLabel(e.target.value)} onKeyDown={e => e.key === 'Enter' && savePin()} placeholder="Name this pin…"
            style={{ background: 'transparent', border: 'none', outline: 'none', color: '#fff', fontSize: 14, width: 150 }} />
          <button onClick={savePin} style={{ padding: '4px 10px', borderRadius: 8, background: `${accentColor}22`, border: `1px solid ${accentColor}44`, color: accentColor, fontSize: 12, fontWeight: 700, cursor: 'pointer' }}>Save</button>
          <button onClick={() => setPendingPin(null)} style={{ background: 'none', border: 'none', cursor: 'pointer', color: '#8E8E93' }}><X style={{ width: 14, height: 14 }} /></button>
        </div>
      )}

      {/* Empty hint */}
      {markers.length === 0 && pins.length === 0 && !pendingPin && (
        <div style={{ position: 'absolute', inset: 0, display: 'flex', alignItems: 'center', justifyContent: 'center', pointerEvents: 'none', zIndex: 400 }}>
          <div style={{ textAlign: 'center', padding: '12px 20px', borderRadius: 14, background: 'rgba(6,8,16,0.65)', border: `1px solid ${accentColor}22` }}>
            <MapPin style={{ width: 20, height: 20, margin: '0 auto 6px', color: accentColor }} />
            <p style={{ fontSize: 12, color: `${accentColor}99` }}>Click anywhere to pin a location</p>
          </div>
        </div>
      )}

      <style>{`
        @keyframes paris3d-pulse { 0%,100%{opacity:.6;transform:scale(1)} 50%{opacity:1;transform:scale(1.15)} }
        .leaflet-popup-content-wrapper { background:rgba(10,15,25,0.96)!important; border:1px solid rgba(255,255,255,0.2)!important; color:#f0f4ff!important; border-radius:12px!important; box-shadow:0 8px 32px rgba(0,0,0,0.8)!important; }
        .leaflet-popup-tip { background:rgba(10,15,25,0.96)!important; }
        .leaflet-popup-content { margin:10px 14px!important; font-size:13px!important; font-weight:600!important; }
        .leaflet-control-zoom a { background:rgba(10,15,25,0.92)!important; color:${accentColor}!important; border-color:rgba(255,255,255,0.15)!important; font-weight:bold!important; }
        .leaflet-control-zoom a:hover { background:rgba(20,30,50,0.95)!important; }
        .leaflet-control-attribution { display:none!important; }
      `}</style>
    </div>
  );
}
