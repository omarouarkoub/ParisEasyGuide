'use client';
import { Star, Trash2 } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

interface Pin { lat: number; lng: number; label: string; }

export default function FavouritePins({ pins, onRemove }: { pins: Pin[]; onRemove: (i: number) => void }) {
  if (!pins.length) return null;
  return (
    <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }}
      style={{ padding: '1rem 1.25rem', borderRadius: 14, background: 'rgba(255,224,0,0.05)', border: '1px solid rgba(255,224,0,0.15)' }}>
      <h4 style={{ fontSize: 12, fontWeight: 700, color: '#fbbf24', marginBottom: 10, display: 'flex', alignItems: 'center', gap: 6 }}>
        <Star style={{ width: 14, height: 14 }} /> Favourite Pins ({pins.length})
      </h4>
      <div style={{ display: 'flex', flexWrap: 'wrap', gap: 6 }}>
        <AnimatePresence>
          {pins.map((p, i) => (
            <motion.div key={`${p.lat}-${p.lng}-${p.label}`}
              initial={{ opacity: 0, scale: 0.8 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0, scale: 0.8 }}
              style={{ display: 'flex', alignItems: 'center', gap: 6, padding: '4px 12px', borderRadius: 20, background: 'rgba(255,224,0,0.08)', border: '1px solid rgba(255,224,0,0.15)', fontSize: 12, color: '#fff' }}>
              <span style={{ color: '#fbbf24' }}>⭐</span>
              {p.label}
              <button onClick={() => onRemove(i)} style={{ background: 'none', border: 'none', cursor: 'pointer', color: '#8E8E93', padding: 0, marginLeft: 2, display: 'flex' }}>
                <Trash2 style={{ width: 11, height: 11 }} />
              </button>
            </motion.div>
          ))}
        </AnimatePresence>
      </div>
      <p style={{ fontSize: 10, color: '#4b5563', marginTop: 8 }}>Pins saved for this session · Click map to add more</p>
    </motion.div>
  );
}
