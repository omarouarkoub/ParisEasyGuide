'use client';
import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import Link from 'next/link';
import { CheckCircle2, Circle, ChevronRight, ExternalLink, Sparkles, ArrowRight, RefreshCw } from 'lucide-react';
import { useLanguage } from '@/lib/i18n/LanguageContext';
import { translations as tr } from '@/lib/i18n/translations';

const GOLD = '#FFD700';
const NAVY = '#002654';

interface TimelineTask {
  id: string; title: string; description: string;
  urgency: 'urgent' | 'soon' | 'when_ready';
  deadline: string; category: string;
  link_label?: string; link_url?: string;
  days_from_arrival: number; emoji: string;
}

interface Timeline {
  welcome_message: string; settled_score: number; settled_score_label: string;
  critical_next: TimelineTask[];
  timeline_weeks: { week: string; theme: string; tasks: string[] }[];
  insider_tips: string[];
  modules_for_them: { path: string; label: string; emoji: string; reason: string }[];
}

interface Profile {
  name: string; profile_type: string; arrondissement: string; visa_type: string; goals: string[];
}

/* ─── Score Ring ────────────────────────────────────────────────────────────── */
function ScoreRing({ score, color }: { score: number; color: string }) {
  const R = 28, circumference = 2 * Math.PI * R;
  return (
    <div style={{ position: 'relative', width: 70, height: 70, flexShrink: 0 }}>
      <svg width="70" height="70" style={{ transform: 'rotate(-90deg)' }}>
        <circle cx="35" cy="35" r={R} fill="none" stroke="rgba(255,255,255,0.06)" strokeWidth="5" />
        <motion.circle
          cx="35" cy="35" r={R} fill="none" stroke={color} strokeWidth="5"
          strokeLinecap="round"
          initial={{ strokeDasharray: `0 ${circumference}` }}
          animate={{ strokeDasharray: `${(score / 100) * circumference} ${circumference}` }}
          transition={{ duration: 1.2, ease: 'easeOut', delay: 0.4 }}
        />
      </svg>
      <div style={{
        position: 'absolute', inset: 0,
        display: 'flex', flexDirection: 'column',
        alignItems: 'center', justifyContent: 'center',
      }}>
        <span style={{ fontSize: 15, fontWeight: 800, color, lineHeight: 1 }}>{score}</span>
        <span style={{ fontSize: 8.5, color: '#8E8E93', marginTop: 1 }}>settled</span>
      </div>
    </div>
  );
}

export default function MarcelDashboard() {
  const { t } = useLanguage();
  const [profile, setProfile]   = useState<Profile | null>(null);
  const [timeline, setTimeline] = useState<Timeline | null>(null);
  const [completed, setCompleted] = useState<string[]>([]);
  const [activeTab, setActiveTab] = useState<'tasks' | 'timeline' | 'tips'>('tasks');
  const [expanded, setExpanded]   = useState<string | null>(null);
  const [stampId, setStampId]     = useState<string | null>(null);

  useEffect(() => {
    try {
      const p  = localStorage.getItem('paris_profile');
      const tl = localStorage.getItem('paris_timeline');
      const c  = localStorage.getItem('paris_completed');
      if (p)  setProfile(JSON.parse(p));
      if (tl) setTimeline(JSON.parse(tl));
      if (c)  setCompleted(JSON.parse(c));
    } catch {}
  }, []);

  const toggleComplete = (id: string) => {
    const next = completed.includes(id)
      ? completed.filter(c => c !== id)
      : [...completed, id];
    setCompleted(next);
    localStorage.setItem('paris_completed', JSON.stringify(next));
    if (!completed.includes(id)) {
      setStampId(id);
      setTimeout(() => setStampId(null), 700);
    }
  };

  if (!profile || !timeline) return null;

  const tasks     = timeline.critical_next || [];
  const doneCount = tasks.filter(task => completed.includes(task.id)).length;
  const rawScore  = Number(timeline.settled_score) || 0;
  const settledScore = Math.min(100, rawScore + Math.round((doneCount / Math.max(tasks.length, 1)) * 30));
  const scoreColor   = settledScore < 30 ? '#ED2939' : settledScore < 60 ? '#FF9F0A' : '#30D158';

  const URGENCY_STYLE = {
    urgent:     { bg: 'rgba(237,41,57,0.08)',  border: 'rgba(237,41,57,0.25)',  text: '#ED2939', dot: '#ED2939', label: t(tr.marcel.urgency.urgent)     },
    soon:       { bg: 'rgba(255,159,10,0.08)', border: 'rgba(255,159,10,0.25)', text: '#FF9F0A', dot: '#FF9F0A', label: t(tr.marcel.urgency.soon)       },
    when_ready: { bg: 'rgba(94,92,230,0.08)',  border: 'rgba(94,92,230,0.22)',  text: '#5E5CE6', dot: '#5E5CE6', label: t(tr.marcel.urgency.when_ready) },
  };

  const TABS = [
    { id: 'tasks'    as const, label: `⚡ ${t(tr.marcel.tabs.tasks)} (${tasks.filter(t => !completed.includes(t.id)).length})` },
    { id: 'timeline' as const, label: `📅 ${t(tr.marcel.tabs.timeline)}` },
    { id: 'tips'     as const, label: `💡 ${t(tr.marcel.tabs.tips)}` },
  ];

  return (
    <motion.div
      initial={{ opacity: 0, y: 14 }} animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.1 }} style={{ marginBottom: '2rem' }}>

      {/* ── Marcel Header Card ─────────────────────────────────────────── */}
      <div style={{
        padding: '1.4rem 1.6rem', borderRadius: 22,
        background: 'linear-gradient(135deg, rgba(0,38,84,0.22) 0%, rgba(0,38,84,0.08) 100%)',
        border: '1px solid rgba(0,38,84,0.45)',
        marginBottom: '1rem',
        position: 'relative', overflow: 'hidden',
        backdropFilter: 'blur(24px)',
        boxShadow: '0 4px 40px rgba(0,0,0,0.3)',
      }}>
        {/* Glow orb */}
        <div style={{
          position: 'absolute', top: -40, right: -40,
          width: 160, height: 160, borderRadius: '50%',
          background: 'radial-gradient(circle, rgba(0,38,84,0.25), transparent 70%)',
          pointerEvents: 'none',
        }} />

        <div style={{
          display: 'flex', alignItems: 'flex-start',
          justifyContent: 'space-between', gap: '1.25rem', flexWrap: 'wrap',
        }}>
          <div style={{ display: 'flex', gap: '0.9rem', alignItems: 'flex-start', flex: 1 }}>
            {/* Marcel bot icon */}
            <motion.div
              animate={{ y: [0,-3,0] }}
              transition={{ duration: 3, repeat: Infinity, ease: 'easeInOut' }}
              style={{
                width: 46, height: 46, borderRadius: 14, flexShrink: 0,
                background: 'linear-gradient(135deg, #002654 0%, #004082 100%)',
                display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 24,
                border: '1px solid rgba(255,215,0,0.2)',
                boxShadow: '0 4px 20px rgba(0,38,84,0.5)',
              }}>
              🧑‍🎨
            </motion.div>
            <div style={{ flex: 1, minWidth: 0 }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginBottom: 5 }}>
                <Sparkles style={{ width: 12, height: 12, color: GOLD }} />
                <span style={{ fontSize: 10.5, fontWeight: 700, color: GOLD, textTransform: 'uppercase', letterSpacing: '0.1em' }}>
                  {t(tr.marcel.header.title)}
                </span>
              </div>
              <p style={{ color: '#C7C7CC', fontSize: 13.5, lineHeight: 1.65, maxWidth: 460 }}>
                {timeline.welcome_message}
              </p>
            </div>
          </div>

          <ScoreRing score={settledScore} color={scoreColor} />
        </div>

        {/* Progress bar */}
        {tasks.length > 0 && (
          <div style={{ marginTop: '1.25rem' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 7 }}>
              <span style={{ fontSize: 11, color: '#8E8E93' }}>
                {doneCount} {t(tr.marcel.progress.of)} {tasks.length} {t(tr.marcel.progress.tasksDone)}
              </span>
              <Link href="/onboarding" style={{
                fontSize: 11, color: '#4A90D9', textDecoration: 'none',
                display: 'flex', alignItems: 'center', gap: 4,
              }}>
                <RefreshCw style={{ width: 10, height: 10 }} />
                {t(tr.marcel.progress.updateProfile)}
              </Link>
            </div>
            <div style={{
              height: 4, borderRadius: 4,
              background: 'rgba(255,255,255,0.07)', overflow: 'hidden',
            }}>
              <motion.div
                initial={{ width: 0 }}
                animate={{ width: `${tasks.length > 0 ? (doneCount / tasks.length) * 100 : 0}%` }}
                transition={{ duration: 1.1, ease: 'easeOut', delay: 0.35 }}
                style={{
                  height: '100%', borderRadius: 4,
                  background: `linear-gradient(90deg, ${NAVY}, ${GOLD})`,
                }}
              />
            </div>
          </div>
        )}
      </div>

      {/* ── Segmented Tabs ────────────────────────────────────────────── */}
      <div style={{
        display: 'flex', gap: '0.375rem', marginBottom: '1rem',
        background: 'rgba(255,255,255,0.04)', padding: 4, borderRadius: 14,
        border: '1px solid rgba(255,255,255,0.06)', width: 'fit-content',
      }}>
        {TABS.map(tab => (
          <motion.button
            key={tab.id}
            onClick={() => setActiveTab(tab.id)}
            whileTap={{ scale: 0.97 }}
            style={{
              padding: '7px 15px', borderRadius: 10,
              fontSize: 12, fontWeight: 600, cursor: 'pointer',
              border: 'none',
              background: activeTab === tab.id ? 'rgba(255,215,0,0.12)' : 'transparent',
              color: activeTab === tab.id ? '#F5F5F7' : '#8E8E93',
              outline: activeTab === tab.id ? '1px solid rgba(255,215,0,0.25)' : 'none',
              transition: 'all 0.15s',
            }}>
            {tab.label}
          </motion.button>
        ))}
      </div>

      {/* ── Tab Content ───────────────────────────────────────────────── */}
      <AnimatePresence mode="wait">
        {activeTab === 'tasks' && (
          <motion.div key="tasks" initial={{ opacity: 0, x: -6 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: 6 }}>
            {tasks.length === 0 ? (
              <div style={{ textAlign: 'center', padding: '2.5rem', color: '#8E8E93' }}>
                {t(tr.marcel.tasks.empty)}
              </div>
            ) : (
              <div style={{ display: 'flex', flexDirection: 'column', gap: '0.5rem' }}>
                {tasks.map((task, i) => {
                  const isDone    = completed.includes(task.id);
                  const urgStyle  = URGENCY_STYLE[task.urgency] || URGENCY_STYLE.when_ready;
                  const isExp     = expanded === task.id;
                  const isStamped = stampId === task.id;

                  return (
                    <motion.div
                      key={task.id}
                      initial={{ opacity: 0, x: -12 }} animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: i * 0.055 }}
                      style={{
                        borderRadius: 16, overflow: 'hidden',
                        background: isDone ? 'rgba(48,209,88,0.05)' : urgStyle.bg,
                        border: `1px solid ${isDone ? 'rgba(48,209,88,0.18)' : urgStyle.border}`,
                        transition: 'all 0.2s',
                      }}>
                      <div
                        style={{ padding: '0.9rem 1.1rem', display: 'flex', alignItems: 'center', gap: '0.75rem', cursor: 'pointer' }}
                        onClick={() => setExpanded(isExp ? null : task.id)}>
                        {/* Check button */}
                        <motion.button
                          whileTap={{ scale: 0.85 }}
                          onClick={e => { e.stopPropagation(); toggleComplete(task.id); }}
                          style={{ background: 'none', border: 'none', cursor: 'pointer', padding: 0, flexShrink: 0, position: 'relative' }}>
                          {isDone ? (
                            <motion.div initial={{ scale: 0 }} animate={{ scale: 1 }} transition={{ type: 'spring', stiffness: 400 }}>
                              <CheckCircle2 style={{ width: 22, height: 22, color: '#30D158' }} />
                            </motion.div>
                          ) : (
                            <Circle style={{ width: 22, height: 22, color: '#3A3A3C' }} />
                          )}
                          {/* Gold stamp flash */}
                          {isStamped && (
                            <motion.div
                              className="stamp"
                              style={{
                                position: 'absolute', top: -4, left: -4,
                                width: 30, height: 30, borderRadius: '50%',
                                background: GOLD, opacity: 0.7,
                                pointerEvents: 'none',
                              }}
                            />
                          )}
                        </motion.button>

                        <span style={{ fontSize: 20, flexShrink: 0 }}>{task.emoji}</span>

                        <div style={{ flex: 1, minWidth: 0 }}>
                          <div style={{
                            fontWeight: 700,
                            color: isDone ? '#8E8E93' : '#F5F5F7',
                            fontSize: 13.5, letterSpacing: '-0.01em',
                            textDecoration: isDone ? 'line-through' : 'none',
                          }}>
                            {task.title}
                          </div>
                          <div style={{
                            fontSize: 10.5, fontWeight: 600, marginTop: 2,
                            display: 'flex', alignItems: 'center', gap: 5, color: urgStyle.text,
                          }}>
                            <div style={{
                              width: 5, height: 5, borderRadius: '50%',
                              background: urgStyle.dot, flexShrink: 0,
                              boxShadow: `0 0 4px ${urgStyle.dot}`,
                            }} />
                            {urgStyle.label} · {task.deadline}
                          </div>
                        </div>

                        <ChevronRight style={{
                          width: 14, height: 14, color: '#3A3A3C', flexShrink: 0,
                          transform: isExp ? 'rotate(90deg)' : 'none', transition: 'transform 0.2s',
                        }} />
                      </div>

                      <AnimatePresence>
                        {isExp && (
                          <motion.div
                            initial={{ height: 0, opacity: 0 }} animate={{ height: 'auto', opacity: 1 }}
                            exit={{ height: 0, opacity: 0 }} transition={{ duration: 0.22 }}
                            style={{ overflow: 'hidden' }}>
                            <div style={{ padding: '0 1.1rem 0.9rem 3.7rem' }}>
                              <p style={{ fontSize: 12.5, color: '#8E8E93', lineHeight: 1.7, marginBottom: '0.75rem' }}>
                                {task.description}
                              </p>
                              {task.link_url && (
                                <a href={task.link_url} target="_blank" rel="noopener noreferrer"
                                  style={{
                                    display: 'inline-flex', alignItems: 'center', gap: 5,
                                    padding: '6px 14px', borderRadius: 10,
                                    background: 'rgba(0,38,84,0.2)',
                                    border: '1px solid rgba(0,38,84,0.35)',
                                    color: '#4A90D9', fontSize: 12, fontWeight: 600, textDecoration: 'none',
                                  }}>
                                  {task.link_label || t(tr.marcel.tasks.openLink)}
                                  <ExternalLink style={{ width: 11, height: 11 }} />
                                </a>
                              )}
                            </div>
                          </motion.div>
                        )}
                      </AnimatePresence>
                    </motion.div>
                  );
                })}
              </div>
            )}

            {/* Recommended modules */}
            {(timeline.modules_for_them?.length ?? 0) > 0 && (
              <div style={{ marginTop: '1.5rem' }}>
                <div style={{ fontSize: 11, fontWeight: 700, color: '#8E8E93', textTransform: 'uppercase', letterSpacing: '0.09em', marginBottom: '0.75rem' }}>
                  🎯 {t(tr.marcel.tasks.recommended)}
                </div>
                <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(175px, 1fr))', gap: '0.5rem' }}>
                  {timeline.modules_for_them.map(mod => (
                    <Link key={mod.path} href={mod.path} style={{ textDecoration: 'none' }}>
                      <motion.div whileHover={{ scale: 1.03, y: -1 }} whileTap={{ scale: 0.97 }}
                        style={{
                          padding: '0.875rem 1rem', borderRadius: 14,
                          background: 'rgba(255,255,255,0.04)',
                          border: '1px solid rgba(255,255,255,0.08)',
                          display: 'flex', alignItems: 'center', gap: 9, cursor: 'pointer',
                        }}>
                        <span style={{ fontSize: 18 }}>{mod.emoji}</span>
                        <div style={{ minWidth: 0, flex: 1 }}>
                          <div style={{ fontWeight: 700, color: '#F5F5F7', fontSize: 12, letterSpacing: '-0.01em' }}>{mod.label}</div>
                          <div style={{ fontSize: 10.5, color: '#8E8E93', lineHeight: 1.4, marginTop: 2 }}>{mod.reason}</div>
                        </div>
                        <ArrowRight style={{ width: 12, height: 12, color: '#3A3A3C', flexShrink: 0 }} />
                      </motion.div>
                    </Link>
                  ))}
                </div>
              </div>
            )}
          </motion.div>
        )}

        {activeTab === 'timeline' && (
          <motion.div key="timeline" initial={{ opacity: 0, x: -6 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: 6 }}>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '0.75rem' }}>
              {(timeline.timeline_weeks || []).map((week, i) => (
                <motion.div key={i}
                  initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: i * 0.08 }}
                  style={{
                    padding: '1rem 1.25rem', borderRadius: 16,
                    background: 'rgba(21,26,35,0.7)',
                    border: '1px solid rgba(255,255,255,0.07)',
                    position: 'relative', overflow: 'hidden',
                  }}>
                  <div style={{
                    position: 'absolute', left: 0, top: 0, bottom: 0, width: 3,
                    background: `hsl(${200 + i * 35}, 75%, 55%)`,
                    borderRadius: '3px 0 0 3px',
                  }} />
                  <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: '0.6rem', paddingLeft: 4 }}>
                    <span style={{ fontWeight: 800, color: '#F5F5F7', fontSize: 13.5, letterSpacing: '-0.01em' }}>{week.week}</span>
                    <span style={{ fontSize: 11, color: '#8E8E93' }}>· {week.theme}</span>
                  </div>
                  <ul style={{ margin: 0, padding: 0, listStyle: 'none', display: 'flex', flexDirection: 'column', gap: 5, paddingLeft: 4 }}>
                    {week.tasks.map((task, j) => (
                      <li key={j} style={{ display: 'flex', alignItems: 'flex-start', gap: 8, fontSize: 12, color: '#C7C7CC', lineHeight: 1.6 }}>
                        <span style={{ color: GOLD, flexShrink: 0, marginTop: 1 }}>›</span>
                        {task}
                      </li>
                    ))}
                  </ul>
                </motion.div>
              ))}
            </div>
          </motion.div>
        )}

        {activeTab === 'tips' && (
          <motion.div key="tips" initial={{ opacity: 0, x: -6 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: 6 }}>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '0.6rem' }}>
              {(timeline.insider_tips || []).map((tip, i) => (
                <motion.div key={i}
                  initial={{ opacity: 0, x: -10 }} animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: i * 0.07 }}
                  style={{
                    display: 'flex', gap: '0.875rem', alignItems: 'flex-start',
                    padding: '0.95rem 1.1rem', borderRadius: 14,
                    background: 'rgba(255,215,0,0.05)',
                    border: '1px solid rgba(255,215,0,0.12)',
                  }}>
                  <div style={{
                    width: 30, height: 30, borderRadius: 9,
                    background: 'rgba(255,215,0,0.10)',
                    display: 'flex', alignItems: 'center', justifyContent: 'center',
                    flexShrink: 0, fontSize: 14,
                  }}>
                    💡
                  </div>
                  <p style={{ fontSize: 13, color: '#C7C7CC', lineHeight: 1.7, margin: 0 }}>{tip}</p>
                </motion.div>
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* ── All done celebration ─────────────────────────────────────── */}
      {doneCount === tasks.length && tasks.length > 0 && (
        <motion.div
          initial={{ opacity: 0, scale: 0.94 }} animate={{ opacity: 1, scale: 1 }}
          style={{
            marginTop: '1rem', padding: '1.4rem', borderRadius: 18, textAlign: 'center',
            background: 'linear-gradient(135deg, rgba(48,209,88,0.08), rgba(255,215,0,0.05))',
            border: '1px solid rgba(48,209,88,0.22)',
          }}>
          <div style={{ fontSize: '2.2rem', marginBottom: '0.5rem' }}>🎉</div>
          <div style={{ fontWeight: 800, color: '#30D158', fontSize: 15, marginBottom: '0.3rem', letterSpacing: '-0.01em' }}>
            {t(tr.marcel.celebration.title)}
          </div>
          <p style={{ color: '#8E8E93', fontSize: 12.5 }}>{t(tr.marcel.celebration.subtitle)}</p>
        </motion.div>
      )}
    </motion.div>
  );
}
