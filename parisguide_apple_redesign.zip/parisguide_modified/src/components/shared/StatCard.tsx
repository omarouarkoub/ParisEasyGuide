'use client';
import { useEffect, useRef, useState } from 'react';
import { motion } from 'framer-motion';
import { LucideIcon } from 'lucide-react';

interface StatCardProps {
  value: number | string;
  label: string;
  icon?: LucideIcon;
  color?: string;
  prefix?: string;
  suffix?: string;
  delay?: number;
  animate?: boolean;
}

export default function StatCard({
  value, label, icon: Icon, color = '#4A90D9',
  prefix = '', suffix = '', delay = 0, animate = true,
}: StatCardProps) {
  const [displayed, setDisplayed] = useState(typeof value === 'number' ? 0 : value);
  const hasAnimated = useRef(false);

  useEffect(() => {
    if (!animate || typeof value !== 'number' || hasAnimated.current) return;
    hasAnimated.current = true;
    const start = Date.now();
    const duration = 1100;
    const tick = () => {
      const elapsed = Date.now() - start;
      const progress = Math.min(elapsed / duration, 1);
      const eased = 1 - Math.pow(1 - progress, 3);
      setDisplayed(Math.round(eased * (value as number)));
      if (progress < 1) requestAnimationFrame(tick);
    };
    const timer = setTimeout(() => requestAnimationFrame(tick), delay * 1000);
    return () => clearTimeout(timer);
  }, [value, animate, delay]);

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.88, y: 10 }}
      animate={{ opacity: 1, scale: 1, y: 0 }}
      transition={{ duration: 0.45, delay, type: 'spring', stiffness: 300, damping: 24 }}
      style={{
        padding: '1.15rem 1rem', borderRadius: 18,
        background: 'rgba(21,26,35,0.7)',
        border: `1px solid ${color}20`,
        backdropFilter: 'blur(20px)',
        textAlign: 'center', position: 'relative', overflow: 'hidden',
        boxShadow: `0 4px 20px rgba(0,0,0,0.2), inset 0 1px 0 rgba(255,255,255,0.04)`,
      }}
    >
      {/* Ambient glow */}
      <div style={{
        position: 'absolute', top: -30, right: -30,
        width: 100, height: 100, borderRadius: '50%',
        background: `radial-gradient(circle, ${color}18, transparent 70%)`,
        pointerEvents: 'none',
      }} />

      {Icon && (
        <Icon style={{ width: 18, height: 18, margin: '0 auto 8px', color, display: 'block' }} />
      )}

      <div style={{
        fontSize: 'clamp(1.5rem, 3vw, 2rem)', fontWeight: 800,
        color, letterSpacing: '-0.03em', lineHeight: 1,
      }}>
        {prefix}{typeof value === 'number' ? displayed : value}{suffix}
      </div>

      <div style={{
        fontSize: 11.5, color: '#8E8E93', marginTop: 6,
        fontWeight: 500, letterSpacing: '0.01em',
      }}>
        {label}
      </div>
    </motion.div>
  );
}
