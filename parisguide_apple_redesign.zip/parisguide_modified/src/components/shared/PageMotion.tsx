'use client';
import { motion, HTMLMotionProps } from 'framer-motion';
import React from 'react';

interface PageMotionProps extends HTMLMotionProps<'div'> {
  children: React.ReactNode;
  style?: React.CSSProperties;
}

export default function PageMotion({ children, style, ...props }: PageMotionProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -6 }}
      transition={{ duration: 0.32, ease: [0.22, 1, 0.36, 1] }}
      style={style}
      {...props}
    >
      {children}
    </motion.div>
  );
}

export function FadeIn({
  children, delay = 0, style,
}: { children: React.ReactNode; delay?: number; style?: React.CSSProperties }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 14 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4, delay, ease: [0.22, 1, 0.36, 1] }}
      style={style}
    >
      {children}
    </motion.div>
  );
}

export function SlideUp({
  children, delay = 0, style,
}: { children: React.ReactNode; delay?: number; style?: React.CSSProperties }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 24 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.45, delay, type: 'spring', stiffness: 280, damping: 24 }}
      style={style}
    >
      {children}
    </motion.div>
  );
}

export function ScaleIn({
  children, delay = 0,
}: { children: React.ReactNode; delay?: number }) {
  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.9 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ duration: 0.35, delay, type: 'spring', stiffness: 320, damping: 26 }}
    >
      {children}
    </motion.div>
  );
}
