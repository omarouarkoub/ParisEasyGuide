'use client';
import { useState } from 'react';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import {
  Languages, Wallet, Map, MessageCircle, Compass, Trophy, Menu, X,
  Train, Plane, Building2, Home, MapPin, CreditCard, Heart, Briefcase,
  GraduationCap, Scale, Sun, Leaf, CheckSquare, Music, User, Settings,
  CloudRain, Sunrise, Headphones, Lock,
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { useLanguage, LANGUAGES, translations } from '@/lib/i18n/LanguageContext';

const GOLD   = '#FFD700';
const NAVY   = '#002654';
const RED    = '#ED2939';
const tr = translations;

const NAV_GROUPS_DEF = [
  {
    labelKey: 'core' as const,
    items: [
      { path: '/dashboard',     icon: Compass,       labelKey: 'dashboard'     as const, color: '#FFD700', emoji: '🧭' },
      { path: '/onboarding',    icon: User,          labelKey: 'profile'       as const, color: '#4A90D9', emoji: '🤖' },
      { path: '/chat',          icon: MessageCircle, labelKey: 'chat'          as const, color: '#5E5CE6', emoji: '💬' },
      { path: '/translate',     icon: Languages,     labelKey: 'translate'     as const, color: '#30D158', emoji: '🌐' },
      { path: '/itinerary',     icon: Map,           labelKey: 'itinerary'     as const, color: '#FF9F0A', emoji: '🗺️' },
      { path: '/explore',       icon: Compass,       labelKey: 'explore'       as const, color: '#64D2FF', emoji: '📍' },
      { path: '/checklist',     icon: CheckSquare,   labelKey: 'checklist'     as const, color: '#FFD700', emoji: '✅' },
    ],
  },
  {
    labelKey: 'settling' as const,
    items: [
      { path: '/arrival',       icon: Plane,         labelKey: 'arrival'       as const, color: '#002654', emoji: '✈️' },
      { path: '/navigo',        icon: CreditCard,    labelKey: 'navigo'        as const, color: '#0A84FF', emoji: '🚇' },
      { path: '/commute',       icon: Train,         labelKey: 'commute'       as const, color: '#5E5CE6', emoji: '🚆' },
      { path: '/admin',         icon: Building2,     labelKey: 'admin'         as const, color: '#30D158', emoji: '🏛️' },
      { path: '/housing',       icon: Home,          labelKey: 'housing'       as const, color: '#34C759', emoji: '🏠' },
      { path: '/banking',       icon: CreditCard,    labelKey: 'banking'       as const, color: '#4A90D9', emoji: '💳' },
    ],
  },
  {
    labelKey: 'life' as const,
    items: [
      { path: '/healthcare',    icon: Heart,         labelKey: 'healthcare'    as const, color: '#ED2939', emoji: '❤️‍🩹' },
      { path: '/work',          icon: Briefcase,     labelKey: 'work'          as const, color: '#BF5AF2', emoji: '💼' },
      { path: '/education',     icon: GraduationCap, labelKey: 'education'     as const, color: '#0A84FF', emoji: '🎓' },
      { path: '/culture',       icon: Music,         labelKey: 'culture'       as const, color: '#FF9F0A', emoji: '🎭' },
      { path: '/sustainability', icon: Leaf,          labelKey: 'sustainability' as const, color: '#30D158', emoji: '🌿' },
      { path: '/pets',          icon: Home,          labelKey: 'pets'          as const, color: '#FF9F0A', emoji: '🐾' },
    ],
  },
  {
    labelKey: 'discover' as const,
    items: [
      { path: '/neighborhoods', icon: MapPin,        labelKey: 'neighborhoods' as const, color: '#FFD700', emoji: '🏘️' },
      { path: '/budget',        icon: Wallet,        labelKey: 'budget'        as const, color: '#30D158', emoji: '💶' },
      { path: '/seasonal',      icon: Sun,           labelKey: 'seasonal'      as const, color: '#FFD700', emoji: '🌸' },
      { path: '/legal',         icon: Scale,         labelKey: 'legal'         as const, color: '#ED2939', emoji: '⚖️' },
      { path: '/quest',         icon: Trophy,        labelKey: 'quest'         as const, color: '#FF9F0A', emoji: '🏆' },
      { path: '/settings',      icon: Settings,      labelKey: 'settings'      as const, color: '#8E8E93', emoji: '⚙️' },
    ],
  },
  {
    labelKey: 'parisPlus' as const,
    items: [
      { path: '/fromage-passport',   icon: Trophy,        labelKey: 'fromagePassport' as const, color: '#FFD700', emoji: '🧀' },
      { path: '/window-light',       icon: Sun,           labelKey: 'windowLight'     as const, color: '#FFD700', emoji: '🌅' },
      { path: '/pigeon-translator',  icon: MessageCircle, labelKey: 'pigeonTranslate' as const, color: '#BF5AF2', emoji: '🐦' },
      { path: '/gentrification-map', icon: MapPin,        labelKey: 'gentrifyMap'     as const, color: '#ED2939', emoji: '🏙️' },
      { path: '/street-musicians',   icon: Music,         labelKey: 'streetMusicians' as const, color: '#30D158', emoji: '🎵' },
      { path: '/rainy-day',          icon: CloudRain,     labelKey: 'rainyDay'        as const, color: '#64D2FF', emoji: '🌧️' },
      { path: '/secret-paris',       icon: Lock,          labelKey: 'secretParis'     as const, color: '#FFD700', emoji: '🗝️' },
      { path: '/morning-ritual',     icon: Sunrise,       labelKey: 'morningRitual'   as const, color: '#FF9F0A', emoji: '☀️' },
      { path: '/soundscape',         icon: Headphones,    labelKey: 'soundscape'      as const, color: '#64D2FF', emoji: '🎧' },
      { path: '/famous-graves',      icon: Trophy,        labelKey: 'famousGraves'    as const, color: '#8E8E93', emoji: '🪦' },
    ],
  },
];

const MOBILE_PATHS = ['/dashboard', '/chat', '/arrival', '/checklist', '/quest', '/settings'];

/* ─── Language Picker ─────────────────────────────────────────────────────── */
function LanguagePicker() {
  const { lang, setLang } = useLanguage();
  const [open, setOpen] = useState(false);
  const current = LANGUAGES.find(l => l.code === lang)!;

  return (
    <div style={{ position: 'relative' }}>
      <button
        onClick={() => setOpen(o => !o)}
        aria-label="Select language"
        style={{
          display: 'flex', alignItems: 'center', gap: 8,
          width: '100%', padding: '9px 12px', borderRadius: 12,
          background: 'rgba(255,255,255,0.05)',
          border: '1px solid rgba(255,255,255,0.09)',
          cursor: 'pointer', color: '#8E8E93', fontSize: 12, fontWeight: 600,
          transition: 'background 0.15s',
        }}
      >
        <span style={{ fontSize: 16 }}>{current.flag}</span>
        <span style={{ color: '#F5F5F7' }}>{current.native}</span>
        <span style={{ marginLeft: 'auto', opacity: 0.4, fontSize: 10 }}>{open ? '▲' : '▼'}</span>
      </button>

      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ opacity: 0, y: 6, scale: 0.97 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 6, scale: 0.97 }}
            transition={{ type: 'spring', stiffness: 400, damping: 30 }}
            style={{
              position: 'absolute', bottom: 'calc(100% + 8px)', left: 0, right: 0,
              background: 'rgba(21,26,35,0.98)', backdropFilter: 'blur(32px)',
              border: '1px solid rgba(255,255,255,0.1)',
              borderRadius: 16, overflow: 'hidden', zIndex: 50,
              boxShadow: '0 -16px 48px rgba(0,0,0,0.6)',
            }}
          >
            {LANGUAGES.map(l => (
              <button key={l.code} onClick={() => { setLang(l.code); setOpen(false); }}
                style={{
                  display: 'flex', alignItems: 'center', gap: 10,
                  width: '100%', padding: '10px 14px',
                  background: l.code === lang ? 'rgba(255,215,0,0.08)' : 'transparent',
                  border: 'none', borderBottom: '1px solid rgba(255,255,255,0.04)',
                  cursor: 'pointer', color: l.code === lang ? '#F5F5F7' : '#8E8E93',
                  fontSize: 13, fontWeight: l.code === lang ? 700 : 500,
                  transition: 'background 0.1s',
                }}>
                <span style={{ fontSize: 18 }}>{l.flag}</span>
                <span>{l.native}</span>
                {l.code === lang && (
                  <span style={{ marginLeft: 'auto', color: GOLD, fontSize: 13, fontWeight: 700 }}>✓</span>
                )}
              </button>
            ))}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

function MobileLangRow() {
  const { lang, setLang } = useLanguage();
  return (
    <div style={{
      padding: '10px 12px',
      borderTop: '1px solid rgba(255,255,255,0.06)',
      display: 'flex', gap: 6, flexWrap: 'wrap',
    }}>
      {LANGUAGES.map(l => (
        <button key={l.code} onClick={() => setLang(l.code)}
          style={{
            padding: '5px 10px', borderRadius: 20, cursor: 'pointer', fontSize: 12,
            background: l.code === lang ? 'rgba(255,215,0,0.12)' : 'rgba(255,255,255,0.05)',
            border: `1px solid ${l.code === lang ? 'rgba(255,215,0,0.4)' : 'rgba(255,255,255,0.08)'}`,
            color: l.code === lang ? GOLD : '#8E8E93', fontWeight: l.code === lang ? 700 : 500,
            transition: 'all 0.15s',
          }}>
          {l.flag} {l.native}
        </button>
      ))}
    </div>
  );
}

/* ─── Logo Mark ───────────────────────────────────────────────────────────── */
function LogoMark() {
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
      {/* Tricolor pill */}
      <div style={{
        width: 34, height: 34, borderRadius: 10, overflow: 'hidden',
        display: 'flex', flexShrink: 0,
        border: '1px solid rgba(255,215,0,0.3)',
        boxShadow: '0 0 20px rgba(0,38,84,0.5), inset 0 1px 0 rgba(255,255,255,0.08)',
      }}>
        <div style={{ flex: 1, background: '#002395' }} />
        <div style={{ flex: 1, background: '#EBEBEB' }} />
        <div style={{ flex: 1, background: '#ED2939' }} />
      </div>
      <div>
        <p style={{
          fontFamily: 'Playfair Display, serif',
          fontWeight: 700, fontSize: 13.5,
          background: 'linear-gradient(135deg, #FFD700, #FFD700)',
          WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent',
          backgroundClip: 'text', lineHeight: 1.1, letterSpacing: '-0.01em',
        }}>
          ParisEasyGuide+
        </p>
        <p style={{ fontSize: 10, color: '#3A3A3C', marginTop: 2, letterSpacing: '0.02em' }}>
          Votre compagnon IA
        </p>
      </div>
    </div>
  );
}

/* ─── AppShell ─────────────────────────────────────────────────────────────── */
export default function AppShell({ children }: { children: React.ReactNode }) {
  const pathname = usePathname();
  const [mobileOpen, setMobileOpen] = useState(false);
  const { t } = useLanguage();

  const NAV_GROUPS = NAV_GROUPS_DEF.map(group => ({
    label: t(tr.nav.groups[group.labelKey]),
    items: group.items.map(item => ({ ...item, label: t(tr.nav.items[item.labelKey]) })),
  }));

  const ALL_NAV   = NAV_GROUPS.flatMap(g => g.items);
  const MOBILE_NAV = MOBILE_PATHS.map(p => ALL_NAV.find(n => n.path === p)!).filter(Boolean);

  const isActive = (path: string) => pathname === path || pathname.startsWith(path + '/');

  const groupColors: Record<string, string> = {
    Core: GOLD, 'Settling In': '#4A90D9', 'Life in Paris': '#ED2939',
    'Discover': '#FF9F0A', 'Paris+ Secrets': '#BF5AF2',
    // French labels too
    'Essentiel': GOLD, 'S\'installer': '#4A90D9',
  };

  return (
    <div style={{ minHeight: '100vh', display: 'flex' }}>

      {/* ── Desktop sidebar ─────────────────────────────────────────────── */}
      <aside className="md-sidebar" style={{ display: 'none' }}>
        <style>{`
          @media(min-width:768px){
            .md-sidebar {
              display: flex !important;
              flex-direction: column;
              width: 248px;
              border-right: 1px solid rgba(255,255,255,0.06);
              position: fixed; top: 0; bottom: 0; left: 0; z-index: 30;
              background: rgba(11,14,20,0.96);
              backdrop-filter: blur(40px) saturate(1.4);
              -webkit-backdrop-filter: blur(40px) saturate(1.4);
            }
          }
        `}</style>

        {/* Logo */}
        <Link href="/" style={{
          display: 'flex', alignItems: 'center', padding: '18px 18px 14px',
          borderBottom: '1px solid rgba(255,255,255,0.05)', textDecoration: 'none',
        }}>
          <LogoMark />
        </Link>

        {/* Nav */}
        <nav style={{
          flex: 1, padding: '10px 10px', overflowY: 'auto',
          display: 'flex', flexDirection: 'column', gap: 2,
        }}>
          {NAV_GROUPS.map(group => (
            <div key={group.label} style={{ marginBottom: 4 }}>
              {/* Section label */}
              <div style={{
                fontSize: 9.5, fontWeight: 700,
                color: groupColors[group.label] || '#3A3A3C',
                textTransform: 'uppercase', letterSpacing: '0.1em',
                padding: '10px 10px 5px',
                opacity: groupColors[group.label] ? 0.7 : 1,
              }}>
                {group.label}
              </div>

              {group.items.map(item => {
                const active = isActive(item.path);
                return (
                  <Link key={item.path} href={item.path} style={{ textDecoration: 'none', display: 'block' }}>
                    <motion.div
                      whileHover={{ backgroundColor: active ? undefined : 'rgba(255,255,255,0.04)', x: active ? 0 : 1 }}
                      whileTap={{ scale: 0.98 }}
                      style={{
                        display: 'flex', alignItems: 'center', gap: 10,
                        padding: '8px 10px', borderRadius: 12, marginBottom: 1,
                        background: active ? `${item.color}14` : 'transparent',
                        border: `1px solid ${active ? item.color + '30' : 'transparent'}`,
                        position: 'relative', overflow: 'hidden',
                        transition: 'background 0.15s, border-color 0.15s',
                      }}>
                      {/* Active shimmer strip */}
                      {active && (
                        <div style={{
                          position: 'absolute', left: 0, top: 0, bottom: 0, width: 2.5,
                          background: item.color, borderRadius: '2px 0 0 2px',
                        }} />
                      )}
                      <span style={{ fontSize: 15, marginLeft: active ? 4 : 0, transition: 'margin 0.15s' }}>
                        {item.emoji}
                      </span>
                      <span style={{
                        fontSize: 13, fontWeight: active ? 600 : 400,
                        color: active ? '#F5F5F7' : '#8E8E93',
                        flex: 1, transition: 'color 0.15s',
                      }}>
                        {item.label}
                      </span>
                      {active && (
                        <div style={{
                          width: 5, height: 5, borderRadius: '50%',
                          background: item.color, flexShrink: 0,
                          boxShadow: `0 0 6px ${item.color}`,
                        }} />
                      )}
                    </motion.div>
                  </Link>
                );
              })}
            </div>
          ))}
        </nav>

        {/* Language & Footer */}
        <div style={{ padding: '10px', borderTop: '1px solid rgba(255,255,255,0.05)' }}>
          <div style={{
            fontSize: 9.5, fontWeight: 700, color: '#3A3A3C',
            textTransform: 'uppercase', letterSpacing: '0.1em', marginBottom: 8, paddingLeft: 4,
          }}>
            {t(tr.shell.language)}
          </div>
          <LanguagePicker />
        </div>
        <div style={{
          padding: '8px 16px 14px', fontSize: 10,
          color: '#3A3A3C', lineHeight: 1.5,
        }}>
          {t(tr.shell.rgpd)}
        </div>
      </aside>

      {/* ── Mobile header ───────────────────────────────────────────────── */}
      <div className="mobile-header" style={{ display: 'none' }}>
        <style>{`
          .mobile-header {
            display: flex !important;
            position: fixed; top: 0; left: 0; right: 0; z-index: 30;
            height: 54px; align-items: center; justify-content: space-between;
            padding: 0 16px;
            background: rgba(11,14,20,0.92);
            backdrop-filter: blur(28px) saturate(1.5);
            -webkit-backdrop-filter: blur(28px) saturate(1.5);
            border-bottom: 1px solid rgba(255,255,255,0.06);
          }
          @media(min-width:768px) { .mobile-header { display: none !important; } }
        `}</style>
        <Link href="/"><LogoMark /></Link>
        <motion.button
          whileTap={{ scale: 0.92 }}
          onClick={() => setMobileOpen(!mobileOpen)}
          aria-label="Toggle navigation"
          style={{
            background: 'rgba(255,255,255,0.06)', border: '1px solid rgba(255,255,255,0.08)',
            borderRadius: 10, cursor: 'pointer', color: '#8E8E93',
            width: 36, height: 36, display: 'flex', alignItems: 'center', justifyContent: 'center',
          }}>
          {mobileOpen
            ? <X style={{ width: 18, height: 18 }} />
            : <Menu style={{ width: 18, height: 18 }} />}
        </motion.button>
      </div>

      {/* ── Mobile drawer ───────────────────────────────────────────────── */}
      <AnimatePresence>
        {mobileOpen && (
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            transition={{ type: 'spring', stiffness: 380, damping: 32 }}
            className="mobile-drawer" style={{ display: 'none' }}
          >
            <style>{`
              .mobile-drawer {
                display: block !important;
                position: fixed; top: 54px; left: 0; right: 0; z-index: 20;
                background: rgba(11,14,20,0.98);
                backdrop-filter: blur(32px);
                -webkit-backdrop-filter: blur(32px);
                border-bottom: 1px solid rgba(255,255,255,0.06);
                max-height: 72vh; overflow-y: auto;
              }
              @media(min-width:768px) { .mobile-drawer { display: none !important; } }
            `}</style>

            <div style={{ padding: '10px 12px' }}>
              {NAV_GROUPS.map(group => (
                <div key={group.label} style={{ marginBottom: '0.75rem' }}>
                  <div style={{
                    fontSize: 9.5, fontWeight: 700,
                    color: groupColors[group.label] || '#3A3A3C',
                    textTransform: 'uppercase', letterSpacing: '0.1em',
                    padding: '6px 8px 6px', opacity: 0.7,
                  }}>
                    {group.label}
                  </div>
                  <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 5 }}>
                    {group.items.map(item => (
                      <Link key={item.path} href={item.path}
                        onClick={() => setMobileOpen(false)}
                        style={{ textDecoration: 'none' }}>
                        <motion.div whileTap={{ scale: 0.96 }} style={{
                          display: 'flex', alignItems: 'center', gap: 8,
                          padding: '9px 11px', borderRadius: 12,
                          background: isActive(item.path) ? `${item.color}14` : 'rgba(255,255,255,0.04)',
                          border: `1px solid ${isActive(item.path) ? item.color + '35' : 'rgba(255,255,255,0.07)'}`,
                        }}>
                          <span style={{ fontSize: 16 }}>{item.emoji}</span>
                          <span style={{
                            fontSize: 12, fontWeight: 600,
                            color: isActive(item.path) ? '#F5F5F7' : '#8E8E93',
                          }}>
                            {item.label}
                          </span>
                        </motion.div>
                      </Link>
                    ))}
                  </div>
                </div>
              ))}
            </div>
            <MobileLangRow />
          </motion.div>
        )}
      </AnimatePresence>

      {/* ── Main content ─────────────────────────────────────────────────── */}
      <main className="main-content" style={{ flex: 1, minHeight: '100vh' }}>
        <style>{`
          .main-content { padding-top: 54px !important; padding-bottom: 70px; }
          @media(min-width:768px) {
            .main-content { margin-left: 248px !important; padding-top: 0 !important; padding-bottom: 0 !important; }
          }
        `}</style>
        {children}
      </main>

      {/* ── Mobile bottom tab bar ────────────────────────────────────────── */}
      <nav className="mobile-bottom" style={{ display: 'none' }}>
        <style>{`
          .mobile-bottom {
            display: flex !important;
            position: fixed; bottom: 0; left: 0; right: 0; z-index: 30;
            justify-content: space-around;
            padding: 8px 4px calc(8px + env(safe-area-inset-bottom));
            background: rgba(11,14,20,0.94);
            backdrop-filter: blur(28px) saturate(1.5);
            -webkit-backdrop-filter: blur(28px) saturate(1.5);
            border-top: 1px solid rgba(255,255,255,0.06);
          }
          @media(min-width:768px) { .mobile-bottom { display: none !important; } }
        `}</style>
        {MOBILE_NAV.map(item => {
          const active = isActive(item.path);
          return (
            <Link key={item.path} href={item.path} style={{ textDecoration: 'none', flex: 1 }}>
              <motion.div
                whileTap={{ scale: 0.88 }}
                style={{
                  display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 3,
                  padding: '4px 6px', position: 'relative',
                }}>
                {/* Active pill background */}
                {active && (
                  <motion.div
                    layoutId="mobile-tab-active"
                    style={{
                      position: 'absolute', inset: '0 8px',
                      background: 'rgba(255,215,0,0.10)',
                      borderRadius: 10,
                    }}
                  />
                )}
                <span style={{ fontSize: 20, position: 'relative' }}>{item.emoji}</span>
                <span style={{
                  fontSize: 9.5, fontWeight: 700, position: 'relative',
                  color: active ? GOLD : '#3A3A3C',
                  transition: 'color 0.2s',
                }}>
                  {item.label.split(' ')[0]}
                </span>
              </motion.div>
            </Link>
          );
        })}
      </nav>

      {/* ── Marcel FAB ──────────────────────────────────────────────────── */}
      <MarcelFAB />
    </div>
  );
}

function MarcelFAB() {
  const [hover, setHover] = useState(false);
  return (
    <Link href="/chat" style={{ textDecoration: 'none' }}>
      <motion.div
        onHoverStart={() => setHover(true)}
        onHoverEnd={() => setHover(false)}
        whileTap={{ scale: 0.92 }}
        whileHover={{ scale: 1.06 }}
        className="marcel-fab"
        style={{ display: 'none' }}
        aria-label="Chat with Marcel AI"
      >
        <style>{`
          .marcel-fab {
            display: none !important;
          }
          @media(min-width:768px) {
            .marcel-fab {
              display: flex !important;
              position: fixed; bottom: 28px; right: 28px; z-index: 40;
              width: 56px; height: 56px; border-radius: 50%;
              align-items: center; justify-content: center;
              background: linear-gradient(135deg, #002654 0%, #004082 100%);
              border: 1.5px solid rgba(255,215,0,0.4);
              box-shadow: 0 8px 32px rgba(0,0,0,0.5), 0 0 0 0 rgba(255,215,0,0);
              cursor: pointer;
            }
          }
        `}</style>
        <span style={{ fontSize: 26 }}>🧑‍🎨</span>
        <AnimatePresence>
          {hover && (
            <motion.div
              initial={{ opacity: 0, x: 10, scale: 0.95 }}
              animate={{ opacity: 1, x: 0, scale: 1 }}
              exit={{ opacity: 0, x: 10, scale: 0.95 }}
              transition={{ type: 'spring', stiffness: 400, damping: 28 }}
              style={{
                position: 'absolute', right: '68px', bottom: 0,
                background: 'rgba(21,26,35,0.97)', backdropFilter: 'blur(20px)',
                border: '1px solid rgba(255,215,0,0.2)',
                borderRadius: 12, padding: '8px 14px',
                whiteSpace: 'nowrap', color: '#F5F5F7', fontSize: 13, fontWeight: 600,
                boxShadow: '0 8px 28px rgba(0,0,0,0.4)',
              }}>
              <span style={{ color: GOLD }}>Marcel</span> — Ask me anything
            </motion.div>
          )}
        </AnimatePresence>
      </motion.div>
    </Link>
  );
}
