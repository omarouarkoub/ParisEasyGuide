import type { Config } from 'tailwindcss';

const config: Config = {
  content: ['./src/**/*.{js,ts,jsx,tsx,mdx}'],
  theme: {
    extend: {
      colors: {
        background: '#0B0E14',
        foreground: '#F5F5F7',
        'paris-gold':  '#FFD700',
        'paris-navy':  '#002654',
        'paris-red':   '#ED2939',
        'glass-bg':    'rgba(21,26,35,0.80)',
        primary: {
          DEFAULT: '#002654',
          foreground: '#FFFFFF',
        },
        muted: {
          DEFAULT: '#151A23',
          foreground: '#8E8E93',
        },
        border: 'rgba(255,255,255,0.08)',
      },
      fontFamily: {
        display: ['Playfair Display', 'Georgia', 'serif'],
        sans: ['Inter', '-apple-system', 'BlinkMacSystemFont', 'Helvetica Neue', 'sans-serif'],
      },
      borderRadius: {
        'apple-sm': '10px',
        'apple-md': '14px',
        'apple-lg': '20px',
        'apple-xl': '28px',
      },
      backdropBlur: {
        'apple': '24px',
        'heavy': '40px',
      },
      boxShadow: {
        'glass': '0 4px 32px rgba(0,0,0,0.35), inset 0 1px 0 rgba(255,255,255,0.04)',
        'gold-glow': '0 0 20px rgba(255,215,0,0.25)',
        'navy-glow': '0 0 20px rgba(0,38,84,0.5)',
      },
      animation: {
        'pulse-slow': 'pulse 3s ease-in-out infinite',
        'shimmer': 'shimmer 2.4s ease-in-out infinite',
        'stamp': 'stamp 0.45s cubic-bezier(0.22, 1, 0.36, 1) forwards',
        'xp-float': 'xpFloat 1.2s ease-out forwards',
        'marcel-dot': 'marceldot 1.2s ease-in-out infinite',
      },
    },
  },
  plugins: [],
};

export default config;
